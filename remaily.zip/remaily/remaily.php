<?php

/**
 * Plugin Name: Re:Maily – Contact Form Builder with Conditional Fields & Entries
 * Plugin URI: https://wordpress.org/plugins/remaily/
 * Description: Contact forms written in plain HTML, with fields you drag in, conditions, stored entries and templates your theme can restyle.
 * Version: 1.0.0
 * Author: VLThemes
 * Author URI: https://vlthemes.me/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: remaily
 * Requires at least: 6.6
 * Requires PHP: 7.4
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/src/Autoloader.php';

VLT\Remaily\Autoloader::register( __DIR__ . '/src' );
VLT\Remaily\Plugin::boot( __FILE__ );
