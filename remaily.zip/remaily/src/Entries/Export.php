<?php

namespace VLT\Remaily\Entries;

use VLT\Remaily\Core\PostType;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Entries as a CSV file: one row per entry, a column per field name, of one form or all
 */
class Export {
	const ACTION = 'remaily_export_entries';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'download' ] );
	}

	/**
	 * Address of the download
	 *
	 * @param int $form_id Form ID (0 = all)
	 *
	 * @return string
	 */
	public static function url( $form_id = 0 ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . self::ACTION . ( $form_id ? '&form=' . (int) $form_id : '' ) ), self::ACTION );
	}

	/**
	 * Send the file
	 */
	public static function download() {
		check_admin_referer( self::ACTION );

		if ( !current_user_can( 'edit_pages' ) ) {
			wp_die( esc_html__( 'You can\'t export entries.', 'remaily' ) );
		}

		$form_id = absint( $_GET['form'] ?? 0 );
		$posts   = get_posts( [
			'post_type'      => Entries::POST_TYPE,
			'post_status'    => 'publish',
			'post_parent'    => $form_id ?: '',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		] );

		$rows  = [];
		$names = [];

		foreach ( $posts as $post ) {
			$data = Entries::data( $post->ID );
			$meta = Entries::meta( $post->ID );
			$row  = [];

			foreach ( $data as $name => $item ) {
				$names[ $name ] = true;
				$row[ $name ]   = $item['value'];
			}

			$rows[] = [
				'date'   => get_the_date( 'Y-m-d H:i', $post ),
				'form'   => PostType::NAME === get_post_type( $post->post_parent ) ? get_the_title( $post->post_parent ) : '',
				'values' => $row,
				'page'   => $meta['url'],
				'ip'     => $meta['ip'],
			];
		}

		$names    = array_keys( $names );
		$filename = sanitize_file_name( 'remaily-entries-' . ( $form_id ? $form_id . '-' : '' ) . gmdate( 'Y-m-d' ) . '.csv' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streamed download

		// A BOM, so spreadsheets read the file as UTF-8
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $out, array_merge( [ __( 'Date', 'remaily' ), __( 'Form', 'remaily' ) ], $names, [ __( 'Page', 'remaily' ), __( 'IP address', 'remaily' ) ] ) );

		foreach ( $rows as $row ) {
			$values = array_map( static fn( $name ) => $row['values'][ $name ] ?? '', $names );

			fputcsv( $out, array_map( [ __CLASS__, 'cell' ], array_merge( [ $row['date'], $row['form'] ], $values, [ $row['page'], $row['ip'] ] ) ) );
		}

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/**
	 * A cell a spreadsheet won't run as a formula
	 *
	 * @param string $value Value
	 *
	 * @return string
	 */
	private static function cell( $value ) {
		$value = (string) $value;

		return '' !== $value && in_array( $value[0], [ '=', '+', '-', '@', "\t", "\r" ], true ) ? "'" . $value : $value;
	}
}
