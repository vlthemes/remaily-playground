<?php

namespace VLT\Remaily\Core;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The form post type: the template in post_content, the rest in _remaily_config
 */
class PostType {
	const NAME = 'remaily_form';

	/**
	 * Register
	 */
	public static function register() {
		register_post_type( self::NAME, [
			'labels'          => [
				'name'               => __( 'Contact Forms', 'remaily' ),
				'singular_name'      => __( 'Contact Form', 'remaily' ),
				'add_new'            => __( 'Add New Form', 'remaily' ),
				'add_new_item'       => __( 'Add New Form', 'remaily' ),
				'edit_item'          => __( 'Edit Form', 'remaily' ),
				'search_items'       => __( 'Search Forms', 'remaily' ),
				'not_found'          => __( 'No forms yet. Add one and it starts with name, email, subject and message fields.', 'remaily' ),
				'not_found_in_trash' => __( 'No forms in the trash.', 'remaily' ),
			],
			'public'          => false,
			// WordPress's list screen; the Contact Form menu links to it and editing opens Remaily's editor (Admin)
			'show_ui'         => true,
			'show_in_menu'    => false,
			'show_in_rest'    => false,
			'rewrite'         => false,
			'query_var'       => false,
			'can_export'      => true,
			'capability_type' => 'page',
			'map_meta_cap'    => true,
			'supports'        => [ 'title', 'editor', 'revisions' ],
		] );
	}
}
