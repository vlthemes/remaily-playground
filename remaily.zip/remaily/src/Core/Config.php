<?php

namespace VLT\Remaily\Core;

use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Template;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's settings (_remaily_config): fields, groups, mails, messages, settings
 *
 * Read through get(): upgraded, merged with the defaults. Saved through save(): sanitized.
 */
class Config {
	const META = '_remaily_config';

	const VERSION = 1;

	const OPERATORS = [ 'is', 'is_not', 'contains', 'not_contains', 'empty', 'not_empty', 'gt', 'lt' ];

	/**
	 * Defaults of a form
	 *
	 * @return array
	 */
	public static function defaults() {
		$defaults = [
			'version'  => self::VERSION,
			'fields'   => [],
			'groups'   => [],
			'mail'     => self::mail_defaults(),
			'mail_2'   => [ 'active' => false ] + self::mail_defaults(),
			'messages' => [],
			'settings' => [
				'style'            => 'default',
				'store_entries'    => true,
				'redirect'         => '',
				'class'            => '',
				// Browser autofill of the fields
				'autocomplete'     => true,
				// Fields are checked, nothing is sent or saved, the visitor sees "sent"
				'demo'             => false,
				// No mail; the entry is still saved
				'skip_mail'        => false,
				// Shown and accepted for logged-in users only
				'subscribers_only' => false,
				// Skip the captchas Settings → Spam turns on for every form (Spam\Captcha)
				'captcha_off'      => false,
				// Addresses each message is posted to as JSON (Integrations\Webhooks)
				'webhooks'         => [],
				// Brevo lists the sender joins, which field is the email (first Email field), the consent box,
				// attributes as lines of NAME = mail tags, the welcome template for new contacts, and double opt-in:
				// the email with [confirm_link] and the page after confirming (Integrations\Brevo)
				'brevo_lists'        => [],
				'brevo_email'        => '',
				'brevo_consent'      => '',
				'brevo_attributes'   => '',
				'brevo_template'     => 0,
				'brevo_doi'          => false,
				'brevo_doi_subject'  => __( 'Please confirm your email for [_site_title]', 'remaily' ),
				'brevo_doi_body'     => __( "Hello,\n\nPlease confirm that you want to get emails from [_site_title]:\n\n[confirm_link]\n\nIf you didn't ask for this, ignore this email and you won't hear from us.", 'remaily' ),
				'brevo_doi_redirect' => '',
			],
		];

		return (array) apply_filters( 'remaily_config_defaults', $defaults );
	}

	/**
	 * Defaults of one mail
	 *
	 * @return array
	 */
	public static function mail_defaults() {
		return [
			'to'          => '[_site_admin_email]',
			'from'        => '[_site_title] <' . self::from_address() . '>',
			'subject'     => '[_site_title]',
			'headers'     => '',
			'body'        => '',
			'html'        => true,
			'attachments' => '',
		];
	}

	/**
	 * An address on the site's own domain, the one mail servers accept as sender
	 *
	 * @return string
	 */
	public static function from_address() {
		$host = (string) wp_parse_url( network_home_url(), PHP_URL_HOST );
		$host = preg_replace( '/^www\./', '', $host );

		return 'wordpress@' . ( $host ?: 'localhost' );
	}

	/**
	 * A form's settings, upgraded and merged with the defaults
	 *
	 * @param int $post_id Form ID
	 *
	 * @return array
	 */
	public static function get( $post_id ) {
		$stored = json_decode( (string) get_post_meta( $post_id, self::META, true ), true );

		return self::merge( self::defaults(), self::upgrade( is_array( $stored ) ? $stored : [] ) );
	}

	/**
	 * Save a form's settings
	 *
	 * @param int   $post_id Form ID
	 * @param array $config  Settings
	 */
	public static function save( $post_id, array $config ) {
		// Webhooks send visitors' messages to other servers: only those who manage the site set them
		if ( !current_user_can( 'manage_options' ) ) {
			$config['settings']['webhooks'] = self::get( $post_id )['settings']['webhooks'];
		}

		update_post_meta( $post_id, self::META, wp_slash( wp_json_encode( self::sanitize( $config ) ) ) );
	}

	/**
	 * Run the upgrade steps a stored config hasn't had
	 *
	 * @param array $config Stored settings
	 *
	 * @return array
	 */
	public static function upgrade( array $config ) {
		$version = (int) ( $config['version'] ?? self::VERSION );

		foreach ( (array) apply_filters( 'remaily_config_upgrades', [] ) as $step_version => $step ) {
			if ( $step_version > $version && is_callable( $step ) ) {
				$config = (array) $step( $config );
			}
		}

		$config['version'] = self::VERSION;

		return $config;
	}

	/**
	 * Keyed arrays merged, lists replaced
	 *
	 * @param array $defaults Defaults
	 * @param array $config   Values
	 *
	 * @return array
	 */
	public static function merge( array $defaults, array $config ) {
		foreach ( $config as $key => $value ) {
			if ( is_array( $value ) && isset( $defaults[ $key ] ) && is_array( $defaults[ $key ] ) && $defaults[ $key ] && !wp_is_numeric_array( $defaults[ $key ] ) ) {
				$defaults[ $key ] = self::merge( $defaults[ $key ], $value );
			} else {
				$defaults[ $key ] = $value;
			}
		}

		return $defaults;
	}

	/**
	 * Clean settings from the editor
	 *
	 * @param array $config Settings
	 *
	 * @return array
	 */
	public static function sanitize( array $config ) {
		$config = self::merge( self::defaults(), $config );
		$clean  = [ 'version' => self::VERSION ];

		$clean['fields'] = [];

		foreach ( (array) $config['fields'] as $name => $field ) {
			$name = strtolower( (string) $name );
			$type = FieldRegistry::get( (string) ( $field['type'] ?? '' ) );

			if ( $type && Template::valid_name( $name ) && is_array( $field ) ) {
				$clean['fields'][ $name ] = $type->sanitize( $field );
			}
		}

		$clean['groups'] = [];

		foreach ( (array) $config['groups'] as $name => $group ) {
			$name = strtolower( (string) $name );

			if ( Template::valid_name( $name ) && is_array( $group ) ) {
				$clean['groups'][ $name ] = self::sanitize_group( $group );
			}
		}

		$clean['mail']   = self::sanitize_mail( (array) $config['mail'] );
		$clean['mail_2'] = [ 'active' => !empty( $config['mail_2']['active'] ) ] + self::sanitize_mail( (array) $config['mail_2'] );

		$clean['messages'] = [];

		foreach ( (array) $config['messages'] as $key => $message ) {
			$message = sanitize_text_field( (string) $message );

			// The defaults aren't stored, so a changed default reaches every form that kept it
			if ( '' !== $message && Messages::default( (string) $key ) !== $message ) {
				$clean['messages'][ sanitize_key( $key ) ] = $message;
			}
		}

		$settings          = (array) $config['settings'];
		$clean['settings'] = [
			'style'            => sanitize_key( (string) $settings['style'] ) ?: 'default',
			'store_entries'    => !empty( $settings['store_entries'] ),
			'redirect'         => esc_url_raw( (string) $settings['redirect'] ),
			'class'            => implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $settings['class'], -1, PREG_SPLIT_NO_EMPTY ) ) ),
			'autocomplete'     => !empty( $settings['autocomplete'] ),
			'demo'             => !empty( $settings['demo'] ),
			'skip_mail'        => !empty( $settings['skip_mail'] ),
			'subscribers_only' => !empty( $settings['subscribers_only'] ),
			'captcha_off'      => !empty( $settings['captcha_off'] ),
			'webhooks'         => self::sanitize_urls( $settings['webhooks'] ),
			'brevo_lists'        => array_values( array_filter( array_map( 'absint', (array) $settings['brevo_lists'] ) ) ),
			'brevo_email'        => Template::valid_name( (string) $settings['brevo_email'] ) ? (string) $settings['brevo_email'] : '',
			'brevo_consent'      => Template::valid_name( (string) $settings['brevo_consent'] ) ? (string) $settings['brevo_consent'] : '',
			'brevo_attributes'   => sanitize_textarea_field( (string) $settings['brevo_attributes'] ),
			'brevo_template'     => absint( $settings['brevo_template'] ),
			'brevo_doi'          => !empty( $settings['brevo_doi'] ),
			'brevo_doi_subject'  => sanitize_text_field( (string) $settings['brevo_doi_subject'] ),
			'brevo_doi_body'     => sanitize_textarea_field( (string) $settings['brevo_doi_body'] ),
			'brevo_doi_redirect' => esc_url_raw( (string) $settings['brevo_doi_redirect'] ),
		];

		return (array) apply_filters( 'remaily_config_sanitize', $clean, $config );
	}

	/**
	 * Web addresses, one per line or a list; only http and https
	 *
	 * @param array|string $urls Addresses
	 *
	 * @return string[]
	 */
	private static function sanitize_urls( $urls ) {
		$urls = is_array( $urls ) ? $urls : preg_split( '/\s+/', (string) $urls, -1, PREG_SPLIT_NO_EMPTY );

		$clean = [];

		foreach ( $urls as $url ) {
			$url = trim( (string) $url );

			// A full http(s) address only: esc_url_raw() would make "http://words" of anything
			if ( preg_match( '~^https?://[^\s/?#]+~i', $url ) && filter_var( $url, FILTER_VALIDATE_URL ) ) {
				$clean[] = esc_url_raw( $url, [ 'http', 'https' ] );
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Clean a group's condition
	 *
	 * @param array $group Group
	 *
	 * @return array
	 */
	private static function sanitize_group( array $group ) {
		$rules = [];

		foreach ( (array) ( $group['rules'] ?? [] ) as $rule ) {
			$op    = (string) ( $rule['op'] ?? 'is' );
			$field = strtolower( (string) ( $rule['field'] ?? '' ) );

			if ( Template::valid_name( $field ) && in_array( $op, self::OPERATORS, true ) ) {
				$rules[] = [
					'field' => $field,
					'op'    => $op,
					'value' => sanitize_text_field( (string) ( $rule['value'] ?? '' ) ),
				];
			}
		}

		return [
			'action' => 'hide' === ( $group['action'] ?? '' ) ? 'hide' : 'show',
			'match'  => 'any' === ( $group['match'] ?? '' ) ? 'any' : 'all',
			'rules'  => $rules,
		];
	}

	/**
	 * Clean a mail
	 *
	 * @param array $mail Mail
	 *
	 * @return array
	 */
	private static function sanitize_mail( array $mail ) {
		$mail += self::mail_defaults();
		$body  = (string) $mail['body'];

		// Addresses keep their "Name <address>" form, so no tag stripping; they only ever go into mail headers
		$line = static fn( $text ) => trim( preg_replace( '/[\r\n\t]+/', ' ', wp_check_invalid_utf8( (string) $text ) ) );

		return [
			'to'          => $line( $mail['to'] ),
			'from'        => $line( $mail['from'] ),
			'subject'     => sanitize_text_field( (string) $mail['subject'] ),
			'headers'     => implode( "\n", array_filter( array_map( $line, preg_split( '/\R/', (string) $mail['headers'] ) ) ) ),
			'body'        => current_user_can( 'unfiltered_html' ) ? $body : wp_kses_post( $body ),
			'html'        => !empty( $mail['html'] ),
			'attachments' => sanitize_textarea_field( (string) $mail['attachments'] ),
		];
	}
}
