<?php

namespace VLT\Remaily\Core;

use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The messages a form shows: the general ones and those of its field types
 *
 * A message is the form's own (its Messages tab), else the site's (Settings → Messages), else the built-in text.
 */
class Messages {
	/**
	 * The messages every form has
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public static function general() {
		return [
			'success'   => [ 'label' => __( 'Message sent', 'remaily' ), 'default' => __( 'Thanks, your message has been sent.', 'remaily' ) ],
			'failed'    => [ 'label' => __( 'Message not sent', 'remaily' ), 'default' => __( 'Your message couldn\'t be sent. Please try again later.', 'remaily' ) ],
			'invalid'   => [ 'label' => __( 'Fields need fixing', 'remaily' ), 'default' => __( 'Some fields need a second look. Please check them and try again.', 'remaily' ) ],
			'spam'      => [ 'label' => __( 'Looks like spam', 'remaily' ), 'default' => __( 'Your message couldn\'t be sent. Please try again later.', 'remaily' ) ],
			'required'  => [ 'label' => __( 'Required field left empty', 'remaily' ), 'default' => __( 'Please fill in this field.', 'remaily' ) ],
			'too_long'  => [ 'label' => __( 'Too long', 'remaily' ), 'default' => __( 'This is longer than allowed.', 'remaily' ) ],
			'too_short' => [ 'label' => __( 'Too short', 'remaily' ), 'default' => __( 'This is shorter than needed.', 'remaily' ) ],
		];
	}

	/**
	 * Messages of the form's settings, listed while that setting is on
	 *
	 * @return array [ setting => [ key => [ 'label', 'default' ] ] ]
	 */
	public static function of_settings() {
		return [
			'subscribers_only' => [
				'login_required' => [ 'label' => __( 'Visitor not logged in', 'remaily' ), 'default' => __( 'Please log in to use this form.', 'remaily' ) ],
			],
		];
	}

	/**
	 * Every message: the general ones, then each field type's
	 *
	 * @param string[]|null $types Only these field types (null: all)
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public static function all( $types = null ) {
		static $cache = [];

		$key = null === $types ? '*' : implode( ',', $types );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$messages = self::general();

		// The settings' messages are listed for a form only while their setting is on (for_form())
		if ( null === $types ) {
			foreach ( self::of_settings() as $setting_messages ) {
				$messages += $setting_messages;
			}
		}

		foreach ( FieldRegistry::all() as $id => $type ) {
			if ( null === $types || in_array( $id, $types, true ) ) {
				$messages += $type->messages();
			}
		}

		$cache[ $key ] = (array) apply_filters( 'remaily_messages', $messages, $types );

		return $cache[ $key ];
	}

	/**
	 * The messages of a form: the general ones and those of the field types it uses
	 *
	 * @param Form $form Form
	 *
	 * @return array [ key => text ]
	 */
	public static function for_form( Form $form ) {
		$types = array_values( array_unique( wp_list_pluck( $form->fields(), 'type' ) ) );
		$saved = (array) $form->config()['messages'];
		$texts = [];

		$keys = array_keys( self::all( $types ) );

		foreach ( self::of_settings() as $setting => $setting_messages ) {
			if ( !empty( $form->config()['settings'][ $setting ] ) ) {
				$keys = array_merge( $keys, array_keys( $setting_messages ) );
			}
		}

		foreach ( $keys as $key ) {
			$texts[ $key ] = isset( $saved[ $key ] ) && '' !== $saved[ $key ] ? $saved[ $key ] : self::default( $key );
		}

		return $texts;
	}

	/**
	 * One message of a form
	 *
	 * @param Form   $form Form
	 * @param string $key  Key
	 *
	 * @return string
	 */
	public static function get( Form $form, $key ) {
		$saved = (array) $form->config()['messages'];

		return (string) apply_filters( 'remaily_message', $saved[ $key ] ?? self::default( $key ), $key, $form );
	}

	/**
	 * Default text of a message
	 *
	 * @param string $key Key
	 *
	 * @return string
	 */
	public static function default( $key ) {
		$site = self::site();

		return isset( $site[ $key ] ) && '' !== $site[ $key ] ? (string) $site[ $key ] : self::built_in( $key );
	}

	/**
	 * The text a message ships with
	 *
	 * @param string $key Key
	 *
	 * @return string
	 */
	public static function built_in( $key ) {
		return (string) ( self::all()[ $key ]['default'] ?? '' );
	}

	/**
	 * The site's own texts (Settings → Messages), read once
	 *
	 * @return array [ key => text ]
	 */
	private static function site() {
		static $site = null;

		if ( null === $site ) {
			$saved = get_option( Settings::OPTION, [] );
			$site  = is_array( $saved['messages'] ?? null ) ? array_map( 'strval', $saved['messages'] ) : [];
		}

		return $site;
	}

	/**
	 * The fields of Settings → Messages: every message, in groups (general, then each field type's)
	 *
	 * @return array [ 'groups' => [ id => [ 'title' ] ], 'fields' => [ key => field ] ]
	 */
	public static function settings_fields() {
		$groups = [ 'general' => [ 'title' => __( 'Every form', 'remaily' ) ] ];
		$fields = [];
		$add    = static function ( $group, array $messages ) use ( &$fields ) {
			foreach ( $messages as $key => $message ) {
				if ( !isset( $fields[ $key ] ) ) {
					$fields[ $key ] = [
						'type'        => 'text',
						'group'       => $group,
						'label'       => $message['label'],
						'default'     => $message['default'],
						'placeholder' => $message['default'],
					];
				}
			}
		};

		$add( 'general', self::general() );

		foreach ( FieldRegistry::all() as $id => $type ) {
			$own = array_diff_key( $type->messages(), $fields );

			if ( $own ) {
				$groups[ $id ] = [ 'title' => $type->label() ];
				$add( $id, $own );
			}
		}

		foreach ( self::of_settings() as $setting => $messages ) {
			$groups[ $setting ] = [ 'title' => __( 'Logged-in users only', 'remaily' ) ];
			$add( $setting, $messages );
		}

		return [ 'groups' => $groups, 'fields' => $fields ];
	}
}
