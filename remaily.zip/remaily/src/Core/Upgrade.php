<?php

namespace VLT\Remaily\Core;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Upgrades of data outside the forms (tables, options), once per site when it updates
 *
 * The forms themselves upgrade on read (Config::upgrade()).
 */
class Upgrade {
	const OPTION = 'remaily_version';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'init', [ __CLASS__, 'run' ], 20 );
	}

	/**
	 * Steps, each safe to run twice
	 *
	 * @return array [ version => callable ]
	 */
	private static function steps() {
		return [];
	}

	/**
	 * Run the steps after the version the site's data was last upgraded to, oldest first
	 */
	public static function run() {
		$stored = (string) get_option( self::OPTION, '0' );

		if ( version_compare( $stored, REMAILY_VERSION, '>=' ) || get_transient( self::OPTION . '_lock' ) ) {
			return;
		}

		set_transient( self::OPTION . '_lock', 1, MINUTE_IN_SECONDS );

		$steps = self::steps();

		uksort( $steps, 'version_compare' );

		foreach ( $steps as $version => $step ) {
			if ( version_compare( $version, $stored, '>' ) && version_compare( $version, REMAILY_VERSION, '<=' ) ) {
				$step();
				// A step done stays done if a later one stops the request
				update_option( self::OPTION, (string) $version );
			}
		}

		update_option( self::OPTION, REMAILY_VERSION );
		delete_transient( self::OPTION . '_lock' );
	}
}
