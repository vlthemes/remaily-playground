<?php

namespace VLT\Remaily\Core;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Admin\Preview;
use VLT\Remaily\Admin\ReviewNotice;
use VLT\Remaily\Admin\Transfer;
use VLT\Remaily\Api\Abilities;
use VLT\Remaily\Api\Describe;
use VLT\Remaily\Api\Rest;
use VLT\Remaily\Entries\Entries;
use VLT\Remaily\Front\Renderer;
use VLT\Remaily\Front\Shortcode;
use VLT\Remaily\Integrations\Block;
use VLT\Remaily\Integrations\Elementor;
use VLT\Remaily\Integrations\Cf7;
use VLT\Remaily\Integrations\Ocdi;
use VLT\Remaily\Integrations\Brevo;
use VLT\Remaily\Integrations\Webhooks;
use VLT\Remaily\Integrations\Widget;
use VLT\Remaily\Integrations\WPBakery;
use VLT\Remaily\Payments\Payments;
use VLT\Remaily\Spam\Spam;
use VLT\Remaily\Submission\NoScript;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starts the parts
 */
class Remaily {
	/**
	 * Instance
	 *
	 * @var Remaily|null
	 */
	private static $instance = null;

	/**
	 * Instance
	 *
	 * @return Remaily
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		PostType::register();
		Entries::init();
		Spam::init();
		Payments::init();
		Webhooks::init();
		Brevo::init();
		Block::init();
		Elementor\Integration::init();
		WPBakery\Integration::init();
		Widget::init();
		Cf7::init();
		Transfer::init();
		Ocdi::init();
		Abilities::init();
		Describe::init();
		Shortcode::init();
		Renderer::init();
		Rest::init();
		NoScript::init();
		Preview::init();

		// Asked once, after the first message: listens on the front end, shows in the admin
		ReviewNotice::init();

		// Edit links of forms open the editor, from the admin bar too
		add_filter( 'get_edit_post_link', [ Admin::class, 'edit_link' ], 10, 2 );
		// After WordPress adds + New (70)
		add_action( 'admin_bar_menu', [ Admin::class, 'new_content' ], 80 );

		if ( is_admin() ) {
			Admin::init();
		}

		do_action( 'remaily_init' );
	}
}
