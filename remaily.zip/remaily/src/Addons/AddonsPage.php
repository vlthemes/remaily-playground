<?php

namespace VLT\Remaily\Addons;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Admin\Icons;
use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Api\Rest;
use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\PostType;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form → Add-ons: the installed add-ons and those on sale as cards, a window per installed one with on/off
 * and the add-on's own part (its 'panel', such as its license: core has none) (assets/js/admin-addons.js); on/off
 * saved through POST remaily/v1/addons/{slug} { enabled }, or admin-post.php?action=remaily_addon without the script
 */
class AddonsPage {
	const PAGE = 'remaily-addons';

	/**
	 * Admin page hook
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_post_remaily_addon', [ __CLASS__, 'handle' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'route' ] );
		add_action( 'remaily_addon_notice', [ __CLASS__, 'notice' ], 10, 3 );
		// Last, after Settings (30)
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 40 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'menu_style' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	/**
	 * The add-ons' cards, the most wanted first: what each one is, shown before it's installed and after (the add-on itself only says how
	 * it runs, through remaily_addons)
	 *
	 * @return array [ slug => [ name, description, premium, category, tags, url, icon, color ] ]
	 */
	public static function catalog() {
		return (array) apply_filters( 'remaily_addons_catalog', [
			'calculator' => [
				'name'        => __( 'Calculator', 'remaily' ),
				'description' => __( 'Work out prices and totals in the form as visitors fill it in, with formulas, option prices and dates. Show or hide parts of the form on a total, and take the payment from it.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Fields', 'remaily' ),
				'tags'        => [ __( 'Formulas', 'remaily' ), __( 'Prices', 'remaily' ), __( 'Payments', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-calculator-addon',
				'icon'        => Icons::icon( 'calculator' ),
				'color'       => '#fff1e5',
			],
			'bookings' => [
				'name'        => __( 'Bookings & Time Slots', 'remaily' ),
				'description' => __( 'Let people book a time right in your form, straight into your Google Calendar. Only free times show, each booking becomes an event, and nothing is booked twice. For salons, barbers, car services, therapists and consultants.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Fields', 'remaily' ),
				'tags'        => [ __( 'Appointments', 'remaily' ), __( 'Time slots', 'remaily' ), __( 'Google Calendar', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-bookings-addon',
				'icon'        => Icons::icon( 'bookings' ),
				'color'       => '#e8f7ff',
			],
			'google-sheets' => [
				'name'        => 'Google Sheets',
				'description' => __( 'Every message lands in your Google Sheets spreadsheet as a row, a column per field. Send the entries you already have with one click.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Spreadsheets', 'remaily' ),
				'tags'        => [ __( 'Spreadsheets', 'remaily' ), __( 'Reports', 'remaily' ), __( 'Sync', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-google-sheets-addon',
				'icon'        => Icons::icon( 'google-sheets' ),
				'color'       => '#e5f7ec',
			],
			'telegram'  => [
				'name'        => 'Telegram',
				'description' => __( 'Get each message in Telegram the moment it\'s sent: in your own chat, your team\'s group or a channel. No more checking your mail every five minutes.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Messengers', 'remaily' ),
				'tags'        => [ __( 'Notifications', 'remaily' ), __( 'Bots', 'remaily' ), __( 'Groups', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-telegram-addon',
				'icon'        => Icons::icon( 'telegram' ),
				'color'       => '#e6f4fc',
			],
			'coupons' => [
				'name'        => __( 'Coupons', 'remaily' ),
				'description' => __( 'Promo codes in your forms: 10% or 5 off the payment or a Calculator total. Codes stay on your server, with an end date and a limit of uses, and each use is counted.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Fields', 'remaily' ),
				'tags'        => [ __( 'Promo codes', 'remaily' ), __( 'Discounts', 'remaily' ), __( 'Payments', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-coupons-addon',
				'icon'        => Icons::icon( 'coupons' ),
				'color'       => '#ffe8ef',
			],
			'brevo' => [
				'name'        => 'Brevo',
				'description' => __( 'Add the people who write to you to your Brevo lists, with their details mapped to Brevo attributes, a welcome email and double opt-in.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Email marketing', 'remaily' ),
				'tags'        => [ __( 'Mailing lists', 'remaily' ), __( 'Double opt-in', 'remaily' ), __( 'Attributes', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-brevo-addon',
				'icon'        => Icons::icon( 'brevo' ),
				'color'       => '#e7f6ef',
			],
			'whatsapp'  => [
				'name'        => 'WhatsApp',
				'description' => __( 'Answer the people who write to you on WhatsApp the moment they send a form, and get each message on your own WhatsApp.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Messengers', 'remaily' ),
				'tags'        => [ __( 'Notifications', 'remaily' ), __( 'Auto-reply', 'remaily' ), __( 'Green-API', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-whatsapp-addon',
				'icon'        => Icons::icon( 'whatsapp' ),
				'color'       => '#e6f7e9',
			],
			'razorpay' => [
				'name'        => 'Razorpay',
				'description' => __( 'Take payments in India with the Payment field: cards, UPI, netbanking and wallets in Razorpay Checkout. Each payment is checked and captured on your server before the message goes.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Payments', 'remaily' ),
				'tags'        => [ __( 'UPI', 'remaily' ), __( 'Cards', 'remaily' ), __( 'India', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-razorpay-addon',
				'icon'        => Icons::icon( 'razorpay' ),
				'color'       => '#e8f2ff',
			],
			'rating' => [
				'name'        => __( 'Star rating', 'remaily' ),
				'description' => __( 'Ask people to rate you, a product or a visit with stars they click. From one to ten stars, the built-in star or your own SVG icon, and the mail shows ★★★★☆ 4/5.', 'remaily' ),
				'premium'     => false,
				'category'    => __( 'Fields', 'remaily' ),
				'tags'        => [ __( 'Reviews', 'remaily' ), __( 'Feedback', 'remaily' ), __( 'Stars', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-rating-addon',
				'icon'        => Icons::icon( 'rating' ),
				'color'       => '#eef0ff',
			],
			'themeforest' => [
				'name'        => 'ThemeForest',
				'description' => __( 'Check ThemeForest and CodeCanyon purchase codes in your forms. Only buyers get through to support, and each message shows the item, the buyer and how long their support lasts.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Purchase codes', 'remaily' ),
				'tags'        => [ __( 'Envato', 'remaily' ), __( 'Support', 'remaily' ), __( 'Licenses', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-themeforest-addon',
				'icon'        => Icons::icon( 'envato' ),
				'color'       => '#eef7e6',
			],
			'gumroad' => [
				'name'        => 'Gumroad',
				'description' => __( 'Check Gumroad license keys in your forms. Only buyers get through to support, and each message shows the item, the buyer and how long their support lasts.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Purchase codes', 'remaily' ),
				'tags'        => [ __( 'License keys', 'remaily' ), __( 'Support', 'remaily' ), __( 'Memberships', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-gumroad-addon',
				'icon'        => Icons::icon( 'gumroad' ),
				'color'       => '#ffeaf5',
			],
			'lemonsqueezy' => [
				'name'        => 'Lemon Squeezy',
				'description' => __( 'Check Lemon Squeezy license keys in your forms. Only buyers get through to support, and each message shows the product, the buyer and when the license expires.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Purchase codes', 'remaily' ),
				'tags'        => [ __( 'License keys', 'remaily' ), __( 'Support', 'remaily' ), __( 'Subscriptions', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-lemonsqueezy-addon',
				'icon'        => Icons::icon( 'lemon' ),
				'color'       => '#f0ebff',
			],
			'freemius' => [
				'name'        => 'Freemius',
				'description' => __( 'Check Freemius license keys in your forms. Only buyers get through to support, and each message shows the plan, the buyer and when the license expires.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Purchase codes', 'remaily' ),
				'tags'        => [ __( 'License keys', 'remaily' ), __( 'Support', 'remaily' ), __( 'WordPress', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-freemius-addon',
				'icon'        => Icons::icon( 'freemius' ),
				'color'       => '#e8f1ff',
			],
			'paddle' => [
				'name'        => 'Paddle',
				'description' => __( 'Check Paddle orders in your forms by their transaction ID or invoice number. Only buyers get through to support, and each message shows the product, the buyer and how long support lasts.', 'remaily' ),
				'premium'     => true,
				'category'    => __( 'Purchase codes', 'remaily' ),
				'tags'        => [ __( 'Orders', 'remaily' ), __( 'Support', 'remaily' ), __( 'Subscriptions', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-paddle-addon',
				'icon'        => Icons::icon( 'paddle' ),
				'color'       => '#deddd9',
			],
			'site-info' => [
				'name'        => __( 'Site info', 'remaily' ),
				'description' => __( 'Adds this site\'s details to the messages of the forms you pick: WordPress and PHP versions, the theme, the active plugins and the server. For support forms.', 'remaily' ),
				'premium'     => false,
				'category'    => __( 'Support', 'remaily' ),
				'tags'        => [ __( 'Support', 'remaily' ), __( 'Plugins', 'remaily' ), __( 'Versions', 'remaily' ) ],
				'url'         => 'https://vlthemes.gumroad.com/l/remaily-site-info-addon',
				'icon'        => Icons::icon( 'site-info' ),
				'color'       => '#eaf0ff',
			],
		] );
	}

	/**
	 * Add-ons in the plugin's menu, after Settings
	 */
	public static function menu() {
		self::$hook = (string) add_submenu_page( Admin::LIST_PAGE, __( 'Add-ons', 'remaily' ), __( 'Add-ons', 'remaily' ), 'manage_options', self::PAGE, [ __CLASS__, 'render' ] );
	}

	/**
	 * Add-ons stands out in the menu on every screen: a few lines inline with WordPress's menu styles, no request
	 */
	public static function menu_style() {
		// The menu's own id: the color schemes' submenu rules come later and are as specific otherwise
		$link = '#adminmenu #toplevel_page_edit-post_type-' . PostType::NAME . ' .wp-submenu a[href$="page=' . self::PAGE . '"]';

		wp_add_inline_style( 'admin-menu', $link . '{color:#f0b849;font-weight:600}' . $link . ':hover,' . $link . '[aria-current="page"]{color:#fff}#adminmenu .wp-submenu li:has(>a[href$="page=' . self::PAGE . '"]){margin-top:6px;padding-top:6px;border-top:1px solid rgba(255,255,255,.12)}' );
	}

	/**
	 * Whether this is the Add-ons screen
	 *
	 * @return bool
	 */
	public static function is_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return $screen && self::$hook && self::$hook === $screen->id;
	}

	/**
	 * The page's script and styles
	 *
	 * @param string $hook Admin page hook
	 */
	public static function enqueue( $hook ) {
		if ( self::$hook && self::$hook === $hook ) {
			Assets::enqueue( 'remaily-admin-settings', 'remaily-admin-addons' );
		}
	}

	/**
	 * An add-on's logo on its background colour ('color' of remaily_addons)
	 *
	 * @param array $card Card
	 */
	private static function the_icon( array $card ) {
		$color = sanitize_hex_color( (string) $card['color'] );
		?>
		<span class="remaily-addon__icon" aria-hidden="true"<?php echo $color ? ' style="--remaily-addon-color:' . esc_attr( $color ) . '"' : ''; ?>><?php echo wp_kses( (string) $card['icon'], remaily_allowed_html( (string) $card['icon'] ) ); ?></span>
		<?php
	}

	/**
	 * Every card: installed add-ons, then the rest of the catalog
	 *
	 * @return array [ slug => [ name, description, premium, category, tags, url, icon, installed, … ] ]
	 */
	private static function cards() {
		$catalog = self::catalog();
		$cards   = [];

		// An installed add-on's card: its catalog entry, with what the add-on says of itself on top (an add-on that
		// isn't in the catalog brings its own description, icon and so on)
		foreach ( Addons::all() as $slug => $addon ) {
			$item = (array) ( $catalog[ $slug ] ?? [] );
			$pick = static fn( $key, $default = '' ) => $addon[ $key ] ?: ( $item[ $key ] ?? $default );

			$cards[ $slug ] = [
				'name'        => $pick( 'name', $slug ),
				'description' => $pick( 'description' ),
				'premium'     => $addon['premium'],
				'category'    => $pick( 'category' ),
				'tags'        => $pick( 'tags', [] ),
				'url'         => $pick( 'url' ),
				'icon'        => $pick( 'icon' ),
				'color'       => $pick( 'color' ),
				'docs'        => $pick( 'docs' ),
				'version'     => $addon['version'],
				'installed'   => true,
			];
		}

		// Installed ones in the catalog's order too (the most wanted first), any other add-on after them
		$order = array_flip( array_keys( $catalog ) );
		uksort( $cards, static fn( $a, $b ) => ( $order[ $a ] ?? PHP_INT_MAX ) <=> ( $order[ $b ] ?? PHP_INT_MAX ) );

		foreach ( $catalog as $slug => $item ) {
			if ( !isset( $cards[ $slug ] ) ) {
				$cards[ $slug ] = wp_parse_args( (array) $item, [ 'name' => $slug, 'description' => '', 'premium' => false, 'category' => '', 'tags' => [], 'url' => '', 'icon' => '', 'color' => '', 'docs' => '', 'version' => '' ] ) + [ 'installed' => false ];
			}
		}

		return $cards;
	}

	/**
	 * A card's state: [ label, tone ]
	 *
	 * @param string $slug Slug
	 * @param array  $card Card
	 *
	 * @return array
	 */
	private static function state( $slug, array $card ) {
		if ( !$card['installed'] ) {
			return [ __( 'Available', 'remaily' ), 'brand' ];
		}

		$addon = Addons::all()[ $slug ];

		if ( !Addons::enabled( $slug ) ) {
			return [ __( 'Off', 'remaily' ), 'muted' ];
		}

		// Its own word first, such as "Not activated"
		if ( 2 === count( $addon['status'] ) ) {
			return $addon['status'];
		}

		return $addon['ready'] ? [ __( 'On', 'remaily' ), 'success' ] : [ __( 'Needs setting up', 'remaily' ), 'warning' ];
	}

	/**
	 * The Add-ons page: as the Settings page, the filters down the side and the search on top; the cards, and a window
	 * per installed add-on (admin-addons.js)
	 */
	public static function render() {
		$cards     = self::cards();
		$installed = array_filter( $cards, static fn( $card ) => $card['installed'] );
		$available = array_diff_key( $cards, $installed );
		$notice    = get_transient( 'remaily_addon_notice_' . get_current_user_id() );

		if ( $notice ) {
			delete_transient( 'remaily_addon_notice_' . get_current_user_id() );
		}

		$filters = [ 'all' => [ __( 'All', 'remaily' ), $cards, 'blocks' ], 'installed' => [ __( 'Installed', 'remaily' ), $installed, 'circle-check' ], 'available' => [ __( 'Available', 'remaily' ), $available, 'download' ] ];
		?>
		<div class="wrap vlt-settings-page">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Add-ons', 'remaily' ); ?></h1>
			<hr class="wp-header-end">

			<?php
			Settings::page()->header( __( 'add-ons', 'remaily' ), [], '', [
				'tagline' => __( 'More services and fields for your forms.', 'remaily' ),
				'stats'   => [
					[ count( $cards ), __( 'Add-ons', 'remaily' ), 'blocks' ],
					[ count( $installed ), __( 'Installed', 'remaily' ), 'circle-check' ],
				],
			] );
			?>

			<?php // As the Settings page: one white card, the search and filters down its side ?>
			<div class="vlt-settings-page__layout remaily-addons">
				<nav class="vlt-settings-page__side">
					<label class="remaily-addons__search">
						<span class="screen-reader-text"><?php esc_html_e( 'Search add-ons', 'remaily' ); ?></span>
						<input type="search" placeholder="<?php esc_attr_e( 'Search', 'remaily' ); ?>" data-remaily-search>
						<kbd aria-hidden="true">/</kbd>
					</label>
					<div class="vlt-admin-header__nav is-side" role="group" aria-label="<?php esc_attr_e( 'Show', 'remaily' ); ?>">
						<?php foreach ( $filters as $id => [ $label, $list, $icon ] ) : ?>
							<button type="button" class="vlt-admin-header__nav-item" aria-pressed="<?php echo 'all' === $id ? 'true' : 'false'; ?>" data-remaily-filter="<?php echo esc_attr( $id ); ?>">
								<?php Icons::the_glyph( $icon ); ?>
								<?php echo esc_html( $label ); ?>
								<span class="remaily-addons__count"><?php echo esc_html( (string) count( $list ) ); ?></span>
							</button>
						<?php endforeach; ?>
					</div>
				</nav>

				<div class="vlt-settings-page__panels">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'Add-ons', 'remaily' ); ?></h2>
						<p><?php esc_html_e( 'Each add-on is a plugin of its own: install it as any plugin, then open its Settings here to set it up and to turn it on or off.', 'remaily' ); ?></p>
					</div>

					<?php
					self::render_group( 'installed', __( 'Installed', 'remaily' ), __( 'Open Settings to set one up, to turn it off, or for its options.', 'remaily' ), $installed );
					self::render_group( 'available', __( 'Available', 'remaily' ), __( 'Install one as any plugin, and it shows up above.', 'remaily' ), $available );
					?>
					<?php // What a filter or search that finds nothing shows (admin-addons.js picks the words) ?>
					<div class="remaily-addons__empty" data-remaily-empty hidden>
						<span data-for="search"><?php Icons::the_glyph( 'search-x' ); ?></span>
						<span data-for="none"><?php Icons::the_glyph( 'package-check' ); ?></span>
						<h3 data-for="search"><?php esc_html_e( 'No add-on found', 'remaily' ); ?></h3>
						<?php /* translators: %s: what was searched for */ ?>
						<p data-for="search" data-text="<?php esc_attr_e( 'Nothing matches “%s”. Try another word, or look at all add-ons.', 'remaily' ); ?>"></p>
						<h3 data-for="none"><?php esc_html_e( 'You have every add-on', 'remaily' ); ?></h3>
						<p data-for="none"><?php esc_html_e( 'All of them are installed. More are on the way: new ones show up here.', 'remaily' ); ?></p>
					</div>
				</div>
			</div>

			<?php
			foreach ( $installed as $slug => $card ) {
				self::render_window( $slug, $card, is_array( $notice ) && $slug === ( $notice['slug'] ?? '' ) ? $notice : null );
			}
			?>
		</div>
		<?php
	}

	/**
	 * A group of cards
	 *
	 * @param string $id    installed or available
	 * @param string $title Title
	 * @param string $text  Line under it
	 * @param array  $cards Cards
	 */
	private static function render_group( $id, $title, $text, array $cards ) {
		if ( !$cards ) {
			return;
		}
		?>
		<section class="remaily-addons__group" data-remaily-group="<?php echo esc_attr( $id ); ?>">
			<header class="remaily-addons__group-head">
				<h2><?php echo esc_html( $title ); ?></h2>
				<p><?php echo esc_html( $text ); ?></p>
			</header>
			<div class="remaily-addons__grid">
				<?php foreach ( $cards as $slug => $card ) : ?>
					<?php self::render_card( (string) $slug, $card ); ?>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
	}

	/**
	 * One card
	 *
	 * @param string $slug Slug
	 * @param array  $card Card
	 */
	private static function render_card( $slug, array $card ) {
		[ $state, $tone ] = self::state( $slug, $card );

		$tags = array_map( 'strval', (array) $card['tags'] );
		$meta = array_filter( [ $card['premium'] ? __( 'Premium', 'remaily' ) : __( 'Free', 'remaily' ), $card['version'] ? 'v' . $card['version'] : '' ] );
		$find = strtolower( implode( ' ', array_merge( [ $card['name'], $card['description'], $card['category'] ], $tags ) ) );
		?>
		<article class="remaily-addon" data-remaily-card="<?php echo esc_attr( $slug ); ?>" data-remaily-find="<?php echo esc_attr( $find ); ?>">
			<header class="remaily-addon__head">
				<?php self::the_icon( $card ); ?>
				<div class="remaily-addon__titles">
					<h3 class="remaily-addon__name"><?php echo esc_html( $card['name'] ); ?></h3>
					<?php if ( $card['category'] ) : ?>
						<p class="remaily-addon__category"><?php echo esc_html( $card['category'] ); ?></p>
					<?php endif; ?>
				</div>
				<span class="remaily-addon__state is-<?php echo esc_attr( $tone ); ?>" data-remaily-state><?php echo esc_html( $state ); ?></span>
			</header>

			<p class="remaily-addon__text"><?php echo esc_html( $card['description'] ); ?></p>

			<?php if ( $tags ) : ?>
				<ul class="remaily-addon__tags">
					<?php foreach ( $tags as $tag ) : ?>
						<li><?php echo esc_html( $tag ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<footer class="remaily-addon__foot">
				<span class="remaily-addon__actions">
					<?php if ( $card['installed'] ) : ?>
						<button type="button" class="vlt-settings-page__button" data-remaily-open="<?php echo esc_attr( $slug ); ?>"><?php Icons::the_glyph( 'settings' ); ?><?php esc_html_e( 'Settings', 'remaily' ); ?></button>
						<?php if ( $card['docs'] ) : ?>
							<a class="vlt-settings-page__button is-link" href="<?php echo esc_url( $card['docs'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Docs', 'remaily' ); ?></a>
						<?php endif; ?>
					<?php elseif ( $card['url'] ) : ?>
						<a class="vlt-settings-page__button is-primary" href="<?php echo esc_url( $card['url'] ); ?>" target="_blank" rel="noopener"><?php Icons::the_glyph( 'external-link' ); ?><?php echo $card['premium'] ? esc_html__( 'Get add-on', 'remaily' ) : esc_html__( 'Download', 'remaily' ); ?></a>
					<?php endif; ?>
				</span>
				<span class="remaily-addon__meta"><?php echo esc_html( implode( ' · ', $meta ) ); ?></span>
			</footer>
		</article>
		<?php
	}

	/**
	 * The window of an installed add-on: its own part (its panel), on/off and its settings
	 *
	 * @param string     $slug   Slug
	 * @param array      $card   Card
	 * @param array|null $notice What the last action said: [ slug, type, text ]
	 */
	private static function render_window( $slug, array $card, $notice ) {
		$addon  = Addons::all()[ $slug ];
		$action = admin_url( 'admin-post.php' );
		$hidden = static function ( $do ) use ( $slug ) {
			?>
			<input type="hidden" name="action" value="remaily_addon">
			<input type="hidden" name="addon" value="<?php echo esc_attr( $slug ); ?>">
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>">
			<?php
			wp_nonce_field( 'remaily_addon_' . $slug );
		};
		?>
		<dialog class="remaily-addon-window" id="remaily-addon-<?php echo esc_attr( $slug ); ?>" aria-labelledby="remaily-addon-<?php echo esc_attr( $slug ); ?>-title"<?php echo $notice ? ' data-remaily-reopen' : ''; ?>>
			<header class="remaily-addon-window__head">
				<?php self::the_icon( $card ); ?>
				<h2 id="remaily-addon-<?php echo esc_attr( $slug ); ?>-title"><?php echo esc_html( $card['name'] ); ?></h2>
				<form method="dialog"><button type="submit" class="remaily-addon-window__close" aria-label="<?php esc_attr_e( 'Close', 'remaily' ); ?>"><?php Icons::the_glyph( 'x' ); ?></button></form>
			</header>

			<?php if ( $notice ) : ?>
				<p class="vlt-settings-page__note is-<?php echo esc_attr( $notice['type'] ); ?>"><?php echo esc_html( $notice['text'] ); ?></p>
			<?php endif; ?>

			<?php if ( $addon['panel'] ) : ?>
				<div class="remaily-addon-window__part">
					<?php call_user_func( $addon['panel'] ); ?>
				</div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( $action ); ?>" class="remaily-addon-window__settings" data-remaily-save="<?php echo esc_attr( $slug ); ?>">
				<?php $hidden( 'save' ); ?>

				<?php // Not ready by its own word (a license not activated yet): nothing to turn on until it is ?>
				<div class="remaily-addon-window__part">
					<label class="vlt-settings-page__check">
						<input type="hidden" name="enabled" value="0">
						<input type="checkbox" name="enabled" value="1" <?php checked( Addons::enabled( $slug ) ); ?> <?php disabled( !$addon['ready'] ); ?>>
						<?php esc_html_e( 'Use this add-on', 'remaily' ); ?>
					</label>
					<p class="remaily-addon-window__hint">
						<?php
						$addon['ready']
							? esc_html_e( 'Off: it does nothing, and its options and form tab are gone until you turn it on. What you set stays.', 'remaily' )
							: esc_html_e( 'Activate the add-on above to use it.', 'remaily' );
						?>
					</p>
				</div>

				<footer class="remaily-addon-window__foot">
					<span class="remaily-addon-window__links">
						<?php if ( $addon['settings'] && Addons::runs( $slug ) && '' === Addons::readonly( $slug ) ) : ?>
							<a href="<?php echo esc_url( Settings::url() . '#' . $addon['settings'] ); ?>"><?php esc_html_e( 'Its options in Settings', 'remaily' ); ?></a>
						<?php endif; ?>
						<?php if ( $card['docs'] ) : ?>
							<a href="<?php echo esc_url( $card['docs'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'remaily' ); ?></a>
						<?php endif; ?>
					</span>
					<button type="submit" class="vlt-settings-page__button is-primary" <?php disabled( !$addon['ready'] ); ?>><?php esc_html_e( 'Save', 'remaily' ); ?></button>
				</footer>
			</form>
		</dialog>
		<?php
	}

	/**
	 * Register the route that turns an add-on on or off
	 */
	public static function route() {
		register_rest_route( Rest::NS, '/addons/(?P<slug>[a-z0-9_-]+)', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'save' ],
			'permission_callback' => static fn() => current_user_can( 'manage_options' ),
			'args'                => [
				'enabled' => [ 'type' => 'boolean', 'required' => true ],
			],
		] );
	}

	/**
	 * Turn an add-on on or off: what its window and card show next
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function save( \WP_REST_Request $request ) {
		$slug  = sanitize_key( (string) $request['slug'] );
		$cards = self::cards();

		if ( !isset( Addons::all()[ $slug ], $cards[ $slug ] ) ) {
			return new \WP_Error( 'remaily_no_addon', __( 'There is no such add-on.', 'remaily' ), [ 'status' => 404 ] );
		}

		if ( !Addons::all()[ $slug ]['ready'] ) {
			return new \WP_Error( 'remaily_addon_not_ready', __( 'Activate the add-on above to use it.', 'remaily' ), [ 'status' => 409 ] );
		}

		self::set_enabled( $slug, (bool) $request['enabled'] );

		[ $state, $tone ] = self::state( $slug, $cards[ $slug ] );

		return rest_ensure_response( [
			'message' => __( 'Saved.', 'remaily' ),
			'state'   => $state,
			'tone'    => $tone,
		] );
	}

	/**
	 * The script's data: where to save and the nonce
	 *
	 * @return array
	 */
	public static function script_data() {
		return [
			'rest'  => esc_url_raw( rest_url( Rest::NS . '/addons/' ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
			'error' => __( 'Couldn\'t save. Try again.', 'remaily' ),
		];
	}

	/**
	 * Save whether an add-on is on
	 *
	 * @param string $slug    Slug
	 * @param bool   $enabled On
	 */
	private static function set_enabled( $slug, $enabled ) {
		$all          = (array) get_option( Addons::OPTION, [] );
		$all[ $slug ] = [ 'enabled' => $enabled ];

		update_option( Addons::OPTION, $all );
	}

	/**
	 * admin-post.php?action=remaily_addon: turn an add-on on or off, then back to its window with what happened
	 */
	public static function handle() {
		$slug = isset( $_POST['addon'] ) ? sanitize_key( wp_unslash( $_POST['addon'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked below, per add-on

		if ( !current_user_can( 'manage_options' ) || !isset( Addons::all()[ $slug ] ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'remaily' ), 403 );
		}

		check_admin_referer( 'remaily_addon_' . $slug );

		// Only an add-on that's ready can be turned on (its window doesn't let it otherwise)
		if ( 'save' === ( isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '' ) && Addons::all()[ $slug ]['ready'] ) {
			self::set_enabled( $slug, !empty( $_POST['enabled'] ) );
		}

		self::notice( $slug, 'success', __( 'Saved.', 'remaily' ) );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '#' . $slug ) );
		exit;
	}

	/**
	 * What an add-on's window says once it opens again (remaily_addon_notice: an add-on's own forms use it too)
	 *
	 * @param string $slug Add-on
	 * @param string $type success, warning or danger
	 * @param string $text Text
	 */
	public static function notice( $slug, $type, $text ) {
		set_transient( 'remaily_addon_notice_' . get_current_user_id(), [
			'slug' => sanitize_key( (string) $slug ),
			'type' => in_array( $type, [ 'success', 'warning', 'danger' ], true ) ? $type : 'success',
			'text' => sanitize_text_field( (string) $text ),
		], MINUTE_IN_SECONDS );
	}
}
