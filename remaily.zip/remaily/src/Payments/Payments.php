<?php

namespace VLT\Remaily\Payments;

use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Admin\Icons;
use VLT\Remaily\Api\Rest;
use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\Messages;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Submission\Conditions;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Payments of the Payment field, with the providers it offers (Gateway), as CF7's Stripe module
 *
 * 1. Send: the fields are checked; with no payment posted, the reply's status is "payment". The amount is kept on the
 *    server under a token, and the reply lists the providers the visitor can pay with (assets/js/payments.js).
 * 2. The visitor picks one: POST remaily/v1/payments/start { token, gateway } starts the payment there, without
 *    sending the form again (its captcha answer works once). With one provider it starts with the reply.
 * 3. The visitor pays; the script puts "gateway:payment ID" in the field and sends again.
 * 4. The payment is checked with that provider (paid, same amount, this form, not used) and taken, then the mail
 *    goes. A checked payment skips the captchas; the other spam checks still run, before anything asks a provider.
 *
 * Keys in Settings → Payments. Amounts are worked out again on the server from the posted values.
 */
class Payments {
	// Currencies both Stripe and PayPal take
	const COMMON = [ 'usd', 'eur', 'gbp', 'cad', 'aud', 'nzd', 'chf', 'sek', 'nok', 'dkk', 'pln', 'czk', 'huf', 'jpy', 'hkd', 'sgd', 'twd', 'thb', 'php', 'myr', 'mxn', 'brl', 'ils', 'cny' ];

	// Shown without cents
	const ZERO_DECIMAL = [ 'huf', 'jpy', 'twd' ];

	// How long a payment asked for waits for the visitor, and how many times they may start it (switching providers)
	const WAIT   = 30 * MINUTE_IN_SECONDS;
	const STARTS = 10;

	/**
	 * Gateways, built once
	 *
	 * @var Gateway[]|null
	 */
	private static $gateways = null;

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'remaily_settings_sections', [ __CLASS__, 'section' ] );
		add_filter( 'remaily_assets', [ __CLASS__, 'assets' ] );
		add_filter( 'remaily_skip_captcha', [ __CLASS__, 'skip_captcha' ], 10, 2 );
		add_action( 'rest_api_init', [ __CLASS__, 'route' ] );
		// Last, so nothing stops the message after the payment is taken
		add_action( 'remaily_before_send_mail', [ __CLASS__, 'pay' ], PHP_INT_MAX );
	}

	/**
	 * Settings → Payments
	 *
	 * @return array
	 */
	public static function settings() {
		return Settings::get( 'payments' );
	}

	/**
	 * The providers by their ID; more through remaily_payment_gateways
	 *
	 *     add_filter( 'remaily_payment_gateways', fn( $gateways ) => $gateways + [ 'square' => new My_Square_Gateway() ] );
	 *
	 * @return Gateway[] [ id => gateway ]
	 */
	public static function gateways() {
		if ( null === self::$gateways ) {
			self::$gateways = [];

			foreach ( (array) apply_filters( 'remaily_payment_gateways', [ 'stripe' => new StripeGateway(), 'paypal' => new PaypalGateway() ] ) as $gateway ) {
				if ( $gateway instanceof Gateway ) {
					self::$gateways[ sanitize_key( $gateway->id() ) ] = $gateway;
				}
			}
		}

		return self::$gateways;
	}

	/**
	 * Currencies for the field's sidebar: those any provider takes
	 *
	 * @return array [ code => label ]
	 */
	public static function currencies() {
		$codes = self::COMMON;

		foreach ( self::gateways() as $gateway ) {
			$codes = array_merge( $codes, array_map( 'strtolower', $gateway->currencies() ) );
		}

		$codes = array_values( array_unique( $codes ) );

		return array_combine( $codes, array_map( 'strtoupper', $codes ) );
	}

	/**
	 * The providers a field offers for a currency: those it picks (none picked: all), set up and taking it
	 *
	 * @param array  $field    Field
	 * @param string $currency Currency
	 *
	 * @return Gateway[] [ id => gateway ]
	 */
	public static function offered( array $field, $currency ) {
		$picked = array_filter( array_map( 'trim', explode( ',', (string) ( $field['providers'] ?? '' ) ) ) );
		$all    = self::gateways();
		$list   = $picked ? array_intersect_key( $all, array_flip( $picked ) ) : $all;

		return array_filter( $list, static fn( $gateway ) => $gateway->ready() && in_array( $currency, $gateway->currencies(), true ) );
	}

	/**
	 * A paid value as posted, "stripe:pi_…": [ gateway, payment ID ], or null
	 *
	 * @param string $value Posted
	 *
	 * @return array|null
	 */
	private static function paid( $value ) {
		return preg_match( '/^([a-z0-9_-]+):(.+)$/', (string) $value, $match ) ? [ $match[1], $match[2] ] : null;
	}

	/**
	 * An amount as visitors read it, such as 20.00 USD
	 *
	 * @param float  $amount   Amount
	 * @param string $currency Currency
	 *
	 * @return string
	 */
	public static function format( $amount, $currency ) {
		return number_format_i18n( $amount, in_array( $currency, self::ZERO_DECIMAL, true ) ? 0 : 2 ) . ' ' . strtoupper( $currency );
	}

	/**
	 * The payment fields of a form that the visitor sees, by name
	 *
	 * @param Form  $form   Form
	 * @param array $hidden Groups hidden
	 *
	 * @return array [ name => field ]
	 */
	private static function fields( Form $form, array $hidden ) {
		$fields = array_filter( $form->fields(), static fn( $field ) => 'payment' === $field['type'] );

		return array_diff_key( $fields, array_flip( Conditions::hidden_fields( $form, $hidden ) ) );
	}

	/**
	 * What a field asks the visitor to pay, from the posted values
	 *
	 * @param array      $field      Field, with name
	 * @param Submission $submission Submission
	 *
	 * @return array 'amount', 'currency', 'description', 'reference', 'email'
	 */
	public static function payment( array $field, Submission $submission ) {
		$form   = $submission->form();
		$amount = (float) $field['amount'];
		$source = $form->field( $field['amount_field'] );

		if ( $source ) {
			// An Output shows another field's value: that field's
			$name   = 'output' === $source['type'] ? $source['source'] : $field['amount_field'];
			$values = $submission->posted( $name );
			$amount = 0.0;

			// A hidden field's posted value is the visitor's to change: its saved one
			if ( 'hidden' === ( $form->field( $name )['type'] ?? '' ) ) {
				$values = $form->field( $name )['default'];
			}

			// The last number of each value: "20", "basic-20", "Basic (20)"; checkboxes add up
			foreach ( (array) $values as $value ) {
				if ( preg_match_all( '/\d+(?:[.,]\d+)?/', (string) $value, $numbers ) ) {
					$amount += (float) str_replace( ',', '.', end( $numbers[0] ) );
				}
			}
		}

		$email = '';

		foreach ( $form->fields() as $name => $other ) {
			if ( 'email' === $other['type'] && is_email( $submission->posted( $name ) ) ) {
				$email = (string) $submission->posted( $name );
				break;
			}
		}

		$payment = [
			'amount'      => round( max( 0, $amount ), in_array( $field['currency'], self::ZERO_DECIMAL, true ) ? 0 : 2 ),
			'currency'    => $field['currency'],
			'description' => '' !== $field['description'] ? $field['description'] : $form->title(),
			'reference'   => $form->id() . ':' . $field['name'],
			'email'       => $email,
		];

		/**
		 * What a payment field asks for: change the amount, currency or description
		 *
		 * @param array      $payment    'amount', 'currency', 'description', 'reference', 'email'
		 * @param array      $field      Field
		 * @param Submission $submission Submission
		 */
		return (array) apply_filters( 'remaily_payment', $payment, $field, $submission ) + $payment;
	}

	/**
	 * A message sent again after a payment that checks out skips the captchas
	 *
	 * @param bool       $skip       Skip so far
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function skip_captcha( $skip, Submission $submission ) {
		if ( $skip ) {
			return true;
		}

		$fields = self::fields( $submission->form(), Conditions::hidden_groups( $submission->form(), $submission->posted() ) );

		foreach ( $fields as $name => $field ) {
			$paid    = self::paid( $submission->posted( $name ) );
			$payment = self::payment( $field, $submission );
			$offered = self::offered( $field, $payment['currency'] );

			if ( !$paid || !isset( $offered[ $paid[0] ] ) || !$offered[ $paid[0] ]->check( $paid[1], $payment ) ) {
				return false;
			}
		}

		return (bool) $fields;
	}

	/**
	 * Ask for the payments not made yet, or check and take those made
	 *
	 * @param Submission $submission Submission
	 */
	public static function pay( Submission $submission ) {
		if ( $submission->aborted() ) {
			return;
		}

		$form   = $submission->form();
		$failed = Messages::get( $form, 'payment_failed' );
		$taken  = [];

		foreach ( self::fields( $form, $submission->hidden_groups() ) as $name => $field ) {
			$payment = self::payment( $field, $submission );
			$paid    = self::paid( $submission->posted( $name ) );

			$submission->set( $name, '' );

			if ( $payment['amount'] <= 0 ) {
				continue;
			}

			$offered = self::offered( $field, $payment['currency'] );

			if ( !$offered ) {
				$submission->abort( $failed );

				return;
			}

			if ( !$paid ) {
				self::ask( $submission, $name, $field, $payment, $offered );

				return;
			}

			[ $gateway, $id ] = $paid;

			if ( !isset( $offered[ $gateway ] ) || !$offered[ $gateway ]->check( $id, $payment ) ) {
				$submission->abort( $failed );

				return;
			}

			$taken[ $name ] = [ $gateway, $id, $payment ];
		}

		// Every payment checks out: take them all
		foreach ( $taken as $name => [ $gateway, $id, $payment ] ) {
			// One request at a time per payment: two sent together would both pass the check above. add_option()
			// fails when the row exists, which the database settles
			$lock = 'remaily_paying_' . md5( $gateway . ':' . $id );

			if ( !add_option( $lock, time(), '', false ) ) {
				$submission->abort( $failed );

				return;
			}

			$completed = self::gateways()[ $gateway ]->complete( $id );

			delete_option( $lock );

			if ( !$completed ) {
				$submission->abort( $failed );

				return;
			}

			/* translators: 1: amount, such as 20.00 USD, 2: the provider, such as Stripe, 3: the payment's ID */
			$submission->set( $name, sprintf( __( '%1$s paid with %2$s (%3$s)', 'remaily' ), self::format( $payment['amount'], $payment['currency'] ), self::gateways()[ $gateway ]->label(), $id ) );
		}
	}

	/**
	 * Ask for a payment: kept under a token, the providers to pick from, started at once when there is one
	 *
	 * @param Submission $submission Submission
	 * @param string     $name       Field name
	 * @param array      $field      Field
	 * @param array      $payment    payment()
	 * @param Gateway[]  $offered    offered()
	 */
	private static function ask( Submission $submission, $name, array $field, array $payment, array $offered ) {
		$form   = $submission->form();
		$failed = Messages::get( $form, 'payment_failed' );
		$amount = self::format( $payment['amount'], $payment['currency'] );
		$token  = wp_generate_password( 32, false );

		set_transient( 'remaily_pay_' . $token, [ 'payment' => $payment, 'gateways' => array_keys( $offered ), 'starts' => 0 ], self::WAIT );

		$data = [
			'field'   => $name,
			'amount'  => $amount,
			'failed'  => $failed,
			'label'   => (string) $field['pay_label'],
			'token'   => $token,
			'start'   => esc_url_raw( rest_url( Rest::NS . '/payments/start' ) ),
			'methods' => array_values( array_map( static fn( $gateway ) => [ 'id' => $gateway->id(), 'label' => $gateway->label() ], $offered ) ),
		];

		if ( 1 === count( $offered ) ) {
			$started = self::begin( $token, (string) key( $offered ) );

			if ( is_wp_error( $started ) ) {
				$submission->abort( $failed );

				return;
			}

			$data['started'] = $started;
		}

		// The payment script loads only now, with this reply: a form page doesn't fetch it
		$submission->abort( str_replace( '{amount}', $amount, Messages::get( $form, 'payment_required' ) ), 'payment', [
			'payment' => $data,
			'script'  => Assets::src( 'remaily-payments' ),
		] );
	}

	/**
	 * Start a payment asked for with one of its providers: what that provider's script needs
	 *
	 * @param string $token   Token of ask()
	 * @param string $gateway Provider
	 *
	 * @return array|\WP_Error
	 */
	private static function begin( $token, $gateway ) {
		$key     = 'remaily_pay_' . $token;
		$pending = get_transient( $key );

		if ( !is_array( $pending ) || !in_array( $gateway, (array) $pending['gateways'], true ) || (int) $pending['starts'] >= self::STARTS || !isset( self::gateways()[ $gateway ] ) ) {
			return new \WP_Error( 'remaily_payment', 'No such payment', [ 'status' => 400 ] );
		}

		$pending['starts'] = (int) $pending['starts'] + 1;
		set_transient( $key, $pending, self::WAIT );

		$provider = self::gateways()[ $gateway ];
		$start    = $provider->start( (array) $pending['payment'] );

		if ( is_wp_error( $start ) ) {
			return new \WP_Error( 'remaily_payment', $start->get_error_message(), [ 'status' => 502 ] );
		}

		return [ 'gateway' => $gateway, 'script' => $provider->script() ] + $provider->client() + (array) $start;
	}

	/**
	 * Register POST remaily/v1/payments/start: public, the token is the payment the server asked for
	 */
	public static function route() {
		register_rest_route( Rest::NS, '/payments/start', [
			'methods'             => 'POST',
			'callback'            => static function ( \WP_REST_Request $request ) {
				$started = self::begin( (string) $request['token'], (string) $request['gateway'] );

				return is_wp_error( $started ) ? $started : rest_ensure_response( $started );
			},
			'permission_callback' => '__return_true',
			'args'                => [
				'token'   => [ 'type' => 'string', 'required' => true, 'pattern' => '^[A-Za-z0-9]{32}$' ],
				'gateway' => [ 'type' => 'string', 'required' => true, 'pattern' => '^[a-z0-9_-]+$' ],
			],
		] );
	}

	/**
	 * The payment script, loaded by the front script when a reply asks for a payment
	 *
	 * @param array $assets Handles
	 *
	 * @return array
	 */
	public static function assets( array $assets ) {
		$assets['remaily-payments'] = [ 'script' => 'js/payments.js', 'deps' => [ 'remaily' ] ];

		return $assets;
	}

	/**
	 * A provider's state for Settings → Payments: [ label, tone ]
	 *
	 * @param string $id stripe or paypal
	 *
	 * @return array
	 */
	public static function status( $id ) {
		// The saved values as they are: settings() builds the sections, which ask for this status
		$settings = (array) ( ( (array) get_option( Settings::OPTION, [] ) )['payments'] ?? [] );
		$public   = (string) ( $settings[ $id ][ 'stripe' === $id ? 'key' : 'client' ] ?? '' );
		$secret   = (string) ( $settings[ $id ]['secret'] ?? '' );

		if ( '' === $public && '' === $secret ) {
			return [ __( 'Not set up', 'remaily' ), 'muted' ];
		}

		if ( '' === $public || '' === $secret ) {
			return [ __( 'Needs both keys', 'remaily' ), 'warning' ];
		}

		$test = 'stripe' === $id ? 0 === strpos( $public, 'pk_test_' ) : 'sandbox' === ( $settings['paypal']['mode'] ?? 'live' );

		return $test ? [ __( 'Test payments', 'remaily' ), 'warning' ] : [ __( 'Live', 'remaily' ), 'success' ];
	}

	/**
	 * The Payments tab of Settings
	 *
	 * @param array $sections Sections
	 *
	 * @return array
	 */
	public static function section( array $sections ) {
		$link = static fn( $url, $text ) => '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>';

		$docs = trailingslashit( \VLT\Remaily\Admin\Settings::docs_url() );

		$sections['payments'] = [
			'tab'         => __( 'Payments', 'remaily' ),
			'icon'        => 'credit-card',
			'title'       => __( 'Payments', 'remaily' ),
			'description' => __( 'Add a Payment field to a form and visitors pay before their message goes, with any provider set up here. Each form sets its own amount.', 'remaily' ),
			'fields'      => [
				/* translators: 1: link to the Stripe dashboard, 2: link to the Payment field page of the documentation */
				'stripe' => [ 'type' => 'section', 'layout' => 'card', 'icon' => \VLT\Remaily\Admin\Icons::icon( 'stripe' ), 'status' => self::status( 'stripe' ), 'title' => 'Stripe', 'description' => sprintf( __( 'Get the publishable and secret keys in your %1$s. Test keys (pk_test_…) take test cards only. Step by step: %2$s.', 'remaily' ), $link( 'https://dashboard.stripe.com/apikeys', __( 'Stripe dashboard', 'remaily' ) ), $link( $docs . 'payment-field/', __( 'Payment field', 'remaily' ) ) ), 'fields' => [
					'key'    => [ 'type' => 'text', 'label' => __( 'Publishable key', 'remaily' ), 'default' => '' ],
					'secret' => [ 'type' => 'secret', 'label' => __( 'Secret key', 'remaily' ), 'default' => '' ],
				] ],
				/* translators: 1: link to the PayPal developer dashboard, 2: link to the Payment field page of the documentation */
				'paypal' => [ 'type' => 'section', 'layout' => 'card', 'icon' => \VLT\Remaily\Admin\Icons::icon( 'paypal' ), 'status' => self::status( 'paypal' ), 'title' => 'PayPal', 'description' => sprintf( __( 'Make an app in the %1$s and copy its client ID and secret. Step by step: %2$s.', 'remaily' ), $link( 'https://developer.paypal.com/dashboard/applications', __( 'PayPal developer dashboard', 'remaily' ) ), $link( $docs . 'payment-field/', __( 'Payment field', 'remaily' ) ) ), 'fields' => [
					'client' => [ 'type' => 'text', 'label' => __( 'Client ID', 'remaily' ), 'default' => '' ],
					'secret' => [ 'type' => 'secret', 'label' => __( 'Secret', 'remaily' ), 'default' => '' ],
					'mode'   => [
							'type'    => 'select',
							'as'      => 'checkbox',
							'checked' => 'sandbox',
							'label'   => __( 'Test payments (sandbox)', 'remaily' ),
							'options' => [ 'live' => __( 'Live', 'remaily' ), 'sandbox' => __( 'Sandbox (test)', 'remaily' ) ],
							'default' => 'live',
							'help'    => __( 'Sandbox takes the keys of a sandbox app and PayPal\'s test accounts.', 'remaily' ),
						],
				] ],
			],
		];

		return $sections;
	}
}
