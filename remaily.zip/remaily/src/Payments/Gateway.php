<?php

namespace VLT\Remaily\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment provider of the Payment field, through its REST API (no SDK); more through remaily_payment_gateways
 *
 * $payment: 'amount' (float), 'currency' (lowercase), 'description', 'reference' (form ID and field name), 'email'.
 *
 * The visitor pays in the form: start() makes the payment, the script of the same id (assets/js/payments.js, or
 * script() of an add-on, which adds its own to window.remailyPaymentProviders) shows it, and the form is sent again
 * with the payment's ID for check() and complete().
 */
interface Gateway {
	/**
	 * Its ID, as fields pick it and the script knows it: stripe
	 *
	 * @return string
	 */
	public function id();

	/**
	 * Its name, as visitors pick it and mails show it: Stripe
	 *
	 * @return string
	 */
	public function label();

	/**
	 * The currencies it takes, lowercase
	 *
	 * @return string[]
	 */
	public function currencies();

	/**
	 * Whether its keys are set
	 *
	 * @return bool
	 */
	public function ready();

	/**
	 * What its script needs besides the payment, such as the public key
	 *
	 * @return array
	 */
	public function client();

	/**
	 * Address of its script ('' = one of payments.js)
	 *
	 * @return string
	 */
	public function script();

	/**
	 * Start a payment: what the script needs to show it
	 *
	 * @param array $payment Payment
	 *
	 * @return array|\WP_Error
	 */
	public function start( array $payment );

	/**
	 * Whether a payment was made for this one and is not used yet; nothing changes
	 *
	 * @param string $id      The provider's payment ID
	 * @param array  $payment Payment
	 *
	 * @return bool
	 */
	public function check( $id, array $payment );

	/**
	 * Take the payment and mark it used, so it can't send a second message; called one request at a time per ID
	 *
	 * @param string $id The provider's payment ID
	 *
	 * @return bool
	 */
	public function complete( $id );
}
