<?php

namespace VLT\Remaily\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stripe, through Payment Intents: the form gets a client secret for the Payment Element, the server checks the
 * intent succeeded for the same amount and marks it used in its metadata
 */
class StripeGateway implements Gateway {
	const API = 'https://api.stripe.com/v1/';

	// Amounts without cents (Stripe's zero-decimal currencies among Payments::currencies())
	const ZERO_DECIMAL = [ 'jpy' ];

	/**
	 * Intents read in this request
	 *
	 * @var array
	 */
	private $intents = [];

	public function id() {
		return 'stripe';
	}

	public function label() {
		return 'Stripe';
	}

	public function currencies() {
		return Payments::COMMON;
	}

	public function ready() {
		$settings = Payments::settings();

		return '' !== (string) ( $settings['stripe']['key'] ?? '' ) && '' !== (string) ( $settings['stripe']['secret'] ?? '' );
	}

	public function client() {
		return [ 'key' => (string) ( Payments::settings()['stripe']['key'] ?? '' ) ];
	}

	public function script() {
		return '';
	}

	public function start( array $payment ) {
		$intent = $this->request( 'POST', 'payment_intents', array_filter( [
			'amount'                    => self::minor( $payment['amount'], $payment['currency'] ),
			'currency'                  => $payment['currency'],
			'description'               => $payment['description'],
			'receipt_email'             => $payment['email'],
			// Cards and wallets: a method that leaves the page would lose the form
			'automatic_payment_methods' => [ 'enabled' => 'true', 'allow_redirects' => 'never' ],
			'metadata'                  => [ 'remaily' => $payment['reference'] ],
		] ) );

		if ( is_wp_error( $intent ) ) {
			return $intent;
		}

		return [ 'secret' => (string) ( $intent['client_secret'] ?? '' ) ];
	}

	public function check( $id, array $payment ) {
		$intent = $this->intent( $id );

		return $intent
			&& 'succeeded' === ( $intent['status'] ?? '' )
			&& self::minor( $payment['amount'], $payment['currency'] ) === (int) ( $intent['amount_received'] ?? 0 )
			&& $payment['currency'] === ( $intent['currency'] ?? '' )
			&& $payment['reference'] === ( $intent['metadata']['remaily'] ?? '' )
			&& empty( $intent['metadata']['remaily_used'] );
	}

	public function complete( $id ) {
		// Read again, not from this request's copy: another message may have used it since (Payments holds a lock)
		$intent = $this->request( 'GET', 'payment_intents/' . rawurlencode( $id ) );

		if ( !is_array( $intent ) || !empty( $intent['metadata']['remaily_used'] ) ) {
			return false;
		}

		return !is_wp_error( $this->request( 'POST', 'payment_intents/' . rawurlencode( $id ), [ 'metadata' => [ 'remaily_used' => (string) time() ] ] ) );
	}

	/**
	 * An intent, read once per request
	 *
	 * @param string $id Intent ID
	 *
	 * @return array|null
	 */
	private function intent( $id ) {
		if ( !array_key_exists( $id, $this->intents ) ) {
			$intent = 0 === strpos( $id, 'pi_' ) ? $this->request( 'GET', 'payment_intents/' . rawurlencode( $id ) ) : null;

			$this->intents[ $id ] = is_array( $intent ) ? $intent : null;
		}

		return $this->intents[ $id ];
	}

	/**
	 * An amount in the currency's smallest unit, as Stripe takes it
	 *
	 * @param float  $amount   Amount
	 * @param string $currency Currency
	 *
	 * @return int
	 */
	private static function minor( $amount, $currency ) {
		return (int) round( $amount * ( in_array( $currency, self::ZERO_DECIMAL, true ) ? 1 : 100 ) );
	}

	/**
	 * A call to Stripe's API
	 *
	 * @param string $method GET or POST
	 * @param string $path   Path after /v1/
	 * @param array  $body   Parameters (form-encoded, nested as Stripe reads them)
	 *
	 * @return array|\WP_Error
	 */
	private function request( $method, $path, array $body = [] ) {
		$response = wp_remote_request( self::API . $path, [
			'method'  => $method,
			'timeout' => 15,
			'headers' => [ 'Authorization' => 'Bearer ' . (string) ( Payments::settings()['stripe']['secret'] ?? '' ) ],
			'body'    => $body ? http_build_query( $body ) : null,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$result = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( !is_array( $result ) || isset( $result['error'] ) ) {
			return new \WP_Error( 'remaily_stripe', (string) ( $result['error']['message'] ?? 'Stripe error' ) );
		}

		return $result;
	}
}
