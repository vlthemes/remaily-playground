<?php

namespace VLT\Remaily\Spam;

use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress's Disallowed Comment Keys (Settings → Discussion): a message with any of those words, addresses or IPs
 * is spam, as a comment would be trashed
 */
class Disallowed {
	/**
	 * Whether a value sent, the IP or the browser is on the list
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		if ( empty( Spam::settings()['disallowed'] ) || '' === trim( (string) get_option( 'disallowed_keys' ) ) || !Spam::enabled( $submission->form() ) ) {
			return false;
		}

		$text = [];

		foreach ( $submission->form()->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( $type && $type->submits() && 'file' !== $field['type'] ) {
				$value  = $submission->posted( $name );
				$text[] = is_array( $value ) ? implode( "\n", array_filter( $value, 'is_scalar' ) ) : (string) $value;
			}
		}

		return wp_check_comment_disallowed_list( '', '', '', implode( "\n", $text ), (string) $submission->meta( 'ip' ), (string) $submission->meta( 'user_agent' ) );
	}
}
