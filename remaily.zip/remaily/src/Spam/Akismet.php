<?php

namespace VLT\Remaily\Spam;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Akismet, when its plugin is set up: the sender's name, email and message are checked as a comment would be
 */
class Akismet {
	/**
	 * Whether Akismet is ready to use
	 *
	 * @return bool
	 */
	public static function available() {
		return is_callable( [ 'Akismet', 'get_api_key' ] ) && is_callable( [ 'Akismet', 'http_post' ] ) && \Akismet::get_api_key();
	}

	/**
	 * Ask Akismet
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		if ( empty( Spam::settings()['akismet'] ) || !self::available() || !Spam::enabled( $submission->form() ) ) {
			return false;
		}

		$params = [
			'blog'                 => home_url( '/' ),
			'user_ip'              => $submission->meta( 'ip' ),
			'user_agent'           => $submission->meta( 'user_agent' ),
			'referrer'             => $submission->meta( 'url' ),
			'permalink'            => $submission->meta( 'url' ),
			'comment_type'         => 'contact-form',
			'blog_lang'            => get_locale(),
			'blog_charset'         => get_option( 'blog_charset' ),
			'comment_author'       => '',
			'comment_author_email' => '',
			'comment_content'      => '',
		];

		// The first email, the first one-line text (a name) and the longer texts (the message)
		foreach ( $submission->form()->fields() as $name => $field ) {
			$value = $submission->posted( $name );
			$value = is_array( $value ) ? implode( ', ', array_filter( $value, 'is_scalar' ) ) : (string) $value;

			if ( 'email' === $field['type'] && '' === $params['comment_author_email'] ) {
				$params['comment_author_email'] = $value;
			} elseif ( 'text' === $field['type'] && '' === $params['comment_author'] ) {
				$params['comment_author'] = $value;
			} elseif ( 'textarea' === $field['type'] ) {
				$params['comment_content'] .= $value . "\n";
			}
		}

		$params   = (array) apply_filters( 'remaily_akismet_params', $params, $submission );
		$response = \Akismet::http_post( http_build_query( $params ), 'comment-check' );

		return isset( $response[1] ) && 'true' === trim( (string) $response[1] );
	}
}
