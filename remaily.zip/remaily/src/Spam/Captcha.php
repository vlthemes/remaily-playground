<?php

namespace VLT\Remaily\Spam;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Admin\Icons;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Captchas, set up once in Settings → Spam: Cloudflare Turnstile, hCaptcha and Google reCAPTCHA v3, any mix, on every
 * form unless a form skips them (Advanced). A message must pass each. Placed where [[captcha]] is, else before the
 * first submit button: the Submit field, or a <button> or <input type="submit"> in the markup; with none, at the end.
 */
class Captcha {
	const PROVIDERS = [
		'turnstile' => [
			'label'    => 'Cloudflare Turnstile',
			'script'   => 'https://challenges.cloudflare.com/turnstile/v0/api.js', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			'response' => 'cf-turnstile-response',
			'verify'   => 'https://challenges.cloudflare.com/turnstile/v0/siteverify', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			// It checks the secret before the answer, so a made-up answer tells whether the secret is right
			'check'    => true,
		],
		'hcaptcha'  => [
			'label'    => 'hCaptcha',
			'script'   => 'https://js.hcaptcha.com/1/api.js',
			'response' => 'h-captcha-response',
			'verify'   => 'https://api.hcaptcha.com/siteverify',
		],
		'recaptcha' => [
			'label'    => 'Google reCAPTCHA v3',
			'script'   => 'https://www.google.com/recaptcha/api.js',
			'response' => 'g-recaptcha-response',
			'verify'   => 'https://www.google.com/recaptcha/api/siteverify',
		],
		'smartcaptcha' => [
			'label'    => 'Yandex SmartCaptcha',
			'script'   => 'https://smartcaptcha.yandexcloud.net/captcha.js', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			'response' => 'smart-token',
			'verify'   => 'https://smartcaptcha.yandexcloud.net/validate', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			'check'    => true,
		],
	];

	// What is known of each secret: [ id => [ 'state' => ok|bad|unreachable|waiting, 'key' => hash of the secret ] ],
	// from a check when the keys are saved (Turnstile, SmartCaptcha) or from the last real answer checked (all of them)
	const STATUS = 'remaily_captcha_status';

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'remaily_token_captcha', [ __CLASS__, 'html' ], 10, 2 );
		add_filter( 'remaily_assets', [ __CLASS__, 'assets' ] );
		// Keys saved in Settings → Spam: ask each provider whether it knows the secret
		add_action( 'update_option_' . \VLT\Remaily\Admin\Settings::OPTION, [ __CLASS__, 'check_keys' ] );
		add_action( 'add_option_' . \VLT\Remaily\Admin\Settings::OPTION, [ __CLASS__, 'check_keys' ] );
		// Saved unchanged: no update_option hook, but a refused secret is asked again
		add_filter( 'pre_update_option_' . \VLT\Remaily\Admin\Settings::OPTION, [ __CLASS__, 'check_unchanged' ], 10, 2 );
	}

	/**
	 * Check the secrets when the settings are saved as they were
	 *
	 * @param mixed $value New value
	 * @param mixed $old   Saved value
	 *
	 * @return mixed
	 */
	public static function check_unchanged( $value, $old ) {
		if ( maybe_serialize( $value ) === maybe_serialize( $old ) ) {
			self::check_keys();
		}

		return $value;
	}

	/**
	 * Check the secrets that changed since the last check, or that the provider refused or couldn't be asked then
	 * (a refusal isn't kept: a captcha refused sits out of every form, so no real answer would clear it); a provider
	 * that can't be asked so waits for its first real answer
	 */
	public static function check_keys() {
		static $asked = [];

		$settings = Spam::settings();
		$status   = (array) get_option( self::STATUS, [] );

		foreach ( array_keys( self::PROVIDERS ) as $id ) {
			$secret = (string) ( $settings[ $id ]['secret'] ?? '' );

			if ( '' === $secret ) {
				unset( $status[ $id ] );
				continue;
			}

			$hash = md5( $secret );

			if ( isset( $asked[ $id . $hash ] ) ) {
				continue;
			}

			if ( ( $status[ $id ]['key'] ?? '' ) !== $hash || in_array( $status[ $id ]['state'] ?? '', [ 'unreachable', 'bad' ], true ) ) {
				$asked[ $id . $hash ] = true;
				$status[ $id ]        =[ 'state' => empty( self::PROVIDERS[ $id ]['check'] ) ? 'waiting' : self::check_secret( $id, $secret ), 'key' => $hash ];
			}
		}

		update_option( self::STATUS, $status, false );
	}

	/**
	 * Whether a provider accepts a secret: a made-up answer is refused either way, the error says which part was wrong
	 *
	 * @param string $id     Provider
	 * @param string $secret Secret key
	 *
	 * @return string ok, bad or unreachable
	 */
	private static function check_secret( $id, $secret ) {
		// SmartCaptcha expects "token" instead of "response"
		$body = 'smartcaptcha' === $id
			? [ 'secret' => $secret, 'token' => 'remaily-key-check' ]
			: [ 'secret' => $secret, 'response' => 'remaily-key-check' ];

		$response = wp_remote_post( self::PROVIDERS[ $id ]['verify'], [
			'timeout' => 10,
			'body'    => $body,
		] );
		$result   = is_wp_error( $response ) ? null : json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( !is_array( $result ) ) {
			return 'unreachable';
		}

		// SmartCaptcha turns a made-up token down ("failed") with a good key, and a wrong key with 403 or a message about it
		if ( 'smartcaptcha' === $id ) {
			return 403 === (int) wp_remote_retrieve_response_code( $response ) || false !== strpos( strtolower( (string) ( $result['message'] ?? '' ) ), 'secret' ) ? 'bad' : 'ok';
		}

		return array_intersect( [ 'invalid-input-secret', 'missing-input-secret' ], (array) ( $result['error-codes'] ?? [] ) ) ? 'bad' : 'ok';
	}

	/**
	 * A provider's state for Settings → Spam: [ label, tone ]
	 *
	 * @param string $id Provider
	 *
	 * @return array
	 */
	public static function status( $id ) {
		// The saved values as they are: Spam::settings() builds the settings sections, which ask for this status
		$settings = (array) ( ( (array) get_option( \VLT\Remaily\Admin\Settings::OPTION, [] ) )['spam'] ?? [] );
		$site     = !empty( $settings[ $id ]['site'] );
		$secret   = !empty( $settings[ $id ]['secret'] );

		if ( !$site && !$secret ) {
			return [ __( 'Not set up', 'remaily' ), 'muted' ];
		}

		if ( !$site || !$secret ) {
			return [ __( 'Needs both keys', 'remaily' ), 'warning' ];
		}

		switch ( ( (array) get_option( self::STATUS, [] ) )[ $id ]['state'] ?? '' ) {
			case 'ok':
				return [ __( 'Connected', 'remaily' ), 'success' ];

			case 'bad':
				return [ __( 'Secret key not accepted: not used', 'remaily' ), 'danger' ];

			case 'waiting':
				return [ __( 'Waiting for the first message', 'remaily' ), 'muted' ];

			default:
				return [ __( 'Not checked yet: save to check', 'remaily' ), 'muted' ];
		}
	}

	/**
	 * The providers with both keys, whichever forms they run on; one whose secret was refused sits out, or every
	 * message would be turned down (its state in Settings → Spam says why)
	 *
	 * @return array [ id => label ]
	 */
	public static function ready() {
		$settings = Spam::settings();
		$status   = (array) get_option( self::STATUS, [] );
		$ready    = [];

		foreach ( self::PROVIDERS as $id => $provider ) {
			$secret  = (string) ( $settings[ $id ]['secret'] ?? '' );
			$refused = 'bad' === ( $status[ $id ]['state'] ?? '' ) && md5( $secret ) === ( $status[ $id ]['key'] ?? '' );

			if ( !empty( $settings[ $id ]['site'] ) && '' !== $secret && !$refused ) {
				$ready[ $id ] = $provider['label'];
			}
		}

		return $ready;
	}

	/**
	 * The ready providers Settings → Spam runs on every form; the others run only on the forms that pick them
	 *
	 * @return array [ id => label ]
	 */
	public static function available() {
		$settings = Spam::settings();

		return array_filter( self::ready(), static fn( $id ) => 'off' !== ( $settings[ $id ]['use'] ?? 'all' ), ARRAY_FILTER_USE_KEY );
	}

	/**
	 * A provider's logo (assets/icons/{id}.svg)
	 *
	 * @param string $id Provider
	 *
	 * @return string SVG
	 */
	public static function logo( $id ) {
		return \VLT\Remaily\Admin\Icons::icon( $id );
	}

	/**
	 * The providers a form runs, by its Advanced → Captcha: '' the site's (those on every form), 'none', or one of
	 * them by its ID; a pick whose keys are gone falls back to the site's
	 *
	 * @param Form $form Form
	 *
	 * @return string[]
	 */
	public static function of( Form $form ) {
		$settings = $form->config()['settings'];
		$pick     = (string) ( $settings['captcha'] ?? '' );

		if ( 'none' === $pick || !Spam::enabled( $form ) ) {
			return [];
		}

		return isset( self::ready()[ $pick ] ) ? [ $pick ] : array_keys( self::available() );
	}

	/**
	 * The providers' scripts (captcha.js asks reCAPTCHA for a token and resets the widgets after sending)
	 *
	 * @param array $assets Handles
	 *
	 * @return array
	 */
	public static function assets( array $assets ) {
		$settings = Spam::settings();

		foreach ( self::PROVIDERS as $id => $provider ) {
			$url = 'recaptcha' === $id ? add_query_arg( 'render', rawurlencode( (string) ( $settings['recaptcha']['site'] ?? '' ) ), $provider['script'] ) : $provider['script'];

			$assets[ 'remaily-' . $id ] = [ 'url' => $url, 'version' => null ];
		}

		return $assets;
	}

	/**
	 * The widgets of a form's providers, Turnstile, hCaptcha and SmartCaptcha shown, reCAPTCHA's hidden field
	 *
	 * @param string $html Markup so far
	 * @param Form   $form Form
	 *
	 * @return string
	 */
	public static function html( $html, Form $form ) {
		$settings = Spam::settings();

		foreach ( self::of( $form ) as $id ) {
			$site = (string) $settings[ $id ]['site'];

			Assets::enqueue( 'remaily-' . $id );

			if ( 'recaptcha' === $id ) {
				// Invisible: captcha.js asks for a token as the form is sent, and loads the script then if something held it back
				// data-badge="hide": remaily.css hides Google's badge while this input is on the page
				$html .= sprintf( '<input type="hidden" name="g-recaptcha-response" value="" data-remaily-captcha="recaptcha" data-sitekey="%s" data-src="%s"%s>', esc_attr( $site ), esc_url( Assets::src( 'remaily-recaptcha' ) ), 'hide' === ( $settings['recaptcha']['badge'] ?? 'show' ) ? ' data-badge="hide"' : '' );

				continue;
			}

			// SmartCaptcha's widget is made by captcha.js (smartCaptcha.render), which gives the ID its reset needs
			$widget_class = [ 'turnstile' => 'cf-turnstile', 'hcaptcha' => 'h-captcha' ][ $id ] ?? '';

			$html .= sprintf(
				'<div class="%s" id="remaily-captcha-%s" data-remaily-captcha="%s" data-sitekey="%s"></div>',
				esc_attr( trim( 'remaily-captcha ' . $widget_class ) ),
				esc_attr( wp_unique_id() ),
				esc_attr( $id ),
				esc_attr( $site )
			);
		}

		return $html;
	}

	/**
	 * Whether the provider turned the submission down
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		/**
		 * Skip the captchas of a submission (a form sent again once paid: an answer works once)
		 *
		 * @param bool       $skip       Skip
		 * @param Submission $submission Submission
		 */
		if ( apply_filters( 'remaily_skip_captcha', false, $submission ) ) {
			return false;
		}

		$settings = Spam::settings();

		// Every provider the form runs must pass
		foreach ( self::of( $submission->form() ) as $id ) {
			$token = (string) $submission->raw( self::PROVIDERS[ $id ]['response'] );

			if ( '' === $token ) {
				return true;
			}

			// SmartCaptcha expects "token" and "ip" instead of "response" and "remoteip"
			$body = 'smartcaptcha' === $id
				? [
					'secret' => (string) $settings[ $id ]['secret'],
					'token'  => $token,
					'ip'     => $submission->meta( 'ip' ),
				]
				: [
					'secret'   => (string) $settings[ $id ]['secret'],
					'response' => $token,
					'remoteip' => $submission->meta( 'ip' ),
				];

			$response = wp_remote_post( self::PROVIDERS[ $id ]['verify'], [
				'timeout' => 10,
				'body'    => $body,
			] );

			// The provider can't be reached: let the message through rather than lose it
			if ( is_wp_error( $response ) ) {
				continue;
			}

			$result = (array) json_decode( (string) wp_remote_retrieve_body( $response ), true );

			self::remember( $id, (string) $settings[ $id ]['secret'], $result );

			// SmartCaptcha returns {"status":"ok"} on success
			if ( 'smartcaptcha' === $id ) {
				if ( ( $result['status'] ?? '' ) !== 'ok' ) {
					return true;
				}
			} else {
				if ( empty( $result['success'] ) ) {
					return true;
				}
			}

			if ( 'recaptcha' === $id && isset( $result['score'] ) && (float) $result['score'] < (float) ( $settings['recaptcha']['score'] ?? 0.5 ) ) {
				return true;
			}
		}

		return false;
	}


	/**
	 * What a real answer's check tells of the secret, kept for Settings → Spam (written only when it changes)
	 *
	 * @param string $id     Provider
	 * @param string $secret Secret key
	 * @param array  $result The provider's reply
	 */
	private static function remember( $id, $secret, array $result ) {
		if ( 'smartcaptcha' === $id ) {
			// SmartCaptcha: {"status":"ok"} or {"status":"failed","message":"..."}
			$message = strtolower( (string) ( $result['message'] ?? '' ) );
			$bad     = str_contains( $message, 'secret' );
			$state   = $bad ? 'bad' : ( ( $result['status'] ?? '' ) === 'ok' ? 'ok' : '' );
		} else {
			$bad   = (bool) array_intersect( [ 'invalid-input-secret', 'missing-input-secret' ], (array) ( $result['error-codes'] ?? [] ) );
			$state = $bad ? 'bad' : ( !empty( $result['success'] ) ? 'ok' : '' );
		}

		if ( '' === $state ) {
			return;
		}

		$status = (array) get_option( self::STATUS, [] );
		$entry  = [ 'state' => $state, 'key' => md5( $secret ) ];

		if ( ( $status[ $id ] ?? null ) !== $entry ) {
			$status[ $id ] = $entry;
			update_option( self::STATUS, $status, false );
		}
	}

}
