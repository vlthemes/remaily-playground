<?php

namespace VLT\Remaily\Spam;

use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Spam checks, run on every submission before anything else (remaily_spam): the honeypot, the time trap and the
 * rate limit (Settings → Spam), WordPress's Disallowed Comment Keys, the form's captcha, Akismet
 */
class Spam {
	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'remaily_spam', [ __CLASS__, 'check' ], 10, 2 );
		add_filter( 'remaily_hidden_inputs', [ TimeTrap::class, 'input' ], 10, 2 );
		add_filter( 'remaily_form_html', [ Honeypot::class, 'html' ], 10, 2 );
		Captcha::init();
	}

	/**
	 * Settings → Spam
	 *
	 * @return array
	 */
	public static function settings() {
		return Settings::get( 'spam' );
	}

	/**
	 * Whether a submission is spam: the first check that says so wins
	 *
	 * @param bool       $spam       Spam so far
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function check( $spam, Submission $submission ) {
		if ( $spam ) {
			return true;
		}

		foreach ( [ Honeypot::class, TimeTrap::class, Disallowed::class, RateLimit::class, Captcha::class, Akismet::class ] as $check ) {
			if ( $check::is_spam( $submission ) ) {
				do_action( 'remaily_spam_caught', $check, $submission );

				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a form is checked at all (a theme can turn the checks off for one)
	 *
	 * @param Form $form Form
	 *
	 * @return bool
	 */
	public static function enabled( Form $form ) {
		return (bool) apply_filters( 'remaily_spam_checks', true, $form );
	}
}
