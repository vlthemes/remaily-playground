<?php
/**
 * Functions for themes. Use these, not the classes, which may move.
 *
 * @package VLT\Remaily
 */

use VLT\Remaily\Admin\Transfer;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;
use VLT\Remaily\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's markup
 *
 * @param int|string $id   The form's hash (a1b2c3d), or its post ID
 * @param array      $args 'class', 'html_id', 'atts' (values for fields filled from shortcode attributes)
 *
 * @return string
 */
function remaily_render( $id, array $args = [] ) {
	return Renderer::render( is_int( $id ) ? $id : (string) $id, $args );
}

/**
 * A field's setting as visitors read it, as [[name:key]] prints it in the form ("10 MB" for a file's size)
 *
 *     echo esc_html( remaily_field_info( 'a1b2c3d', 'your_file', 'size' ) );
 *
 * @param int|string $form The form's hash or post ID
 * @param string     $name Field name
 * @param string     $key  size, types, min, max, amount… (Field::info())
 *
 * @return string '' when there is none
 */
function remaily_field_info( $form, $name, $key ) {
	$form  = Form::find( is_int( $form ) ? $form : (string) $form );
	$field = $form ? $form->field( (string) $name ) : null;
	$type  = $field ? FieldRegistry::get( $field['type'] ) : null;

	return $type ? (string) ( $type->info( $field )[ $key ]['value'] ?? '' ) : '';
}

/**
 * An icon of templates/icons/ (the theme's remaily/icons/ first)
 *
 * @param string $name  File name without .svg
 * @param string $class Class added to the <svg>
 *
 * @return string
 */
function remaily_icon( $name, $class = '' ) {
	return StyleManager::icon( $name, $class );
}

/**
 * Import forms, as Settings → Export & import does (a theme's demo setup, for example)
 *
 *     remaily_import_forms( get_template_directory() . '/demo/remaily-forms.json', true );
 *
 * @param string|array $source  A file path, a URL, JSON or the decoded data: an exported file or one form's code
 * @param bool         $replace Overwrite forms with the same shortcode instead of adding copies
 *
 * @return int[] [ added, replaced ]
 */
function remaily_import_forms( $source, $replace = false ) {
	return Transfer::import_source( $source, $replace );
}
