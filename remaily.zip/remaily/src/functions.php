<?php
/**
 * Functions for themes. Use these, not the classes, which may move.
 *
 * @package VLT\Remaily
 */

use VLT\Remaily\Admin\Icons;
use VLT\Remaily\Admin\Transfer;
use VLT\Remaily\Core\Html;
use VLT\Remaily\Entries\Entries;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;
use VLT\Remaily\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's markup
 *
 * @param string $id   The form's hash (a1b2c3d)
 * @param array      $args 'class', 'html_id', 'atts' (values for fields filled from shortcode attributes)
 *
 * @return string
 */
function remaily_render( $id, array $args = [] ) {
	return Renderer::render( (string) $id, $args );
}

/**
 * A field's setting as visitors read it, as [[name:key]] prints it in the form ("10 MB" for a file's size)
 *
 *     echo esc_html( remaily_field_info( 'a1b2c3d', 'your_file', 'size' ) );
 *
 * @param string     $form The form's hash
 * @param string     $name Field name
 * @param string     $key  size, types, min, max, amount… (Field::info())
 *
 * @return string '' when there is none
 */
function remaily_field_info( $form, $name, $key ) {
	$form  = Form::find( (string) $form );
	$field = $form ? $form->field( (string) $name ) : null;
	$type  = $field ? FieldRegistry::get( $field['type'] ) : null;

	return $type ? (string) ( $type->info( $field )[ $key ]['value'] ?? '' ) : '';
}

/**
 * An icon of templates/icons/ (the theme's remaily/icons/ first)
 *
 * @param string $name  File name without .svg
 * @param string $class Class added to the <svg>
 *
 * @return string
 */
function remaily_icon( $name, $class = '' ) {
	return StyleManager::icon( $name, $class );
}

/**
 * A brand logo for the admin (an add-on's card, Settings card or editor tab): one of Re:Maily's assets/icons/, or an
 * add-on's own registered with remaily_logos; printed through the page's sprite, one copy each, no request; '' for a
 * name it doesn't have
 *
 *     'icon' => remaily_logo( 'telegram' ),
 *
 *     // An add-on of your own: its logo by name, then the same function
 *     add_filter( 'remaily_logos', fn( $logos ) => $logos + [ 'my-crm' => MY_ADDON_PATH . 'assets/my-crm.svg' ] );
 *
 * @param string $name File name without .svg, such as telegram or google-sheets
 *
 * @return string
 */
function remaily_logo( $name ) {
	return Icons::icon( $name );
}

/**
 * A setting by its path: section, then its groups and the field
 *
 *     if ( 'off' !== remaily_get_setting( 'spam.turnstile.use' ) ) { … }
 *
 * @param string $path    Path, such as entries.uploads.folder
 * @param mixed  $default When it has no value
 *
 * @return mixed
 */
function remaily_get_setting( $path, $default = null ) {
	return \VLT\Remaily\Admin\Settings::value( (string) $path, $default );
}

/**
 * What wp_kses() needs to print this markup: its own tags and attributes, except what runs code
 *
 *     $form = remaily_render( 'a1b2c3d' );
 *
 *     echo wp_kses( $form, remaily_allowed_html( $form ) );
 *
 * @param string $html Markup
 *
 * @return array
 */
function remaily_allowed_html( $html ) {
	return Html::allowed( $html );
}

/**
 * Import forms, as Settings → Export & import does (a theme's demo setup, for example)
 *
 *     remaily_import_forms( get_template_directory() . '/demo/remaily-forms.json', true );
 *
 * @param string|array $source  A file path, a URL, JSON or the decoded data: an exported file or one form's code
 * @param bool         $replace Overwrite forms with the same shortcode instead of adding copies
 *
 * @return int[] [ added, replaced ]
 */
function remaily_import_forms( $source, $replace = false ) {
	return Transfer::import_source( $source, $replace );
}

/**
 * A form's saved entries, oldest first: for sending them somewhere else, such as a spreadsheet or a CRM
 *
 *     foreach ( remaily_get_entries( 42 ) as $entry ) {
 *         echo $entry['date'], ': ', $entry['values']['your_name'] ?? '';
 *     }
 *
 * @param int $form_id Form ID
 * @param int $limit   How many at most (0: all)
 *
 * @return array [ [ 'id', 'date', 'url', 'values' => [ name => text ] ] ]
 */
function remaily_get_entries( $form_id, $limit = 0 ) {
	return Entries::of_form( (int) $form_id, (int) $limit );
}
