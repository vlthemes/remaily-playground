<?php

namespace VLT\Remaily\Front;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\Messages;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Fields\Choice;
use VLT\Remaily\Fields\Field;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Forms\Places;
use VLT\Remaily\Forms\Repeater;
use VLT\Remaily\Forms\Template;
use VLT\Remaily\Submission\Conditions;
use VLT\Remaily\Submission\NoScript;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's markup: the wrapper, the <form>, each field's wrapper and control, the groups and the response box
 *
 * These carry what the script and the submission need, so no template can lose them; templates are what goes
 * around each control (fields/) and inside the response box (form/{style}/response.php).
 */
class Renderer {
	/**
	 * Forms rendered on this page
	 *
	 * @var int
	 */
	private static $count = 0;

	/**
	 * Forms rendered on this page, for the admin bar
	 *
	 * @var int[]
	 */
	private static $rendered = [];

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'detect' ], 20 );
		// Before the footer scripts print
		add_action( 'wp_footer', [ __CLASS__, 'admin_bar' ], 5 );
	}

	/**
	 * Admin bar menu of the forms this page shows, linked to their editor
	 */
	public static function admin_bar() {
		if ( !self::$rendered || !is_admin_bar_showing() ) {
			return;
		}

		$items = [];

		foreach ( array_unique( self::$rendered ) as $id ) {
			// No link when the user can't edit the form
			$link = get_edit_post_link( $id, 'raw' );

			if ( $link ) {
				$items[] = [
					'title' => get_the_title( $id ) ?: sprintf( '#%d', $id ),
					'url'   => $link,
				];
			}
		}

		if ( !$items ) {
			return;
		}

		Assets::enqueue( 'remaily-admin-bar' );
		Assets::data( 'remaily-admin-bar', 'remailyAdminBar', [
			'label' => __( 'Contact Form', 'remaily' ),
			'items' => $items,
		] );
	}

	/**
	 * The page's forms, found in its content, get their assets in <head>; any other loads them when rendered
	 */
	public static function detect() {
		if ( !is_singular() ) {
			return;
		}

		$content = (string) get_post_field( 'post_content', get_queried_object_id() );

		if ( false === strpos( $content, '[remaily' ) && false === strpos( $content, '<!-- wp:remaily/' ) ) {
			return;
		}

		// [remaily id="a1b2c3d"] or id="12"
		preg_match_all( '/\[remaily\s[^\]]*\bid=["\']?([a-f0-9]{7}|\d+)/', $content, $matches );

		$ids = $matches[1];

		// A block: its hash, else its post ID
		preg_match_all( '/<!-- wp:remaily\/form (\{[^}]*\})/', $content, $blocks );

		foreach ( $blocks[1] as $json ) {
			$attributes = (array) json_decode( $json, true );
			$ids[]      = (string) ( $attributes['hash'] ?? '' ) ?: (string) ( $attributes['id'] ?? '' );
		}

		foreach ( array_filter( $ids ) as $id ) {
			$form = Form::find( $id );

			if ( $form ) {
				self::enqueue( $form );
			}
		}
	}

	/**
	 * What the front script reads
	 *
	 * @return array
	 */
	public static function script_data() {
		return [
			'restUrl' => esc_url_raw( rest_url( 'remaily/v1/' ) ),
		];
	}

	/**
	 * Enqueue a form's script and styles
	 *
	 * @param Form $form Form
	 */
	public static function enqueue( Form $form ) {
		Assets::enqueue( 'remaily' );
		self::enqueue_styles( $form );

		do_action( 'remaily_enqueue', $form );
	}

	/**
	 * Every published form's styles, for the page builders' previews (Elementor, WPBakery), which
	 * render forms through AJAX or in a frame where a form's own enqueue never reaches
	 */
	public static function enqueue_all_styles() {
		foreach ( get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'fields' => 'ids' ] ) as $id ) {
			$form = Form::get( $id );

			if ( $form ) {
				self::enqueue_styles( $form );
			}
		}
	}

	/**
	 * A form's styles alone: its form style and its fields' (the block editor's canvas shows them without the script)
	 *
	 * @param Form $form Form
	 */
	public static function enqueue_styles( Form $form ) {
		static $settings_css = null;

		Assets::enqueue_style( 'remaily' );

		// The CSS of the settings with an output (an add-on's colors, say), once for every form
		if ( null === $settings_css ) {
			$settings_css = \VLT\Remaily\Admin\Settings::css();

			'' !== $settings_css && wp_add_inline_style( 'remaily', $settings_css );
		}

		// "Theme": the form's look is the theme's, no Re:Maily style loads
		if ( StyleManager::THEME === $form->style() ) {
			return;
		}

		StyleManager::enqueue( dirname( StyleManager::form_file( $form->style(), 'response.php' ) ), 'form' );

		foreach ( $form->fields() as $field ) {
			$template = StyleManager::field_template( $field['type'], $field['style'] ?: $form->style() );

			if ( $template ) {
				StyleManager::enqueue( dirname( $template ), 'fields' );
			}
		}
	}

	/**
	 * A form's markup
	 *
	 * @param int|Form $id   Form ID, or the form itself
	 * @param array    $args 'class', 'html_id', 'atts' (the shortcode's attributes, for fields filled from them)
	 *
	 * @return string
	 */
	public static function render( $id, array $args = [] ) {
		$form = $id instanceof Form ? $id : Form::find( $id );

		// A shortcode or element with no form picked yet: say so to those who can pick one
		if ( !$form && !$id ) {
			return current_user_can( 'edit_pages' ) ? '<p class="remaily-missing">' . esc_html__( 'Re:Maily: choose a form for this element.', 'remaily' ) . '</p>' : '';
		}

		if ( !$form || 'publish' !== $form->status() ) {
			/* translators: %s: form ID, such as a1b2c3d */
			return current_user_can( 'edit_pages' ) ? '<p class="remaily-missing">' . esc_html( sprintf( __( 'Re:Maily: form %s doesn\'t exist.', 'remaily' ), $form ? $form->hash() : sanitize_key( (string) $id ) ) ) . '</p>' : '';
		}

		// Logged-in users only, or closed (remaily_form_closed): a note instead of the form
		if ( !empty( $form->config()['settings']['subscribers_only'] ) && !is_user_logged_in() ) {
			self::enqueue( $form );

			return sprintf( '<div class="remaily remaily--%s is-locked"><div class="remaily-response">%s</div></div>', esc_attr( $form->style() ), self::response( $form, 'locked', Messages::get( $form, 'login_required' ) ) );
		}

		$closed = $form->closed();

		if ( '' !== $closed ) {
			self::enqueue( $form );

			return sprintf( '<div class="remaily remaily--%s is-locked"><div class="remaily-response">%s</div></div>', esc_attr( $form->style() ), self::response( $form, 'locked', $closed ) );
		}

		/**
		 * Render arguments of a form, wherever it is shown (a page, a widget, the editor's Preview)
		 *
		 * @param array $args 'class', 'html_id'
		 * @param Form  $form Form
		 */
		$args = (array) apply_filters( 'remaily_render_args', $args, $form );

		self::$count++;

		if ( $form->id() && $form === Form::get( $form->id() ) ) {
			self::$rendered[] = $form->id();
		}

		$uid    = sanitize_html_class( (string) ( $args['html_id'] ?? '' ) ) ?: 'remaily-' . $form->id() . ( self::$count > 1 ? '-' . self::$count : '' );
		$result = NoScript::result( $form->id(), $uid );
		$fields = [];
		$values = [];
		$ids    = [];
		$autofill = !empty( $form->config()['settings']['autocomplete'] );

		foreach ( $form->fields() as $name => $field ) {
			if ( !$autofill && array_key_exists( 'autocomplete', $field ) ) {
				$field['autocomplete'] = 'off';
			}

			$fields[ $name ] = (array) apply_filters( 'remaily_field', $field, $form );
			$values[ $name ] = $result && isset( $result['posted'][ $name ] ) && 'file' !== $field['type'] ? $result['posted'][ $name ] : ( empty( $fields[ $name ]['default_from'] ) ? $fields[ $name ]['default'] : Defaults::value( $fields[ $name ], (array) ( $args['atts'] ?? [] ) ) );
			$ids[ $name ]    = $fields[ $name ]['id'] ?: $uid . '-' . $name;
		}

		$ids['_uid'] = $uid;

		// A repeated field's values by row, sent back without the script; its rows start with the field's default
		$repeaters = Repeater::all( $form );
		$sent      = [];

		foreach ( $repeaters as $repeater ) {
			foreach ( $repeater['fields'] as $name ) {
				if ( isset( $fields[ $name ] ) && is_array( $values[ $name ] ) && $result && isset( $result['posted'][ $name ] ) ) {
					$sent[ $name ]   = $values[ $name ];
					$values[ $name ] = $fields[ $name ]['default'];
				}
			}
		}

		$hidden   = Conditions::hidden_groups( $form, $sent + $values );
		$errors   = $result['invalid'] ?? [];
		$response = self::response_box( $form, $result );
		$placed   = false;
		$captcha  = false !== strpos( $form->template(), '[[captcha]]' );

		[ $template, $rows ] = Repeater::extract( $form->template(), array_keys( $repeaters ) );

		// A token's HTML; in a repeated group's row, $row is [ group, row key ] and its fields are named for the row
		$closing = [];
		$render  = static function ( $token, $row = null ) use ( $form, $fields, $values, $sent, $ids, $errors, $hidden, $response, &$placed, &$captcha, &$closing ) {
			switch ( $token['kind'] ) {
				case 'field':
					$name = $token['name'];

					if ( !isset( $fields[ $name ] ) ) {
						return '';
					}

					if ( $row ) {
						$key   = Repeater::name( $row[0], $row[1], $name );
						$id    = $ids['_uid'] . '-' . $row[0] . '-' . $row[1] . '-' . $name;
						$value = isset( $sent[ $name ] ) ? ( $sent[ $name ][ $row[1] ] ?? '' ) : $values[ $name ];

						return self::field( $form, [ 'name' => $key ] + $fields[ $name ], [
							'id'       => $id,
							'value'    => $value,
							'values'   => $values,
							'ids'      => $ids,
							'invalid'  => isset( $errors[ $key ] ),
							'message'  => $errors[ $key ] ?? '',
							'error_id' => $id . '-error',
							'form'     => $form,
							'base'     => $name,
						] );
					}

					// The captcha goes before the first submit button, unless [[captcha]] places it
					$before = '';

					if ( 'submit' === $fields[ $name ]['type'] && !$captcha ) {
						$captcha = true;
						$before  = Places::render( 'captcha', $form );
					}

					return $before . self::field( $form, $fields[ $name ], [
						'id'       => $ids[ $name ],
						'value'    => $values[ $name ],
						'values'   => $values,
						'ids'      => $ids,
						'invalid'  => isset( $errors[ $name ] ),
						'message'  => $errors[ $name ] ?? '',
						'error_id' => $ids[ $name ] . '-error',
						'form'     => $form,
					] );

				case 'group':
					// A group inside a repeated one only wraps
					[ $open, $close ] = Groups::group( $form, $token['name'], (bool) $row, in_array( $token['name'], $hidden, true ) );
					$closing[]        = $close;

					return $open;

				case 'end':
					return (string) array_pop( $closing );

				case 'info':
					$field = $fields[ $token['name'] ] ?? null;
					$type  = $field ? FieldRegistry::get( $field['type'] ) : null;
					$info  = $type ? ( $type->info( $field, $values[ $token['name'] ] ?? '' )[ $token['key'] ] ?? null ) : null;

					if ( !$info ) {
						return '';
					}

					// Inside a tag's attribute it stays text; elsewhere a live one is a span the front script keeps up to date
					if ( empty( $info['live'] ) || !empty( $token['in_tag'] ) ) {
						return esc_html( (string) $info['value'] );
					}

					$count = mb_strlen( is_scalar( $values[ $token['name'] ] ?? '' ) ? (string) ( $values[ $token['name'] ] ?? '' ) : '' );
					$max   = (int) ( $field['maxlength'] ?? 0 );
					$min   = (int) ( $field['minlength'] ?? 0 );
					$state = $max && $count > $max ? ' is-over' : ( $min && $count && $count < $min ? ' is-under' : '' );

					return '<span' . Field::html_attributes( [
						'class'            => 'remaily-live' . $state,
						'data-remaily-live' => $token['name'] . ':' . $token['key'],
						'data-max'         => $max ?: null,
						'data-min'         => $min ?: null,
						'style'            => '--remaily-count:' . $count . ';--remaily-max:' . $max,
					] ) . '>' . esc_html( (string) $info['value'] ) . '</span>';

				case 'reserved':
					if ( 'response' === $token['name'] ) {
						$placed = true;

						return $response;
					}

					return Places::render( $token['name'], $form );
			}

			return '';
		};

		$html = Template::replace( $template, $render );

		foreach ( $repeaters as $group => $repeater ) {
			$html = str_replace( Repeater::marker( $group ), Groups::repeater( $form, $group, $repeater, $rows[ $group ] ?? '', $sent, $render, in_array( $group, $hidden, true ) ), $html );
		}

		// No [[captcha]] and no Submit field (a <button>, or an <a data-remaily-submit>, in the markup): before the first
		// submit button, else at the end
		if ( !$captcha ) {
			$widget = Places::render( 'captcha', $form );
			$at     = preg_match( '/<button\b(?![^>]*\btype\s*=\s*["\']?(?:button|reset)\b)[^>]*>|<input\b[^>]*\btype\s*=\s*["\']?(?:submit|image)\b[^>]*>|<a\b[^>]*\bdata-remaily-submit\b[^>]*>/i', $html, $button, PREG_OFFSET_CAPTURE ) ? $button[0][1] : strlen( $html );
			$html   = substr_replace( $html, $widget, $at, 0 );
		}

		if ( !$placed ) {
			$html .= $response;
		}

		$html = (string) apply_filters( 'remaily_form_html', $html, $form );

		$has_file = in_array( 'file', wp_list_pluck( $fields, 'type' ), true );
		$status   = $result['status'] ?? '';
		$action   = remove_query_arg( NoScript::QUERY_VAR );

		$attrs = (array) apply_filters( 'remaily_form_attributes', [
			'class'        => 'remaily__form',
			'method'       => 'post',
			'action'       => $action . '#' . $uid,
			'enctype'      => $has_file ? 'multipart/form-data' : null,
			'novalidate'   => true,
			'autocomplete' => $autofill ? null : 'off',
			'data-remaily'  => $form->id(),
			'data-nonce'   => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : null,
		], $form );

		$hidden_inputs = [
			'_remaily_form' => $form->id(),
			'_remaily_uid'  => $uid,
			'_remaily_post' => (int) get_queried_object_id(),
			// The visit's campaign tags (utm_source…), kept by the front script from the page it landed on
			'_remaily_utm'  => '',
		];

		$inputs = '';

		foreach ( (array) apply_filters( 'remaily_hidden_inputs', $hidden_inputs, $form ) as $name => $value ) {
			$inputs .= sprintf( '<input type="hidden" name="%s" value="%s">', esc_attr( $name ), esc_attr( (string) $value ) );
		}

		$classes = array_filter( [
			'remaily',
			'remaily--' . $form->style(),
			// What "selector" stands for in the form's CSS and JavaScript
			$form->hash() ? 'remaily-' . $form->hash() : '',
			$form->config()['settings']['class'],
			sanitize_text_field( (string) ( $args['class'] ?? '' ) ),
			$status ? 'is-' . $status : '',
		] );

		self::enqueue( $form );
		FormCode::add( $form, $html );

		/**
		 * A form was shown (a page, a widget, the editor's Preview): views for statistics
		 *
		 * @param Form  $form Form
		 * @param array $args Render arguments
		 */
		do_action( 'remaily_form_rendered', $form, $args );

		return sprintf(
			'<div class="%s" id="%s" data-remaily-config="%s"><form%s><div class="remaily__hidden" hidden>%s</div>%s</form></div>',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $uid ),
			// & as \u0026: esc_attr() would leave a message's own &amp; for the browser to decode
			esc_attr( (string) wp_json_encode( self::script_config( $form ), JSON_HEX_TAG | JSON_HEX_AMP ) ),
			Field::html_attributes( $attrs ),
			$inputs,
			$html
		);
	}

	/**
	 * A field: its wrapper, its template, its control and error
	 *
	 * @param Form  $form  Form
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return string
	 */
	private static function field( Form $form, array $field, array $ctx ) {
		$type = FieldRegistry::get( $field['type'] );

		if ( !$type ) {
			return '';
		}

		$control = (string) apply_filters( 'remaily_field_control', $type->control( $field, $ctx ), $field, $form );
		$error   = sprintf(
			'<span class="remaily-error" id="%s" data-remaily-error%s>%s</span>',
			esc_attr( $ctx['error_id'] ),
			$ctx['invalid'] ? '' : ' hidden',
			esc_html( $ctx['message'] )
		);

		$template = StyleManager::field_template( $field['type'], $field['style'] ?: $form->style() );
		$inner    = $template
			? StyleManager::render_template( $template, [
				'field'   => $field,
				'control' => $control,
				'choices' => $type->choices( $field, $ctx ),
				'error'   => $error,
				'form'    => $form,
			] )
			: $control . $error;

		$attrs = array_merge( [
			'class'             => 'remaily-field remaily-field--' . $field['type'] . ( $ctx['invalid'] ? ' is-invalid' : '' ),
			'data-remaily-field' => $field['name'],
			// A repeated row's field: its own name, for the conditions
			'data-remaily-name'  => $ctx['base'] ?? null,
			'data-remaily-type'  => $field['type'],
		], $type->wrapper_attributes( $field ) );

		return '<span' . Field::html_attributes( $attrs ) . '>' . $inner . '</span>';
	}

	/**
	 * The response box, with a result when the page shows one (a submission without the script)
	 *
	 * @param Form       $form   Form
	 * @param array|null $result Result
	 *
	 * @return string
	 */
	private static function response_box( Form $form, $result ) {
		return sprintf(
			'<div class="remaily-response" data-remaily-response role="status" aria-live="polite" aria-atomic="true">%s</div>',
			$result ? self::response( $form, $result['status'], $result['message'] ) : ''
		);
	}

	/**
	 * What the response box shows (form/{style}/response.php)
	 *
	 * @param Form   $form    Form
	 * @param string $status  success, invalid, failed, spam, aborted
	 * @param string $message Message
	 *
	 * @return string
	 */
	public static function response( Form $form, $status, $message ) {
		return StyleManager::render_template( StyleManager::form_file( $form->style(), 'response.php' ), [
			'status'  => $status,
			'message' => $message,
			'form'    => $form,
		] );
	}

	/**
	 * What the front script needs of a form: its groups' conditions and its messages
	 *
	 * @param Form $form Form
	 *
	 * @return array
	 */
	private static function script_config( Form $form ) {
		$ancestry = Template::ancestry( $form->template() );
		$groups   = [];

		foreach ( $ancestry['groups'] as $name => $parents ) {
			$group = ( $form->groups()[ $name ] ?? [ 'action' => 'show', 'match' => 'all', 'rules' => [] ] ) + [ 'parents' => $parents ];

			// A rule on an option's hidden value (an email, a phone) compares the code the page shows instead
			foreach ( $group['rules'] as $i => $rule ) {
				$type = FieldRegistry::get( $form->field( (string) $rule['field'] )['type'] ?? '' );

				if ( $type instanceof Choice ) {
					$group['rules'][ $i ]['value'] = Choice::shown( (string) $rule['value'] );
				}
			}

			$groups[ $name ] = $group;
		}

		return (array) apply_filters( 'remaily_script_config', [
			'groups'   => (object) $groups,
			'messages' => Messages::for_form( $form ),
			'redirect' => $form->config()['settings']['redirect'],
		], $form );
	}
}
