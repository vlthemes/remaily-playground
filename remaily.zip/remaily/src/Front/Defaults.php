<?php

namespace VLT\Remaily\Front;

use VLT\Remaily\Fields\Field;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Where a field's starting value comes from, as CF7's default: options: the URL, a POST, the shortcode, the page's
 * custom field or the logged-in user; the field's own default when that is empty
 */
class Defaults {
	// Sources read under a name: the field's own name unless 'default_key' gives another
	const NAMED = [ 'get', 'post', 'shortcode', 'post_meta' ];

	/**
	 * The sources the sidebar offers
	 *
	 * @return array [ id => label ]
	 */
	public static function sources() {
		return (array) apply_filters( 'remaily_default_sources', [
			''                  => __( 'Only the value above', 'remaily' ),
			'get'               => __( 'URL parameter (?name=…)', 'remaily' ),
			'post'              => __( 'Data posted to the page', 'remaily' ),
			'shortcode'         => __( 'Shortcode attribute', 'remaily' ),
			'post_meta'         => __( 'Custom field of the page', 'remaily' ),
			'user_email'        => __( 'User: email', 'remaily' ),
			'user_display_name' => __( 'User: display name', 'remaily' ),
			'user_first_name'   => __( 'User: first name', 'remaily' ),
			'user_last_name'    => __( 'User: last name', 'remaily' ),
			'user_nickname'     => __( 'User: nickname', 'remaily' ),
			'user_login'        => __( 'User: username', 'remaily' ),
			'user_url'          => __( 'User: website', 'remaily' ),
		] );
	}

	/**
	 * A field's starting value
	 *
	 * @param array $field Field, with 'name'
	 * @param array $atts  The shortcode's attributes
	 *
	 * @return string|string[]
	 */
	public static function value( array $field, array $atts = [] ) {
		$from  = (string) ( $field['default_from'] ?? '' );
		$key   = (string) ( $field['default_key'] ?? '' ) ?: $field['name'];
		$value = '';

		// phpcs:disable WordPress.Security.NonceVerification -- read to fill a field, as a link or another form asks
		switch ( $from ) {
			case 'get':
				$value = isset( $_GET[ $key ] ) ? wp_unslash( $_GET[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned below
				break;

			case 'post':
				// Not Remaily's own POST: a form sent without the script shows what was posted anyway
				$value = isset( $_POST[ $key ] ) && !isset( $_POST['_remaily_form'] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned below
				break;

			case 'shortcode':
				// WordPress lowercases attribute names
				$value = $atts[ strtolower( $key ) ] ?? '';
				break;

			case 'post_meta':
				$post  = get_queried_object_id();
				$value = $post && !is_protected_meta( $key, 'post' ) ? get_post_meta( $post, $key, true ) : '';
				break;

			case '':
				break;

			default:
				if ( 0 === strpos( $from, 'user_' ) && is_user_logged_in() ) {
					// user_email, user_login and user_url are named so on the user; the others without "user_"
					$value = wp_get_current_user()->get( in_array( $from, [ 'user_email', 'user_login', 'user_url' ], true ) ? $from : substr( $from, 5 ) );
				}
		}
		// phpcs:enable

		$value = apply_filters( 'remaily_default_value', $value, $field, $from, $key );
		$value = is_array( $value ) ? array_values( array_filter( array_map( 'sanitize_text_field', array_filter( $value, 'is_scalar' ) ), 'strlen' ) ) : sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );

		return Field::is_empty( $value ) ? $field['default'] : $value;
	}
}
