<?php

namespace VLT\Remaily\Front;

use VLT\Remaily\Core\IdList;
use VLT\Remaily\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remaily templates. Any file in templates/ can be overridden at your-theme/remaily/{path}.
 *
 *     form/{style}/          response.php, style.css: the form's look (the built-in one also styles its fields)
 *     fields/{type}/{style}/ field.php (+ style.css): around a field's control; fields/{kind}/{style}/ for every
 *                            type of a kind (input: text, email, url, tel, number, date; choices: checkbox, radio)
 *     mail/ preview/ icons/
 *
 * A new folder in your-theme/remaily/form/ or fields/{type|kind}/ is a new style, offered in the editor.
 *
 *     add_filter( 'remaily_default_styles', '__return_false' );   // drop the plugin's own look
 *     add_filter( 'remaily_exclude_styles', fn( $ids, $kind ) => 'form' === $kind ? [ 'default' ] : $ids, 10, 2 );
 */
class StyleManager {
	// The form style that loads no Remaily styles: the theme styles the form
	const THEME = 'theme';

	/**
	 * Child theme, parent theme, plugin, then add-ons
	 *
	 * @return array [ [ path, url ], … ]
	 */
	public static function roots() {
		$relative = 'remaily/';
		$roots    = [ [ trailingslashit( get_stylesheet_directory() ) . $relative, trailingslashit( get_stylesheet_directory_uri() ) . $relative ] ];

		if ( get_template_directory() !== get_stylesheet_directory() ) {
			$roots[] = [ trailingslashit( get_template_directory() ) . $relative, trailingslashit( get_template_directory_uri() ) . $relative ];
		}

		$roots[] = [ REMAILY_PATH . 'templates/', REMAILY_URL . 'templates/' ];

		/**
		 * Template folders after the theme's and the plugin's: an add-on's own (its field types), which a theme's
		 * remaily/ folder still overrides
		 *
		 *     add_filter( 'remaily_template_roots', fn( $roots ) => array_merge( $roots, [ [ MY_PATH . 'templates/', MY_URL . 'templates/' ] ] ) );
		 *
		 * @param array $roots [ [ path, url ], … ]
		 */
		return (array) apply_filters( 'remaily_template_roots', $roots );
	}

	/**
	 * Locate a file in the templates tree
	 *
	 * @param string $relative Path, e.g. fields/input/default/field.php
	 *
	 * @return array|null [ path, url ]
	 */
	public static function locate_file( $relative ) {
		// No way out of the tree
		if ( !preg_match( '#^[a-z0-9_-]+(?:/[a-z0-9_-]+)*\.(?:php|css|js|svg)$#', $relative ) ) {
			return null;
		}

		$found = null;

		foreach ( self::roots() as [ $path, $url ] ) {
			if ( is_file( $path . $relative ) ) {
				$found = [ $path . $relative, $url . $relative ];
				break;
			}
		}

		// [ path, url ]
		$found = apply_filters( 'remaily_template', $found, $relative );

		return is_array( $found ) && !empty( $found[0] ) && is_file( $found[0] ) ? $found : null;
	}

	/**
	 * Render a template
	 *
	 * @param string $relative Path, e.g. mail/html.php
	 * @param array  $vars     Variables
	 *
	 * @return string
	 */
	public static function render_template( $relative, array $vars ) {
		ob_start();

		self::print_template( $relative, $vars );

		return (string) ob_get_clean();
	}

	/**
	 * Print a template; it escapes what it prints
	 *
	 * @param string $relative Path in templates/
	 * @param array  $vars     Variables
	 */
	public static function print_template( $relative, array $vars ) {
		$template = self::locate_file( $relative );

		if ( !$template ) {
			return;
		}

		$vars = (array) apply_filters( 'remaily_template_vars', $vars, $relative );

		( static function ( $__template, $__vars ) {
			extract( $__vars, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			include $__template;
		} )( $template[0], $vars );
	}

	/**
	 * An icon of templates/icons/, the theme's copy first
	 *
	 * @param string $name  File name without .svg
	 * @param string $class Class added to the <svg>
	 *
	 * @return string SVG markup, hidden from screen readers ('' when there is no such icon)
	 */
	public static function icon( $name, $class = '' ) {
		static $cache = [];

		$key = $name . '|' . $class;

		if ( !isset( $cache[ $key ] ) ) {
			$file = self::locate_file( 'icons/' . sanitize_key( $name ) . '.svg' );
			$svg  = $file ? trim( (string) file_get_contents( $file[0] ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
			$svg  = preg_replace( '#^.*?(?=<svg[\s>])#s', '', $svg );

			if ( $svg ) {
				$svg = preg_replace( '#^<svg#', '<svg aria-hidden="true" focusable="false"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ), $svg );
			}

			$cache[ $key ] = (string) apply_filters( 'remaily_icon', $svg, $name, $class );
		}

		return $cache[ $key ];
	}

	/**
	 * The styles offered: form styles, or a field type's
	 *
	 * @param string $kind form or fields
	 * @param string $type Field type (fields)
	 *
	 * @return array [ id => label ]
	 */
	public static function styles( $kind = 'form', $type = '' ) {
		$dirs = [ 'form' ];

		if ( 'fields' === $kind ) {
			$field = FieldRegistry::get( $type );
			$dirs  = $field ? array_unique( [ 'fields/' . $field->type(), 'fields/' . $field->kind() ] ) : [];
		}

		$styles = [];

		foreach ( self::roots() as [ $path ] ) {
			foreach ( $dirs as $dir ) {
				foreach ( (array) glob( $path . $dir . '/*', GLOB_ONLYDIR ) as $folder ) {
					$id = sanitize_key( basename( (string) $folder ) );

					if ( $id ) {
						$styles[ $id ] = 'default' === $id ? __( 'Re:Maily style', 'remaily' ) : ucwords( str_replace( [ '-', '_' ], ' ', $id ) );
					}
				}
			}
		}

		// A form can leave its whole look to the theme: no Remaily styles at all
		if ( 'form' === $kind ) {
			$styles[ self::THEME ] = __( 'Inherit from theme', 'remaily' );
		}

		// Remaily's own first, the theme's look second, then the other styles
		$order = [ 'default' => 0, self::THEME => 1 ];

		uksort( $styles, static fn( $a, $b ) => ( $order[ $a ] ?? 2 ) <=> ( $order[ $b ] ?? 2 ) ?: strcmp( $a, $b ) );

		$styles = (array) apply_filters( 'remaily_styles', $styles, $kind, $type );

		return IdList::apply(
			$styles,
			(array) apply_filters( 'remaily_include_styles', [], $kind, $type ),
			(array) apply_filters( 'remaily_exclude_styles', [], $kind, $type )
		);
	}

	/**
	 * The template of a field: the type's own style, the kind's, then their defaults
	 *
	 * @param string $type  Field type
	 * @param string $style Style
	 *
	 * @return string|null Path relative to the templates tree
	 */
	public static function field_template( $type, $style ) {
		$field = FieldRegistry::get( $type );

		if ( !$field ) {
			return null;
		}

		$style = sanitize_key( $style ) ?: 'default';

		foreach ( array_unique( [ $style, 'default' ] ) as $id ) {
			foreach ( array_unique( [ $field->type(), $field->kind() ] ) as $dir ) {
				$relative = 'fields/' . $dir . '/' . $id . '/field.php';

				if ( self::locate_file( $relative ) ) {
					return $relative;
				}
			}
		}

		return null;
	}

	/**
	 * A file of a form style, the default style's when it has none
	 *
	 * @param string $style Style
	 * @param string $file  File name
	 *
	 * @return string Path relative to the templates tree
	 */
	public static function form_file( $style, $file ) {
		$relative = 'form/' . ( sanitize_key( $style ) ?: 'default' ) . '/' . $file;

		return self::locate_file( $relative ) ? $relative : 'form/default/' . $file;
	}

	/**
	 * Enqueue the style.css (and script.js) of a style folder
	 *
	 * @param string $dir  Folder relative to the templates tree, e.g. form/default
	 * @param string $kind form or fields
	 */
	public static function enqueue( $dir, $kind ) {
		$handle = 'remaily-' . str_replace( '/', '-', $dir );
		$style  = self::locate_file( $dir . '/style.css' );
		$script = self::locate_file( $dir . '/script.js' );

		// The plugin's own look can be turned off; a theme's copy always loads
		if ( $style && ( !self::is_plugin_file( $style[0] ) || self::default_styles( $kind, basename( $dir ) ) ) ) {
			wp_enqueue_style( $handle, $style[1], [ 'remaily' ], (string) filemtime( $style[0] ) );
			// Printed inline when small enough, as WordPress does with block styles
			wp_style_add_data( $handle, 'path', $style[0] );
		}

		if ( $script ) {
			wp_enqueue_script( $handle, $script[1], [ 'remaily' ], (string) filemtime( $script[0] ), [ 'in_footer' => true, 'strategy' => 'defer' ] );
		}
	}

	/**
	 * Whether the plugin's own look loads (remaily_default_styles); a theme returns false to style it all itself
	 *
	 * @param string $kind form or fields
	 * @param string $id   Style ID
	 *
	 * @return bool
	 */
	public static function default_styles( $kind, $id = '' ) {
		return (bool) apply_filters( 'remaily_default_styles', !defined( 'REMAILY_DEFAULT_STYLES' ) || REMAILY_DEFAULT_STYLES, $kind, $id );
	}

	/**
	 * Whether a file is the plugin's or an add-on's own look, not a theme's copy in its remaily/ folder
	 *
	 * @param string $path File path
	 *
	 * @return bool
	 */
	private static function is_plugin_file( $path ) {
		$path = wp_normalize_path( $path );

		foreach ( array_unique( [ get_stylesheet_directory(), get_template_directory() ] ) as $theme ) {
			if ( 0 === strpos( $path, trailingslashit( wp_normalize_path( $theme ) ) . 'remaily/' ) ) {
				return false;
			}
		}

		return true;
	}
}
