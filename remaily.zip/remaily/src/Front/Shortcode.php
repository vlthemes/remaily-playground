<?php

namespace VLT\Remaily\Front;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * [remaily id="a1b2c3d" class="" html_id=""] (form="a1b2c3d" works as id) (the form's hash); any other attribute fills the field
 * that reads it
 */
class Shortcode {
	const TAG = 'remaily';

	/**
	 * Init
	 */
	public static function init() {
		add_shortcode( self::TAG, [ __CLASS__, 'render' ] );
	}

	/**
	 * Render
	 *
	 * @param array|string $atts Attributes
	 *
	 * @return string
	 */
	public static function render( $atts ) {
		$all  = (array) $atts;
		$atts = shortcode_atts( [
			'id'      => 0,
			// The same, as page builders save it (WPBakery's element): "id" is often their element's own
			'form'    => '',
			'class'   => '',
			'html_id' => '',
		], $all, self::TAG );

		// The other attributes fill fields set to "Fill from: Shortcode attribute"
		return Renderer::render( (string) ( $atts['form'] ?: $atts['id'] ), [
			'class'   => $atts['class'],
			'html_id' => $atts['html_id'],
			'atts'    => array_diff_key( $all, $atts ),
		] );
	}
}
