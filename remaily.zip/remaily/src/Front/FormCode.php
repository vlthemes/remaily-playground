<?php

namespace VLT\Remaily\Front;

use VLT\Remaily\Forms\Form;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's own CSS and JavaScript (Advanced → CSS, JavaScript) and the <style> blocks of its markup, in the page's
 * styles and scripts: once per form, wherever it shows; "selector" stands for the form's wrapper
 */
class FormCode {
	/**
	 * The form's CSS and JavaScript tabs, and the <style> blocks of its markup, in the page's styles and scripts:
	 * once per form, wherever it shows
	 *
	 * @param Form   $form Form
	 * @param string $html The form's markup; its <style> blocks are taken out
	 */
	public static function add( Form $form, &$html ) {
		static $done = [];

		$styles = [];
		$html   = (string) preg_replace_callback(
			'#<style\b[^>]*>(.*?)</style>#is',
			static function ( $m ) use ( &$styles ) {
				$styles[] = $m[1];

				return '';
			},
			$html
		);

		$hash = $form->hash();

		if ( !$hash || isset( $done[ $hash ] ) ) {
			return;
		}

		$done[ $hash ] = true;
		$scope         = '.remaily-' . $hash;
		$css           = trim( implode( "\n", array_merge( $styles, [ (string) preg_replace( '/\bselector\b/', $scope, (string) ( $form->config()['settings']['css'] ?? '' ) ) ] ) ) );
		$js            = trim( (string) ( $form->config()['settings']['js'] ?? '' ) );

		if ( '' !== $css ) {
			$handle = 'remaily-form-' . $hash;

			// Its own handle: printed in the footer when the page's <head> is already out
			wp_register_style( $handle, false, [], null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- inline only
			wp_enqueue_style( $handle );
			wp_add_inline_style( $handle, $css );
		}

		if ( '' !== $js ) {
			// Once each copy of the form is ready: root is its wrapper, form the <form>
			wp_add_inline_script(
				'remaily',
				sprintf(
					'document.querySelectorAll(%1$s).forEach(function(root){var form=root.querySelector("form"),run=function(){try{(function(root,form){%2$s' . "\n" . '}).call(root,root,form);}catch(e){console.error(e);}};form&&form.remailyReady?run():root.addEventListener("remaily:ready",run,{once:true});});',
					wp_json_encode( $scope ),
					$js
				)
			);
		}
	}
}
