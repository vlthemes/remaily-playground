<?php

namespace VLT\Remaily\Forms;

use VLT\Remaily\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Repeated groups: a group with "repeat" on, whose part of the form visitors add again as rows
 *
 * A row's controls are named group[row][field] (rows[0][phone]); the submission keeps each field's values by row, so
 * [phone] in a mail lists them all, [rows] prints the rows as a table and [group:rows] … [/group:rows] repeats its
 * text for each row. Only the outermost repeated group repeats; a group inside it is a plain wrapper, always shown.
 */
class Repeater {
	// Rows a form takes at most, whatever a group's max
	const LIMIT = 50;

	/**
	 * A form's repeated groups with the fields in them
	 *
	 * @param Form $form Form
	 *
	 * @return array [ group => [ 'fields' => [ name, … ], 'min', 'max', 'add', 'remove' ] ]
	 */
	public static function all( Form $form ) {
		static $cache = [];

		$groups = $form->groups();
		$key    = md5( $form->template() . wp_json_encode( $groups ) );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$ancestry = Template::ancestry( $form->template() );
		$repeated = [];

		foreach ( $ancestry['groups'] as $name => $parents ) {
			if ( !empty( $groups[ $name ]['repeat'] ) && !self::inside( $parents, $groups ) ) {
				$repeated[ $name ] = [ 'fields' => [] ] + $groups[ $name ];
			}
		}

		foreach ( $ancestry['fields'] as $field => $parents ) {
			foreach ( $parents as $parent ) {
				if ( isset( $repeated[ $parent ] ) ) {
					$repeated[ $parent ]['fields'][] = $field;
					break;
				}
			}
		}

		$cache[ $key ] = $repeated;

		return $repeated;
	}

	/**
	 * The repeated group a field is in, '' for none
	 *
	 * @param Form   $form Form
	 * @param string $name Field name
	 *
	 * @return string
	 */
	public static function of( Form $form, $name ) {
		foreach ( self::all( $form ) as $group => $repeater ) {
			if ( in_array( $name, $repeater['fields'], true ) ) {
				return $group;
			}
		}

		return '';
	}

	/**
	 * The groups inside a repeated one: plain wrappers, never hidden
	 *
	 * @param Form $form Form
	 *
	 * @return string[]
	 */
	public static function inner_groups( Form $form ) {
		$groups = $form->groups();
		$inner  = [];

		foreach ( Template::ancestry( $form->template() )['groups'] as $name => $parents ) {
			if ( self::inside( $parents, $groups ) ) {
				$inner[] = $name;
			}
		}

		return $inner;
	}

	/**
	 * Whether one of these groups repeats
	 *
	 * @param string[] $parents Group names
	 * @param array    $groups  The form's groups
	 *
	 * @return bool
	 */
	private static function inside( array $parents, array $groups ) {
		foreach ( $parents as $parent ) {
			if ( !empty( $groups[ $parent ]['repeat'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A row control's name
	 *
	 * @param string     $group Group
	 * @param int|string $row   Row key
	 * @param string     $field Field name
	 *
	 * @return string
	 */
	public static function name( $group, $row, $field ) {
		return $group . '[' . $row . '][' . $field . ']';
	}

	/**
	 * The template with each repeated group's part taken out and a marker left in its place
	 *
	 * @param string   $html  Template
	 * @param string[] $names Repeated groups
	 *
	 * @return array [ template, [ group => its inner template ] ]
	 */
	public static function extract( $html, array $names ) {
		$html  = (string) $html;
		$inner = [];

		if ( !$names ) {
			return [ $html, $inner ];
		}

		preg_match_all( Template::TOKEN, $html, $matches, PREG_OFFSET_CAPTURE );

		$out   = '';
		$at    = 0;
		$open  = null;
		$depth = 0;

		foreach ( $matches[1] as $i => $match ) {
			$token = $match[0];
			$start = $matches[0][ $i ][1];
			$end   = $start + strlen( $matches[0][ $i ][0] );

			if ( null === $open ) {
				if ( 0 === strpos( $token, 'group:' ) && in_array( substr( $token, 6 ), $names, true ) ) {
					$open  = [ substr( $token, 6 ), $end ];
					$depth = 1;
					$out  .= substr( $html, $at, $start - $at ) . self::marker( $open[0] );
				}

				continue;
			}

			if ( 0 === strpos( $token, 'group:' ) ) {
				$depth++;
			} elseif ( '/group' === $token && 0 === --$depth ) {
				$inner[ $open[0] ] = substr( $html, $open[1], $start - $open[1] );
				$at                = $end;
				$open              = null;
			}
		}

		// A repeated group left open runs to the end
		if ( null !== $open ) {
			$inner[ $open[0] ] = substr( $html, $open[1] );

			return [ $out, $inner ];
		}

		return [ $out . substr( $html, $at ), $inner ];
	}

	/**
	 * What stands for a repeated group in the template until its rows are printed
	 *
	 * @param string $group Group
	 *
	 * @return string
	 */
	public static function marker( $group ) {
		return '<!--remaily-repeat:' . $group . '-->';
	}

	/**
	 * The row keys sent for a group, at most its max
	 *
	 * @param array  $request Request data
	 * @param string $name    Group
	 * @param array  $group   Repeated group
	 *
	 * @return int[]
	 */
	public static function rows( array $request, $name, array $group ) {
		$rows = is_array( $request[ $name ] ?? null ) ? array_filter( array_keys( $request[ $name ] ), static fn( $key ) => is_int( $key ) && $key >= 0 ) : [];

		return array_slice( array_values( $rows ), 0, $group['max'] ?: self::LIMIT );
	}

	/**
	 * The request as a row's controls see it: their values under their own names (rows[0][phone])
	 *
	 * @param array    $request Request data
	 * @param string   $group   Group
	 * @param int      $row     Row key
	 * @param string[] $fields  Field names
	 *
	 * @return array
	 */
	public static function row_request( array $request, $group, $row, array $fields ) {
		$values = (array) ( $request[ $group ][ $row ] ?? [] );

		foreach ( $fields as $field ) {
			$request[ self::name( $group, $row, $field ) ] = $values[ $field ] ?? null;
		}

		return $request;
	}

	/**
	 * A row field's upload in the usual $_FILES shape, from the group's nested one
	 *
	 * @param array  $files Uploaded files
	 * @param string $group Group
	 * @param int    $row   Row key
	 * @param string $field Field name
	 *
	 * @return array|null
	 */
	public static function row_upload( array $files, $group, $row, $field ) {
		if ( empty( $files[ $group ]['name'][ $row ] ) || !array_key_exists( $field, (array) $files[ $group ]['name'][ $row ] ) ) {
			return null;
		}

		$upload = [];

		foreach ( [ 'name', 'type', 'tmp_name', 'error', 'size' ] as $key ) {
			$upload[ $key ] = $files[ $group ][ $key ][ $row ][ $field ] ?? null;
		}

		return $upload;
	}

	/**
	 * The rows of a group as text values: [ row => [ field => text ] ]
	 *
	 * @param Form  $form   Form
	 * @param array $group  Repeated group
	 * @param array $posted Clean values by field name, a repeated field's by row
	 * @param bool  $raw    Option values, not labels
	 *
	 * @return array
	 */
	public static function texts( Form $form, array $group, array $posted, $raw = false ) {
		$rows = [];

		foreach ( $group['fields'] as $name ) {
			$field = $form->field( $name );
			$type  = $field ? FieldRegistry::get( $field['type'] ) : null;

			if ( !$type || !$type->submits() ) {
				continue;
			}

			foreach ( (array) ( $posted[ $name ] ?? [] ) as $row => $value ) {
				$rows[ $row ][ $name ] = $type->mail_value( $value, $field, $raw );
			}
		}

		return array_values( $rows );
	}

	/**
	 * Rows as a mail prints them: a table in HTML, a line per row in text
	 *
	 * @param array $rows Rows of texts
	 * @param bool  $html HTML
	 *
	 * @return string
	 */
	public static function table( array $rows, $html ) {
		if ( !$rows ) {
			return '';
		}

		$names = array_keys( (array) reset( $rows ) );

		if ( !$html ) {
			return implode( "\n", array_map( static fn( $row ) => implode( ', ', array_map( static fn( $name, $value ) => $name . ': ' . $value, array_keys( $row ), $row ) ), $rows ) );
		}

		$cell = 'style="padding:6px 10px;border:1px solid #dcdcde;text-align:left;vertical-align:top"';
		$head = implode( '', array_map( static fn( $name ) => '<th ' . $cell . '>' . esc_html( $name ) . '</th>', $names ) );
		$body = implode( '', array_map( static fn( $row ) => '<tr>' . implode( '', array_map( static fn( $name ) => '<td ' . $cell . '>' . nl2br( esc_html( (string) ( $row[ $name ] ?? '' ) ) ) . '</td>', $names ) ) . '</tr>', $rows ) );

		return '<table style="border-collapse:collapse" cellspacing="0"><thead><tr>' . $head . '</tr></thead><tbody>' . $body . '</tbody></table>';
	}
}
