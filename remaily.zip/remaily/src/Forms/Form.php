<?php

namespace VLT\Remaily\Forms;

use VLT\Remaily\Core\Config;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One form: its template and settings
 */
class Form {
	// The shortcode ID: [remaily id="a1b2c3d"]
	const HASH = '_remaily_hash';

	/**
	 * Post
	 *
	 * @var \WP_Post
	 */
	private $post;

	/**
	 * Settings, read once
	 *
	 * @var array|null
	 */
	private $config = null;

	/**
	 * Placed fields, read once
	 *
	 * @var array|null
	 */
	private $fields = null;

	/**
	 * Forms read on this request
	 *
	 * @var Form[]
	 */
	private static $cache = [];

	/**
	 * A form by ID
	 *
	 * @param int $id Form ID
	 *
	 * @return Form|null
	 */
	public static function get( $id ) {
		$id = (int) $id;

		if ( !isset( self::$cache[ $id ] ) ) {
			$post = $id ? get_post( $id ) : null;

			if ( !$post || PostType::NAME !== $post->post_type || 'trash' === $post->post_status ) {
				return null;
			}

			self::$cache[ $id ] = new self( $post );
		}

		return self::$cache[ $id ];
	}

	/**
	 * Published forms for a page builder's picker, by hash (it survives export and import); the hash after the title
	 * tells two forms of the same title apart
	 *
	 * @return array [ hash => "Title (a1b2c3d)" ]
	 */
	public static function choices() {
		$choices = [];

		foreach ( get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] ) as $post ) {
			$hash             = self::hash_of( $post->ID );
			$choices[ $hash ] = ( $post->post_title ?: __( '(no title)', 'remaily' ) ) . ' (' . $hash . ')';
		}

		return $choices;
	}

	/**
	 * A form by its hash (a1b2c3d), as shortcodes, blocks and widgets name it: it survives export and import
	 *
	 * @param string $ref Hash
	 *
	 * @return Form|null
	 */
	public static function find( $ref ) {
		$ref = trim( (string) $ref );

		if ( !preg_match( '/^[a-f0-9]{7}$/', $ref ) ) {
			return null;
		}

		$ids = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => self::HASH, 'meta_value' => $ref ] ); // phpcs:ignore WordPress.DB.SlowDBQuery -- few forms, one per lookup

		return $ids ? self::get( $ids[0] ) : null;
	}

	/**
	 * A form's hash, made once and kept with it
	 *
	 * @param int $id Form ID
	 *
	 * @return string
	 */
	public static function hash_of( $id ) {
		$hash = (string) get_post_meta( $id, self::HASH, true );

		if ( preg_match( '/^[a-f0-9]{7}$/', $hash ) ) {
			return $hash;
		}

		// Always with a letter: an all-digit hash would be read as a post ID by find()
		do {
			$hash = substr( md5( wp_generate_password( 20, false ) ), 0, 7 );
		} while ( ctype_digit( $hash ) || get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'any', 'fields' => 'ids', 'meta_key' => self::HASH, 'meta_value' => $hash ] ) ); // phpcs:ignore WordPress.DB.SlowDBQuery -- once per form

		update_post_meta( $id, self::HASH, $hash );

		return $hash;
	}

	/**
	 * Forget a form read on this request (after it changed)
	 *
	 * @param int $id Form ID
	 */
	public static function forget( $id ) {
		unset( self::$cache[ (int) $id ] );
	}

	/**
	 * A form that isn't saved as it is: the editor's preview
	 *
	 * @param int    $id       Form ID
	 * @param string $title    Title
	 * @param string $template Template
	 * @param array  $config   Settings, sanitized here
	 *
	 * @return Form
	 */
	public static function make( $id, $title, $template, array $config ) {
		$form = new self( new \WP_Post( (object) [
			'ID'           => (int) $id,
			'post_type'    => PostType::NAME,
			'post_status'  => 'publish',
			'post_title'   => (string) $title,
			'post_content' => (string) $template,
		] ) );

		$form->config = Config::merge( Config::defaults(), Config::sanitize( $config ) );

		return $form;
	}

	/**
	 * Constructor
	 *
	 * @param \WP_Post $post Post
	 */
	private function __construct( \WP_Post $post ) {
		$this->post = $post;
	}

	/**
	 * ID
	 *
	 * @return int
	 */
	public function id() {
		return (int) $this->post->ID;
	}

	/**
	 * Shortcode ID (hash_of())
	 *
	 * @return string
	 */
	public function hash() {
		return $this->id() ? self::hash_of( $this->id() ) : '';
	}

	/**
	 * Shortcode
	 *
	 * @return string
	 */
	public function shortcode() {
		return sprintf( '[remaily id="%s"]', $this->hash() );
	}

	/**
	 * Title
	 *
	 * @return string
	 */
	public function title() {
		return get_the_title( $this->post );
	}

	/**
	 * Status: publish, or trash
	 *
	 * @return string
	 */
	public function status() {
		return (string) $this->post->post_status;
	}

	/**
	 * Description, a note for the editor's list
	 *
	 * @return string
	 */
	public function description() {
		return (string) $this->post->post_excerpt;
	}

	/**
	 * Template
	 *
	 * @return string
	 */
	public function template() {
		return (string) $this->post->post_content;
	}

	/**
	 * Settings
	 *
	 * @return array
	 */
	public function config() {
		if ( null === $this->config ) {
			$this->config = Config::get( $this->id() );
		}

		return $this->config;
	}

	/**
	 * The fields placed in the template, with a known type, in order
	 *
	 * @return array [ name => field settings, with 'name' ]
	 */
	public function fields() {
		if ( null !== $this->fields ) {
			return $this->fields;
		}

		$fields = [];
		$config = $this->config()['fields'];

		foreach ( Template::fields( $this->template() ) as $name ) {
			$field = $config[ $name ] ?? null;

			if ( is_array( $field ) && FieldRegistry::get( (string) ( $field['type'] ?? '' ) ) ) {
				$type            = FieldRegistry::get( $field['type'] );
				$fields[ $name ] = [ 'name' => $name ] + $type->sanitize( $field );
			}
		}

		$this->fields = $fields;

		return $fields;
	}

	/**
	 * One placed field
	 *
	 * @param string $name Name
	 *
	 * @return array|null
	 */
	public function field( $name ) {
		return $this->fields()[ $name ] ?? null;
	}

	/**
	 * Why a form takes no messages now, '' while it's open: shown instead of the form, and the reply to a submission
	 *
	 * @return string
	 */
	public function closed() {
		/**
		 * Close a form: a message such as "Registration has ended", '' to keep it open. Runs when the form is shown and
		 * when it's sent, so dates, entry limits or a schedule hold on both:
		 *
		 *     add_filter( 'remaily_form_closed', function ( $message, $form ) {
		 *         return time() > strtotime( '2026-12-31' ) ? 'Registration has ended.' : $message;
		 *     }, 10, 2 );
		 *
		 * @param string $message Message, '' = open
		 * @param Form   $form    Form
		 */
		return (string) apply_filters( 'remaily_form_closed', '', $this );
	}

	/**
	 * The groups' conditions
	 *
	 * @return array [ name => [ 'action', 'match', 'rules' ] ]
	 */
	public function groups() {
		return (array) $this->config()['groups'];
	}

	/**
	 * Form style
	 *
	 * @return string
	 */
	public function style() {
		return (string) $this->config()['settings']['style'] ?: 'default';
	}
}
