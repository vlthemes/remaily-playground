<?php

namespace VLT\Remaily\Forms;

use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Spam\Captcha;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Places: tokens with no settings where the plugin, a theme or an add-on prints its own part ([[captcha]],
 * [[response]]). Each is a chip in the editor, offered in its field buttons until placed; more through remaily_places:
 *
 *     add_filter( 'remaily_places', fn( $places ) => $places + [
 *         'map' => [
 *             'label'   => 'Map',
 *             'summary' => 'Shows the office on a map',
 *             'icon'    => 'M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7Z',
 *             'menu'    => 'more',
 *             'render'  => fn( $form ) => '<div class="my-map"></div>',
 *         ],
 *     ] );
 */
class Places {
	/**
	 * The places by name: label, summary (the More menu's line, the chip's title), icon (a built-in name or the d of
	 * a 24×24 stroke path), menu ('main' or 'more'), offered (shown in the field buttons) and render ( Form ): HTML
	 *
	 * @return array
	 */
	public static function all() {
		$places = [
			'captcha'  => [
				'label'   => __( 'Captcha', 'remaily' ),
				'summary' => __( 'The captchas from Settings → Spam go here, not before the submit button.', 'remaily' ),
				'offered' => (bool) Captcha::available(),
			],
			'response' => [
				'label'   => __( 'Response', 'remaily' ),
				'summary' => __( 'The message visitors get after sending goes here, not at the end of the form.', 'remaily' ),
			],
		];

		/**
		 * Places in the form's markup with no settings
		 *
		 * @param array $places [ name => [ label, summary, icon, menu, offered, render ] ]
		 */
		$places = (array) apply_filters( 'remaily_places', $places );
		$types  = FieldRegistry::all();
		$all    = [];

		foreach ( $places as $name => $place ) {
			// A token's name, not a group's or a field type's
			if ( !is_array( $place ) || !preg_match( '/^[a-z][a-z0-9_-]*$/', (string) $name ) || 'group' === $name || isset( $types[ $name ] ) ) {
				continue;
			}

			$all[ $name ] = [
				'label'   => (string) ( $place['label'] ?? $name ),
				'summary' => (string) ( $place['summary'] ?? '' ),
				'icon'    => (string) ( $place['icon'] ?? $name ),
				'menu'    => 'main' === ( $place['menu'] ?? 'more' ) ? 'main' : 'more',
				'offered' => (bool) ( $place['offered'] ?? true ),
				'render'  => is_callable( $place['render'] ?? null ) ? $place['render'] : null,
			];
		}

		return $all;
	}

	/**
	 * A place's HTML in a form: its render, then remaily_token_{name}
	 *
	 * @param string $name Place
	 * @param Form   $form Form
	 *
	 * @return string
	 */
	public static function render( $name, Form $form ) {
		$render = self::all()[ $name ]['render'] ?? null;
		$html   = $render ? (string) call_user_func( $render, $form ) : '';

		/**
		 * A place's HTML ([[captcha]], [[response]] has its own box)
		 *
		 * @param string $html HTML
		 * @param Form   $form Form
		 */
		return (string) apply_filters( 'remaily_token_' . $name, $html, $form );
	}

	/**
	 * The places for the editor, without their render
	 *
	 * @return array
	 */
	public static function editor() {
		return array_map( static fn( $place ) => array_diff_key( $place, [ 'render' => true ] ), self::all() );
	}
}
