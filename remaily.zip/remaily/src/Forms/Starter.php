<?php

namespace VLT\Remaily\Forms;

use VLT\Remaily\Core\Config;
use VLT\Remaily\Core\PostType;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What a new form starts with: name, email, subject, message and a submit button
 */
class Starter {
	/**
	 * Create a form from the starter
	 *
	 * @param string $title Title
	 *
	 * @return int|\WP_Error Form ID
	 */
	public static function create( $title = '' ) {
		$starter = self::get();
		$id      = wp_insert_post( [
			'post_type'    => PostType::NAME,
			'post_status'  => 'publish',
			'post_title'   => $title ?: self::title(),
			'post_content' => $starter['template'],
		], true );

		if ( !is_wp_error( $id ) ) {
			Config::save( $id, $starter['config'] );
		}

		return $id;
	}

	/**
	 * A new form's title: "Just another contact form 1", 2, 3…
	 *
	 * @return string
	 */
	private static function title() {
		$counts = (array) wp_count_posts( PostType::NAME );

		/* translators: %d: number of the new form */
		return sprintf( __( 'Just another contact form %d', 'remaily' ), array_sum( array_map( 'intval', $counts ) ) + 1 );
	}

	/**
	 * Template and settings
	 *
	 * @return array [ 'template' => string, 'config' => array ]
	 */
	public static function get() {
		// Plain markup, no classes: the form's style lays out a <label> around a field
		$label = static function ( $text, $token, $required = false ) {
			return sprintf( "<label>\n\t%s%s\n\t%s\n</label>", esc_html( $text ), $required ? ' *' : '', $token );
		};

		$template = implode( "\n", [
			$label( __( 'Your name', 'remaily' ), '[[your_name]]', true ),
			$label( __( 'Your email', 'remaily' ), '[[your_email]]', true ),
			$label( __( 'Subject', 'remaily' ), '[[your_subject]]' ),
			$label( __( 'Your message', 'remaily' ), '[[your_message]]' ),
			'[[submit]]',
		] );

		$config = [
			'fields' => [
				'your_name'    => [ 'type' => 'text', 'required' => true, 'autocomplete' => 'name' ],
				'your_email'   => [ 'type' => 'email', 'required' => true, 'autocomplete' => 'email' ],
				'your_subject' => [ 'type' => 'text' ],
				'your_message' => [ 'type' => 'textarea' ],
				'submit'       => [ 'type' => 'submit', 'label' => __( 'Send', 'remaily' ) ],
			],
			'mail'   => [
				'subject' => '[_site_title] "[your_subject]"',
				'headers' => 'Reply-To: [your_email]',
				'body'    => implode( "\n", [
					/* translators: mail body; the tags in brackets are replaced */
					__( 'From: [your_name] ([your_email])', 'remaily' ),
					/* translators: mail body; the tags in brackets are replaced */
					__( 'Subject: [your_subject]', 'remaily' ),
					'',
					__( 'Message:', 'remaily' ),
					'[your_message]',
					'',
					'-- ',
					/* translators: mail body; the tags in brackets are replaced */
					__( 'This mail was sent from a contact form on [_site_title] ([_site_url]).', 'remaily' ),
				] ),
			],
			'mail_2' => [
				'active'  => false,
				'to'      => '[your_email]',
				'subject' => '[_site_title] "[your_subject]"',
				'headers' => 'Reply-To: [_site_admin_email]',
				'body'    => implode( "\n", [
					__( 'Message:', 'remaily' ),
					'[your_message]',
					'',
					'-- ',
					/* translators: mail body; the tags in brackets are replaced */
					__( 'This mail is a copy of the message you sent on [_site_title] ([_site_url]).', 'remaily' ),
				] ),
			],
		];

		return (array) apply_filters( 'remaily_starter', [ 'template' => $template, 'config' => $config ] );
	}
}
