<?php

namespace VLT\Remaily\Forms;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's template: free HTML with tokens
 *
 *     [[your_name]]                  a field
 *     [[group:details]] … [[/group]] a group, shown or hidden by its condition
 *     [[response]]                   where the response box goes (else after the fields)
 *     [[your_file:size]]             a field's setting as text, such as "10 MB" (Field::info())
 */
class Template {
	const TOKEN = '/\[\[(\/group|group:[a-z][a-z0-9_-]*|[a-z][a-z0-9_-]*:[a-z][a-z_]*|[a-z][a-z0-9_-]*)\]\]/';

	// Tokens that aren't fields: the built-in ones; reserved() adds the places of remaily_places
	const RESERVED = [ 'response', 'captcha', 'group' ];

	/**
	 * Names that aren't fields: groups and the places
	 *
	 * @return string[]
	 */
	public static function reserved() {
		return array_values( array_unique( array_merge( self::RESERVED, array_keys( Places::all() ) ) ) );
	}

	/**
	 * Whether a field or group name is valid
	 *
	 * @param string $name Name
	 *
	 * @return bool
	 */
	public static function valid_name( $name ) {
		return (bool) preg_match( '/^[a-z][a-z0-9_-]*$/', $name ) && !in_array( $name, self::reserved(), true );
	}

	/**
	 * The template with its tokens' names in lowercase, for what doesn't come through the editor
	 *
	 * @param string $html Template
	 *
	 * @return string
	 */
	public static function lower_names( $html ) {
		return (string) preg_replace_callback( '/\[\[(?:group:)?[a-zA-Z][\w-]*(?=(?::[a-z][a-z_]*)?\]\])/', static fn( $m ) => strtolower( $m[0] ), (string) $html );
	}

	/**
	 * The tokens, in order
	 *
	 * @param string $html Template
	 *
	 * @return array [ [ 'kind' => field|group|end|reserved|info, 'name' => string, 'key' => info's key ], … ]
	 */
	public static function tokens( $html ) {
		preg_match_all( self::TOKEN, (string) $html, $matches );

		return array_map( [ __CLASS__, 'token' ], $matches[1] );
	}

	/**
	 * The field names, in order, once each
	 *
	 * @param string $html Template
	 *
	 * @return string[]
	 */
	public static function fields( $html ) {
		$names = [];

		foreach ( self::tokens( $html ) as $token ) {
			if ( 'field' === $token['kind'] ) {
				$names[ $token['name'] ] = true;
			}
		}

		return array_keys( $names );
	}

	/**
	 * The groups each field and group sits in, outermost first
	 *
	 * @param string $html Template
	 *
	 * @return array [ 'fields' => [ name => [ group, … ] ], 'groups' => [ name => [ group, … ] ] ]
	 */
	public static function ancestry( $html ) {
		$stack = [];
		$tree  = [ 'fields' => [], 'groups' => [] ];

		foreach ( self::tokens( $html ) as $token ) {
			if ( 'group' === $token['kind'] ) {
				$tree['groups'][ $token['name'] ] = $stack;
				$stack[]                          = $token['name'];
			} elseif ( 'end' === $token['kind'] ) {
				array_pop( $stack );
			} elseif ( 'field' === $token['kind'] && !isset( $tree['fields'][ $token['name'] ] ) ) {
				$tree['fields'][ $token['name'] ] = $stack;
			}
		}

		return $tree;
	}

	/**
	 * Replace every token
	 *
	 * @param string   $html     Template
	 * @param callable $callback fn( array $token ): string; 'in_tag' tells a token inside an HTML tag (an attribute)
	 *
	 * @return string
	 */
	public static function replace( $html, callable $callback ) {
		$open = 0;
		$html = (string) $html;

		$html = (string) preg_replace_callback( self::TOKEN, function ( $match ) use ( $callback, &$open, $html ) {
			$before          = substr( $html, 0, $match[0][1] );
			$token           = self::token( $match[1][0] );
			$token['in_tag'] = strrpos( $before, '<' ) > strrpos( $before, '>' ) || ( false !== strrpos( $before, '<' ) && false === strrpos( $before, '>' ) );

			if ( 'group' === $token['kind'] ) {
				$open++;
			} elseif ( 'end' === $token['kind'] ) {
				// A closing token without its group stays out of the markup
				if ( !$open ) {
					return '';
				}

				$open--;
			}

			return (string) $callback( $token );
		}, $html, -1, $count, PREG_OFFSET_CAPTURE );

		// Groups left open are closed at the end
		return $html . str_repeat( (string) $callback( [ 'kind' => 'end', 'name' => '' ] ), $open );
	}

	/**
	 * A token from its inner text
	 *
	 * @param string $inner Text between [[ and ]]
	 *
	 * @return array
	 */
	private static function token( $inner ) {
		if ( '/group' === $inner ) {
			return [ 'kind' => 'end', 'name' => '' ];
		}

		if ( 0 === strpos( $inner, 'group:' ) ) {
			return [ 'kind' => 'group', 'name' => substr( $inner, 6 ) ];
		}

		if ( false !== strpos( $inner, ':' ) ) {
			[ $name, $key ] = explode( ':', $inner, 2 );

			return [ 'kind' => 'info', 'name' => $name, 'key' => $key ];
		}

		return [ 'kind' => in_array( $inner, self::reserved(), true ) ? 'reserved' : 'field', 'name' => $inner ];
	}
}
