<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\Config;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Entries\Entries;
use VLT\Remaily\Entries\Export;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Forms\Starter;
use VLT\Remaily\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Contact Form menu: WordPress's list of forms (with shortcode and description columns), Add New, the editor and
 * Settings. Edit links and post-new.php lead to the editor.
 */
class Admin {
	// The forms list, WordPress's own
	const LIST_PAGE = 'edit.php?post_type=' . PostType::NAME;

	// The editor, a page without a menu entry: admin.php?page=remaily&form=ID
	const PAGE = 'remaily';

	// The parent the editor is registered under: no menu has that name, and the menu maps it to the forms list,
	// so the editor keeps the Contact Form menu open
	const HIDDEN_PARENT = 'remaily-hidden';

	const NEW_PAGE = 'post-new.php?post_type=' . PostType::NAME;

	/**
	 * The editor's page hook
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * The entry view's page hook
	 *
	 * @var string
	 */
	private static $entry_hook = '';

	// Who may build forms
	const CAPABILITY = 'edit_pages';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 9 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_filter( 'submenu_file', [ __CLASS__, 'submenu_file' ] );
		add_action( 'load-post.php', [ __CLASS__, 'to_editor' ] );
		add_action( 'load-post-new.php', [ __CLASS__, 'to_new' ] );
		add_action( 'admin_action_remaily_duplicate', [ __CLASS__, 'duplicate' ] );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_actions' ], 10, 2 );
		add_filter( 'vlt_toolkit_duplicate_post_types', [ __CLASS__, 'no_toolkit_duplicate' ] );
		add_filter( 'manage_' . PostType::NAME . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . PostType::NAME . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( REMAILY_FILE ), [ __CLASS__, 'action_links' ] );
		add_filter( 'admin_footer_text', [ __CLASS__, 'footer_text' ], 20 );
		add_action( 'admin_notices', [ __CLASS__, 'constants_notice' ] );
		EntriesList::init();
		Export::init();
		Settings::init();
		Welcome::init();
	}

	/**
	 * Menu entries
	 */
	public static function menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( self::icon( 'menu' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- the menu icon

		add_menu_page( __( 'Contact Forms', 'remaily' ), __( 'Contact Form', 'remaily' ), self::CAPABILITY, self::LIST_PAGE, '', $icon, 30 );
		add_submenu_page( self::LIST_PAGE, __( 'Contact Forms', 'remaily' ), __( 'Contact Forms', 'remaily' ), self::CAPABILITY, self::LIST_PAGE );

		add_submenu_page( self::LIST_PAGE, __( 'Add New Form', 'remaily' ), __( 'Add New', 'remaily' ), self::CAPABILITY, self::NEW_PAGE );

		EntriesList::menu();

		self::$hook       = (string) add_submenu_page( self::HIDDEN_PARENT, __( 'Edit Form', 'remaily' ), '', self::CAPABILITY, self::PAGE, [ __CLASS__, 'render' ] );
		self::$entry_hook = (string) add_submenu_page( self::HIDDEN_PARENT, __( 'Entry', 'remaily' ), '', self::CAPABILITY, EntryView::PAGE, [ EntryView::class, 'render' ] );

		// Read before the menu prints, so its count is right
		add_action( 'load-' . self::$entry_hook, [ EntryView::class, 'open' ] );

		// Mapped once the page's access is checked (that check would look for the editor under the list), before the
		// menu prints
		add_action( 'admin_head', static function () {
			$GLOBALS['_wp_real_parent_file'][ self::HIDDEN_PARENT ] = self::LIST_PAGE; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- maps the hidden parent to the list
		} );
	}

	/**
	 * On the editor, Contact Forms is the highlighted entry
	 *
	 * @param string $file Submenu file
	 *
	 * @return string
	 */
	public static function submenu_file( $file ) {
		global $plugin_page;

		if ( EntryView::PAGE === $plugin_page ) {
			return EntriesList::LIST_PAGE;
		}

		return self::PAGE === $plugin_page ? self::LIST_PAGE : $file;
	}

	/**
	 * The editor of one form
	 */
	public static function render() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which form to show
		$form = isset( $_GET['form'] ) ? Form::get( absint( $_GET['form'] ) ) : null;

		if ( !$form || !current_user_can( 'edit_post', $form->id() ) ) {
			wp_die( esc_html__( 'This form doesn\'t exist, or you can\'t edit it.', 'remaily' ) );
		}

		Editor::render( $form );
	}

	/**
	 * Assets of the editor and the list
	 *
	 * @param string $hook Admin page hook
	 */
	public static function enqueue( $hook ) {
		// The menu's line under the forms, on the plugin's own screens
		if ( self::is_plugin_screen() ) {
			Assets::enqueue( 'remaily-admin-menu' );
		}

		if ( self::$hook && self::$hook === $hook ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which form to show
			$form = isset( $_GET['form'] ) ? Form::get( absint( $_GET['form'] ) ) : null;

			if ( $form ) {
				Assets::enqueue( 'remaily-editor' );
				Assets::data( 'remaily-editor', 'remailyEditor', Editor::script_data( $form ) );

				/**
				 * Add-ons' editor scripts (remaily.tabs, remaily.fieldControls, remaily.control): depend on 'remaily-editor'
				 *
				 * @param \VLT\Remaily\Forms\Form $form Form being edited
				 */
				do_action( 'remaily_editor_enqueue', $form );
			}

			return;
		}

		if ( self::$entry_hook && self::$entry_hook === $hook ) {
			Assets::enqueue( 'remaily-admin-settings', 'remaily-admin-list' );

			return;
		}

		ListTable::screen( 'edit-' . PostType::NAME );

		if ( 'edit-' . Entries::POST_TYPE === ( get_current_screen()->id ?? '' ) ) {
			Assets::enqueue( 'remaily-admin-list' );
		}
	}

	/**
	 * Edit links of forms open the editor
	 *
	 * @param string $link    Link
	 * @param int    $post_id Post ID
	 *
	 * @return string
	 */
	public static function edit_link( $link, $post_id ) {
		switch ( get_post_type( $post_id ) ) {
			case PostType::NAME:
				return self::edit_url( $post_id );
			case Entries::POST_TYPE:
				return EntryView::url( $post_id );
		}

		return $link;
	}

	/**
	 * post.php of a form goes to the editor
	 */
	public static function to_editor() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a redirect, nothing changes
		$id = absint( $_GET['post'] ?? 0 );

		if ( $id && PostType::NAME === get_post_type( $id ) && 'edit' === sanitize_key( wp_unslash( $_GET['action'] ?? '' ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_safe_redirect( self::edit_url( $id ) );
			exit;
		}
	}

	/**
	 * post-new.php of forms makes one from the starter and opens it, as WordPress makes a draft there
	 */
	public static function to_new() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- like post-new.php itself
		if ( PostType::NAME !== sanitize_key( $_GET['post_type'] ?? '' ) || !current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$id = Starter::create();

		wp_safe_redirect( is_wp_error( $id ) ? self::url() : self::edit_url( $id ) );
		exit;
	}

	/**
	 * Duplicate a form (its row's action)
	 */
	public static function duplicate() {
		$id = absint( $_GET['post'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- checked next

		check_admin_referer( 'remaily-duplicate-' . $id );

		if ( PostType::NAME !== get_post_type( $id ) || !current_user_can( 'edit_post', $id ) ) {
			wp_die( esc_html__( 'You can\'t copy this form.', 'remaily' ) );
		}

		$post = get_post( $id );
		$copy = wp_insert_post( wp_slash( [
			'post_type'    => PostType::NAME,
			'post_status'  => 'publish',
			/* translators: %s: form title */
			'post_title'   => sprintf( __( '%s (copy)', 'remaily' ), $post->post_title ),
			'post_content' => $post->post_content,
			'post_excerpt' => $post->post_excerpt,
		] ) );

		if ( $copy && !is_wp_error( $copy ) ) {
			update_post_meta( $copy, Config::META, wp_slash( (string) get_post_meta( $id, Config::META, true ) ) );
		}

		wp_safe_redirect( admin_url( self::LIST_PAGE ) );
		exit;
	}

	/**
	 * Forms out of VLThemes Toolkit's Duplicate, which would sit beside our own
	 *
	 * @param array $post_types Post types
	 *
	 * @return array
	 */
	public static function no_toolkit_duplicate( $post_types ) {
		return array_values( array_diff( (array) $post_types, [ PostType::NAME ] ) );
	}

	/**
	 * A form's row: Edit, Duplicate, Trash (no Quick Edit: the editor has it all)
	 *
	 * @param array    $actions Actions
	 * @param \WP_Post $post    Post
	 *
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( PostType::NAME !== $post->post_type ) {
			return $actions;
		}

		unset( $actions['inline hide-if-no-js'], $actions['view'] );

		if ( 'trash' !== $post->post_status && current_user_can( 'edit_post', $post->ID ) ) {
			$url     = wp_nonce_url( admin_url( 'admin.php?action=remaily_duplicate&post=' . $post->ID ), 'remaily-duplicate-' . $post->ID );
			$actions = array_slice( $actions, 0, 1, true ) + [ 'remaily_duplicate' => '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Duplicate', 'remaily' ) . '</a>' ] + $actions;
		}

		return $actions;
	}

	/**
	 * List columns: description and shortcode before the date
	 *
	 * @param array $columns Columns
	 *
	 * @return array
	 */
	public static function columns( $columns ) {
		$date = $columns['date'] ?? null;

		unset( $columns['date'] );

		$columns['remaily_description'] = esc_html__( 'Description', 'remaily' );
		$columns['remaily_shortcode']   = esc_html__( 'Shortcode', 'remaily' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * A column's cell
	 *
	 * @param string $column  Column
	 * @param int    $post_id Post ID
	 */
	public static function column( $column, $post_id ) {
		if ( 'remaily_shortcode' === $column ) {
			echo ListTable::shortcode( sprintf( '[%s id="%s"]', Shortcode::TAG, Form::hash_of( (int) $post_id ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside
		} elseif ( 'remaily_description' === $column ) {
			echo ListTable::note( esc_html( get_post_field( 'post_excerpt', $post_id ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped here, kses inside
		}
	}

	/**
	 * Whether the current screen is one of the plugin's: the forms list, the editor, entries, Settings
	 *
	 * @return bool
	 */
	public static function is_plugin_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( !$screen ) {
			return false;
		}

		return in_array( $screen->post_type, [ PostType::NAME, Entries::POST_TYPE ], true )
			|| in_array( $screen->id, array_filter( [ self::$hook, self::$entry_hook, Welcome::hook() ] ), true )
			|| false !== strpos( $screen->id, Settings::PAGE );
	}

	/**
	 * The admin footer of the plugin's screens: "Thank you for creating with WordPress and Remaily."
	 *
	 * @param string $text WordPress's footer text
	 *
	 * @return string
	 */
	public static function footer_text( $text ) {
		if ( !self::is_plugin_screen() ) {
			return $text;
		}

		return sprintf(
			/* translators: 1: WordPress link, 2: Re:Maily link */
			__( 'Thank you for creating with %1$s and %2$s.', 'remaily' ),
			'<a href="' . esc_url( __( 'https://wordpress.org/', 'remaily' ) ) . '">WordPress</a>',
			'<a href="https://wordpress.org/plugins/remaily/" target="_blank" rel="noopener">Re:Maily</a>'
		);
	}

	/**
	 * On the plugin's screens: a reminder when wp-config.php turns mail off, puts every form in test mode or sends
	 * every mail to one address
	 */
	public static function constants_notice() {
		if ( !self::is_plugin_screen() ) {
			return;
		}

		$notes = [];

		if ( defined( 'REMAILY_DISABLE_MAIL' ) && REMAILY_DISABLE_MAIL ) {
			$notes[] = __( 'Mail is off for every form (REMAILY_DISABLE_MAIL). Messages are still saved in Entries.', 'remaily' );
		}

		if ( defined( 'REMAILY_TEST_MODE' ) && REMAILY_TEST_MODE ) {
			$notes[] = __( 'Every form is in test mode (REMAILY_TEST_MODE): nothing is sent or saved.', 'remaily' );
		}

		if ( defined( 'REMAILY_MAIL_TO' ) && is_email( REMAILY_MAIL_TO ) ) {
			/* translators: %s: email address */
			$notes[] = sprintf( __( 'Every mail goes to %s (REMAILY_MAIL_TO).', 'remaily' ), REMAILY_MAIL_TO );
		}

		foreach ( $notes as $note ) {
			printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( $note ) );
		}
	}

	/**
	 * Forms first in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_links( array $links ) {
		return [ 'remaily-forms' => '<a href="' . esc_url( admin_url( self::LIST_PAGE ) ) . '">' . esc_html__( 'Forms', 'remaily' ) . '</a>' ] + $links;
	}

	/**
	 * The forms list
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( self::LIST_PAGE );
	}

	/**
	 * A form's editor
	 *
	 * @param int $id Form ID
	 *
	 * @return string
	 */
	public static function edit_url( $id ) {
		return admin_url( 'admin.php?page=' . self::PAGE . '&form=' . (int) $id );
	}

	/**
	 * Add New
	 *
	 * @return string
	 */
	public static function new_url() {
		return admin_url( self::NEW_PAGE );
	}

	/**
	 * Contact Form in the admin bar's + New menu
	 *
	 * @param \WP_Admin_Bar $bar Admin bar
	 */
	public static function new_content( $bar ) {
		if ( !current_user_can( self::CAPABILITY ) || !$bar->get_node( 'new-content' ) ) {
			return;
		}

		$bar->add_node( [
			'parent' => 'new-content',
			'id'     => 'new-remaily-form',
			'title'  => __( 'Contact Form', 'remaily' ),
			'href'   => self::new_url(),
		] );
	}

	/**
	 * The Re:Maily logo (assets/icons/logo.webp), decorative
	 *
	 * @param int $size Width and height in px
	 *
	 * @return string
	 */
	public static function logo( $size = 52 ) {
		return sprintf( '<img src="%s" width="%2$d" height="%2$d" alt="">', esc_url( self::logo_url() ), (int) $size );
	}

	/**
	 * URL of the logo
	 *
	 * @return string
	 */
	public static function logo_url() {
		return REMAILY_URL . 'assets/icons/logo.webp';
	}

	/**
	 * An SVG of assets/icons/
	 *
	 * @param string $name File name without .svg
	 *
	 * @return string
	 */
	public static function icon( $name ) {
		$file = REMAILY_PATH . 'assets/icons/' . sanitize_key( $name ) . '.svg';

		return is_file( $file ) ? trim( (string) file_get_contents( $file ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
	}
}
