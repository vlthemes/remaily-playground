<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Entries\Entries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Welcome page. Opens once after activation, then stays reachable by its address
 * (edit.php?post_type=remaily_form&page=remaily-welcome) and the plugin's row, without a menu item.
 */
class Welcome {
	const PAGE = 'remaily-welcome';

	/**
	 * Set on activation, read on the next admin page
	 */
	const REDIRECT = 'remaily_welcome_redirect';

	/**
	 * The page's hook
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'redirect' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_head', [ __CLASS__, 'hide' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( REMAILY_FILE ), [ __CLASS__, 'action_link' ], 20 );
	}

	/**
	 * Activation hook
	 */
	public static function activate() {
		set_transient( self::REDIRECT, 1, MINUTE_IN_SECONDS );
	}

	/**
	 * Page URL
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( 'page', self::PAGE, admin_url( Admin::LIST_PAGE ) );
	}

	/**
	 * The page's hook
	 *
	 * @return string
	 */
	public static function hook() {
		return self::$hook;
	}

	/**
	 * The first admin page after activation goes to the welcome page
	 */
	public static function redirect() {
		if ( !get_transient( self::REDIRECT ) ) {
			return;
		}

		delete_transient( self::REDIRECT );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only checks how the plugin was activated
		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) || !current_user_can( Admin::CAPABILITY ) ) {
			return;
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * The page, in the Contact Form menu so it gets its title and address (edit.php?post_type=remaily_form&page=…)
	 */
	public static function menu() {
		self::$hook = (string) add_submenu_page( Admin::LIST_PAGE, __( 'Welcome to Re:Maily', 'remaily' ), __( 'Welcome', 'remaily' ), Admin::CAPABILITY, self::PAGE, [ __CLASS__, 'page' ] );
	}

	/**
	 * No menu item: removed after the title is read
	 */
	public static function hide() {
		remove_submenu_page( Admin::LIST_PAGE, self::PAGE );
	}

	/**
	 * Settings styles (header, cards) and the page's own
	 *
	 * @param string $hook Admin page hook
	 */
	public static function enqueue( $hook ) {
		if ( self::$hook && self::$hook === $hook ) {
			Assets::enqueue( 'remaily-admin-welcome' );
		}
	}

	/**
	 * "Welcome" in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_link( array $links ) {
		return $links + [ 'remaily-welcome' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Welcome', 'remaily' ) . '</a>' ];
	}

	/**
	 * What the plugin does
	 *
	 * @return array [ [ dashicon, title, text ] ]
	 */
	private static function features() {
		return [
			[ 'editor-code', __( 'Your own markup', 'remaily' ), __( 'A form is plain HTML. Drag fields into it, and set each one in the sidebar instead of inside a tag.', 'remaily' ) ],
			[ 'visibility', __( 'See it as visitors will', 'remaily' ), __( 'Preview shows the unsaved form with your theme\'s styles. Click a field there to edit it.', 'remaily' ) ],
			[ 'forms', __( '20 field types', 'remaily' ), __( 'Text, email, phone with a country mask, dates, choices, countries, files, a quiz, hidden values, a live mirror, a character count and payments. Any field can start filled from the link, the shortcode or the logged-in user.', 'remaily' ) ],
			[ 'editor-textcolor', __( 'Text that stays right', 'remaily' ), __( 'Show a field\'s settings in your text, such as "up to 10 MB" or a live "120 characters left". Change the setting and the text follows.', 'remaily' ) ],
			[ 'randomize', __( 'Conditions', 'remaily' ), __( 'Select some code, right-click, make it a group, and show it only when visitors pick or type something.', 'remaily' ) ],
			[ 'email-alt', __( 'Two mails per form', 'remaily' ), __( 'One for you, one optional copy for the sender, with mail tags, HTML or plain text, and attachments. Visitors can pick the department that gets it.', 'remaily' ) ],
			[ 'archive', __( 'Every message kept', 'remaily' ), __( 'Entries saves each message, even when the mail fails. Filter by form, export a CSV, delete old ones on a schedule.', 'remaily' ) ],
			[ 'money-alt', __( 'Take payments', 'remaily' ), __( 'Add a Stripe or PayPal field and visitors pay inside the form before their message goes. A set amount or one from a field, checked on your server. Your own keys, no fees.', 'remaily' ) ],
			[ 'shield', __( 'Spam stays out', 'remaily' ), __( 'A hidden trap for bots, a time check, a limit per visitor and your Disallowed Comment Keys on every form, plus Turnstile, hCaptcha, reCAPTCHA or Akismet if you like.', 'remaily' ) ],
			[ 'admin-appearance', __( 'Made for themes', 'remaily' ), __( 'Fields and messages are templates your theme can restyle or replace, and CSS variables set the look. Forms read the right way round in right-to-left languages.', 'remaily' ) ],
			[ 'performance', __( 'Lightweight', 'remaily' ), __( 'One small script and inline styles, only on pages with a form, with no jQuery. Payment and captcha scripts load only when needed, and forms work with JavaScript off.', 'remaily' ) ],
			[ 'block-default', __( 'Place it anywhere', 'remaily' ), __( 'The Re:Maily Contact Form block, Elementor widget, WPBakery element or classic widget, or a shortcode.', 'remaily' ) ],
			[ 'groups', __( 'Grow your list with Brevo', 'remaily' ), __( 'Add the people who write to you to your Brevo lists when they agree, send new ones a welcome email, and ask them to confirm their address first.', 'remaily' ) ],
			[ 'rest-api', __( 'Webhooks', 'remaily' ), __( 'Send each message as JSON to Zapier, Make, n8n or your own code.', 'remaily' ) ],
			[ 'privacy', __( 'Private and safe', 'remaily' ), __( 'Visitors\' IPs are shortened, messages can be exported, erased or deleted on a schedule, and a privacy policy text is ready. Uploads are images, audio, video, PDF or text only, and addresses in a form\'s options stay off the page.', 'remaily' ) ],
			[ 'lightbulb', __( 'Build with AI', 'remaily' ), __( 'Describe the form you need and your site\'s AI writes it. AI assistants connected to your site can also list, build and change forms and read entries, with your rights.', 'remaily' ) ],
			[ 'migrate', __( 'Move from Contact Form 7', 'remaily' ), __( 'Import your CF7 forms with their fields, mails and messages. Mail tags stay the same, and the old shortcodes keep working.', 'remaily' ) ],
			[ 'admin-tools', __( 'Safe to test', 'remaily' ), __( 'Test mode checks the fields and sends nothing; "Don\'t send mail" still saves entries. Per form, or for the whole site in wp-config.php.', 'remaily' ) ],
			[ 'admin-page', __( 'Move to another site', 'remaily' ), __( 'Export every form to one file in Settings and import it on the other site, or copy one form\'s code from its Advanced tab.', 'remaily' ) ],
		];
	}

	/**
	 * The page
	 */
	public static function page() {
		$forms   = (int) ( wp_count_posts( PostType::NAME )->publish ?? 0 );
		$entries = (int) ( wp_count_posts( Entries::POST_TYPE )->publish ?? 0 );
		$steps   = [
			[
				'done'   => $forms > 0,
				'title'  => __( 'Make a form', 'remaily' ),
				'text'   => $forms
					/* translators: %s: number of forms */
					? sprintf( _n( '%s form so far. Open it to drag in fields, write the mails and pick its messages.', '%s forms so far. Open one to drag in fields, write the mails and pick its messages.', $forms, 'remaily' ), number_format_i18n( $forms ) )
					: __( 'A new form starts with name, email, subject and message fields. Drag in more, or change the markup around them.', 'remaily' ),
				'action' => $forms ? [ Admin::url(), __( 'Contact Forms', 'remaily' ) ] : [ Admin::new_url(), __( 'Make a form', 'remaily' ) ],
			],
			[
				'done'   => false,
				'title'  => __( 'Put it on a page', 'remaily' ),
				'text'   => __( 'Add the Re:Maily Contact Form block in the block editor or the Elementor widget, or paste the form\'s shortcode anywhere shortcodes work.', 'remaily' ),
				'action' => $forms ? [ Admin::url(), __( 'Copy a shortcode', 'remaily' ) ] : null,
			],
			[
				'done'   => $entries > 0,
				'title'  => __( 'Send yourself a test', 'remaily' ),
				'text'   => __( 'Fill in the form on your site. If the mail doesn\'t arrive, your site needs a mail setup such as an SMTP plugin; Entries keeps the message either way.', 'remaily' ),
				'action' => $entries ? [ admin_url( EntriesList::LIST_PAGE ), __( 'Entries', 'remaily' ) ] : null,
			],
		];
		?>
		<div class="wrap vlt-settings-page vlt-welcome">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Welcome to Re:Maily', 'remaily' ); ?></h1>
			<hr class="wp-header-end">

			<?php Settings::page()->header( __( 'welcome', 'remaily' ) ); ?>

			<div class="vlt-settings-page__panels">
				<section class="vlt-settings-page__card">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'Get started in three steps', 'remaily' ); ?></h2>
					</div>
					<ol class="vlt-welcome__steps">
						<?php foreach ( $steps as $number => $step ) : ?>
							<li class="vlt-welcome__step<?php echo $step['done'] ? ' is-done' : ''; ?>">
								<span class="vlt-welcome__step-number" aria-hidden="true"><?php echo $step['done'] ? '✓' : (int) ( $number + 1 ); ?></span>
								<div class="vlt-welcome__step-text">
									<strong><?php echo esc_html( $step['title'] ); ?></strong>
									<?php if ( $step['done'] ) : ?>
										<span class="screen-reader-text"><?php esc_html_e( '(done)', 'remaily' ); ?></span>
									<?php endif; ?>
									<p><?php echo esc_html( $step['text'] ); ?></p>
								</div>
								<?php if ( $step['action'] ) : ?>
									<a class="vlt-settings-page__button" href="<?php echo esc_url( $step['action'][0] ); ?>"><?php echo esc_html( $step['action'][1] ); ?></a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ol>
				</section>

				<section class="vlt-settings-page__card vlt-welcome__sky">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'What you can do', 'remaily' ); ?></h2>
					</div>
					<ul class="vlt-welcome__features">
						<?php foreach ( self::features() as [ $icon, $title, $text ] ) : ?>
							<li class="vlt-welcome__feature">
								<span class="vlt-welcome__icon dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
								<div>
									<strong><?php echo esc_html( $title ); ?></strong>
									<p><?php echo esc_html( $text ); ?></p>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>

				<footer class="vlt-welcome__help">
					<span><?php esc_html_e( 'Need a hand?', 'remaily' ); ?></span>
					<a href="<?php echo esc_url( Settings::docs_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'remaily' ); ?></a>
					<a href="<?php echo esc_url( (string) apply_filters( 'remaily_support_url', 'https://wordpress.org/support/plugin/remaily/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Support', 'remaily' ); ?></a>
					<a href="<?php echo esc_url( Settings::url() ); ?>"><?php esc_html_e( 'Settings', 'remaily' ); ?></a>
					<a href="https://wordpress.org/support/plugin/remaily/reviews/#new-post" target="_blank" rel="noopener"><?php esc_html_e( 'Enjoying Re:Maily? Leave a review', 'remaily' ); ?></a>
				</footer>
			</div>
		</div>
		<?php
	}
}
