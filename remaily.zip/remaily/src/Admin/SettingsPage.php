<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\Controls;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tabbed settings page stored in one option. Each section's fields are a Controls tree (Core\Controls): sections,
 * rows, dividers, notices and controls with conditions; values nest as their sections do (spam.turnstile.site).
 *
 *     add_filter( '{tabs_filter}', fn( $tabs ) => $tabs + [ 'my' => [ 'label' => 'My', 'icon' => 'settings', 'render' => 'my_render' ] ] );
 */
class SettingsPage {
	// What a field's help and a section's or group's description may hold (SettingsControls)
	const HELP_HTML = SettingsControls::HELP_HTML;

	/**
	 * Page arguments
	 *
	 * @var array
	 */
	private $args;

	/**
	 * Sections cache (labels are translated, so built on first use)
	 *
	 * @var array|null
	 */
	private $sections = null;

	/**
	 * The sections are being built
	 *
	 * @var bool
	 */
	private $building = false;

	/**
	 * The controls of the page's sections, made once
	 *
	 * @var SettingsControls|null
	 */
	private $controls = null;

	/**
	 * Constructor
	 *
	 * @param array $args {
	 *     @type string          $option      Option name
	 *     @type string          $page        Page slug
	 *     @type string|callable $parent      Parent menu slug, or a callable returning it
	 *     @type string          $title       Page title
	 *     @type string          $menu_title  Menu title
	 *     @type string          $name        Name in the header ("{name} settings")
	 *     @type string          $version     Version badge ('' = none)
	 *     @type string          $icon        SVG of the header logo ('' = none)
	 *     @type callable        $sections    Returns [ section => [ tab, icon, title, description, notices, fields => Controls
	 *                                        tree ] ]; a slug field's "preview" (an address with %s) shows its value in place
	 *     @type string          $tabs_filter Filter for extra tabs
	 *     @type callable|null   $validate    Post-processes the whole clean value (cross-field rules)
	 *     @type string          $docs_url    Documentation link in the header ('' = none)
	 *     @type string          $support_url Support link in the header ('' = none)
	 *     @type callable|null   $render      Prints the page instead: a dashboard that shows these settings (content())
	 *                                        under its own header
	 *     @type int             $priority    admin_menu priority
	 *     @type string          $capability  Who may see and save the page (default manage_options)
	 *     @type string          $rest        Address of a REST route that calls save_request(): the page saves
	 *                                        without reloading ('' = through options.php only)
	 * }
	 */
	public function __construct( array $args ) {
		$this->args = $args + [
			'name'        => $args['title'],
			'version'     => '',
			'icon'        => '',
			'validate'    => null,
			'docs_url'    => '',
			'support_url' => '',
			'render'      => null,
			'priority'    => 30,
			'menu_title'  => $args['title'],
			'capability'  => 'manage_options',
			'rest'        => '',
		];

		add_action( 'admin_init', [ $this, 'register' ] );
		add_action( 'admin_menu', [ $this, 'menu' ], $this->args['priority'] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
	}

	/**
	 * Page slug
	 *
	 * @return string
	 */
	public function slug() {
		return $this->args['page'];
	}

	/**
	 * Sections and their fields
	 *
	 * @return array
	 */
	public function sections() {
		if ( null !== $this->sections ) {
			return $this->sections;
		}

		// Asked again while they're being built (a section reads a setting through remaily_setting): none yet, and
		// values() gives what is saved as it is
		if ( $this->building ) {
			return [];
		}

		$this->building = true;
		$sections       = (array) call_user_func( $this->args['sections'] );
		$this->building = false;

		// Modules add sections on init (a filter of the sections callback): don't freeze a list read before them
		if ( did_action( 'wp_loaded' ) ) {
			$this->sections = $sections;
		}

		return $sections;
	}

	/**
	 * Values of a section (saved, or the defaults)
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public function get( $section ) {
		return $this->values()[ $section ] ?? [];
	}

	/**
	 * Every section's values
	 *
	 * @return array
	 */
	public function values() {
		$saved = get_option( $this->args['option'], [] );
		$saved = is_array( $saved ) ? $saved : [];

		return $this->building ? $saved : $this->sanitize( $saved, false );
	}

	/**
	 * One value by its path: spam.turnstile.use
	 *
	 * @param string $path    Path
	 * @param mixed  $default When there is none
	 *
	 * @return mixed
	 */
	public function value( $path, $default = null ) {
		return Controls::pick( $this->values(), $path, $default );
	}

	/**
	 * Validate the whole option
	 *
	 * @param mixed $input    Raw
	 * @param bool  $validate Run the page's cross-field rules (on save)
	 *
	 * @return array
	 */
	public function sanitize( $input, $validate = true ) {
		$input = is_array( $input ) ? $input : [];
		$saved = (array) get_option( $this->args['option'], [] );
		$clean = [];

		foreach ( $this->sections() as $section => $definition ) {
			// A tab sends only its own section: the others keep their saved values
			$clean[ $section ] = Controls::sanitize( (array) ( $definition['fields'] ?? [] ), $input[ $section ] ?? ( $saved[ $section ] ?? [] ), (array) ( $saved[ $section ] ?? [] ) );
		}

		return $validate && $this->args['validate'] ? (array) call_user_func( $this->args['validate'], $clean ) : $clean;
	}

	/**
	 * Save the form sent to the page's REST route (its fields as options.php gets them)
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save_request( \WP_REST_Request $request ) {
		if ( !current_user_can( $this->args['capability'] ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to do that.', 'remaily' ), [ 'status' => 403 ] );
		}

		$input = $request->get_body_params()[ $this->args['option'] ] ?? [];

		// sanitize() here: the option's own callback is registered on admin_init, which a REST request doesn't run
		update_option( $this->args['option'], $this->sanitize( is_array( $input ) ? $input : [] ) );

		// Built again from what was just saved: the states read the settings
		$this->sections = null;

		return rest_ensure_response( [
			'message'  => __( 'Settings saved.', 'remaily' ),
			'statuses' => $this->statuses(),
		] );
	}

	/**
	 * A saved secret for its Copy button: the page shows only its mask
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function secret_request( \WP_REST_Request $request ) {
		if ( !current_user_can( $this->args['capability'] ) ) {
			return new \WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to do that.', 'remaily' ), [ 'status' => 403 ] );
		}

		$path = (string) $request->get_param( 'path' );

		// Only a control the page declares a secret: no other value is read this way
		if ( !in_array( $path, $this->secrets(), true ) ) {
			return new \WP_Error( 'rest_invalid_param', __( 'Not a secret of these settings.', 'remaily' ), [ 'status' => 400 ] );
		}

		return rest_ensure_response( [ 'value' => (string) $this->value( $path, '' ) ] );
	}

	/**
	 * The dotted paths of the page's secret controls
	 *
	 * @return array
	 */
	private function secrets() {
		$found = [];
		$walk  = static function ( array $fields, array $path ) use ( &$walk, &$found ) {
			foreach ( $fields as $key => $node ) {
				if ( !is_array( $node ) ) {
					continue;
				}

				if ( 'secret' === ( $node['type'] ?? '' ) ) {
					$found[] = implode( '.', array_merge( $path, [ $key ] ) );
				}

				if ( !empty( $node['fields'] ) ) {
					$walk( (array) $node['fields'], Controls::nests( $node ) ? array_merge( $path, [ $key ] ) : $path );
				}
			}
		};

		foreach ( $this->sections() as $section => $definition ) {
			$walk( (array) ( $definition['fields'] ?? [] ), [ $section ] );
		}

		return $found;
	}

	/**
	 * The sections' states by their path, as the page shows them: [ 'spam.turnstile' => [ label, tone ] ]
	 *
	 * @return array
	 */
	public function statuses() {
		$found = [];
		$walk  = static function ( array $fields, array $path ) use ( &$walk, &$found ) {
			foreach ( $fields as $key => $node ) {
				if ( !is_array( $node ) ) {
					continue;
				}

				if ( isset( $node['status_callback'] ) && is_callable( $node['status_callback'] ) ) {
					$node['status'] = (array) call_user_func( $node['status_callback'] );
				}

				if ( isset( $node['status'] ) ) {
					$status = array_values( (array) $node['status'] );
					$id     = implode( '.', array_merge( $path, [ $key ] ) );

					$found[ $id ] = [ (string) ( $status[0] ?? '' ), (string) ( $status[1] ?? 'muted' ) ];
				}

				if ( !empty( $node['fields'] ) ) {
					$walk( (array) $node['fields'], Controls::nests( $node ) ? array_merge( $path, [ $key ] ) : $path );
				}
			}
		};

		foreach ( $this->sections() as $section => $definition ) {
			$walk( (array) ( $definition['fields'] ?? [] ), [ $section ] );
		}

		return $found;
	}

	/**
	 * Register the option
	 */
	public function register() {
		// options.php saves only with manage_options unless the page's group says who else may
		add_filter( 'option_page_capability_' . $this->args['option'] . '_group', fn() => $this->args['capability'] );

		register_setting( $this->args['option'] . '_group', $this->args['option'], [
			'type'              => 'array',
			'sanitize_callback' => [ $this, 'sanitize' ],
			'default'           => [],
		] );
	}

	/**
	 * Menu entry
	 */
	public function menu() {
		$parent = is_callable( $this->args['parent'] ) ? call_user_func( $this->args['parent'] ) : $this->args['parent'];

		add_submenu_page( $parent, $this->args['title'], $this->args['menu_title'], $this->args['capability'], $this->args['page'], [ $this, 'page' ] );
	}

	/**
	 * Assets on the page
	 *
	 * @param string $hook Admin page hook
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( $hook, $this->args['page'] ) ) {
			return;
		}

		Assets::enqueue( 'remaily-admin-settings' );
		// The Media Library of image fields
		wp_enqueue_media();
	}

	/**
	 * Tabs: the sections, then the ones modules add
	 *
	 * @return array [ id => [ 'label', 'render' => callable|null ] ], null renders the section's fields
	 */
	public function tabs() {
		$tabs = [];

		foreach ( $this->sections() as $section => $definition ) {
			$tabs[ $section ] = [
				'label'  => $definition['tab'],
				'icon'   => $definition['icon'] ?? '',
				'render' => null,
			];
		}

		// The plugin's own filter, named by the page (remaily_settings_tabs)
		foreach ( (array) apply_filters( $this->args['tabs_filter'], [] ) as $id => $tab ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
			$id = sanitize_key( $id );

			if ( $id && !isset( $tabs[ $id ] ) && !empty( $tab['label'] ) && is_callable( $tab['render'] ?? null ) ) {
				$tabs[ $id ] = [
					'label'  => (string) $tab['label'],
					'icon'   => (string) ( $tab['icon'] ?? '' ),
					'render' => $tab['render'],
				];
			}
		}

		return $tabs;
	}

	/**
	 * Header with the tabs as pills, then the open tab's card
	 */
	public function page() {
		if ( !current_user_can( $this->args['capability'] ) ) {
			return;
		}

		if ( $this->args['render'] ) {
			call_user_func( $this->args['render'] );

			return;
		}

		$tabs  = $this->tabs();
		$first = (string) array_key_first( $tabs );
		?>
		<div class="wrap vlt-settings-page">
			<h1 class="screen-reader-text"><?php echo esc_html( $this->args['title'] ); ?></h1>
			<?php // WordPress notices go here, above the header ?>
			<hr class="wp-header-end">

			<?php $this->header( __( 'settings', 'remaily' ) ); ?>

			<?php $this->body( $tabs, $first, false ); ?>
		</div>
		<?php
	}

	/**
	 * The shared header: name, version, links and, given tabs, the tabs
	 *
	 * @param string $suffix  Word after the name
	 * @param array  $tabs    Tabs, as tabs() returns them
	 * @param string $current Tab shown first
	 * @param array  $extra   For a page of its own (Add-ons): 'tagline' in place of the slogan, 'stats'
	 *                        ( [ [ number, label, dashicon ] ], in place of the links) and 'after' (prints a row
	 *                        under the top)
	 */
	public function header( $suffix, array $tabs = [], $current = '', array $extra = [] ) {
		?>
		<header class="vlt-admin-header">
			<div class="vlt-admin-header__top">
				<div class="vlt-admin-header__brand">
					<?php if ( $this->args['icon'] ) : ?>
						<span class="vlt-admin-header__logo" aria-hidden="true"><?php echo wp_kses( $this->args['icon'], remaily_allowed_html( $this->args['icon'] ) ); ?></span>
					<?php endif; ?>

					<div class="vlt-admin-header__titles">
						<div class="vlt-admin-header__title-row">
							<div class="vlt-admin-header__title" aria-hidden="true">
								<?php echo esc_html( $this->args['name'] ); ?>
								<em><?php echo esc_html( $suffix ); ?></em>
							</div>

							<?php if ( $this->args['version'] ) : ?>
								<span class="vlt-admin-header__version">v<?php echo esc_html( $this->args['version'] ); ?></span>
							<?php endif; ?>
						</div>
						<div class="vlt-admin-header__tagline"><?php echo esc_html( $extra['tagline'] ?? __( 'Every message deserves a Re:', 'remaily' ) ); ?></div>
					</div>
				</div>

				<?php if ( !empty( $extra['stats'] ) ) : ?>
					<dl class="vlt-admin-header__stats">
						<?php foreach ( $extra['stats'] as [ $number, $label, $icon ] ) : ?>
							<div class="vlt-admin-header__stat">
								<dt><?php Icons::the_glyph( $icon ); ?><?php echo esc_html( (string) $number ); ?></dt>
								<dd><?php echo esc_html( $label ); ?></dd>
							</div>
						<?php endforeach; ?>
					</dl>
				<?php else : ?>
				<div class="vlt-admin-header__links">
					<?php if ( $this->args['docs_url'] ) : ?>
						<a class="vlt-admin-header__link is-ghost" href="<?php echo esc_url( $this->args['docs_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'remaily' ); ?></a>
					<?php endif; ?>
					<?php if ( $this->args['support_url'] ) : ?>
						<a class="vlt-admin-header__link is-brand" href="<?php echo esc_url( $this->args['support_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Get support', 'remaily' ); ?></a>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>

			<?php if ( $tabs ) : ?>
				<?php $this->render_tabs( $tabs, $current ); ?>
			<?php endif; ?>

			<?php if ( isset( $extra['after'] ) && is_callable( $extra['after'] ) ) : ?>
				<?php call_user_func( $extra['after'] ); ?>
			<?php endif; ?>
		</header>
		<?php
	}

	/**
	 * The settings without the page around them, for a dashboard page (see "render")
	 */
	public function content() {
		$tabs = $this->tabs();
		?>
		<div class="vlt-settings-page">
			<?php $this->body( $tabs, (string) array_key_first( $tabs ), true ); ?>
		</div>
		<?php
	}

	/**
	 * Notices, tabs, then the cards
	 *
	 * @param array  $tabs     Tabs
	 * @param string $first    Tab open before the script runs
	 * @param bool   $embedded Inside a dashboard page
	 */
	private function body( array $tabs, $first, $embedded ) {
		settings_errors();

		if ( $embedded ) {
			$this->render_tabs( $tabs, $first, 'is-light' );
		}
		?>
		<div class="vlt-settings-page__layout<?php echo $embedded ? ' is-embedded' : ''; ?>">
		<?php if ( !$embedded ) : ?>
			<nav class="vlt-settings-page__side"><?php $this->render_tabs( $tabs, $first, 'is-side' ); ?></nav>
		<?php endif; ?>
		<div class="vlt-settings-page__panels">
			<form method="post" action="options.php" class="vlt-settings-page__card vlt-settings-page__form"<?php echo $tabs[ $first ]['render'] ? ' hidden' : ''; ?><?php if ( $this->args['rest'] ) : ?> data-vlt-rest="<?php echo esc_url( $this->args['rest'] ); ?>" data-vlt-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>" data-vlt-error="<?php esc_attr_e( 'Couldn\'t save. Try again.', 'remaily' ); ?>"<?php endif; ?>>
				<?php settings_fields( $this->args['option'] . '_group' ); ?>

				<?php foreach ( $this->sections() as $section => $definition ) : ?>
					<?php $this->render_section( $section, $section === $first ); ?>
				<?php endforeach; ?>

				<div class="vlt-settings-page__save">
					<span><?php esc_html_e( 'Changes apply after saving.', 'remaily' ); ?></span>
					<button type="submit" class="vlt-settings-page__button is-primary"><?php esc_html_e( 'Save changes', 'remaily' ); ?></button>
				</div>
			</form>

			<?php
			// Module tabs: cards and forms of their own, outside the settings form
			foreach ( $tabs as $id => $tab ) :
				if ( !$tab['render'] ) {
					continue;
				}
				?>
				<section class="vlt-settings-page__panel is-module" id="vlt-settings-panel-<?php echo esc_attr( $id ); ?>" role="tabpanel" aria-labelledby="vlt-settings-tab-<?php echo esc_attr( $id ); ?>" tabindex="0"<?php echo $id !== $first ? ' hidden' : ''; ?>>
					<?php call_user_func( $tab['render'] ); ?>
				</section>
			<?php endforeach; ?>
		</div>
		</div>
		<?php
	}

	/**
	 * The tabs as pills (no list for a single tab)
	 *
	 * @param array  $tabs    Tabs
	 * @param string $current Tab open before the script runs
	 * @param string $class   Extra class of the row
	 */
	private function render_tabs( array $tabs, $current, $class = '' ) {
		if ( count( $tabs ) < 2 ) {
			return;
		}
		?>
		<div class="vlt-admin-header__nav <?php echo esc_attr( $class ); ?>" role="tablist" aria-label="<?php esc_attr_e( 'Settings sections', 'remaily' ); ?>"<?php echo 'is-side' === $class ? ' aria-orientation="vertical"' : ''; ?>>
			<?php foreach ( $tabs as $id => $tab ) : ?>
				<button
					type="button"
					class="vlt-admin-header__nav-item"
					id="vlt-settings-tab-<?php echo esc_attr( $id ); ?>"
					role="tab"
					aria-controls="vlt-settings-panel-<?php echo esc_attr( $id ); ?>"
					aria-selected="<?php echo $id === $current ? 'true' : 'false'; ?>"
					tabindex="<?php echo $id === $current ? '0' : '-1'; ?>"
					data-vlt-tab="<?php echo esc_attr( $id ); ?>"
				>
					<?php if ( $tab['icon'] ) : ?>
						<?php Icons::the_glyph( $tab['icon'] ); ?>
					<?php endif; ?>
					<?php echo esc_html( $tab['label'] ); ?>
				</button>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Any Controls tree drawn as the sections are, its inputs named {name}[a][b] (an add-on's window); conditions
	 * read their controls inside the closest data-vlt-scope
	 *
	 * @param array  $fields Tree
	 * @param array  $values Its values
	 * @param string $name   Name of the inputs' top
	 */
	public function render_tree( array $fields, array $values, $name ) {
		( new SettingsControls( $name, true ) )->render_nodes( $fields, [], $values, true );
	}

	/**
	 * The controls of the page's sections, their inputs named after the option
	 *
	 * @return SettingsControls
	 */
	private function controls() {
		return $this->controls ?? ( $this->controls = new SettingsControls( $this->args['option'] ) );
	}

	/**
	 * A section: heading, notes, then its fields
	 *
	 * @param string $section Section
	 * @param bool   $open    Shown before the script runs
	 */
	private function render_section( $section, $open ) {
		$definition = $this->sections()[ $section ];
		$values     = $this->values();
		?>
		<section class="vlt-settings-page__panel" id="vlt-settings-panel-<?php echo esc_attr( $section ); ?>" role="tabpanel" aria-labelledby="vlt-settings-tab-<?php echo esc_attr( $section ); ?>" tabindex="0"<?php echo $open ? '' : ' hidden'; ?>>
			<div class="vlt-settings-page__head">
				<h2><?php echo esc_html( $definition['title'] ); ?></h2>
				<?php
				// The tab's page of the documentation ('docs'), else the documentation's start
				$docs = (string) ( $definition['docs'] ?? $this->args['docs_url'] );
				if ( '' !== $docs ) :
					?>
					<a class="vlt-settings-page__docs" href="<?php echo esc_url( $docs ); ?>" target="_blank" rel="noopener"><?php Icons::the_glyph( 'info' ); ?><?php esc_html_e( 'Documentation', 'remaily' ); ?></a>
				<?php endif; ?>
				<?php if ( !empty( $definition['description'] ) ) : ?>
					<p><?php echo wp_kses( $definition['description'], self::HELP_HTML ); ?></p>
				<?php endif; ?>
			</div>

			<?php
			// Notes the module adds above the fields (e.g. a conflict it detected)
			foreach ( (array) ( $definition['notices'] ?? [] ) as $notice ) :
				?>
				<p class="vlt-settings-page__note is-<?php echo esc_attr( $notice['type'] ?? 'info' ); ?>"><?php echo esc_html( $notice['text'] ); ?></p>
			<?php endforeach; ?>

			<?php $this->controls()->render_nodes( (array) ( $definition['fields'] ?? [] ), [ $section ], $values, true ); ?>
		</section>
		<?php
	}

}
