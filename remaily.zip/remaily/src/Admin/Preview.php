<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;
use VLT\Remaily\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The editor's Preview: the unsaved form on a front-end page, with the theme's styles but no header or footer
 *
 * The editor posts the form into an iframe; nothing is sent from it.
 */
class Preview {
	const QUERY_VAR = 'remaily-preview';

	const NONCE = 'remaily-preview';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'render' ], 0 );
	}

	/**
	 * Address of the preview
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( self::QUERY_VAR, '1', home_url( '/' ) );
	}

	/**
	 * Print the preview page
	 */
	public static function render() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce is checked below
		if ( empty( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}

		if ( !current_user_can( Admin::CAPABILITY ) || !isset( $_POST['_wpnonce'] ) || !wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_wpnonce'] ) ), self::NONCE ) ) {
			wp_die( esc_html__( 'This view has expired. Reload the editor.', 'remaily' ), '', [ 'response' => 403 ] );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, each part is cleaned below
		$data     = json_decode( wp_unslash( (string) ( $_POST['data'] ?? '' ) ), true );
		$data     = is_array( $data ) ? $data : [];
		$template = (string) ( $data['template'] ?? '' );

		// The template as saving would keep it: through kses for users without unfiltered_html. Form::make() cleans the settings
		$form = Form::make(
			absint( $data['id'] ?? 0 ),
			sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			current_user_can( 'unfiltered_html' ) ? $template : wp_kses_post( $template ),
			(array) ( $data['config'] ?? [] )
		);

		show_admin_bar( false );
		add_filter( 'remaily_form_attributes', static fn( $attrs ) => $attrs + [ 'data-remaily-preview' => __( 'All good. Forms aren\'t sent from the preview.', 'remaily' ) ] );

		// Rendered before wp_head() so its assets land in <head>
		$html = Renderer::render( $form );

		Assets::enqueue( 'remaily-preview' );

		echo StyleManager::render_template( 'preview/page.php', [ 'html' => $html, 'form' => $form ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered template, escaped inside
		exit;
	}
}
