<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\PostType;
use VLT\Remaily\Entries\Entries;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A wordpress.org review, asked once per site: after a form's first real message, on the Contact
 * Forms and Entries lists. Either answer ends it.
 */
class ReviewNotice {
	/**
	 * '' = not yet, 'due' = ask, 'done' = asked
	 */
	const OPTION = 'remaily_review';
	const ACTION = 'remaily_review';
	const URL    = 'https://wordpress.org/support/plugin/remaily/reviews/#new-post';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'remaily_submitted', [ __CLASS__, 'submitted' ] );
		add_action( 'admin_notices', [ __CLASS__, 'render' ] );
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'handle' ] );
	}

	/**
	 * A message that went through (not a test): due
	 *
	 * @param Submission $submission Submission
	 */
	public static function submitted( Submission $submission ) {
		if ( !get_option( self::OPTION ) && 'success' === $submission->status() && !$submission->is_demo() ) {
			update_option( self::OPTION, 'due', false );
		}
	}

	/**
	 * The notice, on the lists of forms and entries
	 */
	public static function render() {
		$screen = get_current_screen();

		if ( 'due' !== get_option( self::OPTION ) || !current_user_can( Admin::CAPABILITY ) || !$screen || 'edit' !== $screen->base
			|| !in_array( $screen->post_type, [ PostType::NAME, Entries::POST_TYPE ], true ) ) {
			return;
		}

		$link = static fn( $answer ) => wp_nonce_url( add_query_arg( [ 'action' => self::ACTION, 'answer' => $answer ], admin_url( 'admin-post.php' ) ), self::ACTION );
		?>
		<div class="notice notice-info remaily-review">
			<span class="remaily-review__logo" aria-hidden="true"><?php echo wp_kses_post( Icons::logo( 44 ) ); ?></span>
			<div class="remaily-review__body">
				<span class="remaily-review__stars" aria-hidden="true"><?php echo str_repeat( '<span class="dashicons dashicons-star-filled"></span>', 5 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup ?></span>
				<p><strong><?php esc_html_e( 'Your form got its first message!', 'remaily' ); ?></strong></p>
				<p><?php esc_html_e( 'If Re:Maily helps you, a review on WordPress.org helps others find it. It takes a minute.', 'remaily' ); ?></p>
				<p class="remaily-review__actions">
					<a class="button button-primary" href="<?php echo esc_url( $link( 'review' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Leave a review', 'remaily' ); ?></a>
					<a class="button" href="<?php echo esc_url( $link( 'no' ) ); ?>"><?php esc_html_e( 'No, thanks', 'remaily' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * An answer: either one ends it; "Leave a review" goes on to the review form
	 */
	public static function handle() {
		check_admin_referer( self::ACTION );

		if ( !current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Sorry, you can\'t do that.', 'remaily' ), 403 );
		}

		update_option( self::OPTION, 'done', false );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- checked above
		if ( 'review' === sanitize_key( wp_unslash( $_GET['answer'] ?? '' ) ) ) {
			wp_redirect( self::URL ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- wordpress.org
			exit;
		}

		wp_safe_redirect( wp_get_referer() ?: Admin::url() );
		exit;
	}
}
