<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Entries\Entries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Re:Maily box on the Dashboard: unread and this week's messages, the latest ones and links to the lists
 */
class Dashboard {
	const WIDGET = 'remaily_dashboard';

	// Latest entries shown
	const LATEST = 5;

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'wp_dashboard_setup', [ __CLASS__, 'setup' ] );
	}

	/**
	 * Add the box for those who build forms
	 */
	public static function setup() {
		if ( !current_user_can( Admin::CAPABILITY ) ) {
			return;
		}

		wp_add_dashboard_widget( self::WIDGET, 'Re:Maily', [ __CLASS__, 'render' ] );
		Assets::enqueue( 'remaily-admin-dashboard' );
	}

	/**
	 * The box
	 */
	public static function render() {
		$entries = get_posts( [
			'post_type'      => Entries::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => self::LATEST,
		] );
		$unread  = Entries::unread();
		$week    = self::week();
		$list    = admin_url( EntriesList::LIST_PAGE );
		?>
		<div class="activity-block remaily-dash__stats">
			<a href="<?php echo esc_url( $list ); ?>">
				<strong><?php echo esc_html( number_format_i18n( $unread ) ); ?></strong>
				<?php esc_html_e( 'Unread', 'remaily' ); ?>
			</a>
			<a href="<?php echo esc_url( $list ); ?>">
				<strong><?php echo esc_html( number_format_i18n( $week ) ); ?></strong>
				<?php esc_html_e( 'Last 7 days', 'remaily' ); ?>
			</a>
		</div>

		<div class="activity-block">
			<?php if ( $entries ) : ?>
				<h3><?php esc_html_e( 'Latest messages', 'remaily' ); ?></h3>
				<ul class="remaily-dash__list">
					<?php foreach ( $entries as $entry ) : ?>
						<?php
						$form  = (int) $entry->post_parent;
						$title = esc_html( get_the_title( $entry ) ?: __( '(no title)', 'remaily' ) );
						?>
						<li>
							<a href="<?php echo esc_url( EntryView::url( $entry->ID ) ); ?>"><?php echo get_post_meta( $entry->ID, '_remaily_unread', true ) ? '<strong>' . $title . '</strong>' : $title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?></a>
							<span class="description">
								<?php
								echo esc_html( PostType::NAME === get_post_type( $form ) ? get_the_title( $form ) : __( 'Form deleted', 'remaily' ) );
								echo ' · ';
								/* translators: %s: time since the message, such as "2 hours" */
								echo esc_html( sprintf( __( '%s ago', 'remaily' ), human_time_diff( get_post_timestamp( $entry ) ) ) );
								?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'No messages yet. They show up here once someone sends one of your forms.', 'remaily' ); ?></p>
			<?php endif; ?>
		</div>

		<p class="community-events-footer remaily-dash__links">
			<a href="<?php echo esc_url( $list ); ?>"><?php esc_html_e( 'All entries', 'remaily' ); ?></a>
			<a href="<?php echo esc_url( admin_url( Admin::LIST_PAGE ) ); ?>"><?php esc_html_e( 'Contact forms', 'remaily' ); ?></a>
		</p>
		<?php
	}

	/**
	 * How many entries came in the last 7 days
	 *
	 * @return int
	 */
	private static function week() {
		$query = new \WP_Query( [
			'post_type'      => Entries::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'date_query'     => [ [ 'after' => '7 days ago', 'inclusive' => true ] ],
		] );

		return (int) $query->found_posts;
	}
}
