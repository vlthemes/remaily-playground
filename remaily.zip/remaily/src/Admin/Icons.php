<?php

namespace VLT\Remaily\Admin;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin icons: brand logos (assets/icons/, and an add-on's own through remaily_logos) and UI icons (Lucide,
 * assets/icons/lucide/), each sent once per page in an inline sprite, and the Re:Maily logo
 */
class Icons {
	/**
	 * The Re:Maily logo (assets/icons/logo.webp), decorative
	 *
	 * @param int $size Width and height in px
	 *
	 * @return string
	 */
	public static function logo( $size = 52 ) {
		return sprintf( '<img src="%s" width="%2$d" height="%2$d" alt="">', esc_url( self::logo_url() ), (int) $size );
	}

	/**
	 * URL of the logo
	 *
	 * @return string
	 */
	public static function logo_url() {
		return REMAILY_URL . 'assets/icons/logo.webp';
	}

	/**
	 * Icons used on this page, printed once as a sprite in the footer (sprite())
	 *
	 * @var array [ name => true ]
	 */
	private static $icons = [];

	/**
	 * An icon of assets/icons/: a <use> of the page's sprite, so each is sent once and nothing more is loaded
	 *
	 * @param string $name File name without .svg
	 *
	 * @return string
	 */
	public static function icon( $name ) {
		$name = sanitize_key( $name );

		if ( '' === self::svg( $name ) ) {
			return '';
		}

		if ( !self::$icons ) {
			add_action( 'admin_footer', [ __CLASS__, 'sprite' ] );
		}

		self::$icons[ $name ] = true;

		return '<svg class="remaily-svg" aria-hidden="true" focusable="false"><use href="#remaily-' . esc_attr( $name ) . '"></use></svg>';
	}

	/**
	 * A UI icon: one of assets/icons/lucide/ (Lucide, lucide.dev) through the sprite, an add-on's own SVG markup, else a
	 * dashicon of that name
	 *
	 * @param string $name  Icon name (settings, shield, credit-card…)
	 * @param string $class More classes
	 *
	 * @return string
	 */
	public static function glyph( $name, $class = '' ) {
		// An add-on's own icon, as SVG markup
		if ( 0 === strpos( trim( (string) $name ), '<svg' ) ) {
			return (string) preg_replace( '/^\s*<svg\b/', '<svg class="remaily-svg remaily-glyph' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" aria-hidden="true" focusable="false"', (string) $name, 1 );
		}

		$name = sanitize_key( $name );
		$svg  = self::icon( $name );

		if ( '' !== $svg ) {
			return str_replace( 'class="remaily-svg"', 'class="remaily-svg remaily-glyph' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '"', $svg );
		}

		return '' === $name ? '' : '<span class="dashicons dashicons-' . esc_attr( $name ) . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" aria-hidden="true"></span>';
	}

	/**
	 * Print a UI icon (glyph())
	 *
	 * @param string $name  Icon name
	 * @param string $class More classes
	 */
	public static function the_glyph( $name, $class = '' ) {
		$glyph = self::glyph( $name, $class );

		echo wp_kses( $glyph, remaily_allowed_html( $glyph ) );
	}

	/**
	 * The whole SVG of assets/icons/ or assets/icons/lucide/ (the menu's icon, a data URI)
	 *
	 * @param string $name File name without .svg
	 *
	 * @return string
	 */
	public static function svg( $name ) {
		$name  = sanitize_key( $name );
		$added = self::added()[ $name ] ?? '';

		// An add-on's own logo first: a name it registered
		if ( '' !== $added && '.svg' === substr( $added, -4 ) && is_file( $added ) ) {
			return trim( (string) file_get_contents( $added ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
		}

		foreach ( [ 'assets/icons/', 'assets/icons/lucide/' ] as $dir ) {
			$file = REMAILY_PATH . $dir . sanitize_key( $name ) . '.svg';

			if ( is_file( $file ) ) {
				return trim( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
			}
		}

		return '';
	}

	/**
	 * Logos an add-on of someone else's brings, by name: its SVG files (remaily_logos), read once
	 *
	 *     add_filter( 'remaily_logos', fn( $logos ) => $logos + [ 'my-crm' => MY_ADDON_PATH . 'assets/my-crm.svg' ] );
	 *     'icon' => remaily_logo( 'my-crm' ),
	 *
	 * @return array [ name => file path ]
	 */
	private static function added() {
		static $added = null;

		if ( null === $added ) {
			$added = [];

			foreach ( (array) apply_filters( 'remaily_logos', [] ) as $name => $file ) {
				$added[ sanitize_key( (string) $name ) ] = (string) $file;
			}
		}

		return $added;
	}

	/**
	 * The icons used on the page as <symbol>s; their own ids get the icon's name (two icons may both say id="a")
	 */
	public static function sprite() {
		$symbols = '';

		foreach ( array_keys( self::$icons ) as $name ) {
			$svg = self::svg( $name );

			if ( !preg_match( '/<svg\b([^>]*)>(.*)<\/svg>/s', $svg, $parts ) ) {
				continue;
			}

			$box   = preg_match( '/viewBox="([^"]+)"/', $parts[1], $match ) ? $match[1] : '0 0 24 24';
			// The root's paint (a Lucide icon's stroke) goes to its symbol
			$fill  = preg_match_all( '/\s((?:fill|stroke|stroke-width|stroke-linecap|stroke-linejoin)="[^"]+")/', $parts[1], $match ) ? ' ' . implode( ' ', $match[1] ) : '';
			$inner = preg_replace( [ '/\bid="([^"]+)"/', '/url\(#([^)]+)\)/', '/href="#([^"]+)"/' ], [ 'id="' . $name . '-$1"', 'url(#' . $name . '-$1)', 'href="#' . $name . '-$1"' ], $parts[2] );

			$symbols .= '<symbol id="remaily-' . $name . '" viewBox="' . $box . '"' . $fill . '>' . $inner . '</symbol>';
		}

		// Out of sight but drawn: clip paths and gradients of a display:none SVG don't render
		$sprite = '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden">' . $symbols . '</svg>';

		echo wp_kses( $sprite, remaily_allowed_html( $sprite ) );
	}}
