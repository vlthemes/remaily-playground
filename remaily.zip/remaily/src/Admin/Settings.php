<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Addons\Addons;
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's settings (Contact Form → Settings), stored in one option
 *
 * Values: Settings::get( 'section' ), Settings::value( 'spam.turnstile.use' ) (themes: remaily_get_setting()). More
 * sections: remaily_settings_sections, each a Controls tree (Core\Controls); more tabs: remaily_settings_tabs.
 */
class Settings {
	const OPTION = 'remaily_settings';
	const PAGE   = 'remaily-settings';

	/**
	 * The page
	 *
	 * @var SettingsPage|null
	 */
	private static $page = null;

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'plugin_action_links_' . plugin_basename( REMAILY_FILE ), [ __CLASS__, 'action_links' ] );
		self::page();
	}

	/**
	 * Settings and Docs in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_links( array $links ) {
		return [
			'remaily-settings' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Settings', 'remaily' ) . '</a>',
			'remaily-docs'     => '<a href="' . esc_url( self::docs_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs', 'remaily' ) . '</a>',
		] + $links;
	}

	/**
	 * The documentation
	 *
	 * @return string
	 */
	public static function docs_url() {
		return (string) apply_filters( 'remaily_docs_url', 'https://vlthemes.me/docs/remaily/' );
	}

	/**
	 * The settings page
	 *
	 * @return SettingsPage
	 */
	public static function page() {
		if ( null === self::$page ) {
			self::upgrade();

			self::$page = new SettingsPage( [
				'option'      => self::OPTION,
				'page'        => self::PAGE,
				'parent'      => Admin::LIST_PAGE,
				'title'       => __( 'Re:Maily Settings', 'remaily' ),
				'menu_title'  => __( 'Settings', 'remaily' ),
				'name'        => 'Re:Maily',
				'version'     => REMAILY_VERSION,
				'icon'        => Icons::logo(),
				'sections'    => [ __CLASS__, 'sections' ],
				'tabs_filter' => 'remaily_settings_tabs',
				'validate'    => [ __CLASS__, 'validate' ],
				'docs_url'    => self::docs_url(),
				'support_url' => (string) apply_filters( 'remaily_support_url', 'https://wordpress.org/support/plugin/remaily/' ),
			] );
		}

		return self::$page;
	}

	/**
	 * Sections and their fields
	 *
	 * @return array
	 */
	public static function sections() {
		// A captcha's section: its keys and where it runs (spam.{id}.site, .secret, .use)
		$captcha = static fn( array $head, array $more = [] ) => [ 'type' => 'section', 'layout' => 'card' ] + $head + [
			'fields' => [
				'site'   => [ 'type' => 'text', 'label' => __( 'Site key', 'remaily' ), 'default' => '' ],
				'secret' => [ 'type' => 'secret', 'label' => __( 'Secret key', 'remaily' ), 'default' => '' ],
				'use'    => [ 'type' => 'select', 'as' => 'checkbox', 'checked' => 'all', 'label' => __( 'Use on every form', 'remaily' ), 'options' => [ 'all' => __( 'Every form', 'remaily' ), 'off' => __( 'Only the forms that pick it', 'remaily' ) ], 'default' => 'all', 'help' => __( 'Off: it runs only on the forms that pick it, in their Advanced tab.', 'remaily' ) ],
			] + $more,
		];

		// A link in a description or help, the others' sites in a new tab
		$link = static fn( $url, $text, $own = false ) => '<a href="' . esc_url( $url ) . '"' . ( $own ? '' : ' target="_blank" rel="noopener"' ) . '>' . esc_html( $text ) . '</a>';

		$sections = (array) apply_filters( 'remaily_settings_sections', [
			'spam'    => [
				'tab'         => __( 'Spam', 'remaily' ),
				'icon'        => 'shield',
				'title'       => __( 'Spam', 'remaily' ),
				'description' => __( 'Checks every form runs before a message is sent. Visitors see none of these first ones. A captcha below runs on every form once its keys are saved, or only on the forms that pick it in their Advanced tab.', 'remaily' ),
				'docs'        => trailingslashit( self::docs_url() ) . 'spam-protection/',
				'fields'      => [
					'honeypot'   => [
						'type'    => 'toggle',
						'label'   => __( 'Hidden trap for bots', 'remaily' ),
						'default' => true,
						'help'    => __( 'Adds a field people never see. Bots fill it in and get caught.', 'remaily' ),
					],
					'min_time'   => [
						'type'    => 'number',
						'label'   => __( 'Least time to fill a form', 'remaily' ),
						'unit'    => __( 'seconds', 'remaily' ),
						'min'     => 0,
						'max'     => 60,
						'default' => 3,
						'help'    => __( 'Forms sent faster than this are treated as spam: people need a few seconds. 0 turns it off.', 'remaily' ),
					],
					'rate_limit' => [
						'type'    => 'number',
						'label'   => __( 'Messages per visitor', 'remaily' ),
						'unit'    => __( 'in 10 minutes', 'remaily' ),
						'min'     => 0,
						'max'     => 100,
						'default' => 10,
						'help'    => __( 'More from the same IP address in 10 minutes are treated as spam. 0 turns it off.', 'remaily' ),
					],
					'disallowed' => [
						'type'    => 'toggle',
						'label'   => __( 'Use the Disallowed Comment Keys', 'remaily' ),
						'default' => true,
						/* translators: %s: link to Settings → Discussion */
						'help'    => sprintf( __( 'Messages with a word, email, IP address or browser from the list in %s are treated as spam, as comments are.', 'remaily' ), $link( admin_url( 'options-discussion.php#disallowed_keys' ), __( 'Settings → Discussion', 'remaily' ), true ) ),
					],
					'akismet'    => [
						'type'    => 'toggle',
						'label'   => __( 'Check with Akismet', 'remaily' ),
						'default' => false,
						'help'    => \VLT\Remaily\Spam\Akismet::available() ? __( 'Akismet looks at the name, email and message as it does with comments.', 'remaily' ) : /* translators: %s: link to install Akismet, or to its key screen */ sprintf( __( 'Needs the %s, active and set up with its key.', 'remaily' ), $link( class_exists( 'Akismet' ) ? admin_url( 'options-general.php?page=akismet-key-config' ) : admin_url( 'plugin-install.php?s=akismet&tab=search&type=term' ), __( 'Akismet plugin', 'remaily' ), true ) ),
					],
				] + [
					// phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- a link to the Cloudflare dashboard, nothing loads from it
					'turnstile'    => $captcha( [ 'icon' => Icons::icon( 'turnstile' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'turnstile' ), 'title' => 'Cloudflare Turnstile', /* translators: %s: link to the Cloudflare dashboard */ 'description' => sprintf( __( 'Free and private, usually without a puzzle. Get keys in your %s, under Turnstile.', 'remaily' ), $link( 'https://dash.cloudflare.com/?to=/:account/turnstile', __( 'Cloudflare dashboard', 'remaily' ) ) ) ] ),
					'hcaptcha'     => $captcha( [ 'icon' => Icons::icon( 'hcaptcha' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'hcaptcha' ), 'title' => 'hCaptcha', /* translators: %s: link to dashboard.hcaptcha.com */ 'description' => sprintf( __( 'Get keys at %s.', 'remaily' ), $link( 'https://dashboard.hcaptcha.com/', 'dashboard.hcaptcha.com' ) ) ] ),
					'smartcaptcha' => $captcha( [ 'icon' => Icons::icon( 'smartcaptcha' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'smartcaptcha' ), 'title' => 'Yandex SmartCaptcha', /* translators: %s: link to the Yandex Cloud console */ 'description' => sprintf( __( 'Get keys in the %s.', 'remaily' ), $link( 'https://console.cloud.yandex.com/', __( 'Yandex Cloud console', 'remaily' ) ) ) ] ),
					'recaptcha'    => $captcha( [ 'icon' => Icons::icon( 'recaptcha' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'recaptcha' ), 'title' => 'Google reCAPTCHA v3', /* translators: %s: link to google.com/recaptcha/admin */ 'description' => sprintf( __( 'Invisible: it scores each visitor. Get v3 keys at %s.', 'remaily' ), $link( 'https://www.google.com/recaptcha/admin', 'google.com/recaptcha/admin' ) ) ], [
						'score' => [
							'type'    => 'select',
							'as'      => 'radio',
							'label'   => __( 'Lowest score let through', 'remaily' ),
							'options' => [ '0.3' => __( '0.3: lenient', 'remaily' ), '0.5' => __( '0.5: balanced', 'remaily' ), '0.7' => __( '0.7: strict', 'remaily' ) ],
							'default' => '0.5',
							'inline'  => true,
							'help'    => __( 'reCAPTCHA scores visitors from 0 (a bot) to 1 (a person).', 'remaily' ),
						],
						'badge' => [
							'type'    => 'select',
							'as'      => 'checkbox',
							'checked' => 'hide',
							'label'   => __( 'Hide the badge', 'remaily' ),
							'options' => [ 'show' => __( 'In the page corner', 'remaily' ), 'hide' => __( 'Hidden', 'remaily' ) ],
							'default' => 'show',
							'help'    => __( 'Google lets you hide its badge only if the page says the site is protected by reCAPTCHA and links to Google\'s Privacy Policy and Terms of Service. Add that line to your form or theme yourself.', 'remaily' ),
						],
					] ),
				],
			],
			'messages' => [
				'tab'         => __( 'Messages', 'remaily' ),
				'icon'        => 'message-square',
				'title'       => __( 'Messages', 'remaily' ),
				'description' => __( 'What visitors read after sending, or when a field needs fixing, in every form. A form can still change any of them in its Messages tab. Leave one empty to use the text Re:Maily comes with.', 'remaily' ),
				'fields'      => \VLT\Remaily\Core\Messages::settings_fields(),
			],
			'entries' => [
				'tab'         => __( 'Entries', 'remaily' ),
				'icon'        => 'mail',
				'title'       => __( 'Entries', 'remaily' ),
				'description' => __( 'Re:Maily keeps a copy of every message in Contact Form → Entries. Each form can turn this off in its Advanced tab.', 'remaily' ),
				'fields'      => [
					'retention'   => [
						'type'    => 'number',
						'label'   => __( 'Keep entries for', 'remaily' ),
						'unit'    => __( 'days', 'remaily' ),
						'min'     => 0,
						'max'     => 3650,
						'default' => 0,
						'help'    => __( 'Older entries are deleted once a day. 0 keeps them until you delete them.', 'remaily' ),
					],
					'visitor_ip'  => [
						'type'    => 'select',
						'as'      => 'radio',
						'label'   => __( 'Visitor\'s IP address and browser', 'remaily' ),
						'options' => [
							'short' => __( 'Shortened IP and the browser', 'remaily' ),
							'full'  => __( 'Full IP and the browser', 'remaily' ),
							'none'  => __( 'Don\'t save them', 'remaily' ),
						],
						'default' => 'short',
						'help'    => __( 'What entries and webhooks keep of each visit. Shortened: the last part of the IP is dropped (192.168.1.0), which is usually enough under the GDPR. Spam checks use the full IP either way and don\'t keep it.', 'remaily' ),
					],
					'delete_data' => [
						'type'    => 'toggle',
						'label'   => __( 'Remove everything when the plugin is deleted', 'remaily' ),
						'default' => false,
						'help'    => __( 'Forms, entries and settings go when you delete Re:Maily from the Plugins screen. Off: they stay, ready if you install it again.', 'remaily' ),
					],
					'uploads'     => [
						'type'        => 'section',
						'title'       => __( 'Uploaded files', 'remaily' ),
						'description' => __( 'Files sent with a form wait here, closed to the web, until they are mailed.', 'remaily' ),
						'fields'      => [
							'folder' => [
								'type'    => 'slug',
								'label'   => __( 'Folder', 'remaily' ),
								'default' => 'remaily',
								/* translators: %s: the folder's name */
								'preview' => sprintf( __( 'Path: %s', 'remaily' ), '/' . trim( str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( wp_upload_dir( null, false )['basedir'] ) ), '/' ) . '/%s' ),
								'help'    => __( 'A folder in uploads. Files sent after a change go to the new folder; earlier ones stay where they are.', 'remaily' ),
							],
						],
					],
				],
			],
		] );

		// An add-on's section while it's read-only (its own word): its note in place of its fields, saved as it was
		foreach ( $sections as $id => $section ) {
			if ( isset( $section['fields'] ) ) {
				$sections[ $id ]['fields'] = Addons::mark_readonly( (array) $section['fields'] );
			}
		}

		return $sections;
	}

	/**
	 * Messages left as Remaily ships them are stored empty, so a better text in an update reaches them
	 *
	 * @param array $clean Clean values of every section
	 *
	 * @return array
	 */
	public static function validate( array $clean ) {
		foreach ( (array) ( $clean['messages'] ?? [] ) as $key => $text ) {
			if ( \VLT\Remaily\Core\Messages::built_in( $key ) === $text ) {
				$clean['messages'][ $key ] = '';
			}
		}

		return $clean;
	}

	/**
	 * One value by its path, such as spam.turnstile.use
	 *
	 * @param string $path    Path
	 * @param mixed  $default When there is none
	 *
	 * @return mixed
	 */
	public static function value( $path, $default = null ) {
		return self::page()->value( $path, $default );
	}

	/**
	 * CSS of the settings with an output, for every form (Renderer prints it with the forms' styles)
	 *
	 * @return string
	 */
	public static function css() {
		$values = self::page()->values();
		$css    = '';

		foreach ( self::page()->sections() as $section => $definition ) {
			$css .= \VLT\Remaily\Core\Controls::css( (array) ( $definition['fields'] ?? [] ), (array) ( $values[ $section ] ?? [] ), '.remaily', $values, $section );
		}

		return $css;
	}

	/**
	 * Values saved before their sections nested (spam.turnstile_site) move to their sections (spam.turnstile.site), once
	 */
	private static function upgrade() {
		$saved = get_option( self::OPTION, [] );
		$moved = false;

		if ( !is_array( $saved ) ) {
			return;
		}

		foreach ( [ 'spam' => [ 'turnstile', 'hcaptcha', 'smartcaptcha', 'recaptcha' ], 'payments' => [ 'stripe', 'paypal' ], 'integrations' => [ 'brevo' ] ] as $section => $groups ) {
			foreach ( (array) ( $saved[ $section ] ?? [] ) as $key => $value ) {
				if ( !is_array( $value ) && preg_match( '/^(' . implode( '|', $groups ) . ')_(.+)$/', (string) $key, $match ) ) {
					$saved[ $section ][ $match[1] ][ $match[2] ] = $value;
					unset( $saved[ $section ][ $key ] );
					$moved = true;
				}
			}
		}

		if ( $moved ) {
			update_option( self::OPTION, $saved );
		}
	}

	/**
	 * Values of a section
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public static function get( $section ) {
		return self::page()->get( $section );
	}

	/**
	 * The settings screen
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'admin.php?page=' . self::PAGE );
	}
}
