<?php

namespace VLT\Remaily\Admin;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's settings (Contact Form → Settings), stored in one option
 *
 * Values: Settings::get( 'section' ). More sections: remaily_settings_sections; more tabs: remaily_settings_tabs.
 */
class Settings {
	const OPTION = 'remaily_settings';
	const PAGE   = 'remaily-settings';

	/**
	 * The page
	 *
	 * @var SettingsPage|null
	 */
	private static $page = null;

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 31 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'docs_link' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( REMAILY_FILE ), [ __CLASS__, 'action_links' ] );
		self::page();
	}

	/**
	 * Documentation after Settings in the Contact Form menu
	 */
	public static function menu() {
		// A full URL as the slug: WordPress prints it as the link
		add_submenu_page( Admin::LIST_PAGE, __( 'Documentation', 'remaily' ), __( 'Documentation', 'remaily' ), Admin::CAPABILITY, self::docs_url() );
	}

	/**
	 * The Documentation menu link opens in a new tab
	 */
	public static function docs_link() {
		if ( !Admin::is_plugin_screen() ) {
			return;
		}

		// The menu prints the URL without its trailing slash
		wp_add_inline_script( 'common', 'document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("#adminmenu a[href^=\'' . esc_js( untrailingslashit( self::docs_url() ) ) . '\']").forEach(function(a){a.target="_blank";a.rel="noopener";});});' );
	}

	/**
	 * Settings and Docs in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_links( array $links ) {
		return [
			'remaily-settings' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Settings', 'remaily' ) . '</a>',
			'remaily-docs'     => '<a href="' . esc_url( self::docs_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs', 'remaily' ) . '</a>',
		] + $links;
	}

	/**
	 * The documentation
	 *
	 * @return string
	 */
	public static function docs_url() {
		return (string) apply_filters( 'remaily_docs_url', 'https://vlthemes.me/docs/remaily/' );
	}

	/**
	 * The settings page
	 *
	 * @return SettingsPage
	 */
	public static function page() {
		if ( null === self::$page ) {
			self::$page = new SettingsPage( [
				'option'      => self::OPTION,
				'page'        => self::PAGE,
				'parent'      => Admin::LIST_PAGE,
				'title'       => __( 'Re:Maily Settings', 'remaily' ),
				'menu_title'  => __( 'Settings', 'remaily' ),
				'name'        => 'Re:Maily',
				'version'     => REMAILY_VERSION,
				'icon'        => Admin::logo(),
				'sections'    => [ __CLASS__, 'sections' ],
				'tabs_filter' => 'remaily_settings_tabs',
				'validate'    => [ __CLASS__, 'validate' ],
				'docs_url'    => self::docs_url(),
				'support_url' => (string) apply_filters( 'remaily_support_url', 'https://wordpress.org/support/plugin/remaily/' ),
			] );
		}

		return self::$page;
	}

	/**
	 * Sections and their fields
	 *
	 * @return array
	 */
	public static function sections() {
		$keys = static fn( $group ) => [
			$group . '_site'   => [ 'type' => 'text', 'group' => $group, 'label' => __( 'Site key', 'remaily' ), 'default' => '' ],
			$group . '_secret' => [ 'type' => 'secret', 'group' => $group, 'label' => __( 'Secret key', 'remaily' ), 'default' => '' ],
			$group . '_use'    => [ 'type' => 'select', 'group' => $group, 'label' => __( 'Use on', 'remaily' ), 'options' => [ 'all' => __( 'Every form', 'remaily' ), 'off' => __( 'No form', 'remaily' ) ], 'default' => 'all' ],
		];

		// A link in a description or help, the others' sites in a new tab
		$link = static fn( $url, $text, $own = false ) => '<a href="' . esc_url( $url ) . '"' . ( $own ? '' : ' target="_blank" rel="noopener"' ) . '>' . esc_html( $text ) . '</a>';

		return (array) apply_filters( 'remaily_settings_sections', [
			'spam'    => [
				'tab'         => __( 'Spam', 'remaily' ),
				'icon'        => 'shield',
				'title'       => __( 'Spam', 'remaily' ),
				/* translators: %s: link to the Spam protection page of the documentation */
				'description' => sprintf( __( 'Checks every form runs before a message is sent. Visitors see none of these first ones. A captcha below runs on every form once its keys are saved; a form can skip them in its Advanced tab. Step by step: %s.', 'remaily' ), $link( trailingslashit( self::docs_url() ) . 'spam-protection/', __( 'Spam protection', 'remaily' ) ) ),
				'groups'      => [
					// phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- a link to the Cloudflare dashboard, nothing loads from it
					'turnstile' => [ 'icon' => Admin::icon( 'captcha-turnstile' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'turnstile' ), 'title' => 'Cloudflare Turnstile', /* translators: %s: link to the Cloudflare dashboard */ 'description' => sprintf( __( 'Free and private, usually without a puzzle. Get keys in your %s, under Turnstile.', 'remaily' ), $link( 'https://dash.cloudflare.com/?to=/:account/turnstile', __( 'Cloudflare dashboard', 'remaily' ) ) ) ],
					'hcaptcha'  => [ 'icon' => Admin::icon( 'captcha-hcaptcha' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'hcaptcha' ), 'title' => 'hCaptcha', /* translators: %s: link to dashboard.hcaptcha.com */ 'description' => sprintf( __( 'Get keys at %s.', 'remaily' ), $link( 'https://dashboard.hcaptcha.com/', 'dashboard.hcaptcha.com' ) ) ],
					'recaptcha' => [ 'icon' => Admin::icon( 'captcha-recaptcha' ), 'status' => \VLT\Remaily\Spam\Captcha::status( 'recaptcha' ), 'title' => 'Google reCAPTCHA v3', /* translators: %s: link to google.com/recaptcha/admin */ 'description' => sprintf( __( 'Invisible: it scores each visitor. Get v3 keys at %s.', 'remaily' ), $link( 'https://www.google.com/recaptcha/admin', 'google.com/recaptcha/admin' ) ) ],
				],
				'fields'      => [
					'honeypot'   => [
						'type'    => 'toggle',
						'label'   => __( 'Hidden trap for bots', 'remaily' ),
						'default' => true,
						'help'    => __( 'Adds a field people never see. Bots fill it in and get caught.', 'remaily' ),
					],
					'min_time'   => [
						'type'    => 'number',
						'label'   => __( 'Least time to fill a form', 'remaily' ),
						'unit'    => __( 'seconds', 'remaily' ),
						'min'     => 0,
						'max'     => 60,
						'default' => 3,
						'help'    => __( 'Forms sent faster than this are treated as spam: people need a few seconds. 0 turns it off.', 'remaily' ),
					],
					'rate_limit' => [
						'type'    => 'number',
						'label'   => __( 'Messages per visitor', 'remaily' ),
						'unit'    => __( 'in 10 minutes', 'remaily' ),
						'min'     => 0,
						'max'     => 100,
						'default' => 10,
						'help'    => __( 'More from the same IP address in 10 minutes are treated as spam. 0 turns it off.', 'remaily' ),
					],
					'disallowed' => [
						'type'    => 'toggle',
						'label'   => __( 'Use the Disallowed Comment Keys', 'remaily' ),
						'default' => true,
						/* translators: %s: link to Settings → Discussion */
						'help'    => sprintf( __( 'Messages with a word, email, IP address or browser from the list in %s are treated as spam, as comments are.', 'remaily' ), $link( admin_url( 'options-discussion.php#disallowed_keys' ), __( 'Settings → Discussion', 'remaily' ), true ) ),
					],
					'akismet'    => [
						'type'    => 'toggle',
						'label'   => __( 'Check with Akismet', 'remaily' ),
						'default' => false,
						'help'    => \VLT\Remaily\Spam\Akismet::available() ? __( 'Akismet looks at the name, email and message as it does with comments.', 'remaily' ) : /* translators: %s: link to install Akismet, or to its key screen */ sprintf( __( 'Needs the %s, active and set up with its key.', 'remaily' ), $link( class_exists( 'Akismet' ) ? admin_url( 'options-general.php?page=akismet-key-config' ) : admin_url( 'plugin-install.php?s=akismet&tab=search&type=term' ), __( 'Akismet plugin', 'remaily' ), true ) ),
					],
				] + $keys( 'turnstile' ) + $keys( 'hcaptcha' ) + $keys( 'recaptcha' ) + [
					'recaptcha_score' => [
						'type'    => 'select',
						'group'   => 'recaptcha',
						'label'   => __( 'Lowest score let through', 'remaily' ),
						'options' => [ '0.3' => __( '0.3: lenient', 'remaily' ), '0.5' => __( '0.5: balanced', 'remaily' ), '0.7' => __( '0.7: strict', 'remaily' ) ],
						'default' => '0.5',
						'help'    => __( 'reCAPTCHA scores visitors from 0 (a bot) to 1 (a person).', 'remaily' ),
					],
					'recaptcha_badge' => [
						'type'    => 'select',
						'group'   => 'recaptcha',
						'label'   => __( 'Badge', 'remaily' ),
						'options' => [ 'show' => __( 'In the page corner', 'remaily' ), 'hide' => __( 'Hidden', 'remaily' ) ],
						'default' => 'show',
						'help'    => __( 'Google lets you hide its badge only if the page says the site is protected by reCAPTCHA and links to Google\'s Privacy Policy and Terms of Service. Add that line to your form or theme yourself.', 'remaily' ),
					],
				],
			],
			'messages' => [
				'tab'         => __( 'Messages', 'remaily' ),
				'icon'        => 'format-chat',
				'title'       => __( 'Messages', 'remaily' ),
				'description' => __( 'What visitors read after sending, or when a field needs fixing, in every form. A form can still change any of them in its Messages tab. Leave one empty to use the text Re:Maily comes with.', 'remaily' ),
				'columns'     => 2,
			] + \VLT\Remaily\Core\Messages::settings_fields(),
			'entries' => [
				'tab'         => __( 'Entries', 'remaily' ),
				'icon'        => 'email-alt',
				'title'       => __( 'Entries', 'remaily' ),
				'description' => __( 'Re:Maily keeps a copy of every message in Contact Form → Entries. Each form can turn this off in its Advanced tab.', 'remaily' ),
				'fields'      => [
					'retention'   => [
						'type'    => 'number',
						'label'   => __( 'Keep entries for', 'remaily' ),
						'unit'    => __( 'days', 'remaily' ),
						'min'     => 0,
						'max'     => 3650,
						'default' => 0,
						'help'    => __( 'Older entries are deleted once a day. 0 keeps them until you delete them.', 'remaily' ),
					],
					'visitor_ip'  => [
						'type'    => 'select',
						'label'   => __( 'Visitor\'s IP address and browser', 'remaily' ),
						'options' => [
							'short' => __( 'Shortened IP and the browser', 'remaily' ),
							'full'  => __( 'Full IP and the browser', 'remaily' ),
							'none'  => __( 'Don\'t save them', 'remaily' ),
						],
						'default' => 'short',
						'help'    => __( 'What entries and webhooks keep of each visit. Shortened: the last part of the IP is dropped (192.168.1.0), which is usually enough under the GDPR. Spam checks use the full IP either way and don\'t keep it.', 'remaily' ),
					],
					'delete_data' => [
						'type'    => 'toggle',
						'label'   => __( 'Remove everything when the plugin is deleted', 'remaily' ),
						'default' => false,
						'help'    => __( 'Forms, entries and settings go when you delete Re:Maily from the Plugins screen. Off: they stay, ready if you install it again.', 'remaily' ),
					],
				],
			],
		] );
	}

	/**
	 * Messages left as Remaily ships them are stored empty, so a better text in an update reaches them
	 *
	 * @param array $clean Clean values of every section
	 *
	 * @return array
	 */
	public static function validate( array $clean ) {
		foreach ( (array) ( $clean['messages'] ?? [] ) as $key => $text ) {
			if ( \VLT\Remaily\Core\Messages::built_in( $key ) === $text ) {
				$clean['messages'][ $key ] = '';
			}
		}

		return $clean;
	}

	/**
	 * Values of a section
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public static function get( $section ) {
		return self::page()->get( $section );
	}

	/**
	 * The settings screen
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'admin.php?page=' . self::PAGE );
	}
}
