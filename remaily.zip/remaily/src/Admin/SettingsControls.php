<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Addons\AddonsPage;
use VLT\Remaily\Core\Controls;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The controls of a Controls tree on a settings screen: lines, cards, rows, notes and each control with its label,
 * help and conditions. The Settings page draws its sections with it; an add-on's window draws its own tree
 */
class SettingsControls {
	// What a field's help and a section's or group's description may hold: links, such as to a WordPress screen
	const HELP_HTML = [ 'a' => [ 'href' => true, 'target' => true, 'rel' => true ], 'code' => [], 'strong' => [], 'ol' => [], 'ul' => [], 'li' => [], 'br' => [] ];

	/**
	 * Name of the inputs' top: the option's, or a tree's own ({name}[a][b])
	 *
	 * @var string
	 */
	private $name;

	/**
	 * Drawing a tree of its own (an add-on's window), not the page's sections: its ids carry its name
	 *
	 * @var bool
	 */
	private $tree;

	/**
	 * Constructor
	 *
	 * @param string $name Name of the inputs' top
	 * @param bool   $tree A tree of its own
	 */
	public function __construct( $name, $tree = false ) {
		$this->name = (string) $name;
		$this->tree = (bool) $tree;
	}

	/**
	 * A level of the tree. On the tab's own level each control and section is a line: its name on the left, the
	 * controls on the right; inside a section the controls stack, a row's side by side
	 *
	 * @param array $fields Tree
	 * @param array $path   Keys of this level from the option's top (the section first)
	 * @param array $top    Every value, for conditions
	 * @param bool  $outer  The tab's own level
	 */
	public function render_nodes( array $fields, array $path, array $top, $outer = false ) {
		$cards = [];
		$flush = function () use ( &$cards, $path, $top ) {
			if ( $cards ) {
				echo '<div class="vlt-settings-page__cards">';

				foreach ( $cards as $key => $node ) {
					$this->render_card( $key, $node, $path, $top );
				}

				echo '</div>';
				$cards = [];
			}
		};

		foreach ( $fields as $key => $node ) {
			$type = $node['type'] ?? 'text';

			// Sections shown as cards (a service each: a captcha, a payment, an integration), side by side
			if ( $outer && 'section' === $type && 'card' === ( $node['layout'] ?? '' ) ) {
				$cards[ $key ] = $node;
				continue;
			}

			$flush();

			if ( 'section' === $type || 'row' === $type ) {
				$this->render_container( $key, $node, $path, $top, $outer );
			} elseif ( 'divider' === $type ) {
				echo '<hr class="vlt-settings-page__divider"';
				$this->the_condition( $node, $path, $top );
				echo '>';
			} elseif ( 'notice' === $type ) {
				?>
				<p class="vlt-settings-page__note is-<?php echo esc_attr( $node['tone'] ?? 'info' ); ?>"<?php $this->the_condition( $node, $path, $top ); ?>><?php echo wp_kses( (string) ( $node['text'] ?? '' ), self::HELP_HTML ); ?></p>
				<?php
			} elseif ( Controls::valued( $type ) && 'map' !== $type ) {
				$outer ? $this->render_line( $key, $node, $path, $top ) : $this->render_field( $key, $node, $path, $top );
			}
		}

		$flush();
	}

	/**
	 * A section as a card: its icon, title and state, the description, then its controls
	 *
	 * @param string $key  Key
	 * @param array  $node Section
	 * @param array  $path Keys of its level
	 * @param array  $top  Every value
	 */
	private function render_card( $key, array $node, array $path, array $top ) {
		$inner = Controls::nests( $node ) ? array_merge( $path, [ $key ] ) : $path;

		if ( isset( $node['status_callback'] ) && is_callable( $node['status_callback'] ) ) {
			$node['status'] = (array) call_user_func( $node['status_callback'] );
		}
		?>
		<div class="vlt-settings-page__service"<?php $this->the_condition( $node, $path, $top ); ?>>
			<div class="vlt-settings-page__service-head">
				<?php if ( !empty( $node['icon'] ) ) : ?>
					<span class="vlt-settings-page__block-icon" aria-hidden="true"><?php echo wp_kses( $node['icon'], remaily_allowed_html( $node['icon'] ) ); ?></span>
				<?php endif; ?>
				<h3><?php echo esc_html( (string) ( $node['title'] ?? '' ) ); ?></h3>
				<?php if ( !empty( $node['status'] ) ) : ?>
					<span class="vlt-settings-page__status is-<?php echo esc_attr( $node['status'][1] ?? 'muted' ); ?>"><?php echo esc_html( $node['status'][0] ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( !empty( $node['description'] ) || !empty( $node['docs'] ) ) : ?>
				<div class="vlt-settings-page__service-text">
					<?php echo wp_kses( (string) ( $node['description'] ?? '' ), self::HELP_HTML ); ?>
					<?php if ( !empty( $node['docs'] ) ) : ?>
						<?php // The set-up, step by step, lives in the documentation ?>
						<a href="<?php echo esc_url( $node['docs'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $node['docs_label'] ?? __( 'How to set it up', 'remaily' ) ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="vlt-settings-page__service-body">
				<?php if ( !empty( $node['readonly'] ) ) : ?>
					<?php $this->the_readonly( $node ); ?>
				<?php else : ?>
					<?php $this->render_nodes( (array) ( $node['fields'] ?? [] ), $inner, $top ); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * The note in place of a read-only add-on's controls: its own words, and its window on the Add-ons page
	 *
	 * @param array $node Section
	 */
	private function the_readonly( array $node ) {
		$link = '<a href="' . esc_url( admin_url( 'admin.php?page=' . AddonsPage::PAGE . '#' . $node['addon'] ) ) . '">' . esc_html__( 'Open the add-on', 'remaily' ) . '</a>';

		echo '<p class="vlt-settings-page__note is-warning">' . wp_kses( (string) $node['readonly'], self::HELP_HTML ) . ' ' . $link . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the link is built and escaped above
	}

	/**
	 * A section (a line: its heading, icon, state and description on the left, its controls on the right) or a row
	 * (its controls side by side)
	 *
	 * @param string $key   Key
	 * @param array  $node  Container
	 * @param array  $path  Keys of its level
	 * @param array  $top   Every value
	 * @param bool   $outer On the tab's own level
	 */
	private function render_container( $key, array $node, array $path, array $top, $outer ) {
		$inner = Controls::nests( $node ) ? array_merge( $path, [ $key ] ) : $path;

		if ( 'row' === ( $node['type'] ?? '' ) ) {
			$fields = (array) ( $node['fields'] ?? [] );
			?>
			<div class="vlt-settings-page__columns" style="--vlt-settings-columns:<?php echo esc_attr( max( 1, (int) ( $node['columns'] ?? count( $fields ) ) ) ); ?>"<?php $this->the_condition( $node, $path, $top ); ?>>
				<?php $this->render_nodes( $fields, $inner, $top ); ?>
			</div>
			<?php
			return;
		}

		// Worked out when shown: a status that reads the settings can't while they are being built
		if ( isset( $node['status_callback'] ) && is_callable( $node['status_callback'] ) ) {
			$node['status'] = (array) call_user_func( $node['status_callback'] );
		}
		?>
		<div class="vlt-settings-page__line is-section<?php echo $outer ? '' : ' is-inner'; ?>"<?php $this->the_condition( $node, $path, $top ); ?>>
			<div class="vlt-settings-page__line-label">
				<?php if ( !empty( $node['title'] ) ) : ?>
					<h3>
						<?php if ( !empty( $node['icon'] ) ) : ?>
							<span class="vlt-settings-page__block-icon" aria-hidden="true"><?php echo wp_kses( $node['icon'], remaily_allowed_html( $node['icon'] ) ); ?></span>
						<?php endif; ?>
						<?php echo esc_html( $node['title'] ); ?>
					</h3>
				<?php endif; ?>
				<?php if ( !empty( $node['status'] ) ) : ?>
					<span class="vlt-settings-page__status is-<?php echo esc_attr( $node['status'][1] ?? 'muted' ); ?>"><?php echo esc_html( $node['status'][0] ); ?></span>
				<?php endif; ?>
				<?php if ( !empty( $node['description'] ) ) : ?>
					<p><?php echo wp_kses( $node['description'], self::HELP_HTML ); ?></p>
				<?php endif; ?>
			</div>

			<div class="vlt-settings-page__line-control">
				<?php if ( !empty( $node['readonly'] ) ) : ?>
					<?php $this->the_readonly( $node ); ?>
				<?php else : ?>
					<?php $this->render_nodes( (array) ( $node['fields'] ?? [] ), $inner, $top ); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Print a control's help, under it
	 *
	 * @param array  $field Control
	 * @param string $id    The control's ID
	 */
	private function the_help( array $field, $id ) {
		if ( !empty( $field['help'] ) ) {
			echo '<p class="vlt-settings-page__help" id="' . esc_attr( $id . '-help' ) . '">' . wp_kses( $field['help'], self::HELP_HTML ) . '</p>';
		}
	}

	/**
	 * Print a control's aria-describedby, pointing at its help
	 *
	 * @param array  $field Control
	 * @param string $id    The control's ID
	 */
	private function the_described( array $field, $id ) {
		if ( !empty( $field['help'] ) ) {
			echo ' aria-describedby="' . esc_attr( $id . '-help' ) . '"';
		}
	}

	/**
	 * Print the attributes of a node with a condition: the rules for admin-settings.js, hidden while they don't hold
	 *
	 * @param array $node Node
	 * @param array $path Keys of its level
	 * @param array $top  Every value
	 */
	private function the_condition( array $node, array $path, array $top ) {
		$rules = Controls::conditions( $node['condition'] ?? [], implode( '.', $path ) );

		if ( $rules ) {
			echo ' data-vlt-condition="' . esc_attr( (string) wp_json_encode( $rules ) ) . '"' . ( Controls::matches( $rules, $top ) ? '' : ' hidden' );
		}
	}

	/**
	 * What a control needs to be drawn: its value, id, input name and dotted path
	 *
	 * @param string $key   Key
	 * @param array  $field Control
	 * @param array  $path  Keys of its level
	 * @param array  $top   Every value
	 *
	 * @return array [ value, id, name, path ]
	 */
	private function input( $key, array $field, array $path, array $top ) {
		$parts = array_merge( $path, [ $key ] );
		$saved = Controls::pick( $top, implode( '.', $parts ) );
		$root  = $this->name;

		return [
			'' === $saved && !empty( $field['fill'] ) ? $field['default'] : $saved,
			'vlt-settings-' . ( $this->tree ? sanitize_key( $root ) . '-' : '' ) . implode( '-', $parts ),
			$root . '[' . implode( '][', $parts ) . ']',
			implode( '.', $parts ),
		];
	}

	/**
	 * A control's label: its icon, its name and unit
	 *
	 * @param array  $field Control
	 * @param string $id    The control's ID
	 */
	private function the_label( array $field, $id ) {
		?>
		<label class="vlt-settings-page__label" for="<?php echo esc_attr( $id ); ?>">
			<?php if ( !empty( $field['icon'] ) && 0 === strpos( $field['icon'], '<svg' ) ) : ?>
				<span class="vlt-settings-page__icon" aria-hidden="true"><?php echo wp_kses( $field['icon'], remaily_allowed_html( $field['icon'] ) ); ?></span>
			<?php elseif ( !empty( $field['icon'] ) ) : ?>
				<?php Icons::the_glyph( $field['icon'] ); ?>
			<?php endif; ?>
			<?php echo esc_html( $field['label'] . ( !empty( $field['unit'] ) ? ', ' . $field['unit'] : '' ) ); ?>
		</label>
		<?php
	}

	/**
	 * A control of the tab's own level: its name on the left, the control and its help on the right
	 *
	 * @param string $key   Key
	 * @param array  $field Control
	 * @param array  $path  Keys of its level
	 * @param array  $top   Every value
	 */
	private function render_line( $key, array $field, array $path, array $top ) {
		[ , $id ] = $this->input( $key, $field, $path, $top );
		?>
		<div class="vlt-settings-page__line"<?php $this->the_condition( $field, $path, $top ); ?>>
			<div class="vlt-settings-page__line-label"><?php $this->the_label( $field, $id ); ?></div>
			<div class="vlt-settings-page__line-control">
				<?php $this->the_control( $key, $field, $path, $top, 'checkbox' === ( $field['as'] ?? '' ) ? $field['label'] : __( 'Enable', 'remaily' ) ); ?>
				<?php $this->the_help( $field, $id ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * A control inside a section: its label above (a checkbox's beside), the help under
	 *
	 * @param string $key   Key
	 * @param array  $field Control
	 * @param array  $path  Keys of its level
	 * @param array  $top   Every value
	 */
	private function render_field( $key, array $field, array $path, array $top ) {
		[ , $id ] = $this->input( $key, $field, $path, $top );
		$toggle   = 'toggle' === ( $field['type'] ?? 'text' ) || 'checkbox' === ( $field['as'] ?? '' );
		?>
		<div class="vlt-settings-page__field"<?php $this->the_condition( $field, $path, $top ); ?>>
			<?php if ( !$toggle ) : ?>
				<?php $this->the_label( $field, $id ); ?>
			<?php endif; ?>
			<?php $this->the_control( $key, $field, $path, $top, $toggle ? $field['label'] : '' ); ?>
			<?php $this->the_help( $field, $id ); ?>
		</div>
		<?php
	}

	/**
	 * The control itself
	 *
	 * @param string $key   Key
	 * @param array  $field Control
	 * @param array  $path  Keys of its level
	 * @param array  $top   Every value
	 * @param string $check A checkbox's words beside it
	 */
	private function the_control( $key, array $field, array $path, array $top, $check = '' ) {
		[ $value, $id, $name, $dotted ] = $this->input( $key, $field, $path, $top );

		$type = $field['type'] ?? 'text';

		switch ( $type ) {
			case 'toggle':
				?>
				<label class="vlt-settings-page__check">
					<?php // Unchecked boxes are not sent: the hidden 0 keeps "off" as a saved choice ?>
					<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
					<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $value ); ?> data-vlt-path="<?php echo esc_attr( $dotted ); ?>"<?php $this->the_described( $field, $id ); ?>>
					<?php echo esc_html( $check ); ?>
				</label>
				<?php
				break;

			case 'checkboxes':
				// Its fixed options (a source is for the form editor)
				?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>[]" value="">
				<?php foreach ( (array) ( $field['options'] ?? [] ) as $option => $label ) : ?>
					<label class="vlt-settings-page__check"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $option ); ?>" <?php checked( in_array( (string) $option, array_map( 'strval', (array) $value ), true ) ); ?>> <?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
				<?php
				break;

			case 'image':
				// A picked image of the Media Library (admin-settings.js opens it)
				$image = $value ? wp_get_attachment_image( $value, 'medium' ) : '';
				?>
				<div class="vlt-settings-page__image" data-vlt-settings-image data-title="<?php echo esc_attr( $field['label'] ); ?>" data-empty="<?php esc_attr_e( 'No image', 'remaily' ); ?>">
					<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" data-vlt-path="<?php echo esc_attr( $dotted ); ?>">
					<button type="button" class="vlt-settings-page__image-preview<?php echo $image ? '' : ' is-empty'; ?>" data-vlt-settings-image-choose aria-label="<?php esc_attr_e( 'Choose image', 'remaily' ); ?>">
						<?php echo wp_kses_post( $image ?: '<span>' . esc_html__( 'No image', 'remaily' ) . '</span>' ); ?>
					</button>
					<div class="vlt-settings-page__image-actions">
						<button type="button" class="vlt-settings-page__button" data-vlt-settings-image-choose><?php esc_html_e( 'Choose image', 'remaily' ); ?></button>
						<button type="button" class="vlt-settings-page__button is-link" data-vlt-settings-image-remove<?php echo $image ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove', 'remaily' ); ?></button>
					</div>
				</div>
				<?php
				break;

			case 'textarea':
				?>
				<textarea class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="<?php echo esc_attr( $field['rows'] ?? 4 ); ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>" data-vlt-path="<?php echo esc_attr( $dotted ); ?>"<?php $this->the_described( $field, $id ); ?>><?php echo esc_textarea( $value ); ?></textarea>
				<?php
				break;

			case 'select':
				$options = (array) $field['options'];

				// Two options as a box: ticked for 'checked', the other one when not
				if ( 'checkbox' === ( $field['as'] ?? '' ) && 2 === count( $options ) ) {
					$on  = (string) ( $field['checked'] ?? array_key_first( $options ) );
					$off = (string) current( array_diff( array_map( 'strval', array_keys( $options ) ), [ $on ] ) );
					?>
					<label class="vlt-settings-page__check">
						<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $off ); ?>">
						<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $on ); ?>" <?php checked( (string) $value, $on ); ?> data-vlt-path="<?php echo esc_attr( $dotted ); ?>" data-vlt-off="<?php echo esc_attr( $off ); ?>"<?php $this->the_described( $field, $id ); ?>>
						<?php echo esc_html( $check ); ?>
					</label>
					<?php
					break;
				}

				// A few options as radios: each one in sight, one a line or side by side ('inline' => true)
				if ( 'radio' === ( $field['as'] ?? '' ) ) {
					?>
					<span class="vlt-settings-page__radios<?php echo empty( $field['inline'] ) ? '' : ' is-inline'; ?>" role="radiogroup" id="<?php echo esc_attr( $id ); ?>"<?php $this->the_described( $field, $id ); ?>>
						<?php foreach ( $options as $option => $label ) : ?>
							<label class="vlt-settings-page__check"><input type="radio" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $option ); ?>" <?php checked( (string) $value, (string) $option ); ?> data-vlt-path="<?php echo esc_attr( $dotted ); ?>"> <?php echo esc_html( $label ); ?></label>
						<?php endforeach; ?>
					</span>
					<?php
					break;
				}
				?>
				<select class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" data-vlt-path="<?php echo esc_attr( $dotted ); ?>"<?php $this->the_described( $field, $id ); ?>>
					<?php foreach ( $field['options'] as $option => $label ) : ?>
						<option value="<?php echo esc_attr( $option ); ?>" <?php selected( (string) $value, (string) $option ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php
				break;

			case 'number':
				?>
				<input type="number" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" min="<?php echo esc_attr( $field['min'] ?? '' ); ?>" max="<?php echo esc_attr( $field['max'] ?? '' ); ?>" step="<?php echo esc_attr( $field['step'] ?? 1 ); ?>" placeholder="<?php echo esc_attr( $field['default'] ?? '' ); ?>" data-vlt-path="<?php echo esc_attr( $dotted ); ?>"<?php $this->the_described( $field, $id ); ?>>
				<?php
				break;

			case 'color':
				// A color as text (#hex, rgba(), a var()), with the browser's picker beside it (admin-settings.js keeps them in step)
				?>
				<span class="vlt-settings-page__color">
					<input type="color" value="<?php echo esc_attr( preg_match( '/^#[\da-f]{6}$/i', (string) $value ) ? $value : '#000000' ); ?>" aria-label="<?php echo esc_attr( $field['label'] ); ?>" data-vlt-color-for="<?php echo esc_attr( $id ); ?>">
					<input type="text" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $field['default'] ?? '#1b2aff' ); ?>" spellcheck="false" data-vlt-path="<?php echo esc_attr( $dotted ); ?>">
				</span>
				<?php
				break;

			default:
				// text, secret (its mask, never the key: kept while left as is, replaced when typed over), slug, unit (16px)
				$shown       = 'secret' === $type ? Controls::mask( (string) $value ) : $value;
				$placeholder = 'slug' === $type || 'unit' === $type ? ( $field['default'] ?? '' ) : ( $field['placeholder'] ?? '' );
				?>
				<input type="text" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $shown ); ?>" placeholder="<?php echo esc_attr( $placeholder ); ?>"<?php echo 'secret' === $type ? ' autocomplete="off"' : ''; ?> spellcheck="false" data-vlt-path="<?php echo esc_attr( $dotted ); ?>"<?php $this->the_described( $field, $id ); ?>>
				<?php
				// Example address of a slug field, updated as it is typed (admin-settings.js)
				if ( !empty( $field['preview'] ) ) :
					[ $before, $after ] = array_pad( explode( '%s', $field['preview'], 2 ), 2, '' );
					?>
					<p class="vlt-settings-page__preview" data-vlt-settings-preview="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $before ); ?><b><?php echo esc_html( $value ); ?></b><?php echo esc_html( $after ); ?></p>
					<?php
				endif;
		}
	}}
