<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Core\PostType;
use VLT\Remaily\Entries\Entries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One entry: its values and where it came from (Contact Form → Entries → View); opening it marks it read
 */
class EntryView {
	const PAGE = 'remaily-entry';

	/**
	 * Address of an entry
	 *
	 * @param int $id Entry ID
	 *
	 * @return string
	 */
	public static function url( $id ) {
		return add_query_arg( '_wpnonce', wp_create_nonce( self::PAGE . '-' . (int) $id ), admin_url( 'admin.php?page=' . self::PAGE . '&entry=' . (int) $id ) );
	}

	/**
	 * Opening an entry from its list marks it read; a link from elsewhere only shows it
	 */
	public static function open() {
		$id = absint( $_GET['entry'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which entry is open

		if ( !wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), self::PAGE . '-' . $id ) ) {
			return;
		}

		if ( $id && Entries::POST_TYPE === get_post_type( $id ) && current_user_can( 'edit_post', $id ) ) {
			Entries::mark_read( $id );
		}
	}

	/**
	 * The screen
	 */
	public static function render() {
		$id   = absint( $_GET['entry'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which entry to show
		$post = $id ? get_post( $id ) : null;

		if ( !$post || Entries::POST_TYPE !== $post->post_type || !current_user_can( 'edit_post', $id ) ) {
			wp_die( esc_html__( 'This entry doesn\'t exist, or you can\'t see it.', 'remaily' ) );
		}

		$data = Entries::data( $id );
		$meta = Entries::meta( $id );
		$form = PostType::NAME === get_post_type( $post->post_parent ) ? (int) $post->post_parent : 0;
		$user = $meta['user_id'] ? get_userdata( (int) $meta['user_id'] ) : null;
		?>
		<div class="wrap vlt-settings-page remaily-entry">
			<h1 class="screen-reader-text"><?php echo esc_html( get_the_title( $post ) ); ?></h1>
			<hr class="wp-header-end">

			<?php Settings::page()->header( __( 'entry', 'remaily' ) ); ?>

			<div class="vlt-settings-page__card remaily-entry__card">
				<div class="remaily-entry__head">
					<div>
						<h2><?php echo esc_html( get_the_title( $post ) ?: __( '(no title)', 'remaily' ) ); ?></h2>
						<p>
							<?php
							/* translators: 1: date, 2: time */
							echo esc_html( sprintf( __( 'Sent on %1$s at %2$s', 'remaily' ), get_the_date( '', $post ), get_the_time( '', $post ) ) );
							?>
							<?php if ( get_post_meta( $id, '_remaily_mail_failed', true ) ) : ?>
								<span class="remaily-entry-flag"><?php esc_html_e( 'The mail for this message could not be sent', 'remaily' ); ?></span>
							<?php endif; ?>
						</p>
					</div>
					<div class="remaily-entry__actions">
						<a class="vlt-settings-page__button" href="<?php echo esc_url( admin_url( EntriesList::LIST_PAGE ) ); ?>"><?php esc_html_e( 'All entries', 'remaily' ); ?></a>
						<?php if ( current_user_can( 'delete_post', $id ) ) : ?>
							<a class="vlt-settings-page__button is-danger" href="<?php echo esc_url( get_delete_post_link( $id ) ); ?>"><?php esc_html_e( 'Move to trash', 'remaily' ); ?></a>
						<?php endif; ?>
						<?php
						/**
						 * Buttons beside All entries and Move to trash, such as Reply or Refund
						 *
						 * @param int $id Entry ID
						 */
						do_action( 'remaily_entry_actions', $id );
						?>
					</div>
				</div>

				<table class="remaily-entry__values">
					<?php foreach ( $data as $name => $item ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( ucfirst( str_replace( [ '_', '-' ], ' ', $name ) ) ); ?> <code>[<?php echo esc_html( $name ); ?>]</code></th>
							<td>
								<?php if ( !empty( $item['rows'] ) ) : ?>
									<table class="remaily-entry__rows">
										<tr>
											<?php foreach ( array_keys( (array) reset( $item['rows'] ) ) as $column ) : ?>
												<th scope="col"><?php echo esc_html( ucfirst( str_replace( [ '_', '-' ], ' ', $column ) ) ); ?></th>
											<?php endforeach; ?>
										</tr>
										<?php foreach ( $item['rows'] as $row ) : ?>
											<tr>
												<?php foreach ( (array) $row as $value ) : ?>
													<td><?php echo nl2br( esc_html( (string) $value ) ); ?></td>
												<?php endforeach; ?>
											</tr>
										<?php endforeach; ?>
									</table>
								<?php elseif ( '' === trim( $item['value'] ) ) : ?>
									<span class="remaily-entry__empty"><?php esc_html_e( 'Left empty', 'remaily' ); ?></span>
								<?php elseif ( 'email' === $item['type'] && is_email( $item['value'] ) ) : ?>
									<a href="mailto:<?php echo esc_attr( $item['value'] ); ?>"><?php echo esc_html( $item['value'] ); ?></a>
								<?php else : ?>
									<?php echo nl2br( esc_html( $item['value'] ) ); ?>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h3 class="remaily-entry__subtitle"><?php esc_html_e( 'Details', 'remaily' ); ?></h3>
				<table class="remaily-entry__values is-details">
					<tr>
						<th scope="row"><?php esc_html_e( 'Form', 'remaily' ); ?></th>
						<td><?php echo $form ? '<a href="' . esc_url( Admin::edit_url( $form ) ) . '">' . esc_html( get_the_title( $form ) ) . '</a>' : esc_html__( 'Deleted', 'remaily' ); ?></td>
					</tr>
					<?php if ( $meta['url'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Sent from', 'remaily' ); ?></th>
							<td><a href="<?php echo esc_url( $meta['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $meta['url'] ); ?></a></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'User', 'remaily' ); ?></th>
						<td><?php echo $user ? esc_html( $user->display_name ) : esc_html__( 'A visitor, not logged in', 'remaily' ); ?></td>
					</tr>
					<?php if ( $meta['ip'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'IP address', 'remaily' ); ?></th>
							<td><?php echo esc_html( $meta['ip'] ); ?></td>
						</tr>
					<?php endif; ?>
					<?php if ( $meta['user_agent'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Browser', 'remaily' ); ?></th>
							<td><?php echo esc_html( $meta['user_agent'] ); ?></td>
						</tr>
					<?php endif; ?>
					<?php foreach ( (array) $meta['utm'] as $key => $value ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $key ); ?></th>
							<td><?php echo esc_html( $value ); ?></td>
						</tr>
					<?php endforeach; ?>
				</table>

				<?php
				/**
				 * More of the entry under its details, such as notes, a status or the payment
				 *
				 * @param int   $id   Entry ID
				 * @param array $data Values by field: [ name => [ 'value', 'type' ] ]
				 * @param array $meta The visit: ip, user_agent, url, user_id
				 */
				do_action( 'remaily_entry_view', $id, $data, $meta );
				?>
			</div>
		</div>
		<?php
	}
}
