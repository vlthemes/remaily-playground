<?php

namespace VLT\Remaily\Admin;

use VLT\Remaily\Addons\Addons;
use VLT\Remaily\Addons\AddonsPage;
use VLT\Remaily\Core\Messages;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Forms\Places;
use VLT\Remaily\Front\StyleManager;
use VLT\Remaily\Mail\MailTags;
use VLT\Remaily\Spam\Captcha;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The form editor: a React app (assets/src/editor) on Contact Form → Contact Forms → a form
 */
class Editor {
	/**
	 * The screen: the app mounts here
	 *
	 * @param Form $form Form
	 */
	public static function render( Form $form ) {
		?>
		<div class="wrap remaily-editor-wrap">
			<h1 class="screen-reader-text"><?php echo esc_html( $form->title() ); ?></h1>
			<hr class="wp-header-end">
			<div id="remaily-editor"><p class="remaily-editor-loading"><?php esc_html_e( 'Loading the editor…', 'remaily' ); ?></p></div>
		</div>
		<?php
	}

	/**
	 * Every message with its label and the text it has when the form doesn't change it (the site's, else the built-in)
	 *
	 * @return array [ key => [ 'label', 'default' ] ]
	 */
	private static function messages() {
		$messages = Messages::all();

		foreach ( $messages as $key => $message ) {
			$messages[ $key ]['default'] = Messages::default( $key );
		}

		return $messages;
	}

	/**
	 * The captchas a form can run (both keys in Settings → Spam), with their logos and whether they run on every form
	 *
	 * @return array [ id => [ 'label', 'logo', 'every' ] ]
	 */
	private static function captchas() {
		$captchas = [];
		$every    = Captcha::available();

		foreach ( Captcha::ready() as $id => $label ) {
			$captchas[ $id ] = [ 'label' => $label, 'logo' => Captcha::logo( $id ), 'every' => isset( $every[ $id ] ) ];
		}

		return $captchas;
	}

	/**
	 * What the app reads (window.remailyEditor)
	 *
	 * @param Form $form Form
	 *
	 * @return array
	 */
	public static function script_data( Form $form ) {
		$types = [];

		foreach ( FieldRegistry::all() as $id => $type ) {
			$types[] = [
				'type'     => $id,
				'label'    => $type->label(),
				'tip'      => $type->tip(),
				'icon'     => $type->icon(),
				/**
				 * Where a type's button goes in the editor: 'main' (the row of field buttons) or 'more' (the More menu)
				 *
				 * @param string $menu Menu
				 * @param string $id   Type
				 * @param Field  $type Type
				 */
				'menu'     => 'more' === apply_filters( 'remaily_field_menu', $type->menu(), $id, $type ) ? 'more' : 'main',
				'summary'  => $type->summary(),
				'docs'     => $type->docs(),
				'defaults' => $type->defaults(),
				'schema'   => (object) $type->schema(),
				'required' => isset( $type->shared()['required'] ),
				'shared'   => (object) $type->shared(),
				'submits'  => $type->submits(),
				'styles'   => (object) StyleManager::styles( 'fields', $id ),
				'messages' => array_keys( $type->messages() ),
				// What [[name:key]] can show of this type: [ key => label ]
				'info'     => (object) array_map( static fn( $item ) => (string) $item['label'], $type->info( $type->defaults() ) ),
			];
		}

		$config = $form->config();

		foreach ( [ 'fields', 'groups', 'messages', 'addons' ] as $key ) {
			$config[ $key ] = (object) $config[ $key ];
		}

		return (array) apply_filters( 'remaily_editor_data', [
			'form'         => [
				'id'          => $form->id(),
				'hash'        => $form->hash(),
				'title'       => $form->title(),
				'description' => $form->description(),
				'status'      => $form->status(),
				'template'    => $form->template(),
				'config'      => $config,
			],
			'types'        => $types,
			'formStyles'   => (object) StyleManager::styles( 'form' ),
			'messages'     => (object) self::messages(),
			'general'      => array_keys( Messages::general() ),
			'settingMessages' => array_map( 'array_keys', Messages::of_settings() ),
			'specialTags'  => MailTags::specials(),
			'listUrl'      => Admin::url(),
			'settingsUrl'  => Settings::url(),
			// Add-ons that run: [ slug => { name, readonly } ]; a read-only one's tab shows its note and can't be changed
			'addons'       => (object) Addons::editor_data(),
			// Tabs drawn from Controls trees (remaily_form_tabs)
			'formTabs'     => Addons::form_tabs_data(),
			'addonsUrl'    => admin_url( 'admin.php?page=' . AddonsPage::PAGE ),
			// Webhooks send messages off the site: administrators only (Config::save() keeps them for the others)
			'canWebhooks'  => current_user_can( 'manage_options' ),
			// The JavaScript tab: Config::save() keeps the form's code for the others
			'canJs'        => current_user_can( 'unfiltered_html' ),
			// Where WordPress connects AI services (7.0+), for those who may change it
			'connectorsUrl' => current_user_can( 'manage_options' ) && file_exists( ABSPATH . 'wp-admin/options-connectors.php' ) ? admin_url( 'options-connectors.php' ) : '',
			// Set in wp-config.php: on for every form, the form's own toggle can't turn them off
			'testMode'     => defined( 'REMAILY_TEST_MODE' ) && REMAILY_TEST_MODE,
			'mailOff'      => defined( 'REMAILY_DISABLE_MAIL' ) && REMAILY_DISABLE_MAIL,
			'previewUrl'   => Preview::url(),
			'previewNonce' => wp_create_nonce( Preview::NONCE ),
			'logo'         => Icons::logo(),
			'captchas'     => (object) self::captchas(),
			'places'       => (object) Places::editor(),
			// The Country field's and the Tel masks' list, by name: code => name
			'countries'    => (object) array_map( static fn( $country ) => $country['name'], \VLT\Remaily\Core\Countries::all() ),
			'docsUrl'      => Settings::docs_url(),
			'aiAvailable'  => \VLT\Remaily\Api\Describe::available(),
		], $form );
	}
}
