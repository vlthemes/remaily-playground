<?php

namespace VLT\Remaily;

use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\Remaily;
use VLT\Remaily\Core\Upgrade;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin bootstrap
 */
class Plugin {
	const VERSION = '1.0.0';

	/**
	 * Start the plugin
	 *
	 * @param string $file Main plugin file
	 */
	public static function boot( $file ) {
		define( 'REMAILY_VERSION', self::VERSION );
		define( 'REMAILY_FILE', $file );
		define( 'REMAILY_PATH', plugin_dir_path( $file ) );
		define( 'REMAILY_URL', plugin_dir_url( $file ) );

		// The functions for themes, there from the start (a theme's functions.php may check for them)
		require_once __DIR__ . '/functions.php';

		register_activation_hook( $file, [ __CLASS__, 'activate' ] );
		register_deactivation_hook( $file, [ __CLASS__, 'deactivate' ] );

		// On init, not earlier: messages and labels are translated strings
		add_action( 'init', [ __CLASS__, 'start' ], 0 );
	}

	/**
	 * Start the parts
	 */
	public static function start() {
		Assets::init();
		Upgrade::init();
		Remaily::instance();
	}

	/**
	 * Activation
	 */
	public static function activate() {
		Upgrade::run();
		Admin\Welcome::activate();
	}

	/**
	 * Deactivation: the daily cleanup of entries stops
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( Entries\Entries::CRON );
	}
}
