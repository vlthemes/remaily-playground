<?php

namespace VLT\Remaily\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor widget: a saved Remaily form
 */
class FormWidget extends Widget_Base {
	/**
	 * Widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return Integration::WIDGET;
	}

	/**
	 * Widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Re:Maily Contact Form', 'remaily' );
	}

	/**
	 * Widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		// The Re:Maily mark, drawn by Integration::editor_icon()
		return 'remaily-eicon';
	}

	/**
	 * Widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Search keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'form', 'contact', 'remaily', 'email' ];
	}

	/**
	 * Styles the widget needs
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return [ 'remaily' ];
	}

	/**
	 * Controls
	 */
	protected function register_controls() {
		$this->start_controls_section( 'section_form', [ 'label' => __( 'Form', 'remaily' ) ] );

		$this->add_control( 'form', [
			'label'   => __( 'Form', 'remaily' ),
			'type'    => Controls_Manager::SELECT,
			'options' => [ '' => __( 'Choose a form', 'remaily' ) ] + Form::choices(),
			'default' => '',
		] );

		$this->add_control( 'form_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => sprintf(
				/* translators: %s: link to the forms list */
				__( 'Fields, mails and messages are set in %s.', 'remaily' ),
				'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'remaily' ) . '</a>'
			),
			'content_classes' => 'elementor-descriptor',
		] );

		$this->end_controls_section();
	}

	/**
	 * Output
	 */
	protected function render() {
		$id = (string) $this->get_settings_for_display( 'form' );

		if ( $id ) {
			$html = Renderer::render( $id );

			echo wp_kses( $html, remaily_allowed_html( $html ) );
		} elseif ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<p class="elementor-descriptor">' . esc_html__( 'Choose a form in the widget\'s settings.', 'remaily' ) . '</p>';
		}
	}
}
