<?php

namespace VLT\Remaily\Integrations;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Core\Config;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Fields\Choice;
use VLT\Remaily\Forms\Beautify;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Forms\Template;
use VLT\Remaily\Front\Defaults;
use VLT\Remaily\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 import (Settings → Migrate from CF7): its forms become Remaily forms, with their fields, mails, messages and
 * additional settings. Field names stay, so the mail tags still match. With CF7 turned off, its
 * [contact-form-7 id="…"] shortcodes show the imported forms.
 */
class Cf7 {
	const POST_TYPE = 'wpcf7_contact_form';
	const ACTION    = 'remaily_import_cf7';
	const ORIGIN    = '_remaily_cf7_id';

	// CF7's message keys → Remaily's
	const MESSAGES = [
		'mail_sent_ok'             => 'success',
		'mail_sent_ng'             => 'failed',
		'validation_error'         => 'invalid',
		'spam'                     => 'spam',
		'invalid_required'         => 'required',
		'invalid_too_long'         => 'too_long',
		'invalid_too_short'        => 'too_short',
		'invalid_email'            => 'invalid_email',
		'invalid_url'              => 'invalid_url',
		'invalid_tel'              => 'invalid_tel',
		'invalid_number'           => 'invalid_number',
		'number_too_small'         => 'number_too_small',
		'number_too_large'         => 'number_too_large',
		'invalid_date'             => 'invalid_date',
		'date_too_early'           => 'date_too_early',
		'date_too_late'            => 'date_too_late',
		'upload_failed'            => 'upload_failed',
		'upload_file_type_invalid' => 'upload_file_type_invalid',
		'upload_file_too_large'    => 'upload_file_too_large',
		'accept_terms'             => 'accept_terms',
		'quiz_answer_not_correct'  => 'quiz_answer_not_correct',
	];

	// CF7's tags → Remaily's field types
	const TYPES = [
		'text'       => 'text',
		'email'      => 'email',
		'url'        => 'url',
		'tel'        => 'tel',
		'number'     => 'number',
		'range'      => 'number',
		'date'       => 'date',
		'textarea'   => 'textarea',
		'select'     => 'select',
		'checkbox'   => 'checkbox',
		'radio'      => 'radio',
		'acceptance' => 'acceptance',
		'quiz'       => 'quiz',
		'file'       => 'file',
		'hidden'     => 'hidden',
		'submit'     => 'submit',
		'count'      => 'count',
	];

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'remaily_settings_tabs', [ __CLASS__, 'tab' ] );
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'import_request' ] );
		// After CF7 would have registered its own
		add_action( 'init', [ __CLASS__, 'shortcode' ], 20 );
	}

	/**
	 * CF7's forms
	 *
	 * @return \WP_Post[]
	 */
	public static function forms() {
		return get_posts( [ 'post_type' => self::POST_TYPE, 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
	}

	/**
	 * The Import tab, while there are CF7 forms
	 *
	 * @param array $tabs Tabs
	 *
	 * @return array
	 */
	public static function tab( array $tabs ) {
		if ( !self::forms() ) {
			return $tabs;
		}

		return $tabs + [
			'import' => [
				'label'  => __( 'Migrate from CF7', 'remaily' ),
				'icon'   => 'import',
				'render' => [ __CLASS__, 'render' ],
			],
		];
	}

	/**
	 * The Import tab's card
	 */
	public static function render() {
		$imported = self::imported();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the result of the import just done
		$done = absint( $_GET['remaily-imported'] ?? 0 );
		?>
		<div>
			<div class="vlt-settings-page__head">
				<h2><?php esc_html_e( 'Migrate from Contact Form 7', 'remaily' ); ?></h2>
				<p><?php esc_html_e( 'Each form comes over with its fields, both mails, its messages and its additional settings (demo mode, skip mail, subscribers only). Field names stay the same, so mail tags keep working. Your CF7 forms aren\'t changed.', 'remaily' ); ?></p>
				<p><?php esc_html_e( 'Once you turn Contact Form 7 off, its [contact-form-7] shortcodes show the imported forms, so your pages keep working.', 'remaily' ); ?></p>
			</div>

			<?php if ( $done ) : ?>
				<?php /* translators: %d: number of forms */ ?>
				<p class="remaily-import__done"><?php echo esc_html( sprintf( _n( '%d form imported.', '%d forms imported.', $done, 'remaily' ), $done ) ); ?></p>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<?php wp_nonce_field( self::ACTION ); ?>
				<table class="remaily-import">
					<thead>
						<tr>
							<td><input type="checkbox" data-remaily-check-all aria-label="<?php esc_attr_e( 'Select all', 'remaily' ); ?>"></td>
							<th><?php esc_html_e( 'Contact Form 7 form', 'remaily' ); ?></th>
							<th><?php esc_html_e( 'In Re:Maily', 'remaily' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( self::forms() as $cf7 ) : ?>
							<tr>
								<td><input type="checkbox" name="forms[]" value="<?php echo esc_attr( $cf7->ID ); ?>" id="remaily-cf7-<?php echo esc_attr( $cf7->ID ); ?>" <?php checked( !isset( $imported[ $cf7->ID ] ) ); ?>></td>
								<td><label for="remaily-cf7-<?php echo esc_attr( $cf7->ID ); ?>"><?php echo esc_html( $cf7->post_title ?: '#' . $cf7->ID ); ?></label></td>
								<td>
									<?php if ( isset( $imported[ $cf7->ID ] ) ) : ?>
										<a href="<?php echo esc_url( Admin::edit_url( $imported[ $cf7->ID ] ) ); ?>"><?php echo esc_html( get_the_title( $imported[ $cf7->ID ] ) ); ?></a>
										<span class="remaily-import__note"><?php esc_html_e( 'Imported. Importing again makes another copy.', 'remaily' ); ?></span>
									<?php else : ?>
										<span class="remaily-import__note"><?php esc_html_e( 'Not imported yet', 'remaily' ); ?></span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="vlt-settings-page__save">
					<span><?php esc_html_e( 'New Re:Maily forms are made; nothing is overwritten.', 'remaily' ); ?></span>
					<button type="submit" class="vlt-settings-page__button is-primary"><?php esc_html_e( 'Import selected forms', 'remaily' ); ?></button>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * The import, from the tab
	 */
	public static function import_request() {
		check_admin_referer( self::ACTION );

		if ( !current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You can\'t import forms.', 'remaily' ) );
		}

		$count = 0;

		foreach ( array_map( 'absint', (array) ( $_POST['forms'] ?? [] ) ) as $id ) {
			$count += is_int( self::import( $id ) ) ? 1 : 0;
		}

		wp_safe_redirect( add_query_arg( [ 'page' => \VLT\Remaily\Admin\Settings::PAGE, 'remaily-imported' => $count ], admin_url( 'admin.php' ) ) . '#import' );
		exit;
	}

	/**
	 * Import one CF7 form
	 *
	 * @param int $id CF7 form ID
	 *
	 * @return int|\WP_Error The Remaily form's ID
	 */
	public static function import( $id ) {
		$post = get_post( $id );

		if ( !$post || self::POST_TYPE !== $post->post_type ) {
			return new \WP_Error( 'remaily_cf7_missing', __( 'There is no such Contact Form 7 form.', 'remaily' ) );
		}

		$converted = self::convert( (string) get_post_meta( $id, '_form', true ) );
		$config    = [
			'fields'   => $converted['fields'],
			'mail'     => self::mail( (array) get_post_meta( $id, '_mail', true ), $converted['renamed'] ),
			'mail_2'   => [ 'active' => !empty( get_post_meta( $id, '_mail_2', true )['active'] ) ] + self::mail( (array) get_post_meta( $id, '_mail_2', true ), $converted['renamed'] ),
			'messages' => [],
			'settings' => self::settings( (string) get_post_meta( $id, '_additional_settings', true ) ),
		];

		foreach ( (array) get_post_meta( $id, '_messages', true ) as $key => $text ) {
			if ( isset( self::MESSAGES[ $key ] ) && is_string( $text ) && '' !== $text ) {
				$config['messages'][ self::MESSAGES[ $key ] ] = $text;
			}
		}

		$form = wp_insert_post( wp_slash( [
			'post_type'    => PostType::NAME,
			'post_status'  => 'publish',
			'post_title'   => $post->post_title,
			'post_content' => $converted['template'],
		] ), true );

		if ( is_wp_error( $form ) ) {
			return $form;
		}

		Config::save( $form, $config );
		update_post_meta( $form, self::ORIGIN, $id );

		do_action( 'remaily_cf7_imported', $form, $id );

		return $form;
	}

	/**
	 * A CF7 form template as a Remaily template and its fields
	 *
	 * @param string $source CF7's form template
	 *
	 * @return array [ 'template', 'fields' => [ name => settings ], 'renamed' => [ CF7 name => Remaily name ] ]
	 */
	public static function convert( $source ) {
		$fields  = [];
		$renamed = [];
		$tags    = implode( '|', array_merge( array_keys( self::TYPES ), [ 'response' ] ) );

		$template = (string) preg_replace_callback(
			'/\[(' . $tags . ')(\*?)(?:\s+([^\]]*?))?\s*\](?:([^\[]*?)\[\/\1\])?/',
			static function ( $m ) use ( &$fields, &$renamed ) {
				$type = $m[1];

				if ( 'response' === $type ) {
					return '[[response]]';
				}

				[ $name, $options, $values ] = self::tokens( (string) ( $m[3] ?? '' ), 'submit' !== $type );

				$name = 'submit' === $type ? 'submit' : $name;
				$safe = strtolower( preg_replace( '/[^\w-]/', '_', (string) $name ) );
				$safe = preg_match( '/^[a-z]/', $safe ) ? $safe : 'field_' . $safe;

				// [count your-message] is named after the field it counts: it gets a name of its own
				$source = '';

				if ( 'count' === $type ) {
					$source = $safe;
					$safe  .= '_count';
				}

				// A name already taken (two submit buttons): the next free one
				for ( $base = $safe, $i = 2; isset( $fields[ $safe ] ) || in_array( $safe, Template::reserved(), true ); $i++ ) {
					$safe = $base . '_' . $i;
				}

				if ( $safe !== $name && !in_array( $type, [ 'submit', 'count' ], true ) ) {
					$renamed[ $name ] = $safe;
				}

				$fields[ $safe ] = self::field( self::TYPES[ $type ], '*' === $m[2], $options, $values, trim( (string) ( $m[4] ?? '' ) ) );

				if ( 'count' === $type ) {
					$fields[ $safe ]['source'] = $source;
				}

				return '[[' . $safe . ']]';
			},
			$source
		);

		// The markup as written, without CF7's <p> and <br>: one line per block, then indented
		return [ 'template' => Beautify::html( self::lines( $template ) ), 'fields' => $fields, 'renamed' => $renamed ];
	}

	/**
	 * One line per block: the line breaks in a block become spaces, the empty lines between blocks one line break.
	 * <pre>, <textarea>, <script> and <style> stay as written.
	 *
	 * @param string $html Markup
	 *
	 * @return string
	 */
	private static function lines( $html ) {
		$raw  = [];
		$html = (string) preg_replace_callback( '/<(pre|textarea|script|style)\b.*?<\/\1\s*>/is', static function ( $m ) use ( &$raw ) {
			$raw[] = $m[0];

			return "\x00" . ( count( $raw ) - 1 ) . "\x00";
		}, trim( $html ) );

		$html = (string) preg_replace( [ '/\s*\n\s*\n\s*/', '/\s*\n\s*/' ], [ "\x01", ' ' ], $html );

		return (string) preg_replace_callback( '/\x00(\d+)\x00/', static fn( $m ) => $raw[ (int) $m[1] ], str_replace( "\x01", "\n", $html ) );
	}

	/**
	 * A tag's name, options and quoted values
	 *
	 * @param string $attr     What follows the tag's type
	 * @param bool   $has_name The first word is the name
	 *
	 * @return array [ name, options [ key => value|true ], values string[] ]
	 */
	private static function tokens( $attr, $has_name ) {
		preg_match_all( '/"[^"]*"|\'[^\']*\'|\S+/', $attr, $m );

		$name    = '';
		$options = [];
		$values  = [];

		foreach ( $m[0] as $i => $token ) {
			if ( '"' === $token[0] || "'" === $token[0] ) {
				$values[] = substr( $token, 1, -1 );
			} elseif ( 0 === $i && $has_name ) {
				$name = $token;
			} else {
				$parts = explode( ':', $token, 2 );

				// class:a class:b → both
				if ( 'class' === $parts[0] && isset( $options['class'], $parts[1] ) && true !== $options['class'] ) {
					$options['class'] .= ' ' . $parts[1];
				} else {
					$options[ $parts[0] ] = $parts[1] ?? true;
				}
			}
		}

		return [ $name, $options, $values ];
	}

	/**
	 * A field's settings from its CF7 tag
	 *
	 * @param string $type     Remaily type
	 * @param bool   $required Required (the *)
	 * @param array  $options  Options
	 * @param array  $values   Quoted values
	 * @param string $content  An enclosing tag's content (acceptance)
	 *
	 * @return array
	 */
	private static function field( $type, $required, array $options, array $values, $content ) {
		$field = [ 'type' => $type, 'required' => $required ];
		$first = $values[0] ?? '';

		foreach ( [ 'class' => 'class', 'id' => 'id', 'minlength' => 'minlength', 'maxlength' => 'maxlength', 'min' => 'min', 'max' => 'max', 'step' => 'step', 'autocomplete' => 'autocomplete' ] as $from => $to ) {
			if ( isset( $options[ $from ] ) && true !== $options[ $from ] ) {
				$field[ $to ] = $options[ $from ];
			}
		}

		switch ( $type ) {
			case 'select':
			case 'checkbox':
			case 'radio':
				// "Label|value": the label shows, the value is sent
				$field['options'] = Choice::parse_options( array_map( static function ( $value ) {
					$parts = explode( '|', $value, 2 );

					return [ 'value' => $parts[1] ?? $parts[0], 'label' => $parts[0] ];
				}, $values ) );

				if ( isset( $options['first_as_label'] ) && $field['options'] ) {
					$field['placeholder'] = array_shift( $field['options'] )['label'];
				}

				$field['include_blank'] = isset( $options['include_blank'] ) || isset( $options['first_as_label'] );
				$field['multiple']      = isset( $options['multiple'] );
				$field['label_first']   = isset( $options['label_first'] );
				$field['exclusive']     = isset( $options['exclusive'] );
				$field['allow_null']    = true;

				// default:1_3 → the first and third options
				if ( isset( $options['default'] ) && preg_match( '/^\d+(_\d+)*$/', (string) $options['default'] ) ) {
					$picked           = array_map( static fn( $n ) => $field['options'][ (int) $n - 1 ]['value'] ?? '', explode( '_', $options['default'] ) );
					$field['default'] = implode( ', ', array_filter( $picked, 'strlen' ) );
				}
				break;

			case 'acceptance':
				$field['content']  = $content;
				$field['optional'] = isset( $options['optional'] );
				$field['invert']   = isset( $options['invert'] );
				$field['checked']  = 'on' === ( $options['default'] ?? '' );
				break;

			case 'quiz':
				$field['questions'] = array_map( static function ( $value ) {
					$parts = explode( '|', $value, 2 );

					return [ 'question' => $parts[0], 'answer' => $parts[1] ?? '' ];
				}, $values );
				break;

			case 'file':
				if ( isset( $options['filetypes'] ) && true !== $options['filetypes'] ) {
					$field['accept'] = str_replace( '|', ', ', $options['filetypes'] );
				}

				// limit:2mb, 500kb or bytes
				if ( isset( $options['limit'] ) && preg_match( '/^(\d+)(kb|mb)?$/i', (string) $options['limit'], $limit ) ) {
					$bytes             = (int) $limit[1] * ( 'mb' === strtolower( $limit[2] ?? '' ) ? MB_IN_BYTES : ( 'kb' === strtolower( $limit[2] ?? '' ) ? KB_IN_BYTES : 1 ) );
					$field['max_size'] = (string) round( $bytes / MB_IN_BYTES, 2 );
				}
				break;

			case 'submit':
				$field['label'] = $first ?: __( 'Send', 'remaily' );
				break;

			case 'count':
				// down: what's left to the max length
				$field['format'] = isset( $options['down'] ) ? '{left}' : '{count}';
				break;

			case 'hidden':
				$field['default'] = $first;
				break;

			default:
				// The first quoted value: the placeholder with the "placeholder" option, else the field's value
				if ( isset( $options['placeholder'] ) || isset( $options['watermark'] ) ) {
					$field['placeholder'] = $first;
				} else {
					$field['default'] = $first;
				}
		}

		// default:get, default:user_email… → where the starting value comes from
		$from = 'shortcode_attr' === ( $options['default'] ?? '' ) ? 'shortcode' : ( $options['default'] ?? '' );

		if ( is_string( $from ) && '' !== $from && array_key_exists( $from, Defaults::sources() ) ) {
			$field['default_from'] = $from;
		}

		return $field;
	}

	/**
	 * A CF7 mail as a Remaily mail
	 *
	 * @param array $mail    CF7 mail
	 * @param array $renamed Field names that changed
	 *
	 * @return array
	 */
	private static function mail( array $mail, array $renamed ) {
		$tags = static function ( $text ) use ( $renamed ) {
			foreach ( $renamed as $from => $to ) {
				$text = str_replace( [ '[' . $from . ']', '[_raw_' . $from . ']' ], [ '[' . $to . ']', '[_raw_' . $to . ']' ], (string) $text );
			}

			return (string) $text;
		};

		return [
			'to'          => $tags( $mail['recipient'] ?? '' ),
			'from'        => $tags( $mail['sender'] ?? '' ),
			'subject'     => $tags( $mail['subject'] ?? '' ),
			'headers'     => $tags( $mail['additional_headers'] ?? '' ),
			'body'        => $tags( $mail['body'] ?? '' ),
			'html'        => !empty( $mail['use_html'] ),
			'attachments' => $tags( $mail['attachments'] ?? '' ),
		];
	}

	/**
	 * CF7's additional settings Remaily has a switch for
	 *
	 * @param string $text Additional settings, "key: value" lines
	 *
	 * @return array
	 */
	private static function settings( $text ) {
		$on = static fn( $key ) => (bool) preg_match( '/^\s*' . $key . '\s*:\s*(on|true|1)\s*$/mi', $text );

		return [
			'demo'             => $on( 'demo_mode' ),
			'skip_mail'        => $on( 'skip_mail' ),
			'subscribers_only' => $on( 'subscribers_only' ),
		];
	}

	/**
	 * Imported forms by their CF7 form
	 *
	 * @return array [ CF7 ID => Remaily ID ]
	 */
	private static function imported() {
		$map = [];

		foreach ( get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => self::ORIGIN ] ) as $form ) { // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- few forms
			$map[ (int) get_post_meta( $form, self::ORIGIN, true ) ] = $form;
		}

		return $map;
	}

	/**
	 * [contact-form-7 id="…"] shows the imported form once CF7 is off (its numeric ID, or the hash newer CF7 prints)
	 */
	public static function shortcode() {
		if ( shortcode_exists( 'contact-form-7' ) ) {
			return;
		}

		add_shortcode( 'contact-form-7', static function ( $atts ) {
			$id  = (string) ( ( (array) $atts )['id'] ?? '' );
			$cf7 = ctype_digit( $id ) ? (int) $id : 0;

			if ( !$cf7 && '' !== $id ) {
				global $wpdb;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- CF7's hash, with CF7 off
				$cf7 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_hash' AND meta_value LIKE %s LIMIT 1", $wpdb->esc_like( $id ) . '%' ) );
			}

			$forms = $cf7 ? get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => self::ORIGIN, 'meta_value' => $cf7 ] ) : []; // phpcs:ignore WordPress.DB.SlowDBQuery

			// CF7's own attributes; the others fill fields set to "Fill from: Shortcode attribute"
			$all  = (array) $atts;
			$own  = array_flip( [ 'id', 'title', 'html_id', 'html_name', 'html_title', 'html_class', 'output' ] );
			$args = [
				'class'   => (string) ( $all['html_class'] ?? '' ),
				'html_id' => (string) ( $all['html_id'] ?? '' ),
				'atts'    => array_diff_key( $all, $own ),
			];

			$form = $forms ? Form::get( (int) $forms[0] ) : null;

			return $form ? Renderer::render( $form, $args ) : '';
		} );
	}
}
