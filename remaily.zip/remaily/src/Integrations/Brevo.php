<?php

namespace VLT\Remaily\Integrations;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Core\Config;
use VLT\Remaily\Mail\Mailer;
use VLT\Remaily\Mail\MailTags;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Brevo: the sender of each message added to Brevo's contact lists (Settings → Integrations for the API key,
 * Advanced → Brevo in each form for the rest). New contacts can get a welcome template, and can be asked to confirm
 * their email first (double opt-in, the email sent by Re:Maily, the contact added once its link is opened)
 */
class Brevo {
	const API = 'https://api.brevo.com/v3/';

	// What Brevo said of the key: [ 'state' => ok|bad|unreachable, 'key' => hash of the key ]
	const STATUS = 'remaily_brevo_status';

	// The link of a confirmation email: ?remaily_confirm=token
	const CONFIRM = 'remaily_confirm';

	// How long a confirmation link works
	const CONFIRM_DAYS = 7;

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'remaily_settings_sections', [ __CLASS__, 'section' ] );
		add_filter( 'remaily_editor_data', [ __CLASS__, 'editor_data' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
		// After the entry is saved (10), as webhooks
		add_action( 'remaily_submitted', [ __CLASS__, 'send' ], 20 );
		add_action( 'template_redirect', [ __CLASS__, 'confirm' ] );
		add_action( 'update_option_' . Settings::OPTION, [ __CLASS__, 'check_key' ] );
		add_action( 'add_option_' . Settings::OPTION, [ __CLASS__, 'check_key' ] );
	}

	/**
	 * The saved API key
	 *
	 * @return string
	 */
	public static function key() {
		return (string) ( Settings::get( 'integrations' )['brevo_key'] ?? '' );
	}

	/**
	 * A request to Brevo's API
	 *
	 * @param string $method GET or POST
	 * @param string $path   Path after /v3/
	 * @param array  $body   JSON body
	 * @param string $key    API key ('' = the saved one)
	 *
	 * @return array [ HTTP code (0: no answer), decoded body ]
	 */
	private static function request( $method, $path, array $body = [], $key = '' ) {
		$response = wp_remote_request( self::API . $path, [
			'method'  => $method,
			'timeout' => 10,
			'headers' => [ 'api-key' => $key ?: self::key(), 'accept' => 'application/json', 'content-type' => 'application/json' ],
			'body'    => $body ? wp_json_encode( $body ) : null,
		] );

		if ( is_wp_error( $response ) ) {
			return [ 0, [] ];
		}

		return [ (int) wp_remote_retrieve_response_code( $response ), (array) json_decode( (string) wp_remote_retrieve_body( $response ), true ) ];
	}

	/**
	 * Ask Brevo whether it knows the key, once per key saved
	 */
	public static function check_key() {
		$key    = self::key();
		$status = (array) get_option( self::STATUS, [] );

		if ( '' === $key ) {
			delete_option( self::STATUS );

			return;
		}

		if ( ( $status['key'] ?? '' ) === md5( $key ) && 'unreachable' !== ( $status['state'] ?? '' ) ) {
			return;
		}

		[ $code ] = self::request( 'GET', 'account', [], $key );
		$state    = 200 === $code ? 'ok' : ( in_array( $code, [ 401, 403 ], true ) ? 'bad' : 'unreachable' );

		update_option( self::STATUS, [ 'state' => $state, 'key' => md5( $key ) ], false );
	}

	/**
	 * Brevo's state for Settings → Integrations: [ label, tone ]
	 *
	 * @return array
	 */
	public static function status() {
		// The saved value as it is: the settings sections ask for this status while they are built
		if ( empty( ( (array) get_option( Settings::OPTION, [] ) )['integrations']['brevo_key'] ) ) {
			return [ __( 'Not set up', 'remaily' ), 'muted' ];
		}

		switch ( ( (array) get_option( self::STATUS, [] ) )['state'] ?? '' ) {
			case 'ok':
				return [ __( 'Connected', 'remaily' ), 'success' ];

			case 'bad':
				return [ __( 'API key not accepted', 'remaily' ), 'danger' ];

			default:
				return [ __( 'Brevo can\'t be reached', 'remaily' ), 'warning' ];
		}
	}

	/**
	 * The Integrations tab of Settings
	 *
	 * @param array $sections Sections
	 *
	 * @return array
	 */
	public static function section( array $sections ) {
		$link = static fn( $url, $text ) => '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $text ) . '</a>';

		$sections['integrations'] = [
			'tab'         => __( 'Integrations', 'remaily' ),
			'icon'        => 'admin-plugins',
			'title'       => __( 'Integrations', 'remaily' ),
			'description' => __( 'Send the people who write to you to other services. Each form picks what it sends in its Advanced tab.', 'remaily' ),
			'groups'      => [
				/* translators: 1: link to Brevo's API keys page, 2: link to the Brevo page of the documentation */
				'brevo' => [ 'icon' => Admin::icon( 'integration-brevo' ), 'status' => self::status(), 'title' => 'Brevo', 'description' => sprintf( __( 'Adds the sender of each message to your Brevo contact lists. Make an API key in %1$s. Step by step: %2$s.', 'remaily' ), $link( 'https://app.brevo.com/settings/keys/api', __( 'Brevo → SMTP & API', 'remaily' ) ), $link( trailingslashit( Settings::docs_url() ) . 'brevo/', 'Brevo' ) ) ],
			],
			'fields'      => [
				'brevo_key' => [ 'type' => 'secret', 'group' => 'brevo', 'label' => __( 'API key', 'remaily' ), 'default' => '' ],
			],
		];

		return $sections;
	}

	/**
	 * Whether the editor shows the form's Brevo settings, and Brevo's logo
	 *
	 * @param array $data Editor data
	 *
	 * @return array
	 */
	public static function editor_data( array $data ) {
		$data['brevo']     = '' !== self::key();
		$data['brevoLogo'] = Admin::icon( 'integration-brevo' );

		return $data;
	}

	/**
	 * GET remaily/v1/brevo: the account's lists and active email templates for the editor, in one request
	 */
	public static function routes() {
		register_rest_route( 'remaily/v1', '/brevo', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'account' ],
			'permission_callback' => static fn() => current_user_can( Admin::CAPABILITY ),
		] );
	}

	/**
	 * The account's lists and templates: { lists: [ { id, name } ], templates: [ { id, name } ] }
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function account() {
		[ $code, $lists ] = self::request( 'GET', 'contacts/lists?limit=50&offset=0&sort=desc' );

		if ( 200 !== $code ) {
			return new \WP_Error( 'remaily_brevo', __( 'Brevo didn\'t send your lists. Check the API key in Settings → Integrations.', 'remaily' ), [ 'status' => 502 ] );
		}

		[ , $templates ] = self::request( 'GET', 'smtp/templates?templateStatus=true&limit=100&offset=0&sort=desc' );

		$pick = static fn( $items ) => array_map( static fn( $item ) => [ 'id' => (int) ( $item['id'] ?? 0 ), 'name' => (string) ( $item['name'] ?? '' ) ], (array) $items );

		return rest_ensure_response( [
			'lists'     => $pick( $lists['lists'] ?? [] ),
			'templates' => $pick( $templates['templates'] ?? [] ),
		] );
	}

	/**
	 * Add the sender to the form's lists, or email them a link to confirm first
	 *
	 * @param Submission $submission Submission
	 */
	public static function send( Submission $submission ) {
		$settings = $submission->form()->config()['settings'];
		$lists    = array_values( array_filter( array_map( 'absint', (array) $settings['brevo_lists'] ) ) );

		if ( !$lists || '' === self::key() || !in_array( $submission->status(), [ 'success', 'failed' ], true ) || $submission->is_demo() ) {
			return;
		}

		// Only those who ticked the consent box, when the form has one picked
		if ( '' !== $settings['brevo_consent'] && !self::filled( $submission->posted( $settings['brevo_consent'] ) ) ) {
			return;
		}

		$email = self::email( $submission, $settings['brevo_email'] );

		if ( '' === $email ) {
			return;
		}

		$contact    = [ 'email' => $email, 'listIds' => $lists ];
		$attributes = self::attributes( $submission, $settings['brevo_attributes'] );

		if ( $attributes ) {
			$contact['attributes'] = $attributes;
		}

		/**
		 * The contact sent to Brevo; an empty array sends nothing
		 *
		 * @param array      $contact    email, listIds, attributes
		 * @param Submission $submission Submission
		 */
		$contact = (array) apply_filters( 'remaily_brevo_contact', $contact, $submission );

		if ( empty( $contact['email'] ) ) {
			return;
		}

		$welcome = absint( $settings['brevo_template'] );

		// Double opt-in: anyone not on every list picked confirms first; the rest have nothing to add
		if ( !empty( $settings['brevo_doi'] ) ) {
			[ $code, $known ] = self::request( 'GET', 'contacts/' . rawurlencode( $contact['email'] ) );

			if ( 404 === $code || ( 200 === $code && array_diff( $contact['listIds'], array_map( 'intval', (array) ( $known['listIds'] ?? [] ) ) ) ) ) {
				self::ask_to_confirm( $submission, $contact, $welcome );
			}

			return;
		}

		self::save_contact( $contact, $welcome );
	}

	/**
	 * Add a contact; a new one gets the welcome template. Anyone can type anyone's email into a form, so a contact
	 * already in Brevo only joins the lists and keeps its own details, unless it just confirmed its email
	 *
	 * @param array $contact   Contact
	 * @param int   $welcome   Template ID, 0 for none
	 * @param bool  $confirmed The owner of the email opened its confirmation link
	 */
	private static function save_contact( array $contact, $welcome, $confirmed = false ) {
		[ $code ] = self::request( 'POST', 'contacts', [ 'updateEnabled' => $confirmed ] + $contact );

		// Already in Brevo (unconfirmed): only the lists
		if ( 400 === $code ) {
			self::request( 'POST', 'contacts', [ 'email' => $contact['email'], 'listIds' => $contact['listIds'], 'updateEnabled' => true ] );
		}

		// 201: created; an existing contact that was updated answers 204
		if ( 201 === $code && $welcome ) {
			$name = trim( ( $contact['attributes']['FIRSTNAME'] ?? '' ) . ' ' . ( $contact['attributes']['LASTNAME'] ?? '' ) );

			self::request( 'POST', 'smtp/email', [
				'templateId' => $welcome,
				'to'         => [ array_filter( [ 'email' => $contact['email'], 'name' => $name ] ) ],
				'params'     => (object) ( $contact['attributes'] ?? [] ),
				'tags'       => [ 'Re:Maily' ],
			] );
		}
	}

	/**
	 * Keep the contact until its link is opened, and email the link
	 *
	 * @param Submission $submission Submission
	 * @param array      $contact    Contact
	 * @param int        $welcome    Template ID, 0 for none
	 */
	private static function ask_to_confirm( Submission $submission, array $contact, $welcome ) {
		$settings = $submission->form()->config()['settings'];
		$token    = wp_generate_password( 32, false );

		set_transient( self::CONFIRM . '_' . md5( $token ), [
			'contact'  => $contact,
			'welcome'  => $welcome,
			'redirect' => $settings['brevo_doi_redirect'],
		], self::CONFIRM_DAYS * DAY_IN_SECONDS );

		$url     = add_query_arg( self::CONFIRM, $token, home_url( '/' ) );
		$subject = trim( str_replace( [ "\r", "\n" ], ' ', MailTags::replace( $settings['brevo_doi_subject'], $submission ) ) );
		$body    = MailTags::replace( $settings['brevo_doi_body'], $submission, true );
		$body    = str_replace( '[confirm_link]', '<a href="' . esc_url( $url ) . '">' . esc_html( $url ) . '</a>', $body );
		$to      = defined( 'REMAILY_MAIL_TO' ) && is_email( REMAILY_MAIL_TO ) ? REMAILY_MAIL_TO : $contact['email'];
		$from    = trim( MailTags::replace( Config::mail_defaults()['from'], $submission ) );

		wp_mail( $to, $subject, Mailer::html( wpautop( $body ), $subject, $submission ), [
			'From: ' . $from,
			'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ),
		] );
	}

	/**
	 * A confirmation link opened: a button to confirm, then the contact is added and the form's page or a short note
	 * shows. Opening the link alone confirms nothing: mail scanners open links too
	 */
	public static function confirm() {
		// phpcs:disable WordPress.Security.NonceVerification -- the token is the proof
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
		$posted = 'POST' === $method && isset( $_POST[ self::CONFIRM ] );
		$raw    = $posted ? sanitize_text_field( wp_unslash( $_POST[ self::CONFIRM ] ) ) : ( isset( $_GET[ self::CONFIRM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::CONFIRM ] ) ) : '' );
		// phpcs:enable WordPress.Security.NonceVerification
		$token  = preg_replace( '/[^A-Za-z0-9]/', '', $raw );

		if ( '' === $token ) {
			return;
		}

		$key     = self::CONFIRM . '_' . md5( $token );
		$pending = get_transient( $key );
		$home    = [ 'link_url' => esc_url( home_url( '/' ) ), 'link_text' => esc_html__( 'Go to the home page', 'remaily' ) ];

		if ( !is_array( $pending ) ) {
			wp_die( esc_html__( 'This confirmation link has expired or was already used. Send the form again to get a new one.', 'remaily' ), esc_html__( 'Link expired', 'remaily' ), [ 'response' => 410 ] + $home ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
		}

		if ( !$posted ) {
			$button = sprintf(
				'%s<form method="post"><input type="hidden" name="%s" value="%s"><p><button type="submit" class="button button-large">%s</button></p></form>',
				esc_html__( 'Confirm that you want to get our emails.', 'remaily' ),
				esc_attr( self::CONFIRM ),
				esc_attr( $token ),
				esc_html__( 'Confirm my email', 'remaily' )
			);

			wp_die( $button, esc_html__( 'Confirm your email', 'remaily' ), [ 'response' => 200 ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
		}

		delete_transient( $key );
		self::save_contact( (array) $pending['contact'], absint( $pending['welcome'] ), true );

		if ( !empty( $pending['redirect'] ) ) {
			wp_safe_redirect( $pending['redirect'] );
			exit;
		}

		wp_die( esc_html__( 'Thank you! Your email is confirmed.', 'remaily' ), esc_html__( 'Email confirmed', 'remaily' ), [ 'response' => 200 ] + $home ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
	}

	/**
	 * The contact's attributes: the form's lines of NAME = mail tags; with none written, the basics guessed from the
	 * fields (FIRSTNAME and LASTNAME from a name field, SMS from a Tel field)
	 *
	 * @param Submission $submission Submission
	 * @param string     $lines      The form's lines
	 *
	 * @return array
	 */
	private static function attributes( Submission $submission, $lines ) {
		$attributes = [];

		foreach ( preg_split( '/\R/', (string) $lines ) as $line ) {
			$parts = array_map( 'trim', explode( '=', $line, 2 ) );

			if ( 2 === count( $parts ) && '' !== $parts[0] ) {
				$attributes[ strtoupper( $parts[0] ) ] = MailTags::replace( $parts[1], $submission );
			}
		}

		if ( '' !== trim( (string) $lines ) ) {
			return array_filter( $attributes, static fn( $value ) => '' !== $value );
		}

		foreach ( $submission->form()->fields() as $name => $field ) {
			$value = $submission->posted( $name );

			if ( !is_string( $value ) || '' === trim( $value ) ) {
				continue;
			}

			if ( 'tel' === $field['type'] && !isset( $attributes['SMS'] ) ) {
				// Brevo takes international numbers only: + and 7 to 15 digits
				$digits = preg_replace( '/\D/', '', $value );

				if ( 0 === strpos( trim( $value ), '+' ) && strlen( $digits ) >= 7 && strlen( $digits ) <= 15 ) {
					$attributes['SMS'] = '+' . $digits;
				}
			} elseif ( 'text' === $field['type'] ) {
				if ( preg_match( '/(^|[_-])(first[_-]?name|fname)$/i', $name ) ) {
					$attributes['FIRSTNAME'] = trim( $value );
				} elseif ( preg_match( '/(^|[_-])(last[_-]?name|lname|surname)$/i', $name ) ) {
					$attributes['LASTNAME'] = trim( $value );
				} elseif ( preg_match( '/(^|[_-])name$/i', $name ) && !isset( $attributes['FIRSTNAME'] ) ) {
					// A whole name: its first word, the rest the last name
					$words                   = preg_split( '/\s+/', trim( $value ) );
					$attributes['FIRSTNAME'] = array_shift( $words );
					$attributes['LASTNAME']  = $attributes['LASTNAME'] ?? implode( ' ', $words );
				}
			}
		}

		return array_filter( $attributes, static fn( $value ) => '' !== $value );
	}

	/**
	 * The sender's email: the picked field, else the form's first Email field
	 *
	 * @param Submission $submission Submission
	 * @param string     $name       Field name ('' = the first Email field)
	 *
	 * @return string
	 */
	private static function email( Submission $submission, $name ) {
		foreach ( $submission->form()->fields() as $field_name => $field ) {
			if ( ( '' === $name && 'email' === $field['type'] ) || $field_name === $name ) {
				$value = $submission->posted( $field_name );

				return is_string( $value ) && is_email( $value ) ? $value : '';
			}
		}

		return '';
	}

	/**
	 * Whether a posted value says yes: a ticked box or any text
	 *
	 * @param mixed $value Value
	 *
	 * @return bool
	 */
	private static function filled( $value ) {
		return is_array( $value ) ? (bool) array_filter( $value, static fn( $item ) => '' !== (string) $item ) : '' !== trim( (string) $value );
	}
}
