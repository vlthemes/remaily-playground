<?php

namespace VLT\Remaily\Integrations\WPBakery;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Admin\Icons;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;
use VLT\Remaily\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPBakery element. It stays the [remaily form="…"] shortcode, so pages keep working without WPBakery.
 */
class Integration {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'vc_before_init', [ __CLASS__, 'map' ] );
		// The front-end editor renders a new element through AJAX, where the styles its form enqueues never reach the page
		add_action( 'vc_load_iframe_jscss', [ __CLASS__, 'enqueue_editor' ] );
		add_filter( 'vc_shortcode_output', [ __CLASS__, 'notice' ], 10, 4 );
	}


	/**
	 * The forms' look in the front-end editor: every form's styles, its fields' and the theme's included
	 */
	public static function enqueue_editor() {
		Renderer::enqueue_all_styles();
	}

	/**
	 * In the front-end editor, a note while no form is picked (the Elementor widget's)
	 *
	 * @param string $output    Element output
	 * @param object $shortcode WPBakery shortcode object
	 * @param array  $atts      Attributes
	 * @param string $tag       Shortcode
	 *
	 * @return string
	 */
	public static function notice( $output, $shortcode, $atts, $tag ) {
		if ( Shortcode::TAG !== $tag || !function_exists( 'vc_is_page_editable' ) || !vc_is_page_editable() || !empty( $atts['form'] ) ) {
			return $output;
		}

		return '<p class="remaily-missing">' . esc_html__( 'Choose a form in the element\'s settings.', 'remaily' ) . '</p>';
	}

	/**
	 * The element
	 */
	public static function map() {
		// A field of text only, like Elementor's RAW_HTML: no input, so nothing is saved in the shortcode
		vc_add_shortcode_param( 'remaily_note', static fn( $settings ) => '<div class="vc_description">' . wp_kses_post( $settings['text'] ?? '' ) . '</div>' );

		vc_map( [
			'name'        => __( 'Re:Maily Contact Form', 'remaily' ),
			'base'        => Shortcode::TAG,
			'description' => __( 'A form made with Re:Maily.', 'remaily' ),
			'category'    => __( 'Content', 'remaily' ),
			'icon'        => Icons::logo_url(),
			'params'      => [
				[
					'type'        => 'dropdown',
					'heading'     => __( 'Form', 'remaily' ),
					// Not "id": builders often use that name for the element itself, and a page saved [remaily] without it
					'param_name'  => 'form',
					'value'       => self::forms(),
					'admin_label' => true,
				],
				[
					'type'        => 'textfield',
					'heading'     => __( 'CSS classes', 'remaily' ),
					'param_name'  => 'class',
					'description' => __( 'Added to the form\'s wrapper, separated by spaces.', 'remaily' ),
				],
				[
					'type'       => 'remaily_note',
					'param_name' => 'note',
					'text'       => sprintf(
						/* translators: %s: link to the forms list */
						__( 'Fields, mails and messages are set in %s.', 'remaily' ),
						'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'remaily' ) . '</a>'
					),
				],
			],
		] );
	}

	/**
	 * Published forms for the dropdown
	 *
	 * @return array [ title => id ] (WPBakery's order)
	 */
	private static function forms() {
		// WPBakery takes them the other way round: label => value
		return [ __( 'Choose a form', 'remaily' ) => '' ] + array_flip( Form::choices() );
	}
}
