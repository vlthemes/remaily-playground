<?php

namespace VLT\Remaily\Integrations;

use VLT\Remaily\Admin\Admin;
use VLT\Remaily\Core\Assets;
use VLT\Remaily\Core\PostType;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Re:Maily Contact Form block: a saved form, rendered as its shortcode on the site; the editor shows which one
 *
 *     remaily/form   { id }
 */
class Block {
	const NAME = 'remaily/form';

	/**
	 * Init
	 */
	public static function init() {
		self::register();
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_editor' ] );
	}

	/**
	 * Register the block
	 */
	public static function register() {
		register_block_type( self::NAME, [
			'api_version'     => 3,
			'title'           => __( 'Re:Maily Contact Form', 'remaily' ),
			'description'     => __( 'A form made with Re:Maily.', 'remaily' ),
			'category'        => 'widgets',
			'keywords'        => [ 'form', 'contact', 'remaily', 'email' ],
			// The hash finds the form after an export and import; the post ID is for the editor's links
			'attributes'      => [
				'id'   => [ 'type' => 'integer', 'default' => 0 ],
				'hash' => [ 'type' => 'string', 'default' => '' ],
			],
			'supports'        => [
				'html'  => false,
				'align' => [ 'wide', 'full' ],
			],
			'render_callback' => [ __CLASS__, 'render' ],
		] );
	}

	/**
	 * The block's markup, in the block wrapper (alignment, the block's own classes)
	 *
	 * @param array $attributes Block attributes
	 *
	 * @return string
	 */
	public static function render( $attributes ) {
		$html = Renderer::render( (string) ( $attributes['hash'] ?? '' ) ?: (int) ( $attributes['id'] ?? 0 ) );

		return '' === $html ? '' : '<div ' . get_block_wrapper_attributes() . '>' . $html . '</div>';
	}

	/**
	 * The editor script
	 */
	public static function enqueue_editor() {
		Assets::enqueue( 'remaily-blocks' );
	}

	/**
	 * What the editor script reads (window.remailyBlocks)
	 *
	 * @return array
	 */
	public static function script_data() {
		$forms = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );

		return [
			'forms'   => array_map( static fn( $post ) => [ 'id' => $post->ID, 'hash' => Form::hash_of( $post->ID ), 'title' => $post->post_title ?: '#' . $post->ID ], $forms ),
			'editUrl' => admin_url( 'admin.php?page=' . Admin::PAGE . '&form=' ),
			'newUrl'  => Admin::new_url(),
			'canEdit' => current_user_can( Admin::CAPABILITY ),
			// The Re:Maily mark, the same as Elementor's and WPBakery's
			'icon'    => Admin::logo_url(),
		];
	}
}
