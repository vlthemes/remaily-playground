<?php

namespace VLT\Remaily\Integrations;

use VLT\Remaily\Entries\Entries;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Submission\Conditions;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Webhooks: each message that went through is posted as JSON to the form's addresses (Advanced → Webhooks),
 * without making the visitor wait
 *
 *     { "form": { "id", "title" }, "entry": 123, "fields": { name: value }, "raw": { name: value }, "meta": {…}, "date" }
 */
class Webhooks {
	/**
	 * Init
	 */
	public static function init() {
		// After the entry is saved (10), so its ID goes along
		add_action( 'remaily_submitted', [ __CLASS__, 'send' ], 20 );
	}

	/**
	 * Post the message to the form's webhooks
	 *
	 * @param Submission $submission Submission
	 */
	public static function send( Submission $submission ) {
		$urls = (array) ( $submission->form()->config()['settings']['webhooks'] ?? [] );

		if ( !$urls || !in_array( $submission->status(), [ 'success', 'failed' ], true ) || $submission->is_demo() ) {
			return;
		}

		$body = wp_json_encode( self::payload( $submission ) );

		foreach ( $urls as $url ) {
			// Not to the site's own network: WordPress refuses local and private addresses (developers can allow one with
			// its http_request_host_is_external filter)
			wp_safe_remote_post( $url, [
				'blocking' => false,
				'timeout'  => 5,
				'headers'  => [ 'Content-Type' => 'application/json' ],
				'body'     => $body,
			] );
		}
	}

	/**
	 * What a webhook receives
	 *
	 * @param Submission $submission Submission
	 *
	 * @return array
	 */
	public static function payload( Submission $submission ) {
		$form   = $submission->form();
		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$fields = [];
		$raw    = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( $type && $type->submits() && !in_array( $name, $hidden, true ) ) {
				$fields[ $name ] = $type->mail_value( $submission->posted( $name ), $field );
				$raw[ $name ]    = $type->mail_value( $submission->posted( $name ), $field, true );
			}
		}

		return (array) apply_filters( 'remaily_webhook_payload', [
			'form'   => [ 'id' => $form->id(), 'title' => $form->title() ],
			'entry'  => Entries::last(),
			'fields' => $fields,
			'raw'    => $raw,
			'meta'   => [
				'url'        => $submission->meta( 'url' ),
				'ip'         => Entries::stored_ip( (string) $submission->meta( 'ip' ) ),
				'user_agent' => Entries::stored_agent( (string) $submission->meta( 'user_agent' ) ),
				'user_id'    => $submission->meta( 'user_id' ),
			],
			'date'   => gmdate( 'c', $submission->meta( 'time' ) ),
		], $submission );
	}
}
