<?php

namespace VLT\Remaily;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PSR-4 autoloader of the VLT\Remaily namespace (src/ of the built plugin)
 *
 * One namespace, so no Composer runtime is shipped for it.
 */
class Autoloader {
	const PREFIX = __NAMESPACE__ . '\\';

	/**
	 * Base directory of the namespace
	 *
	 * @var string
	 */
	private static $dir = '';

	/**
	 * Register
	 *
	 * @param string $dir src/ directory
	 */
	public static function register( $dir ) {
		self::$dir = trailingslashit( $dir );

		spl_autoload_register( [ __CLASS__, 'load' ] );
	}

	/**
	 * Load a class of the namespace
	 *
	 * @param string $class Fully qualified class name
	 */
	public static function load( $class ) {
		if ( 0 !== strpos( $class, self::PREFIX ) ) {
			return;
		}

		$file = self::$dir . str_replace( '\\', '/', substr( $class, strlen( self::PREFIX ) ) ) . '.php';

		if ( is_readable( $file ) ) {
			require $file;
		}
	}
}
