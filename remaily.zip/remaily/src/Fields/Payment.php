<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Payments\Payments;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment before the message goes, with the providers set up in Settings → Payments (Stripe, PayPal, an add-on's),
 * as CF7's [stripe]: the first Send checks the fields and asks for the payment, the visitor picks a provider and pays
 * in the form, the form is sent again and the payment is checked on the server (Payments)
 *
 * Its value is "provider:payment ID"; once checked, a line such as "20.00 USD paid with Stripe (pi_…)" for mails and
 * entries.
 */
class Payment extends Field {
	public function type() {
		return 'payment';
	}

	public function label() {
		return __( 'Payment', 'remaily' );
	}

	public function summary() {
		return __( 'Visitors pay before the message goes', 'remaily' );
	}

	public function tip() {
		return __( 'Visitors pay before the message goes, with a provider they pick: Stripe, PayPal or one an add-on brings. Set the amount, or take it from a field such as a select of plans. Keys go in Settings → Payments.', 'remaily' );
	}

	public function menu() {
		return 'more';
	}

	public function kind() {
		return 'payment';
	}

	protected function own_defaults() {
		return [
			'amount'       => '',
			'amount_field' => '',
			'currency'     => 'usd',
			'description'  => '',
			'providers'    => '',
			'pay_label'    => __( 'Pay {amount}', 'remaily' ),
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['required']  = false;
		$clean['amount']    = '' === trim( $clean['amount'] ) ? '' : (string) max( 0, (float) str_replace( ',', '.', $clean['amount'] ) );
		$clean['currency']  = array_key_exists( strtolower( $clean['currency'] ), Payments::currencies() ) ? strtolower( $clean['currency'] ) : 'usd';
		$clean['providers'] = implode( ', ', array_intersect( array_map( 'trim', explode( ',', (string) $clean['providers'] ) ), array_keys( Payments::gateways() ) ) );

		return $clean;
	}

	public function messages() {
		return [
			'payment_required' => [ 'label' => __( 'Payment needed', 'remaily' ), 'default' => __( 'Please pay {amount} to send your message.', 'remaily' ) ],
			'payment_failed'   => [ 'label' => __( 'Payment didn\'t go through', 'remaily' ), 'default' => __( 'The payment didn\'t go through, so your message wasn\'t sent. Please try again.', 'remaily' ) ],
		];
	}

	// "stripe:pi_…": the provider and its payment ID
	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? substr( preg_replace( '/[^A-Za-z0-9_:-]/', '', (string) $raw ), 0, 100 ) : '';
	}

	// Checked by Payments, which needs the other fields' values
	public function validate( $value, array $field, Submission $submission ) {
		return '';
	}

	// The input the script fills in; the box around the payment is the template's (template_vars())
	public function control( array $field, array $ctx ) {
		return sprintf( '<input type="hidden" name="%s" value="">', esc_attr( $field['name'] ) );
	}

	/**
	 * The payment box's attributes, escaped, for the template: the script finds the box and its parts by their
	 * data-remaily-payment* attributes, never by class, so a theme lays them out as it likes
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return array
	 */
	public function template_vars( array $field, array $ctx ) {
		return [
			'attributes' => self::html_attributes( [
				'id'                   => $ctx['id'],
				'class'                => trim( 'remaily-payment ' . $field['class'] ),
				'data-remaily-payment' => true,
				'hidden'               => true,
			] ),
		];
	}

	// Paid or not, never required; the provider draws the box, so no attributes of its own
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true, 'attrs' => true ] );
	}

	// A fixed amount; one taken from a field isn't known until visitors pick it
	protected function own_info( array $field, $value = '' ) {
		return [
			'amount' => [ 'label' => __( 'Amount', 'remaily' ), 'value' => '' !== $field['amount'] ? Payments::format( (float) $field['amount'], $field['currency'] ) : '' ],
		];
	}

	public function editor_schema() {
		$providers = array_map( static fn( $gateway ) => $gateway->label(), Payments::gateways() );

		return [
			'amount'       => [ 'type' => 'text', 'label' => __( 'Amount', 'remaily' ), 'help' => __( 'Such as 20 or 19.99. Leave it empty to take the amount from a field below.', 'remaily' ) ],
			'amount_field' => [ 'type' => 'field', 'label' => __( 'Amount from', 'remaily' ), 'help' => __( 'A field whose value is the amount: a number, or a select or radio whose values are prices (the last number in the value counts). Checkboxes add up. An amount of 0 sends the message without a payment.', 'remaily' ) ],
			'currency'     => [ 'type' => 'select', 'label' => __( 'Currency', 'remaily' ), 'options' => Payments::currencies(), 'help' => __( 'A provider that doesn\'t take it isn\'t offered.', 'remaily' ) ],
			'providers'    => [ 'type' => 'chips', 'free' => false, 'label' => __( 'Pay with', 'remaily' ), 'options' => $providers, 'placeholder' => __( 'Every provider set up', 'remaily' ), 'help' => __( 'The providers visitors pick from, those set up in Settings → Payments. Empty: every one set up.', 'remaily' ) ],
			'description'  => [ 'type' => 'text', 'label' => __( 'Description', 'remaily' ), 'help' => __( 'What the payment is for, shown on the receipt and in your payments dashboard. Empty: the form\'s title.', 'remaily' ) ],
			'pay_label'    => [ 'type' => 'text', 'label' => __( 'Pay button', 'remaily' ), 'help' => __( 'The button under a provider\'s card fields, such as Stripe\'s. {amount} is replaced with the amount.', 'remaily' ) ],
		];
	}
}
