<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Payments\Payments;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment before the message goes (Stripe, PayPal), as CF7's [stripe]: the first Send checks the fields and asks
 * for the payment, the visitor pays in the form, the form is sent again and the payment is checked on the server
 *
 * Its value is the provider's payment ID; once checked, a line such as "20.00 USD, Stripe pi_…" for mails and entries.
 */
abstract class Payment extends Field {
	public function menu() {
		return 'more';
	}

	public function kind() {
		return 'payment';
	}

	protected function own_defaults() {
		return [
			'amount'       => '',
			'amount_field' => '',
			'currency'     => 'usd',
			'description'  => '',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['required'] = false;
		$clean['amount']   = '' === trim( $clean['amount'] ) ? '' : (string) max( 0, (float) str_replace( ',', '.', $clean['amount'] ) );
		$clean['currency'] = array_key_exists( strtolower( $clean['currency'] ), Payments::currencies() ) ? strtolower( $clean['currency'] ) : 'usd';

		return $clean;
	}

	public function messages() {
		return [
			'payment_required' => [ 'label' => __( 'Payment needed', 'remaily' ), 'default' => __( 'Please pay {amount} to send your message.', 'remaily' ) ],
			'payment_failed'   => [ 'label' => __( 'Payment didn\'t go through', 'remaily' ), 'default' => __( 'The payment didn\'t go through, so your message wasn\'t sent. Please try again.', 'remaily' ) ],
		];
	}

	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? substr( preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $raw ), 0, 64 ) : '';
	}

	// Checked by Payments, which needs the other fields' values
	public function validate( $value, array $field, Submission $submission ) {
		return '';
	}

	/**
	 * Data attributes the payment script reads: the provider's public key and what to show
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	abstract protected function client( array $field );

	public function control( array $field, array $ctx ) {
		$attrs = [
			'id'                  => $ctx['id'],
			'class'               => trim( 'remaily-payment ' . $field['class'] ),
			'data-remaily-payment' => $this->type(),
			'hidden'              => true,
		] + $this->client( $field );

		// Stripe's card fields need a button of ours; PayPal's buttons are their own
		$pay = isset( $field['pay_label'] ) ? '<button type="button" class="remaily-control remaily-control--submit remaily-payment__pay"></button>' : '';

		return sprintf(
			'<input type="hidden" name="%1$s" value=""><div%2$s><div class="remaily-payment__element"></div><p class="remaily-payment__error" role="alert" hidden></p><div class="remaily-payment__actions">%3$s<button type="button" class="remaily-payment__cancel">%4$s</button></div></div>',
			esc_attr( $field['name'] ),
			self::html_attributes( $attrs ),
			$pay,
			esc_html__( 'Change my details', 'remaily' )
		);
	}

	// Paid or not, never required; the provider draws the box, so no attributes of its own
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true, 'attrs' => true ] );
	}

	// A fixed amount; one taken from a field isn't known until visitors pick it
	protected function own_info( array $field, $value = '' ) {
		return [
			'amount' => [ 'label' => __( 'Amount', 'remaily' ), 'value' => '' !== $field['amount'] ? Payments::format( (float) $field['amount'], $field['currency'] ) : '' ],
		];
	}

	public function editor_schema() {
		return [
			'amount'       => [ 'type' => 'text', 'label' => __( 'Amount', 'remaily' ), 'help' => __( 'Such as 20 or 19.99. Leave it empty to take the amount from a field below.', 'remaily' ) ],
			'amount_field' => [ 'type' => 'field', 'label' => __( 'Amount from', 'remaily' ), 'help' => __( 'A field whose value is the amount: a number, or a select or radio whose values are prices (the last number in the value counts). Checkboxes add up. An amount of 0 sends the message without a payment.', 'remaily' ) ],
			'currency'     => [ 'type' => 'select', 'label' => __( 'Currency', 'remaily' ), 'options' => Payments::currencies() ],
			'description'  => [ 'type' => 'text', 'label' => __( 'Description', 'remaily' ), 'help' => __( 'What the payment is for, shown on the receipt and in your payments dashboard. Empty: the form\'s title.', 'remaily' ) ],
		];
	}
}
