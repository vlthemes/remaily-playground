<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Core\Countries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A drop-down of countries: the value is the two-letter code, the label the name
 */
class Country extends Select {
	public function type() {
		return 'country';
	}

	public function label() {
		return __( 'Country', 'remaily' );
	}

	public function tip() {
		return __( 'A list of countries. [country] prints the name in a mail, [_raw_country] its code, and conditions compare the code, such as "country is us".', 'remaily' );
	}

	public function kind() {
		return 'select';
	}

	protected function own_defaults() {
		return [ 'options' => self::options( '', '' ), 'countries' => '', 'countries_exclude' => '', 'flags' => true ] + parent::own_defaults();
	}

	// A flag before each name in the list, and the picked one's flag, a caret and its name inside the field, as the
	// Tel field shows them; on the page only: mails and entries keep the name
	public function control( array $field, array $ctx ) {
		if ( !$field['flags'] ) {
			return parent::control( $field, $ctx );
		}

		$names            = array_column( $field['options'], 'label', 'value' );
		$field['options'] = array_map( static fn( $option ) => [ 'label' => Countries::flag( $option['value'] ) . ' ' . $option['label'] ] + $option, $field['options'] );
		$html             = parent::control( $field, $ctx );

		if ( $this->multiple( $field ) ) {
			return $html;
		}

		$picked = (string) ( array_values( array_intersect( $this->selected( $field, $ctx ), array_keys( $names ) ) )[0] ?? '' );

		if ( '' === $picked && !$field['include_blank'] ) {
			$picked = (string) key( $names );
		}

		$name = '' !== $picked ? $names[ $picked ] : ( $field['placeholder'] ?: __( '— Please choose —', 'remaily' ) );

		return Countries::flagged( $html, $picked, true, 'remaily-country', $name );
	}

	/**
	 * The options of a list of codes ('' for every country), without those left out
	 *
	 * @param string $include Codes to offer
	 * @param string $exclude Codes to leave out
	 *
	 * @return array
	 */
	private static function options( $include, $exclude ) {
		$all = Countries::all();

		return array_map( static fn( $code ) => [ 'value' => $code, 'label' => $all[ $code ]['name'] ], Countries::codes( $include, $exclude ) );
	}

	// The options come from the countries chosen, never from what was sent
	protected function sanitize_own( array $clean, array $field ) {
		$clean['countries']         = Countries::clean( $clean['countries'] );
		$clean['countries_exclude'] = Countries::clean( $clean['countries_exclude'] );
		$clean['options']           = self::options( $clean['countries'], $clean['countries_exclude'] );

		return $clean;
	}

	public function editor_schema() {
		$schema = parent::editor_schema();

		unset( $schema['options'] );

		return [
			'countries'         => [ 'type' => 'countries', 'label' => __( 'Only these countries', 'remaily' ), 'help' => __( 'The list shows them in the order you pick them. None picked: every country, by name. Save the form to use new ones in conditions.', 'remaily' ) ],
			'countries_exclude' => [ 'type' => 'countries', 'label' => __( 'Leave out', 'remaily' ), 'help' => __( 'Countries taken off the list. On their own: every country but these.', 'remaily' ) ],
			'default'           => [ 'type' => 'select', 'label' => __( 'Picked first', 'remaily' ), 'options' => [ '' => __( 'None', 'remaily' ) ] + array_map( static fn( $country ) => $country['name'], Countries::all() ), 'help' => __( 'The country the list opens on. Fill from can still set it from the visit.', 'remaily' ) ],
		] + $schema + [
			'flags'             => [ 'type' => 'toggle', 'label' => __( 'Flags', 'remaily' ), 'help' => __( 'A flag before each name. Mails and entries keep the name alone. Windows shows the country\'s letters instead.', 'remaily' ) ],
		];
	}
}
