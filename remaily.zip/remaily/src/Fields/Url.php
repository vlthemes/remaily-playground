<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A web address
 */
class Url extends Text {
	public function type() {
		return 'url';
	}

	public function label() {
		return __( 'URL', 'remaily' );
	}

	public function tip() {
		return __( 'A web address. Visitors have to start it with http:// or https://.', 'remaily' );
	}

	protected function input_type() {
		return 'url';
	}

	public function messages() {
		return [
			'invalid_url' => [ 'label' => __( 'Web address isn\'t valid', 'remaily' ), 'default' => __( 'Please enter a full web address, such as https://example.com.', 'remaily' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return parent::validate( $value, $field, $submission ) ?: ( '' !== $value && !preg_match( '~^[a-z][a-z0-9+.-]*://[^\s/?.#][^\s]*$~i', $value ) ? 'invalid_url' : '' );
	}
}
