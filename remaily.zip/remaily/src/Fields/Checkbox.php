<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checkboxes: any number of options
 */
class Checkbox extends Choice {
	public function type() {
		return 'checkbox';
	}

	public function label() {
		return __( 'Checkbox', 'remaily' );
	}

	public function tip() {
		return __( 'Any number of boxes. Turn on "Only one at a time" for a single choice visitors can also leave empty.', 'remaily' );
	}

	public function kind() {
		return 'choices';
	}

	protected function multiple( array $field ) {
		return true;
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'label_wrap'  => true,
			'label_first' => false,
			'exclusive'   => false,
		];
	}

	// The browser can't ask for "one of several checkboxes": the script checks data-remaily-required
	protected function input_required( array $field ) {
		return $field['required'] && count( $field['options'] ) < 2;
	}

	public function wrapper_attributes( array $field ) {
		return [
			'data-remaily-required'  => $field['required'] && count( $field['options'] ) > 1,
			'data-remaily-exclusive' => !empty( $field['exclusive'] ),
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = parent::validate( $value, $field, $submission );

		return $error ?: ( !empty( $field['exclusive'] ) && count( (array) $value ) > 1 ? 'invalid_choice' : '' );
	}

	public function choices( array $field, array $ctx ) {
		return $this->inputs( $field, $ctx, 'checkbox' );
	}

	public function control( array $field, array $ctx ) {
		return '<span class="remaily-choices">' . implode( '', array_column( $this->choices( $field, $ctx ), 'control' ) ) . '</span>';
	}

	public function editor_schema() {
		return parent::editor_schema() + [
			'label_wrap'  => [ 'type' => 'toggle', 'label' => __( 'Wrap each option in its label', 'remaily' ), 'help' => __( 'Only changes the HTML, for your theme\'s CSS. Visitors see no difference; if unsure, leave it as it is.', 'remaily' ) ],
			'label_first' => [ 'type' => 'toggle', 'label' => __( 'Label before the box', 'remaily' ), 'help' => __( 'Puts each option\'s text before its box instead of after it.', 'remaily' ) ],
			'exclusive'   => [ 'type' => 'toggle', 'label' => __( 'Only one at a time', 'remaily' ), 'help' => __( 'Ticking a box clears the others, like radio buttons, but visitors can still clear them all.', 'remaily' ) ],
		];
	}
}
