<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A file upload; Submission\Uploads receives and checks the files, the value is their list
 */
class File extends Field {
	// The types taken from visitors by default, whatever a field lists: files that can't carry code or macros (types())
	const TYPES = [
		'jpg' => 'image', 'jpeg' => 'image', 'jpe' => 'image', 'png' => 'image', 'gif' => 'image', 'webp' => 'image', 'avif' => 'image', 'heic' => 'image', 'heics' => 'image', 'heif' => 'image', 'heifs' => 'image', 'bmp' => 'image', 'tiff' => 'image', 'tif' => 'image', 'ico' => 'image',
		'pdf' => 'text', 'txt' => 'text',
		'mp3' => 'audio', 'm4a' => 'audio', 'm4b' => 'audio', 'aac' => 'audio', 'flac' => 'audio', 'ogg' => 'audio', 'oga' => 'audio', 'wav' => 'audio', 'x-wav' => 'audio', 'mka' => 'audio', 'wma' => 'audio', 'wax' => 'audio', 'mid' => 'audio', 'midi' => 'audio', 'ra' => 'audio', 'ram' => 'audio',
		'mp4' => 'video', 'm4v' => 'video', 'mov' => 'video', 'qt' => 'video', 'webm' => 'video', 'mkv' => 'video', 'avi' => 'video', 'divx' => 'video', 'mpeg' => 'video', 'mpg' => 'video', 'mpe' => 'video', 'ogv' => 'video', 'flv' => 'video', 'wmv' => 'video', 'wm' => 'video', 'wmx' => 'video', 'asf' => 'video', 'asx' => 'video', '3gp' => 'video', '3gpp' => 'video', '3g2' => 'video', '3gp2' => 'video',
	];

	public function type() {
		return 'file';
	}

	public function label() {
		return __( 'File', 'remaily' );
	}

	public function tip() {
		return __( 'Lets visitors attach files. Put [your_file] in the mail\'s Attachments to get them by mail.', 'remaily' );
	}

	protected function own_defaults() {
		return [
			'accept'   => 'jpg, jpeg, png, gif, webp, pdf, txt',
			'max_size' => '2',
			'multiple' => false,
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		// None left of the safe types: the defaults, so the field still takes something
		$clean['accept']   = implode( ', ', self::extensions( $clean ) ) ?: $this->own_defaults()['accept'];
		$clean['max_size'] = is_numeric( $clean['max_size'] ) && $clean['max_size'] > 0 ? (string) (float) $clean['max_size'] : '2';

		return $clean;
	}

	/**
	 * The types a File field may take: [ ext => kind (image, audio, video, text, or a label of its own) ]
	 *
	 * @return array
	 */
	public static function types() {
		/**
		 * The types File fields may take; each still has to be one WordPress allows (upload_mimes):
		 *
		 *     add_filter( 'remaily_file_types', fn( $types ) => $types + [ 'docx' => 'Word document', 'zip' => 'ZIP archive' ] );
		 *
		 * @param array $types [ ext => kind ]
		 */
		$types = (array) apply_filters( 'remaily_file_types', self::TYPES );
		$clean = [];

		foreach ( $types as $ext => $kind ) {
			$ext = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) $ext ) );

			if ( '' !== $ext ) {
				$clean[ $ext ] = (string) $kind;
			}
		}

		return $clean;
	}

	/**
	 * Allowed extensions
	 *
	 * @param array $field Field
	 *
	 * @return string[] Lowercase, no dots
	 */
	public static function extensions( array $field ) {
		$list = preg_split( '/[\s,|]+/', strtolower( (string) $field['accept'] ), -1, PREG_SPLIT_NO_EMPTY );

		$list = array_map( static fn( $ext ) => preg_replace( '/[^a-z0-9-]/', '', $ext ), $list );

		return array_values( array_unique( array_intersect( $list, array_keys( self::types() ) ) ) );
	}

	/**
	 * Largest size allowed, in bytes
	 *
	 * @param array $field Field
	 *
	 * @return int
	 */
	public static function max_bytes( array $field ) {
		return (int) min( (float) $field['max_size'] * MB_IN_BYTES, wp_max_upload_size() );
	}

	public function messages() {
		return [
			'upload_failed'            => [ 'label' => __( 'Upload failed', 'remaily' ), 'default' => __( 'The file couldn\'t be uploaded. Please try again.', 'remaily' ) ],
			'upload_file_type_invalid' => [ 'label' => __( 'File type not allowed', 'remaily' ), 'default' => __( 'This type of file isn\'t allowed.', 'remaily' ) ],
			'upload_file_too_large'    => [ 'label' => __( 'File too large', 'remaily' ), 'default' => __( 'This file is too large.', 'remaily' ) ],
		];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'type'                 => 'file',
			'name'                 => $field['multiple'] ? $field['name'] . '[]' : $field['name'],
			'multiple'             => $field['multiple'],
			'accept'               => implode( ',', array_map( static fn( $ext ) => '.' . $ext, self::extensions( $field ) ) ),
			'data-remaily-max-size' => self::max_bytes( $field ),
		] );

		return '<input' . self::html_attributes( $attrs ) . '>';
	}

	// Submission\Uploads passes the files received
	public function value( $raw, array $field ) {
		return is_array( $raw ) ? $raw : [];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return $submission->upload_error( $field['name'] ) ?: parent::validate( $value, $field, $submission );
	}

	public function mail_value( $value, array $field, $raw = false ) {
		return implode( ', ', wp_list_pluck( (array) $value, 'name' ) );
	}

	protected function own_info( array $field, $value = '' ) {
		return [
			'size'  => [ 'label' => __( 'Max size', 'remaily' ), 'value' => size_format( self::max_bytes( $field ) ) ],
			'types' => [ 'label' => __( 'Types', 'remaily' ), 'value' => strtoupper( implode( ', ', self::extensions( $field ) ) ) ],
		];
	}

	public function editor_schema() {
		$kinds = [
			'image' => __( 'Image', 'remaily' ),
			'audio' => __( 'Audio', 'remaily' ),
			'video' => __( 'Video', 'remaily' ),
			'text'  => __( 'Document', 'remaily' ),
		];

		return [
			'accept'   => [
				'type'  => 'extensions',
				'label' => __( 'Allowed types', 'remaily' ),
				'help'  => __( 'The types visitors may send. Only files that can\'t carry code or macros are listed: images, audio, video, PDF and plain text.', 'remaily' ),
				'types' => array_map( static fn( $kind ) => $kinds[ $kind ] ?? $kind, self::types() ),
			],
			'max_size' => [ 'type' => 'number', 'label' => __( 'Max size (MB)', 'remaily' ), 'help' => __( 'The largest file allowed. Your server may set a lower limit, and that one wins.', 'remaily' ) ],
			'multiple' => [ 'type' => 'toggle', 'label' => __( 'Several files', 'remaily' ), 'help' => __( 'Visitors can pick more than one file at once.', 'remaily' ) ],
		];
	}
}
