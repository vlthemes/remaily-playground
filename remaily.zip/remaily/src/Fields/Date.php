<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A date (YYYY-MM-DD), with optional limits; the default and the limits can be "today" or "today+7", worked out
 * in the site's time zone when the form is shown and checked
 */
class Date extends Text {
	public function type() {
		return 'date';
	}

	public function label() {
		return __( 'Date', 'remaily' );
	}

	public function tip() {
		return __( 'A date picker. Min and max limit the days visitors can pick.', 'remaily' );
	}

	protected function input_type() {
		return 'date';
	}

	protected function own_defaults() {
		return [
			'min'          => '',
			'max'          => '',
			'autocomplete' => '',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		foreach ( [ 'default', 'min', 'max' ] as $key ) {
			$clean[ $key ] = self::is_date( $clean[ $key ] ) || self::is_relative( $clean[ $key ] ) ? $clean[ $key ] : '';
		}

		return $clean;
	}

	protected function input_attributes( array $field ) {
		return [
			'min' => self::resolve( $field['min'] ),
			'max' => self::resolve( $field['max'] ),
		];
	}

	public function control( array $field, array $ctx ) {
		// The default "today" as the date it is now; a posted value is already a date
		$ctx['value'] = self::resolve( is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '' );

		return parent::control( $field, $ctx );
	}

	public function messages() {
		return [
			'invalid_date'   => [ 'label' => __( 'Date isn\'t valid', 'remaily' ), 'default' => __( 'Please enter a valid date.', 'remaily' ) ],
			'date_too_early' => [ 'label' => __( 'Date too early', 'remaily' ), 'default' => __( 'This date is too early.', 'remaily' ) ],
			'date_too_late'  => [ 'label' => __( 'Date too late', 'remaily' ), 'default' => __( 'This date is too late.', 'remaily' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = Field::validate( $value, $field, $submission );

		if ( $error || '' === $value ) {
			return $error;
		}

		if ( !self::is_date( $value ) ) {
			return 'invalid_date';
		}

		$min = self::resolve( $field['min'] );
		$max = self::resolve( $field['max'] );

		// YYYY-MM-DD compares as text
		if ( '' !== $min && $value < $min ) {
			return 'date_too_early';
		}

		if ( '' !== $max && $value > $max ) {
			return 'date_too_late';
		}

		return '';
	}

	// The limits in the site's date format, "today" as the date it is now
	protected function own_info( array $field, $value = '' ) {
		$date = static fn( $value ) => self::is_date( self::resolve( $value ) ) ? wp_date( get_option( 'date_format' ), strtotime( self::resolve( $value ) . ' 12:00' ) ) : '';

		return [
			'min' => [ 'label' => __( 'Earliest', 'remaily' ), 'value' => $date( $field['min'] ) ],
			'max' => [ 'label' => __( 'Latest', 'remaily' ), 'value' => $date( $field['max'] ) ],
		];
	}

	public function editor_schema() {
		return [
			'default' => [ 'type' => 'date', 'label' => __( 'Default value', 'remaily' ), 'empty' => __( 'Empty', 'remaily' ), 'help' => __( 'The date already picked when the page opens.', 'remaily' ) ],
			'min'     => [ 'type' => 'date', 'label' => __( 'Earliest', 'remaily' ), 'empty' => __( 'No limit', 'remaily' ), 'help' => __( 'The first date visitors can pick. "Today" keeps them from picking a past date.', 'remaily' ) ],
			'max'     => [ 'type' => 'date', 'label' => __( 'Latest', 'remaily' ), 'empty' => __( 'No limit', 'remaily' ), 'help' => __( 'The last date visitors can pick, such as 30 days from today for bookings.', 'remaily' ) ],
		];
	}

	/**
	 * Whether a value is a real date in YYYY-MM-DD
	 *
	 * @param string $value Value
	 *
	 * @return bool
	 */
	private static function is_date( $value ) {
		return (bool) preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * Whether a value is "today" or days from it ("today+7", "today-1")
	 *
	 * @param string $value Value
	 *
	 * @return bool
	 */
	private static function is_relative( $value ) {
		return (bool) preg_match( '/^today([+-]\d{1,4})?$/', (string) $value );
	}

	/**
	 * A setting as a date: "today+7" as the date it is in the site's time zone, others as they are
	 *
	 * @param string $value Value
	 *
	 * @return string
	 */
	public static function resolve( $value ) {
		if ( !self::is_relative( $value ) ) {
			return (string) $value;
		}

		$days = (int) substr( (string) $value, 5 );

		return ( new \DateTimeImmutable( 'today', wp_timezone() ) )->modify( sprintf( '%+d days', $days ) )->format( 'Y-m-d' );
	}
}
