<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A mirror of another field's value, as text, updated as the visitor types; never sent
 */
class Output extends Field {
	public function type() {
		return 'output';
	}

	public function label() {
		return __( 'Output', 'remaily' );
	}

	public function menu() {
		return 'more';
	}

	public function summary() {
		return __( 'Shows what visitors type in another field, as they type', 'remaily' );
	}

	public function tip() {
		return __( 'Repeats another field as visitors type. For example, pick the name field and the format "Thanks, {value}!".', 'remaily' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'source' => '',
			'format' => '{value}',
			'empty'  => '',
		];
	}

	public function control( array $field, array $ctx ) {
		$source = $field['source'];
		$value  = $ctx['values'][ $source ] ?? '';
		$value  = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
		$text   = '' === $value ? $field['empty'] : str_replace( '{value}', $value, $field['format'] ?: '{value}' );

		$attrs = array_merge( $this->custom_attributes( $field ), [
			'id'                 => $ctx['id'],
			'class'              => trim( 'remaily-output ' . $field['class'] ),
			'for'                => $ctx['ids'][ $source ] ?? null,
			'aria-live'          => 'polite',
			'data-remaily-output' => $source,
			'data-format'        => $field['format'] ?: '{value}',
			'data-empty'         => $field['empty'],
		] );

		return '<output' . self::html_attributes( $attrs ) . '>' . esc_html( $text ) . '</output>';
	}

	// Never sent, so nothing to require
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true ] );
	}

	public function editor_schema() {
		return [
			'source' => [ 'type' => 'field', 'label' => __( 'Mirror of', 'remaily' ), 'help' => __( 'The field whose value shows here as visitors type or pick. For options, their labels show.', 'remaily' ) ],
			'format' => [
				'type'   => 'format',
				'label'  => __( 'Text shown', 'remaily' ),
				'help'   => __( 'Write the text and click Value to add what visitors typed, such as: Thanks, Olga!', 'remaily' ),
				'tokens' => [ '{value}' => __( 'Value', 'remaily' ) ],
			],
			'empty'  => [ 'type' => 'text', 'label' => __( 'Text when empty', 'remaily' ), 'help' => __( 'Shown until that field has a value. Empty: nothing shows.', 'remaily' ) ],
		];
	}
}
