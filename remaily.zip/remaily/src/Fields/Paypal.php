<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Payments\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment through PayPal, with PayPal's own buttons in the form
 */
class Paypal extends Payment {
	public function type() {
		return 'paypal';
	}

	public function label() {
		return __( 'PayPal payment', 'remaily' );
	}

	public function summary() {
		return __( 'Visitors pay with PayPal before the message goes', 'remaily' );
	}

	public function tip() {
		return __( 'Visitors pay with PayPal or a card before the message goes. Set the amount, or take it from a field such as a select of plans. Keys go in Settings → Payments.', 'remaily' );
	}

	protected function client( array $field ) {
		return [
			'data-key' => (string) ( Payments::settings()['paypal_client'] ?? '' ),
		];
	}
}
