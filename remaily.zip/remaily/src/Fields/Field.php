<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Admin\Settings;
use VLT\Remaily\Front\Defaults;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A field type: its settings, its control, how a posted value is read, checked and mailed
 *
 * The control (the input itself, with its name, id, ARIA and validation attributes) is printed here, so no template
 * can lose it; templates/fields/{kind}/{style}/field.php is what goes around it.
 */
abstract class Field {
	/**
	 * Type ID
	 *
	 * @return string
	 */
	abstract public function type();

	/**
	 * Name shown in the editor
	 *
	 * @return string
	 */
	abstract public function label();

	/**
	 * The control's markup
	 *
	 * @param array $field Field settings, with 'name'
	 * @param array $ctx   'id', 'value', 'invalid', 'error_id', 'ids' (name => control ID), 'form'
	 *
	 * @return string
	 */
	abstract public function control( array $field, array $ctx );

	/**
	 * A short tip with an example, shown at the bottom of the editor while the field is selected
	 *
	 * @return string
	 */
	public function tip() {
		return '';
	}

	/**
	 * Icon of the editor's chip and button: a built-in icon's name, or the d of a 24×24 stroke path
	 *
	 * @return string
	 */
	public function icon() {
		return $this->type();
	}

	/**
	 * Its page in the documentation ('' = none), linked from the sidebar
	 *
	 * @return string
	 */
	public function docs() {
		// Only the built-in types have a page; an add-on's type gives its own
		return 0 === strpos( static::class, __NAMESPACE__ . '\\' ) ? trailingslashit( Settings::docs_url() ) . $this->type() . '-field/' : '';
	}

	/**
	 * Where its button goes in the editor: 'main' (the row of field buttons) or 'more' (the More menu after them)
	 *
	 * @return string
	 */
	public function menu() {
		return 'main';
	}

	/**
	 * One line on what it does: under its name in the More menu, and its button's title
	 *
	 * @return string
	 */
	public function summary() {
		return '';
	}

	/**
	 * Template folder shared with similar types (templates/fields/{kind}/), after the type's own
	 *
	 * @return string
	 */
	public function kind() {
		return $this->type();
	}

	/**
	 * Whether the field sends a value
	 *
	 * @return bool
	 */
	public function submits() {
		return true;
	}

	/**
	 * Settings of this type only
	 *
	 * @return array
	 */
	protected function own_defaults() {
		return [];
	}

	/**
	 * Whether the starting value can come from the visit (the URL, the user…): types with a default value setting
	 *
	 * @return bool
	 */
	public function dynamic_default() {
		return isset( $this->editor_schema()['default'] );
	}

	/**
	 * Every setting's default; remaily_field_defaults adds settings to any type
	 *
	 * @return array
	 */
	public function defaults() {
		$defaults = [
			'type'        => $this->type(),
			'required'    => false,
			'default'     => '',
			'placeholder' => '',
			'style'       => '',
			'class'       => '',
			'id'          => '',
			'attrs'       => [],
		] + $this->own_defaults();

		if ( $this->dynamic_default() ) {
			$defaults += [ 'default_from' => '', 'default_key' => '' ];
		}

		return (array) apply_filters( 'remaily_field_defaults', $defaults, $this->type(), $this ) + $defaults;
	}

	/**
	 * Clean settings; unknown keys are dropped
	 *
	 * @param array $field Settings
	 *
	 * @return array
	 */
	public function sanitize( array $field ) {
		$field += $this->defaults();
		$clean  = [];

		foreach ( $this->defaults() as $key => $default ) {
			$value = $field[ $key ];

			if ( is_bool( $default ) ) {
				$clean[ $key ] = !empty( $value ) && 'false' !== $value;
			} elseif ( is_int( $default ) ) {
				$clean[ $key ] = max( 0, (int) $value );
			} elseif ( is_string( $default ) ) {
				$clean[ $key ] = sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );
			} else {
				$clean[ $key ] = is_array( $value ) ? $value : $default;
			}
		}

		$clean['type']  = $this->type();
		$clean['style'] = sanitize_key( $clean['style'] );
		$clean['class'] = implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', $clean['class'], -1, PREG_SPLIT_NO_EMPTY ) ) );
		$clean['id']    = sanitize_html_class( $clean['id'] );
		$clean['attrs'] = self::sanitize_attrs( $clean['attrs'] );

		if ( isset( $clean['default_from'] ) && !array_key_exists( $clean['default_from'], Defaults::sources() ) ) {
			$clean['default_from'] = '';
		}

		// Plain values of added settings are cleaned above; arrays are the filter's to clean
		return (array) apply_filters( 'remaily_field_sanitize', $this->sanitize_own( $clean, $field ), $field, $this->type(), $this );
	}

	/**
	 * Clean what this type adds beyond the plain values
	 *
	 * @param array $clean Settings cleaned so far
	 * @param array $field Settings as given
	 *
	 * @return array
	 */
	protected function sanitize_own( array $clean, array $field ) {
		return $clean;
	}

	/**
	 * Messages this type adds to the Messages tab
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public function messages() {
		return [];
	}

	/**
	 * The settings every field has that this type uses (required, style, class, id, attrs), for the sidebar; one
	 * may hold a when as editor_schema()'s does, shown only while other settings have those values
	 *
	 * @return array [ setting => true | [ other setting => [ values ] ] ]
	 */
	public function shared() {
		return [ 'required' => true, 'style' => true, 'class' => true, 'id' => true, 'attrs' => true ];
	}

	/**
	 * The field's custom attributes, as name => value
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	protected function custom_attributes( array $field ) {
		return array_column( (array) $field['attrs'], 'value', 'name' );
	}

	/**
	 * Attributes every control has: name, id, class, ARIA, required, custom ones
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return array
	 */
	protected function attributes( array $field, array $ctx ) {
		return array_merge( $this->custom_attributes( $field ), [
			'name'             => $field['name'],
			'id'               => $ctx['id'],
			'class'            => trim( 'remaily-control remaily-control--' . $this->type() . ' ' . $field['class'] ),
			'required'         => $field['required'],
			'aria-invalid'     => $ctx['invalid'] ? 'true' : null,
			'aria-describedby' => $ctx['invalid'] ? $ctx['error_id'] : null,
		] );
	}

	/**
	 * Attributes of the field's wrapper the script reads
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	public function wrapper_attributes( array $field ) {
		return [];
	}

	/**
	 * Choices of select, checkbox and radio, for templates that print their own
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return array [ [ 'value', 'label', 'id', 'checked', 'control' ], … ]
	 */
	public function choices( array $field, array $ctx ) {
		return [];
	}

	/**
	 * The posted value, clean
	 *
	 * @param mixed $raw   Posted value (unslashed)
	 * @param array $field Field
	 *
	 * @return mixed
	 */
	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? sanitize_text_field( (string) $raw ) : '';
	}

	/**
	 * The clean value from the whole request: a type whose control sends more than its own name reads it here
	 *
	 * @param array $request Posted values (unslashed)
	 * @param array $field   Field, with 'name'
	 *
	 * @return mixed
	 */
	public function request_value( array $request, array $field ) {
		return $this->value( $request[ $field['name'] ] ?? '', $field );
	}

	/**
	 * Check a value
	 *
	 * @param mixed      $value      Clean value
	 * @param array      $field      Field
	 * @param Submission $submission Submission
	 *
	 * @return string Message key, '' when valid
	 */
	public function validate( $value, array $field, Submission $submission ) {
		return $field['required'] && self::is_empty( $value ) ? 'required' : '';
	}

	/**
	 * The value as a mail tag prints it
	 *
	 * @param mixed $value Clean value
	 * @param array $field Field
	 * @param bool  $raw   The values themselves ([_raw_name]), not their labels
	 *
	 * @return string
	 */
	public function mail_value( $value, array $field, $raw = false ) {
		return is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
	}

	/**
	 * What of a field's settings the form's text can show, [[name:key]]: [ key => [ 'label', 'value', 'live' ] ], the
	 * value as visitors read it ("10 MB"); 'live' ones (count, left) change as visitors type. remaily_field_info adds more
	 *
	 * @param array $field Field
	 * @param mixed $value The field's value now, for live ones ('' when unknown)
	 *
	 * @return array
	 */
	final public function info( array $field, $value = '' ) {
		$info = $this->own_info( $field, $value );

		/**
		 * What [[name:key]] can show of a field, such as [[your_file:size]]:
		 *
		 *     add_filter( 'remaily_field_info', function ( $info, $field, $type ) {
		 *         if ( 'file' === $type ) {
		 *             $info['size_kb'] = [ 'label' => 'Max size in KB', 'value' => (string) ( $field['max_size'] * 1024 ) ];
		 *         }
		 *         return $info;
		 *     }, 10, 3 );
		 *
		 * @param array  $info  [ key => [ 'label', 'value' ] ]
		 * @param array  $field Field
		 * @param string $type  Type
		 */
		return (array) apply_filters( 'remaily_field_info', $info, $field, $this->type() );
	}

	/**
	 * The type's own info() entries
	 *
	 * @param array $field Field
	 * @param mixed $value The field's value now
	 *
	 * @return array
	 */
	protected function own_info( array $field, $value = '' ) {
		return [];
	}

	/**
	 * The editor's sidebar controls of this type, after the shared ones
	 *
	 * @return array [ key => [ 'type' => toggle|text|textarea|number|select|options|pairs|field|date|countries, 'label' => string, … ] ]
	 */
	public function editor_schema() {
		return [];
	}

	/**
	 * The sidebar controls the editor shows; remaily_field_schema adds controls to any type
	 *
	 * @return array
	 */
	final public function schema() {
		$schema = $this->editor_schema();

		// Where the default value may come from, right after it
		if ( $this->dynamic_default() ) {
			$at     = array_search( 'default', array_keys( $schema ), true ) + 1;
			$schema = array_slice( $schema, 0, $at, true ) + [
				'default_from' => [ 'type' => 'select', 'label' => __( 'Fill from', 'remaily' ), 'options' => Defaults::sources(), 'help' => __( 'Fills the field when the page opens: from a link such as ?name=Olga, the shortcode ([remaily id="…" name="Olga"]), the page or the logged-in user. The value above is used when that is empty. On a cached page everyone gets the same value, so leave URL and user values to pages that aren\'t cached.', 'remaily' ) ],
				'default_key'  => [ 'type' => 'text', 'label' => __( 'Name to read', 'remaily' ), 'when' => [ 'default_from' => Defaults::NAMED ], 'help' => __( 'The URL parameter, posted field, shortcode attribute or custom field to read. Empty: this field\'s name.', 'remaily' ) ],
			] + array_slice( $schema, $at, null, true );
		}

		return (array) apply_filters( 'remaily_field_schema', $schema, $this->type(), $this );
	}

	/**
	 * Whether a value is empty
	 *
	 * @param mixed $value Value
	 *
	 * @return bool
	 */
	public static function is_empty( $value ) {
		return is_array( $value ) ? !array_filter( $value, static fn( $item ) => '' !== (string) $item ) : '' === trim( (string) $value );
	}

	/**
	 * Attributes as HTML: true prints the name alone, false and null leave it out
	 *
	 * @param array $attrs Attributes
	 *
	 * @return string
	 */
	public static function html_attributes( array $attrs ) {
		$html = '';

		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value || '' === $value && 'value' !== $name ) {
				continue;
			}

			$html .= true === $value ? ' ' . $name : sprintf( ' %s="%s"', $name, esc_attr( (string) $value ) );
		}

		return $html;
	}

	/**
	 * Clean custom attributes: no event handlers, none the control sets itself
	 *
	 * @param mixed $attrs [ [ 'name', 'value' ], … ]
	 *
	 * @return array
	 */
	private static function sanitize_attrs( $attrs ) {
		$clean = [];

		foreach ( (array) $attrs as $attr ) {
			$name = strtolower( trim( (string) ( $attr['name'] ?? '' ) ) );

			if ( preg_match( '/^[a-z_:][a-z0-9_:.-]*$/', $name ) && 0 !== strpos( $name, 'on' ) && !in_array( $name, [ 'name', 'id', 'type', 'value', 'class', 'form', 'style' ], true ) ) {
				$clean[] = [ 'name' => $name, 'value' => sanitize_text_field( (string) ( $attr['value'] ?? '' ) ) ];
			}
		}

		return $clean;
	}
}
