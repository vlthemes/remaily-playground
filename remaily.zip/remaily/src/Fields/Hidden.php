<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A value sent with the form, not shown
 */
class Hidden extends Field {
	public function type() {
		return 'hidden';
	}

	public function label() {
		return __( 'Hidden', 'remaily' );
	}

	public function tip() {
		return __( 'Sent with the message, never shown. For example, fill it from the URL parameter utm_source to see where visitors came from.', 'remaily' );
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['required'] = false;

		return $clean;
	}

	public function control( array $field, array $ctx ) {
		return '<input' . self::html_attributes( [
			'type'  => 'hidden',
			'name'  => $field['name'],
			'id'    => $ctx['id'],
			'value' => is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '',
		] ) . '>';
	}

	// Never shown: none of the shared settings
	public function shared() {
		return [];
	}

	public function editor_schema() {
		return [
			'default' => [ 'type' => 'text', 'label' => __( 'Value', 'remaily' ), 'help' => __( 'Sent with every message without being shown, such as a campaign name. It goes into mails and entries like any field.', 'remaily' ) ],
		];
	}
}
