<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A number, with optional limits and step
 */
class Number extends Text {
	public function type() {
		return 'number';
	}

	public function label() {
		return __( 'Number', 'remaily' );
	}

	public function tip() {
		return __( 'A number, with an optional min, max and step. For example, min 1 and max 10 for "How many guests?".', 'remaily' );
	}

	protected function input_type() {
		return 'number';
	}

	protected function own_defaults() {
		return [
			'min'          => '',
			'max'          => '',
			'step'         => '',
			'autocomplete' => '',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		foreach ( [ 'min', 'max', 'step' ] as $key ) {
			$clean[ $key ] = is_numeric( $clean[ $key ] ) ? $clean[ $key ] : '';
		}

		return $clean;
	}

	protected function input_attributes( array $field ) {
		return [
			'min'  => $field['min'],
			'max'  => $field['max'],
			'step' => $field['step'] ?: 'any',
		];
	}

	public function messages() {
		return [
			'invalid_number'   => [ 'label' => __( 'Not a number', 'remaily' ), 'default' => __( 'Please enter a number.', 'remaily' ) ],
			'number_too_small' => [ 'label' => __( 'Number too small', 'remaily' ), 'default' => __( 'This number is too small.', 'remaily' ) ],
			'number_too_large' => [ 'label' => __( 'Number too large', 'remaily' ), 'default' => __( 'This number is too large.', 'remaily' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = Field::validate( $value, $field, $submission );

		if ( $error || '' === $value ) {
			return $error;
		}

		if ( !is_numeric( $value ) ) {
			return 'invalid_number';
		}

		if ( '' !== $field['min'] && (float) $value < (float) $field['min'] ) {
			return 'number_too_small';
		}

		if ( '' !== $field['max'] && (float) $value > (float) $field['max'] ) {
			return 'number_too_large';
		}

		return '';
	}

	protected function own_info( array $field, $value = '' ) {
		return [
			'min' => [ 'label' => __( 'Min', 'remaily' ), 'value' => (string) $field['min'] ],
			'max' => [ 'label' => __( 'Max', 'remaily' ), 'value' => (string) $field['max'] ],
		];
	}

	public function editor_schema() {
		return [
			'placeholder' => [ 'type' => 'text', 'label' => __( 'Placeholder', 'remaily' ), 'help' => __( 'A hint shown in the empty field.', 'remaily' ) ],
			'default'     => [ 'type' => 'text', 'label' => __( 'Default value', 'remaily' ), 'help' => __( 'The number already in the field when the page opens.', 'remaily' ) ],
			'min'         => [ 'type' => 'number', 'label' => __( 'Min', 'remaily' ), 'help' => __( 'The smallest number allowed. Empty: no limit.', 'remaily' ) ],
			'max'         => [ 'type' => 'number', 'label' => __( 'Max', 'remaily' ), 'help' => __( 'The largest number allowed. Empty: no limit.', 'remaily' ) ],
			'step'        => [ 'type' => 'number', 'label' => __( 'Step', 'remaily' ), 'help' => __( 'How much the arrows add or take away, and which numbers are allowed: 5 allows 0, 5, 10… Empty: any number.', 'remaily' ) ],
		];
	}
}
