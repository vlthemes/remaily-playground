<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * How many characters another field has, updated as the visitor types; never sent
 */
class Count extends Field {
	public function type() {
		return 'count';
	}

	public function label() {
		return __( 'Count', 'remaily' );
	}

	public function menu() {
		return 'more';
	}

	public function summary() {
		return __( 'Counts the characters visitors type in another field', 'remaily' );
	}

	public function tip() {
		return __( 'Counts the characters in another field. For example, pick the message, give it a max length of 500 and use the format "{left} characters left".', 'remaily' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'source' => '',
			'format' => '{count}',
		];
	}

	/**
	 * The text for a number of characters: {count}, {left} (to the max length) and {max}
	 *
	 * @param string $format Format
	 * @param int    $count  Characters typed
	 * @param int    $max    Max length, 0 for none
	 *
	 * @return string
	 */
	public static function text( $format, $count, $max ) {
		return strtr( $format ?: '{count}', [
			'{count}' => $count,
			'{left}'  => $max ? $max - $count : '',
			'{max}'   => $max ?: '',
		] );
	}

	public function control( array $field, array $ctx ) {
		$source = $field['source'];
		$limits = $ctx['form']->fields()[ $source ] ?? [];
		$max    = (int) ( $limits['maxlength'] ?? 0 );
		$min    = (int) ( $limits['minlength'] ?? 0 );
		$value  = $ctx['values'][ $source ] ?? '';
		$count  = is_scalar( $value ) ? mb_strlen( (string) $value ) : 0;
		$state  = $max && $count > $max ? ' is-over' : ( $min && $count && $count < $min ? ' is-under' : '' );

		$attrs = array_merge( $this->custom_attributes( $field ), [
			'id'                => $ctx['id'],
			'class'             => trim( 'remaily-count' . $state . ' ' . $field['class'] ),
			'for'               => $ctx['ids'][ $source ] ?? null,
			'data-remaily-count' => $source,
			'data-format'       => $field['format'] ?: '{count}',
			'data-max'          => $max ?: null,
			'data-min'          => $min ?: null,
			// For progress bars: width: calc(var(--remaily-count) / var(--remaily-max) * 100%)
			'style'             => '--remaily-count:' . $count . ';--remaily-max:' . $max,
		] );

		return '<output' . self::html_attributes( $attrs ) . '>' . esc_html( self::text( $field['format'], $count, $max ) ) . '</output>';
	}

	// Never sent, so nothing to require
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true ] );
	}

	public function editor_schema() {
		return [
			'source' => [ 'type' => 'field', 'label' => __( 'Count of', 'remaily' ), 'help' => __( 'The field whose characters are counted as visitors type, usually a textarea.', 'remaily' ) ],
			'format' => [
				'type'     => 'format',
				'label'    => __( 'Text shown', 'remaily' ),
				'help'     => __( 'Write the text and click a value to add it, such as: 120 characters left.', 'remaily' ),
				'tokens'   => [
					'{count}' => __( 'Characters typed', 'remaily' ),
					'{left}'  => __( 'Characters left', 'remaily' ),
					'{max}'   => __( 'Max length', 'remaily' ),
				],
				// Empty until the counted field has a max length
				'need_max' => [ '{left}', '{max}' ],
			],
		];
	}
}
