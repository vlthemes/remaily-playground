<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The submit button: a <button>, or a link (<a>) when the design needs one; the front script sends the form for the link
 */
class Submit extends Field {
	public function type() {
		return 'submit';
	}

	public function label() {
		return __( 'Submit', 'remaily' );
	}

	public function tip() {
		return __( 'The send button. The reply shows where [[response]] is, or at the end of the form.', 'remaily' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'label' => __( 'Send', 'remaily' ),
			'tag'   => 'button',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['tag'] = 'a' === $clean['tag'] ? 'a' : 'button';

		return $clean;
	}

	public function control( array $field, array $ctx ) {
		$attrs = $this->attributes( $field, $ctx );
		$label = '<span class="remaily-submit__label">' . esc_html( $field['label'] ?: __( 'Send', 'remaily' ) ) . '</span>';

		unset( $attrs['name'], $attrs['required'], $attrs['aria-invalid'], $attrs['aria-describedby'] );

		if ( 'a' === $field['tag'] ) {
			return '<a href="#" role="button"' . self::html_attributes( $attrs + [ 'data-remaily-submit' => true ] ) . '>' . $label . '</a>';
		}

		return '<button type="submit"' . self::html_attributes( $attrs ) . '>' . $label . '</button>';
	}

	// Sends nothing, so nothing to require
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true ] );
	}

	public function editor_schema() {
		return [
			'label' => [ 'type' => 'text', 'label' => __( 'Label', 'remaily' ), 'help' => __( 'The text on the button.', 'remaily' ) ],
			'tag'   => [
				'type'    => 'select',
				'label'   => __( 'Show as', 'remaily' ),
				'help'    => __( 'A button works everywhere. A link looks like text and needs JavaScript in the browser; use it only if your design asks for one.', 'remaily' ),
				'options' => [
					'button' => __( 'Button', 'remaily' ),
					'a'      => __( 'Link', 'remaily' ),
				],
			],
		];
	}
}
