<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A question with a known answer, against bots; one of its questions is picked at random
 *
 * The page carries hashes of the answers only (_remaily_quiz[name]).
 */
class Quiz extends Field {
	public function type() {
		return 'quiz';
	}

	public function label() {
		return __( 'Quiz', 'remaily' );
	}

	public function tip() {
		return __( 'A question only a person can answer, written as "question | answer", such as "1 + 1 = ? | 2".', 'remaily' );
	}

	protected function own_defaults() {
		return [
			'questions' => [ [ 'question' => '1 + 1 = ?', 'answer' => '2' ] ],
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$questions = $field['questions'] ?? [];

		// "Question | answer" lines, as the editor writes them
		if ( is_string( $questions ) ) {
			$questions = array_map( static function ( $line ) {
				$parts = array_map( 'trim', explode( '|', $line, 2 ) );

				return [ 'question' => $parts[0], 'answer' => $parts[1] ?? '' ];
			}, preg_split( '/\R/', $questions, -1, PREG_SPLIT_NO_EMPTY ) );
		}

		$clean['questions'] = [];

		foreach ( (array) $questions as $item ) {
			$question = sanitize_text_field( (string) ( $item['question'] ?? '' ) );
			$answer   = sanitize_text_field( (string) ( $item['answer'] ?? '' ) );

			if ( '' !== $question && '' !== $answer ) {
				$clean['questions'][] = [ 'question' => $question, 'answer' => $answer ];
			}
		}

		$clean['required'] = true;

		return $clean;
	}

	public function messages() {
		return [
			'quiz_answer_not_correct' => [ 'label' => __( 'Wrong quiz answer', 'remaily' ), 'default' => __( 'That answer isn\'t right. Please try again.', 'remaily' ) ],
		];
	}

	public function control( array $field, array $ctx ) {
		if ( !$field['questions'] ) {
			return '';
		}

		$item   = $field['questions'][ array_rand( $field['questions'] ) ];
		$hashes = array_map( [ __CLASS__, 'hash' ], explode( '|', $item['answer'] ) );
		$attrs  = array_merge( $this->attributes( $field, $ctx ), [
			'type'             => 'text',
			'value'            => '',
			'autocomplete'     => 'off',
			'placeholder'      => $field['placeholder'],
			'aria-describedby' => trim( $ctx['id'] . '-question ' . ( $ctx['invalid'] ? $ctx['error_id'] : '' ) ),
		] );

		return sprintf(
			'<span class="remaily-quiz__question" id="%s-question">%s</span><input%s><input type="hidden" name="_remaily_quiz[%s]" value="%s">',
			esc_attr( $ctx['id'] ),
			esc_html( $item['question'] ),
			self::html_attributes( $attrs ),
			esc_attr( $field['name'] ),
			esc_attr( implode( ',', $hashes ) )
		);
	}

	public function validate( $value, array $field, Submission $submission ) {
		if ( self::is_empty( $value ) ) {
			return 'required';
		}

		$posted = (array) $submission->raw( '_remaily_quiz' );
		$hashes = explode( ',', (string) ( $posted[ $field['name'] ] ?? '' ) );

		foreach ( $hashes as $hash ) {
			if ( '' !== $hash && hash_equals( $hash, self::hash( $value ) ) ) {
				return '';
			}
		}

		return 'quiz_answer_not_correct';
	}

	// Always answered
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true ] );
	}

	public function editor_schema() {
		return [
			'questions' => [ 'type' => 'pairs', 'label' => __( 'Questions (question | answer)', 'remaily' ), 'help' => __( 'One per line. Several answers: 2|two.', 'remaily' ) ],
		];
	}

	/**
	 * Hash of an answer, case and spaces aside
	 *
	 * @param string $answer Answer
	 *
	 * @return string
	 */
	private static function hash( $answer ) {
		return wp_hash( 'remaily-quiz|' . mb_strtolower( trim( (string) $answer ) ) );
	}
}
