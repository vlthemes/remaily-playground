<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A drop-down of options, one or several
 */
class Select extends Choice {
	public function type() {
		return 'select';
	}

	public function label() {
		return __( 'Select', 'remaily' );
	}

	public function tip() {
		return __( 'A dropdown. Write options as "value : Label" lines: visitors see the label, conditions and [_raw_name] get the value.', 'remaily' );
	}

	protected function multiple( array $field ) {
		return !empty( $field['multiple'] );
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'multiple'      => false,
			'include_blank' => true,
		];
	}

	public function control( array $field, array $ctx ) {
		$selected = $this->selected( $field, $ctx );
		$attrs    = array_merge( $this->attributes( $field, $ctx ), [
			'name'     => $this->multiple( $field ) ? $field['name'] . '[]' : $field['name'],
			'multiple' => $this->multiple( $field ),
		] );

		$html = '<select' . self::html_attributes( $attrs ) . '>';

		if ( $field['include_blank'] && !$this->multiple( $field ) ) {
			$html .= '<option value="">' . esc_html( $field['placeholder'] ?: __( '— Please choose —', 'remaily' ) ) . '</option>';
		}

		foreach ( $field['options'] as $option ) {
			$html .= sprintf(
				'<option value="%s"%s>%s</option>',
				esc_attr( self::shown( $option['value'] ) ),
				in_array( (string) $option['value'], $selected, true ) ? ' selected' : '',
				esc_html( $option['label'] )
			);
		}

		return $html . '</select>';
	}

	public function editor_schema() {
		return parent::editor_schema() + [
			'include_blank' => [ 'type' => 'toggle', 'when' => [ 'multiple' => [ false ] ], 'label' => __( 'Start with an empty choice', 'remaily' ), 'help' => __( 'The list opens on a "Please choose" line instead of the first option, so visitors have to pick one themselves.', 'remaily' ) ],
			'placeholder'   => [ 'type' => 'text', 'when' => [ 'include_blank' => [ true ], 'multiple' => [ false ] ], 'label' => __( 'Empty choice label', 'remaily' ), 'help' => __( 'The text of that first, empty line. Empty: "— Please choose —".', 'remaily' ) ],
			'multiple'      => [ 'type' => 'toggle', 'label' => __( 'Allow several', 'remaily' ), 'help' => __( 'Visitors can pick more than one option, holding Ctrl or Cmd.', 'remaily' ) ],
		];
	}
}
