<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One line of text; the base of email, URL, tel, number and date
 */
class Text extends Field {
	public function type() {
		return 'text';
	}

	public function label() {
		return __( 'Text', 'remaily' );
	}

	public function tip() {
		return __( 'One line, such as a name or a subject. For example, with Fill from set to URL parameter, a link ending in ?subject=Pricing opens the form with the subject filled in.', 'remaily' );
	}

	public function kind() {
		return 'input';
	}

	/**
	 * The input's type attribute
	 *
	 * @return string
	 */
	protected function input_type() {
		return 'text';
	}

	protected function own_defaults() {
		return [
			'minlength'    => 0,
			'maxlength'    => 0,
			'autocomplete' => '',
		];
	}

	/**
	 * Attributes of this type: limits, pattern
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	protected function input_attributes( array $field ) {
		return [
			'minlength' => $field['minlength'] ?: null,
			'maxlength' => $field['maxlength'] ?: null,
		];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'type'         => $this->input_type(),
			'value'        => is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '',
			'placeholder'  => $field['placeholder'],
			'autocomplete' => $field['autocomplete'] ?? '',
		], $this->input_attributes( $field ) );

		return '<input' . self::html_attributes( $attrs ) . '>';
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = parent::validate( $value, $field, $submission );

		if ( $error || self::is_empty( $value ) ) {
			return $error;
		}

		$length = mb_strlen( (string) $value );

		if ( !empty( $field['maxlength'] ) && $length > $field['maxlength'] ) {
			return 'too_long';
		}

		if ( !empty( $field['minlength'] ) && $length < $field['minlength'] ) {
			return 'too_short';
		}

		return '';
	}

	// count and left change as visitors type (the front script); left needs a max length
	protected function own_info( array $field, $value = '' ) {
		$count = is_scalar( $value ) ? mb_strlen( (string) $value ) : 0;
		$max   = (int) ( $field['maxlength'] ?? 0 );

		return [
			'min'   => [ 'label' => __( 'Min length', 'remaily' ), 'value' => (string) ( $field['minlength'] ?: '' ) ],
			'max'   => [ 'label' => __( 'Max length', 'remaily' ), 'value' => (string) ( $max ?: '' ) ],
			'count' => [ 'label' => __( 'Characters typed', 'remaily' ), 'value' => (string) $count, 'live' => true ],
			'left'  => [ 'label' => __( 'Characters left', 'remaily' ), 'value' => $max ? (string) ( $max - $count ) : '', 'live' => true ],
		];
	}

	public function editor_schema() {
		return [
			'placeholder'  => [ 'type' => 'text', 'label' => __( 'Placeholder', 'remaily' ), 'help' => __( 'A hint shown in the empty field. It goes away as soon as visitors type.', 'remaily' ) ],
			'default'      => [ 'type' => 'text', 'label' => __( 'Default value', 'remaily' ), 'help' => __( 'Text already in the field when the page opens. Visitors can change it.', 'remaily' ) ],
			'minlength'    => [ 'type' => 'number', 'label' => __( 'Min length', 'remaily' ), 'help' => __( 'The fewest characters visitors must type. Empty: no limit.', 'remaily' ) ],
			'maxlength'    => [ 'type' => 'number', 'label' => __( 'Max length', 'remaily' ), 'help' => __( 'The most characters visitors can type. Empty: no limit.', 'remaily' ) ],
			'autocomplete' => [ 'type' => 'select', 'label' => __( 'Autocomplete', 'remaily' ), 'options' => self::autocomplete_options(), 'help' => __( 'Browsers can fill this field in for visitors with what they saved before, such as their name or address. Pick what the field asks for.', 'remaily' ) ],
		];
	}

	/**
	 * The autocomplete hints browsers know, for the sidebar: [ token => label ]
	 *
	 * @return array
	 */
	public static function autocomplete_options() {
		return [
			''                   => __( 'Let the browser guess', 'remaily' ),
			'off'                => __( 'Never fill in', 'remaily' ),
			'name'               => __( 'Full name', 'remaily' ),
			'given-name'         => __( 'First name', 'remaily' ),
			'family-name'        => __( 'Last name', 'remaily' ),
			'nickname'           => __( 'Nickname', 'remaily' ),
			'email'              => __( 'Email', 'remaily' ),
			'tel'                => __( 'Phone', 'remaily' ),
			'url'                => __( 'Website', 'remaily' ),
			'organization'       => __( 'Company', 'remaily' ),
			'organization-title' => __( 'Job title', 'remaily' ),
			'street-address'     => __( 'Street address', 'remaily' ),
			'address-line1'      => __( 'Address line 1', 'remaily' ),
			'address-line2'      => __( 'Address line 2', 'remaily' ),
			'address-level2'     => __( 'City', 'remaily' ),
			'address-level1'     => __( 'State or region', 'remaily' ),
			'postal-code'        => __( 'Postal code', 'remaily' ),
			'country-name'       => __( 'Country', 'remaily' ),
			'bday'               => __( 'Birthday', 'remaily' ),
			'sex'                => __( 'Gender', 'remaily' ),
			'language'           => __( 'Language', 'remaily' ),
			'username'           => __( 'Username', 'remaily' ),
			'one-time-code'      => __( 'One-time code', 'remaily' ),
		];
	}
}
