<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Payments\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A card payment through Stripe, in the form (Stripe's Payment Element)
 */
class StripeField extends Payment {
	public function type() {
		return 'stripe';
	}

	public function label() {
		return __( 'Stripe payment', 'remaily' );
	}

	public function summary() {
		return __( 'Visitors pay by card before the message goes', 'remaily' );
	}

	public function tip() {
		return __( 'Visitors pay by card before the message goes. Set the amount, or take it from a field such as a select of plans. Keys go in Settings → Payments.', 'remaily' );
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'pay_label' => __( 'Pay {amount}', 'remaily' ),
		];
	}

	protected function client( array $field ) {
		return [
			'data-key'   => (string) ( Payments::settings()['stripe']['key'] ?? '' ),
			'data-label' => $field['pay_label'],
		];
	}

	public function editor_schema() {
		return parent::editor_schema() + [
			'pay_label' => [ 'type' => 'text', 'label' => __( 'Pay button', 'remaily' ), 'help' => __( 'The button under the card fields. {amount} is replaced with the amount.', 'remaily' ) ],
		];
	}
}
