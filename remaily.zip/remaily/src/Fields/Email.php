<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * An email address
 */
class Email extends Text {
	public function type() {
		return 'email';
	}

	public function label() {
		return __( 'Email', 'remaily' );
	}

	public function tip() {
		return __( 'Checks that the address looks right. Put it in your mail\'s Reply-To ([your_email]) to answer with one click.', 'remaily' );
	}

	protected function input_type() {
		return 'email';
	}

	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? trim( sanitize_text_field( (string) $raw ) ) : '';
	}

	public function messages() {
		return [
			'invalid_email' => [ 'label' => __( 'Email address isn\'t valid', 'remaily' ), 'default' => __( 'Please enter a valid email address.', 'remaily' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return parent::validate( $value, $field, $submission ) ?: ( '' !== $value && !is_email( $value ) ? 'invalid_email' : '' );
	}
}
