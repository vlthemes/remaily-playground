<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A box to accept terms; required unless optional, or to be left clear when inverted
 */
class Acceptance extends Field {
	public function type() {
		return 'acceptance';
	}

	public function label() {
		return __( 'Acceptance', 'remaily' );
	}

	public function tip() {
		return __( 'A box visitors must tick to send, such as "I agree to the privacy policy".', 'remaily' );
	}

	protected function own_defaults() {
		return [
			'content'  => '',
			'optional' => false,
			'invert'   => false,
			'checked'  => false,
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		// Links are welcome in terms
		$clean['content']  = wp_kses( (string) ( $field['content'] ?? '' ), [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ], 'strong' => [], 'em' => [] ] );
		// Inverted, the box must be clear, so the browser can't ask for it
		$clean['required'] = !$clean['optional'] && !$clean['invert'];
		$clean['default']  = $clean['checked'] ? '1' : '';

		return $clean;
	}

	public function messages() {
		return [
			'accept_terms' => [ 'label' => __( 'Terms not accepted', 'remaily' ), 'default' => __( 'Please accept the terms to continue.', 'remaily' ) ],
		];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'type'    => 'checkbox',
			'value'   => '1',
			'checked' => '1' === (string) $ctx['value'],
		] );

		$input = '<input' . self::html_attributes( $attrs ) . '>';

		return '' === $field['content'] ? $input : '<label class="remaily-acceptance">' . $input . '<span class="remaily-acceptance__text">' . $field['content'] . '</span></label>';
	}

	// The script checks an inverted box itself
	public function wrapper_attributes( array $field ) {
		return [ 'data-remaily-invert' => $field['invert'] && !$field['optional'] ];
	}

	public function value( $raw, array $field ) {
		return is_scalar( $raw ) && '' !== (string) $raw ? '1' : '';
	}

	public function validate( $value, array $field, Submission $submission ) {
		if ( $field['optional'] ) {
			return '';
		}

		return ( '1' === $value ) === $field['invert'] ? 'accept_terms' : '';
	}

	public function mail_value( $value, array $field, $raw = false ) {
		if ( $raw || '1' !== $value ) {
			return (string) $value;
		}

		return '' !== $field['content'] ? wp_strip_all_tags( $field['content'] ) : __( 'Accepted', 'remaily' );
	}

	// Optional and Invert say whether it must be ticked
	public function shared() {
		return array_diff_key( parent::shared(), [ 'required' => true ] );
	}

	public function editor_schema() {
		return [
			'content'  => [ 'type' => 'textarea', 'label' => __( 'Text', 'remaily' ), 'help' => __( 'Printed next to the box. Links allowed.', 'remaily' ) ],
			'optional' => [ 'type' => 'toggle', 'label' => __( 'Optional', 'remaily' ), 'help' => __( 'Visitors can send the form without ticking the box, such as for a newsletter. Off: they must tick it.', 'remaily' ) ],
			'invert'   => [ 'type' => 'toggle', 'label' => __( 'Send only if left unticked', 'remaily' ), 'help' => __( 'For a box visitors must not tick, such as "I am under 16": the form goes only while it is clear.', 'remaily' ) ],
			'checked'  => [ 'type' => 'toggle', 'label' => __( 'Checked by default', 'remaily' ), 'help' => __( 'The box starts ticked.', 'remaily' ) ],
		];
	}
}
