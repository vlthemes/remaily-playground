<?php

namespace VLT\Remaily\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Several lines of text
 */
class Textarea extends Text {
	public function type() {
		return 'textarea';
	}

	public function label() {
		return __( 'Textarea', 'remaily' );
	}

	public function tip() {
		return __( 'Several lines, for the message. Add a Count from More to show how many characters are left.', 'remaily' );
	}

	public function kind() {
		return 'textarea';
	}

	protected function own_defaults() {
		return parent::own_defaults() + [ 'rows' => 6 ];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'rows'         => $field['rows'] ?: 6,
			'placeholder'  => $field['placeholder'],
			'autocomplete' => $field['autocomplete'],
		], $this->input_attributes( $field ) );

		return '<textarea' . self::html_attributes( $attrs ) . '>' . esc_textarea( is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '' ) . '</textarea>';
	}

	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? sanitize_textarea_field( (string) $raw ) : '';
	}

	public function editor_schema() {
		return [ 'rows' => [ 'type' => 'number', 'label' => __( 'Rows', 'remaily' ), 'help' => __( 'How tall the box is, in lines of text. Visitors can still write more.', 'remaily' ) ] ] + parent::editor_schema();
	}
}
