<?php

namespace VLT\Remaily\Fields;

use VLT\Remaily\Core\Countries;
use VLT\Remaily\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A telephone number, with an optional mask: a country's, one of its own, or the country visitors pick
 *
 * A mask is "+1 (###) ###-####": # is a digit, the digits before the first # are the country code. remaily.js formats
 * the number as visitors type; the server fits what was sent to the mask, so it works without JavaScript too. When
 * visitors pick the country, a flag at the start of the input opens the list (an invisible select over it), sent as
 * _remaily_country[name]; request_value() reads the number by that country's mask.
 */
class Tel extends Text {
	// Digits and the signs numbers are written with; the same pattern checks it in the browser (escaped for the v flag)
	const PATTERN = '[0-9\(\)#&+*=.\/ \-]{3,}';

	public function type() {
		return 'tel';
	}

	public function label() {
		return __( 'Tel', 'remaily' );
	}

	public function tip() {
		return __( 'A phone number. Phones open the number keypad for it. Pick a Mask and the number formats itself as visitors type, such as +1 (555) 012-3456.', 'remaily' );
	}

	protected function input_type() {
		return 'tel';
	}

	// A mask sets the length itself: min and max length only count without one
	protected function input_attributes( array $field ) {
		$attrs = parent::input_attributes( $field ) + [ 'pattern' => self::PATTERN ];

		return $this->masks( $field ) ? array_diff_key( $attrs, [ 'minlength' => 0, 'maxlength' => 0 ] ) : $attrs;
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'mask'              => '',
			'mask_custom'       => '',
			'countries'         => '',
			'countries_exclude' => '',
			'country'           => '',
			'flags'             => true,
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$known = [ '', 'custom', 'pick' ];

		if ( !in_array( $clean['mask'], $known, true ) && !isset( Countries::all()[ $clean['mask'] ] ) ) {
			$clean['mask'] = '';
		}

		$clean['countries']         = Countries::clean( $clean['countries'] );
		$clean['countries_exclude'] = Countries::clean( $clean['countries_exclude'] );
		$clean['country']           = isset( Countries::all()[ $clean['country'] ] ) ? $clean['country'] : '';

		return $clean;
	}

	/**
	 * A country's mask, with its code
	 *
	 * @param array $country Country
	 *
	 * @return string
	 */
	public static function country_mask( array $country ) {
		return '+' . $country['dial'] . ' ' . $country['mask'];
	}

	/**
	 * The masks a value may fit, by country code ('' for one of the field's own)
	 *
	 * @param array $field Field
	 *
	 * @return array [ code => [ 'mask', 'trunk' ] ]
	 */
	protected function masks( array $field ) {
		$countries = Countries::all();

		if ( 'custom' === $field['mask'] ) {
			return '' !== $field['mask_custom'] ? [ '' => [ 'mask' => $field['mask_custom'], 'trunk' => '' ] ] : [];
		}

		$codes = 'pick' === $field['mask'] ? Countries::codes( $field['countries'], $field['countries_exclude'] ) : ( isset( $countries[ $field['mask'] ] ) ? [ $field['mask'] ] : [] );
		$masks = [];

		// The country picked first is tried first: a number sent without its code (no JavaScript) is taken as its
		if ( in_array( $field['country'], $codes, true ) ) {
			$codes = array_unique( array_merge( [ $field['country'] ], $codes ) );
		}

		foreach ( $codes as $code ) {
			$masks[ $code ] = [ 'mask' => self::country_mask( $countries[ $code ] ), 'trunk' => $countries[ $code ]['trunk'] ];
		}

		/**
		 * The masks a Tel field's number may fit, the first one first: change a country's for one field, add or
		 * take away some. Every country at once: remaily_countries
		 *
		 *     add_filter( 'remaily_tel_masks', fn( $masks, $field ) => 'office_phone' === $field['name']
		 *         ? [ 'de' => [ 'mask' => '+49 (####) ######', 'trunk' => '0' ] ] + $masks : $masks, 10, 2 );
		 *
		 * @param array $masks [ country code => [ 'mask' => '+1 (###) ###-####', 'trunk' => '1' ] ] ('' for "My own")
		 * @param array $field Field
		 */
		$masks = (array) apply_filters( 'remaily_tel_masks', $masks, $field );

		$masks = array_filter( $masks, static fn( $mask ) => is_array( $mask ) && false !== strpos( (string) ( $mask['mask'] ?? '' ), '#' ) );

		return array_map( static fn( $mask ) => [ 'mask' => (string) $mask['mask'], 'trunk' => preg_replace( '/\D/', '', (string) ( $mask['trunk'] ?? '' ) ) ], $masks );
	}

	/**
	 * The national digits of a number: without the code the mask writes (or the visitor typed again), nor a trunk
	 * prefix; remaily.js's national() reads it the same way
	 *
	 * @param string $value Number
	 * @param string $mask  Mask
	 * @param string $trunk Trunk prefix visitors may type first
	 *
	 * @return string
	 */
	public static function national( $value, $mask, $trunk = '' ) {
		$sign  = self::sign( $mask );
		$code  = preg_replace( '/\D/', '', $sign );
		$slots = substr_count( $mask, '#' );
		$rest  = ltrim( (string) $value );

		if ( '' !== $sign && 0 === strpos( $rest, $sign ) ) {
			$rest = substr( $rest, strlen( $sign ) );
		}

		$digits = preg_replace( '/\D/', '', $rest );
		$typed  = preg_replace( '/[^\d+]/', '', $rest );

		// "+", "+7": the code typed again, nothing of the number yet
		if ( '' !== $code && 0 === strpos( $typed, '+' ) ) {
			$after = substr( $typed, 1 );

			if ( 0 === strpos( $code, $after ) ) {
				$digits = '';
			} elseif ( 0 === strpos( $after, $code ) ) {
				$digits = substr( $digits, strlen( $code ) );
			}
		}

		// The code without its +, or a trunk prefix, when there are more digits than the mask holds
		if ( '' !== $code && strlen( $digits ) > $slots && 0 === strpos( $digits, $code ) ) {
			$digits = substr( $digits, strlen( $code ) );
		}

		if ( '' !== $trunk && strlen( $digits ) > $slots && 0 === strpos( $digits, $trunk ) ) {
			$digits = substr( $digits, strlen( $trunk ) );
		}

		return (string) $digits;
	}

	/**
	 * The code a mask starts with, as written: "+1" of "+1 (###) ###-####"
	 *
	 * @param string $mask Mask
	 *
	 * @return string
	 */
	public static function sign( $mask ) {
		$lead = (string) strstr( $mask . '#', '#', true );
		$code = preg_replace( '/\D/', '', $lead );

		return '' !== $code ? substr( $lead, 0, strrpos( $lead, substr( $code, -1 ) ) + 1 ) : '';
	}

	/**
	 * A mask filled with digits, its signs only as far as the digits go; remaily.js's fill() does the same
	 *
	 * @param string $digits Digits
	 * @param string $mask   Mask
	 *
	 * @return string
	 */
	public static function fill( $digits, $mask ) {
		$out = '';
		$i   = 0;

		foreach ( preg_split( '//u', $mask, -1, PREG_SPLIT_NO_EMPTY ) as $char ) {
			if ( $i >= strlen( $digits ) ) {
				break;
			}

			$out .= '#' === $char ? $digits[ $i++ ] : $char;
		}

		return $out;
	}

	/**
	 * A number written to a mask, or null when its digits don't fit
	 *
	 * @param string $value Number
	 * @param string $mask  Mask
	 * @param string $trunk Trunk prefix
	 *
	 * @return string|null
	 */
	public static function fit( $value, $mask, $trunk = '' ) {
		$digits = self::national( $value, $mask, $trunk );
		$slots  = substr_count( $mask, '#' );

		return $slots && strlen( $digits ) === $slots ? self::fill( $digits, $mask ) : null;
	}

	public function control( array $field, array $ctx ) {
		$masks = $this->masks( $field );

		if ( !$masks ) {
			return parent::control( $field, $ctx );
		}

		$value = is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '';
		$pick  = 'pick' === $field['mask'];
		$code  = key( $masks );

		if ( $pick ) {
			// The country the number fits, else the one picked first (masks() puts it first)
			$fits = array_filter( $masks, static fn( $mask ) => '' !== $value && null !== self::fit( $value, $mask['mask'], $mask['trunk'] ) );
			$code = key( $fits ) ?: $code;
		}

		$mask = $masks[ $code ];

		if ( '' === $field['placeholder'] ) {
			$field['placeholder'] = str_replace( '#', '_', $mask['mask'] );
		}

		$input = str_replace( '<input', '<input data-remaily-mask="' . esc_attr( $mask['mask'] ) . '" data-remaily-trunk="' . esc_attr( $mask['trunk'] ) . '"', parent::control( $field, $ctx ) );

		if ( !$pick ) {
			return $input;
		}

		$countries = Countries::all();
		$options   = '';

		// In the order of the field's list, then any a filter added
		$order = array_intersect( array_unique( array_merge( Countries::codes( $field['countries'], $field['countries_exclude'] ), array_keys( $masks ) ) ), array_keys( $masks ) );

		foreach ( $order as $country ) {
			$mask     = $masks[ $country ];
			$dial     = preg_replace( '/\D/', '', self::sign( $mask['mask'] ) );
			$options .= sprintf(
				'<option value="%1$s" data-mask="%2$s" data-trunk="%3$s"%4$s>%5$s +%6$s</option>',
				esc_attr( $country ),
				esc_attr( $mask['mask'] ),
				esc_attr( $mask['trunk'] ),
				$country === $code ? ' selected' : '',
				esc_html( $countries[ $country ]['name'] ?? strtoupper( $country ) ),
				esc_html( $dial )
			);
		}

		// The list itself is invisible over the flag: the flag opens it, the input shows the code
		$select = sprintf(
			'<select class="remaily-tel__country" name="_remaily_country[%s]" aria-label="%s" data-remaily-country>%s</select>',
			esc_attr( $field['name'] ),
			esc_attr__( 'Country', 'remaily' ),
			$options
		);

		return Countries::flagged( $select . $input, $code, $field['flags'], 'remaily-tel' );
	}

	// The country picked and the number typed next to it, as one number with its code
	public function request_value( array $request, array $field ) {
		$masks  = 'pick' === $field['mask'] ? $this->masks( $field ) : [];
		$picked = (array) ( $request['_remaily_country'] ?? [] );
		$code   = sanitize_key( (string) ( $picked[ $field['name'] ] ?? '' ) );
		$raw    = $request[ $field['name'] ] ?? '';

		if ( !isset( $masks[ $code ] ) || !is_scalar( $raw ) ) {
			return parent::request_value( $request, $field );
		}

		$value = sanitize_text_field( (string) $raw );
		$fit   = self::fit( $value, $masks[ $code ]['mask'], $masks[ $code ]['trunk'] );

		if ( null !== $fit || '' === self::national( $value, $masks[ $code ]['mask'], $masks[ $code ]['trunk'] ) ) {
			return (string) $fit;
		}

		// Another country's number written in full (+44…), or a number too short for the one picked
		return false !== strpos( $value, '+' ) ? $this->value( $value, $field ) : $value;
	}

	public function messages() {
		return [
			'invalid_tel' => [ 'label' => __( 'Phone number isn\'t valid', 'remaily' ), 'default' => __( 'Please enter a valid phone number.', 'remaily' ) ],
		];
	}

	// A number that fits a mask is kept as the mask writes it; only its code is nothing
	public function value( $raw, array $field ) {
		$value = parent::value( $raw, $field );

		$masks = '' !== $value ? $this->masks( $field ) : [];

		foreach ( $masks as $mask ) {
			$fit = self::fit( $value, $mask['mask'], $mask['trunk'] );

			if ( null !== $fit ) {
				return $fit;
			}
		}

		// Only the code a mask writes ("+7 (", sent with Enter): nothing typed
		foreach ( $masks as $mask ) {
			if ( '' === self::national( $value, $mask['mask'], $mask['trunk'] ) ) {
				return '';
			}
		}

		return $value;
	}

	public function validate( $value, array $field, Submission $submission ) {
		$masks = $this->masks( $field );

		if ( $masks ) {
			$field['minlength'] = 0;
			$field['maxlength'] = 0;
		}

		$error = parent::validate( $value, $field, $submission );

		if ( $error || '' === $value ) {
			return $error;
		}

		if ( !preg_match( '/^' . self::PATTERN . '$/', $value ) ) {
			return 'invalid_tel';
		}

		foreach ( $masks as $mask ) {
			if ( self::fit( $value, $mask['mask'], $mask['trunk'] ) === $value ) {
				return '';
			}
		}

		return $masks ? 'invalid_tel' : '';
	}

	public function editor_schema() {
		$countries = [];

		foreach ( Countries::all() as $code => $country ) {
			$countries[ $code ] = $country['name'] . ' ' . self::country_mask( $country );
		}

		$schema = parent::editor_schema();

		// Without a mask only: a mask sets the length
		$schema['minlength']['when'] = [ 'mask' => [ '' ] ];
		$schema['maxlength']['when'] = [ 'mask' => [ '' ] ];

		// The mask first: it changes the placeholder and the length
		return [
			'mask'              => [
				'type'    => 'select',
				'label'   => __( 'Mask', 'remaily' ),
				'help'    => __( 'The number formats itself as visitors type and must be complete to send. Visitors pick the country: a list of countries in front of the number.', 'remaily' ),
				'options' => [
					''       => __( 'None', 'remaily' ),
					'pick'   => __( 'Visitors pick the country', 'remaily' ),
					'custom' => __( 'My own', 'remaily' ),
				] + $countries,
			],
			'mask_custom'       => [ 'type' => 'text', 'label' => __( 'Your mask', 'remaily' ), 'when' => [ 'mask' => [ 'custom' ] ], 'help' => __( 'Each # is a digit; the rest is written as it is. Digits before the first # are the country code, such as +1 (###) ###-####.', 'remaily' ) ],
			'countries'         => [ 'type' => 'countries', 'label' => __( 'Only these countries', 'remaily' ), 'when' => [ 'mask' => [ 'pick' ] ], 'help' => __( 'The list shows them in the order you pick them. None picked: every country.', 'remaily' ) ],
			'countries_exclude' => [ 'type' => 'countries', 'label' => __( 'Leave out', 'remaily' ), 'when' => [ 'mask' => [ 'pick' ] ], 'help' => __( 'Countries taken off the list. On their own: every country but these.', 'remaily' ) ],
			'country'           => [ 'type' => 'select', 'label' => __( 'Picked first', 'remaily' ), 'help' => __( 'The country already chosen when the page opens.', 'remaily' ), 'when' => [ 'mask' => [ 'pick' ] ], 'options' => [ '' => __( 'The first in the list', 'remaily' ) ] + array_map( static fn( $country ) => $country['name'], Countries::all() ) ],
			'flags'             => [ 'type' => 'toggle', 'label' => __( 'Flags', 'remaily' ), 'when' => [ 'mask' => [ 'pick' ] ], 'help' => __( 'The picked country\'s flag at the start of the number; it opens the list. Off: its letters, such as US. Windows shows the letters either way.', 'remaily' ) ],
		] + $schema;
	}
}
