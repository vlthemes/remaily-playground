<?php

namespace VLT\Remaily\Submission;

use VLT\Remaily\Core\Messages;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Form;
use VLT\Remaily\Forms\Repeater;
use VLT\Remaily\Mail\Mailer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One submission of a form: values, spam check, conditions, validation, mail
 *
 *     $result = ( new Submission( $form, $data, $files ) )->run();
 */
class Submission {
	/**
	 * Form
	 *
	 * @var Form
	 */
	private $form;

	/**
	 * Request data, unslashed
	 *
	 * @var array
	 */
	private $request;

	/**
	 * Uploaded files ($_FILES shape)
	 *
	 * @var array
	 */
	private $files;

	/**
	 * Where and by whom: ip, user_agent, url, post_id, user_id, time
	 *
	 * @var array
	 */
	private $meta;

	/**
	 * Clean values by field name
	 *
	 * @var array
	 */
	private $posted = [];

	/**
	 * Upload errors by field name (message keys)
	 *
	 * @var array
	 */
	private $upload_errors = [];

	/**
	 * Groups hidden by their conditions
	 *
	 * @var string[]
	 */
	private $hidden_groups = [];

	/**
	 * Errors by field name
	 *
	 * @var array
	 */
	private $invalid = [];

	/**
	 * success, invalid, failed, spam, aborted or payment
	 *
	 * @var string
	 */
	private $status = '';

	/**
	 * Message shown
	 *
	 * @var string
	 */
	private $message = '';

	/**
	 * Set by abort(): [ status, message ]
	 *
	 * @var array|null
	 */
	private $abort = null;

	/**
	 * What the reply carries besides the message (a payment to make)
	 *
	 * @var array
	 */
	private $data = [];

	/**
	 * Constructor
	 *
	 * @param Form  $form  Form
	 * @param array $data  Request data, unslashed
	 * @param array $files Uploaded files
	 * @param array $meta  What is known of the request
	 */
	public function __construct( Form $form, array $data, array $files = [], array $meta = [] ) {
		$this->form  = $form;
		$this->request = $data;
		$this->files   = $files;
		$this->meta  = $meta + [
			'ip'         => Visitor::ip(),
			'user_agent' => Visitor::agent(),
			'url'        => esc_url_raw( (string) wp_get_referer() ),
			'post_id'    => absint( $data['_remaily_post'] ?? 0 ),
			'user_id'    => get_current_user_id(),
			'time'       => time(),
			'utm'        => Visitor::utm( $data ),
		];
	}

	/**
	 * Run it
	 *
	 * @return array [ 'status', 'message', 'invalid' => [ name => message ], 'data', 'posted' ]
	 */
	public function run() {
		$settings = $this->form->config()['settings'];

		if ( !empty( $settings['subscribers_only'] ) && !is_user_logged_in() ) {
			return $this->finish( 'aborted', Messages::get( $this->form, 'login_required' ) );
		}

		$closed = $this->form->closed();

		if ( '' !== $closed ) {
			return $this->finish( 'aborted', $closed );
		}

		$this->read();

		if ( !apply_filters( 'remaily_skip_spam_check', false, $this ) && apply_filters( 'remaily_spam', false, $this ) ) {
			return $this->finish( 'spam' );
		}

		$this->hidden_groups = Conditions::hidden_groups( $this->form, $this->posted );

		// A hidden field sends nothing
		foreach ( Conditions::hidden_fields( $this->form, $this->hidden_groups ) as $name ) {
			if ( array_key_exists( $name, $this->posted ) ) {
				Uploads::delete( $this->files( $name ) );
				$this->posted[ $name ] = is_array( $this->posted[ $name ] ) ? [] : '';
				$this->upload_errors   = array_filter( $this->upload_errors, static fn( $key ) => $key !== $name && false === strpos( $key, '][' . $name . ']' ), ARRAY_FILTER_USE_KEY );
			}
		}

		// What is worked out from the values (calculations), from the ones that are sent
		$this->posted = Conditions::values( $this->form, $this->posted, $this->hidden_groups );

		$this->invalid = Validator::validate( $this );

		if ( $this->invalid ) {
			return $this->finish( 'invalid' );
		}

		// Test mode: all checked, nothing sent or saved
		if ( $this->is_demo() ) {
			return $this->finish( 'success' );
		}

		do_action_ref_array( 'remaily_before_send_mail', [ $this ] );

		if ( null !== $this->abort ) {
			return $this->finish( $this->abort[0], $this->abort[1] );
		}

		$sent = Mailer::send_all( $this );

		if ( $sent ) {
			do_action( 'remaily_mail_sent', $this );
		} else {
			do_action( 'remaily_mail_failed', $this );
		}

		return $this->finish( $sent ? 'success' : 'failed' );
	}

	/**
	 * Read the values of the fields placed in the form
	 */
	private function read() {
		$repeaters = Repeater::all( $this->form );
		$repeated  = array_merge( [], ...array_values( array_column( $repeaters, 'fields' ) ) );

		foreach ( $this->form->fields() as $name => $field ) {
			if ( !in_array( $name, $repeated, true ) ) {
				$this->read_field( $field, $this->request, $this->files[ $name ] ?? null );
			}
		}

		// A repeated field's values by row: [ row => value ]
		foreach ( $repeaters as $group => $repeater ) {
			$rows = Repeater::rows( $this->request, $group, $repeater );

			foreach ( $repeater['fields'] as $name ) {
				$field = $this->form->field( $name );

				if ( !$field ) {
					continue;
				}

				$this->posted[ $name ] = [];

				foreach ( $rows as $row ) {
					$key     = Repeater::name( $group, $row, $name );
					$request = Repeater::row_request( $this->request, $group, $row, $repeater['fields'] );
					$value   = $this->read_field( [ 'name' => $key ] + $field, $request, Repeater::row_upload( $this->files, $group, $row, $name ) );

					if ( null !== $value ) {
						$this->posted[ $name ][ $row ] = $value;
						unset( $this->posted[ $key ] );
					}
				}
			}
		}

		$this->posted = (array) apply_filters( 'remaily_posted_data', $this->posted, $this );
	}

	/**
	 * Read one field's value into posted, under its control's name
	 *
	 * @param array      $field   Field
	 * @param array      $request Request data
	 * @param array|null $upload  Its upload
	 *
	 * @return mixed|null The value; null for a field that sends nothing
	 */
	private function read_field( array $field, array $request, $upload ) {
		$type = FieldRegistry::get( $field['type'] );
		$name = $field['name'];

		if ( !$type || !$type->submits() ) {
			return null;
		}

		if ( 'file' === $field['type'] ) {
			[ $files, $error ] = Uploads::receive( $upload, $field );

			if ( $error ) {
				$this->upload_errors[ $name ] = $error;
			}

			return $this->posted[ $name ] = $files;
		}

		return $this->posted[ $name ] = $type->request_value( $request, $field );
	}

	/**
	 * End with a status
	 *
	 * @param string $status  Status
	 * @param string $message Message ('' = the form's for the status)
	 *
	 * @return array
	 */
	private function finish( $status, $message = '' ) {
		$this->status  = $status;
		$this->message = '' !== $message ? $message : Messages::get( $this->form, 'aborted' === $status ? 'failed' : $status );

		do_action( 'remaily_submitted', $this );

		// Files go once mailed, unless something (entries) keeps them
		if ( !apply_filters( 'remaily_keep_uploads', false, $this ) ) {
			foreach ( array_keys( $this->form->fields() ) as $name ) {
				Uploads::delete( $this->files( $name ) );
			}
		}

		return [
			'status'  => $this->status,
			'message' => $this->message,
			'invalid' => $this->invalid,
			'data'    => $this->data,
			'posted'  => array_filter( $this->posted, fn( $name ) => 'file' !== ( $this->form->field( $name )['type'] ?? '' ), ARRAY_FILTER_USE_KEY ),
		];
	}

	/**
	 * Whether the form is in test mode: checked, never sent or saved
	 *
	 * @return bool
	 */
	public function is_demo() {
		return !empty( $this->form->config()['settings']['demo'] ) || ( defined( 'REMAILY_TEST_MODE' ) && REMAILY_TEST_MODE );
	}

	/**
	 * Stop before the mail (from remaily_before_send_mail)
	 *
	 * @param string $message Message shown ('' = the form's "failed" one)
	 * @param string $status  Status of the reply (payment: the visitor pays, then sends again)
	 * @param array  $data    What the reply carries for the script
	 */
	public function abort( $message = '', $status = 'aborted', array $data = [] ) {
		$this->abort = [ (string) $status, (string) $message ];
		$this->data  = $data;
	}

	/**
	 * Whether something stopped the submission before the mail
	 *
	 * @return bool
	 */
	public function aborted() {
		return null !== $this->abort;
	}

	/**
	 * Form
	 *
	 * @return Form
	 */
	public function form() {
		return $this->form;
	}

	/**
	 * Clean values, or one
	 *
	 * @param string|null $name Field name
	 *
	 * @return mixed
	 */
	public function posted( $name = null ) {
		return null === $name ? $this->posted : ( $this->posted[ $name ] ?? '' );
	}

	/**
	 * A file field's files, of every row when it repeats
	 *
	 * @param string $name Field name
	 *
	 * @return array [ [ 'name', 'path', 'size', 'type' ], … ]
	 */
	public function files( $name ) {
		if ( 'file' !== ( $this->form->field( $name )['type'] ?? '' ) || empty( $this->posted[ $name ] ) ) {
			return [];
		}

		$files = (array) $this->posted[ $name ];

		return Repeater::of( $this->form, $name ) ? array_merge( [], ...array_values( array_map( 'array_values', array_filter( $files, 'is_array' ) ) ) ) : $files;
	}

	/**
	 * A field's value as text, as [name] prints it: a repeated field's rows joined with commas
	 *
	 * @param string $name Field name
	 * @param bool   $raw  Option values, not labels
	 *
	 * @return string
	 */
	public function text( $name, $raw = false ) {
		$field = $this->form->field( $name );
		$type  = $field ? FieldRegistry::get( $field['type'] ) : null;

		if ( !$type ) {
			return '';
		}

		if ( !Repeater::of( $this->form, $name ) ) {
			return $type->mail_value( $this->posted( $name ), $field, $raw );
		}

		$texts = array_map( static fn( $value ) => $type->mail_value( $value, $field, $raw ), (array) $this->posted( $name ) );

		return implode( ', ', array_filter( $texts, static fn( $text ) => '' !== $text ) );
	}

	/**
	 * A repeated group's rows as text: [ [ field => text ], … ]
	 *
	 * @param string $group Group
	 * @param bool   $raw   Option values, not labels
	 *
	 * @return array
	 */
	public function rows( $group, $raw = false ) {
		$repeater = Repeater::all( $this->form )[ $group ] ?? null;

		return $repeater && !in_array( $group, $this->hidden_groups, true ) ? Repeater::texts( $this->form, $repeater, $this->posted, $raw ) : [];
	}

	/**
	 * Change a value (from remaily_before_send_mail)
	 *
	 * @param string $name  Field name
	 * @param mixed  $value Value
	 */
	public function set( $name, $value ) {
		$this->posted[ $name ] = $value;
	}

	/**
	 * A raw request value (unslashed)
	 *
	 * @param string $key Key
	 *
	 * @return mixed
	 */
	public function raw( $key ) {
		return $this->request[ $key ] ?? null;
	}

	/**
	 * What is known of the request, or one part
	 *
	 * @param string|null $key ip, user_agent, url, post_id, user_id, time
	 *
	 * @return mixed
	 */
	public function meta( $key = null ) {
		return null === $key ? $this->meta : ( $this->meta[ $key ] ?? '' );
	}

	/**
	 * Upload error of a field
	 *
	 * @param string $name Field name
	 *
	 * @return string Message key
	 */
	public function upload_error( $name ) {
		return $this->upload_errors[ $name ] ?? '';
	}

	/**
	 * Groups hidden by their conditions
	 *
	 * @return string[]
	 */
	public function hidden_groups() {
		return $this->hidden_groups;
	}

	/**
	 * Status
	 *
	 * @return string
	 */
	public function status() {
		return $this->status;
	}

	/**
	 * Message
	 *
	 * @return string
	 */
	public function message() {
		return $this->message;
	}

	/**
	 * Errors by field name
	 *
	 * @return array
	 */
	public function invalid() {
		return $this->invalid;
	}

}
