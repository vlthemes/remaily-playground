<?php

namespace VLT\Remaily\Submission;

use VLT\Remaily\Core\Messages;
use VLT\Remaily\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks a submission's values: each type's rules, then remaily_validate_{type} and remaily_validate
 */
class Validator {
	/**
	 * Errors of a submission
	 *
	 * @param Submission $submission Submission
	 *
	 * @return array [ name => message ]
	 */
	public static function validate( Submission $submission ) {
		$form   = $submission->form();
		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$errors = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( !$type || !$type->submits() || in_array( $name, $hidden, true ) ) {
				continue;
			}

			$value   = $submission->posted( $name );
			$key     = $type->validate( $value, $field, $submission );
			$message = (string) apply_filters( 'remaily_validate_' . $field['type'], $key ? Messages::get( $form, $key ) : '', $value, $field, $submission );

			if ( '' !== $message ) {
				$errors[ $name ] = $message;
			}
		}

		return (array) apply_filters( 'remaily_validate', $errors, $submission );
	}
}
