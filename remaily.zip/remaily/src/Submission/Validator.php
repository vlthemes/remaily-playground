<?php

namespace VLT\Remaily\Submission;

use VLT\Remaily\Core\Messages;
use VLT\Remaily\Fields\FieldRegistry;
use VLT\Remaily\Forms\Repeater;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks a submission's values: each type's rules, then remaily_validate_{type} and remaily_validate
 */
class Validator {
	/**
	 * Errors of a submission
	 *
	 * @param Submission $submission Submission
	 *
	 * @return array [ name => message ]
	 */
	public static function validate( Submission $submission ) {
		$form   = $submission->form();
		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$errors = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( !$type || !$type->submits() || in_array( $name, $hidden, true ) ) {
				continue;
			}

			$group = Repeater::of( $form, $name );

			// A repeated field is checked in each row, its error under the row control's name (rows[0][phone])
			$checks = $group ? array_map( static fn( $row ) => Repeater::name( $group, $row, $name ), array_keys( (array) $submission->posted( $name ) ) ) : [ $name ];
			$values = $group ? array_values( (array) $submission->posted( $name ) ) : [ $submission->posted( $name ) ];

			foreach ( $checks as $i => $key ) {
				$one     = [ 'name' => $key ] + $field;
				$problem = $type->validate( $values[ $i ], $one, $submission );
				$message = (string) apply_filters( 'remaily_validate_' . $field['type'], $problem ? Messages::get( $form, $problem ) : '', $values[ $i ], $one, $submission );

				if ( '' !== $message ) {
					$errors[ $key ] = $message;
				}
			}
		}

		return (array) apply_filters( 'remaily_validate', $errors, $submission );
	}
}
