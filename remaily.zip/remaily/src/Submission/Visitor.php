<?php

namespace VLT\Remaily\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who sent a message and where from: their IP address, browser and the campaign that brought them (UTM tags)
 */
class Visitor {
	/**
	 * The visit's campaign tags: from utm.js, or from the page's address when the form was sent without it
	 *
	 * @param array $data Request data
	 *
	 * @return array [ utm_source => value, … ]
	 */
	public static function utm( array $data ) {
		$posted = json_decode( (string) ( $data['_remaily_utm'] ?? '' ), true );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read only, to note where the visit came from
		$source = is_array( $posted ) && $posted ? $posted : wp_unslash( $_GET );
		$utm    = [];

		/**
		 * The campaign tags kept with a message
		 *
		 * @param string[] $keys Query keys
		 */
		foreach ( (array) apply_filters( 'remaily_utm_keys', [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'yclid' ] ) as $key ) {
			if ( isset( $source[ $key ] ) && is_scalar( $source[ $key ] ) && '' !== trim( (string) $source[ $key ] ) ) {
				$utm[ $key ] = substr( sanitize_text_field( (string) $source[ $key ] ), 0, 200 );
			}
		}

		return $utm;
	}

	/**
	 * The visitor's IP address
	 *
	 * @return string
	 */
	public static function ip() {
		$ip     = self::server( 'REMOTE_ADDR' );
		$ip     = filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
		$server = self::server( 'SERVER_ADDR' );
		$public = static fn( $address ) => $address !== $server && filter_var( $address, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );

		// A proxy on this server or the private network (nginx, Varnish, a load balancer) sends every request: the
		// visitor is the last public address it forwarded. Headers from anywhere else could be made up, so they're not read.
		if ( '' !== $ip && !$public( $ip ) ) {
			$forwarded   = array_reverse( array_map( 'trim', explode( ',', self::server( 'HTTP_X_FORWARDED_FOR' ) ) ) );
			$forwarded[] = self::server( 'HTTP_X_REAL_IP' );

			foreach ( $forwarded as $address ) {
				if ( $public( $address ) ) {
					$ip = $address;
					break;
				}
			}
		}

		// A fix a site made for CF7 keeps working after the move
		$ip = (string) apply_filters( 'wpcf7_remote_ip_addr', $ip ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- CF7's own filter

		/**
		 * The visitor's IP address, for a proxy Remaily doesn't recognize (Cloudflare: its CF-Connecting-IP header)
		 *
		 * @param string $ip IP address
		 */
		return (string) apply_filters( 'remaily_remote_ip', $ip );
	}

	/**
	 * A $_SERVER value, sanitized
	 *
	 * @param string $key Key
	 *
	 * @return string
	 */
	private static function server( $key ) {
		return isset( $_SERVER[ $key ] ) ? sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) : '';
	}
	/**
	 * The visitor's browser, as it names itself
	 *
	 * @return string
	 */
	public static function agent() {
		return substr( self::server( 'HTTP_USER_AGENT' ), 0, 255 );
	}
}
