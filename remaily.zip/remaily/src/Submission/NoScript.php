<?php

namespace VLT\Remaily\Submission;

use VLT\Remaily\Forms\Form;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form sent without the script: the page itself receives it, then redirects back to show the result (POST,
 * redirect, GET), so reloading doesn't send it twice
 */
class NoScript {
	const QUERY_VAR = 'remaily-result';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'handle' ], 1 );
	}

	/**
	 * Receive a form posted to a page
	 */
	public static function handle() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- a public form, like its REST route
		if ( !isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] || empty( $_POST['_remaily_form'] ) ) {
			return;
		}

		$form = Form::get( absint( $_POST['_remaily_form'] ) );

		if ( !$form || 'publish' !== get_post_status( $form->id() ) ) {
			return;
		}

		$data   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field cleans its own value
		$uid    = sanitize_html_class( (string) ( $data['_remaily_uid'] ?? '' ) );
		$result = ( new Submission( $form, $data, $_FILES ) )->run();
		// phpcs:enable

		$redirect = $form->config()['settings']['redirect'];

		if ( 'success' === $result['status'] && $redirect ) {
			wp_redirect( $redirect ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- set by the form's editor
			exit;
		}

		$token = wp_generate_password( 16, false );

		set_transient( 'remaily_result_' . $token, [
			'form'    => $form->id(),
			'uid'     => $uid,
			'status'  => $result['status'],
			'message' => $result['message'],
			'invalid' => $result['invalid'],
			// A sent form starts empty again
			'posted'  => 'success' === $result['status'] ? [] : $result['posted'],
		], 10 * MINUTE_IN_SECONDS );

		$back = remove_query_arg( self::QUERY_VAR, wp_get_referer() ?: home_url( '/' ) );

		wp_safe_redirect( add_query_arg( self::QUERY_VAR, $token, $back ) . '#' . $uid, 303 );
		exit;
	}

	/**
	 * The result this page shows for a form, if any
	 *
	 * @param int    $form_id Form ID
	 * @param string $uid     The form's HTML ID on the page
	 *
	 * @return array|null
	 */
	public static function result( $form_id, $uid ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a token, read only
		$token = isset( $_GET[ self::QUERY_VAR ] ) ? preg_replace( '/[^a-zA-Z0-9]/', '', sanitize_text_field( wp_unslash( $_GET[ self::QUERY_VAR ] ) ) ) : '';
		$saved = $token ? get_transient( 'remaily_result_' . $token ) : false;

		return is_array( $saved ) && (int) $saved['form'] === (int) $form_id && $saved['uid'] === $uid ? $saved : null;
	}
}
