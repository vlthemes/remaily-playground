/**
 * Numbers and countries: Tel masks ("+1 (###) ###-####") that format as visitors type, the country list in front of a
 * number, and the flag of a country list. The server fits what was sent the same way (Fields\Tel)
 */
// Tel masks ("+1 (###) ###-####"), as Tel::fit(): the national digits of a number (without its code or a
// trunk prefix), then the mask filled with them, its signs only as far as the digits go
// The code a mask starts with, as written: "+1" of "+1 (###) ###-####" (Tel::sign())
const signOf = (mask) => {
	const lead = mask.split('#')[0];
	const code = lead.replace(/\D/g, '');

	return code ? lead.slice(0, lead.lastIndexOf(code.slice(-1)) + 1) : '';
};

export const national = (value, mask, trunk) => {
	const sign = signOf(mask);
	const code = sign.replace(/\D/g, '');
	const slots = mask.split('#').length - 1;
	let rest = value.trimStart();

	// The code the mask writes, then the same code typed again with its + ("+7 (+7 812")
	if (sign && rest.startsWith(sign)) {
		rest = rest.slice(sign.length);
	}

	let digits = rest.replace(/\D/g, '');
	const typed = rest.replace(/[^\d+]/g, '');

	// "+", "+7": the code being typed, nothing of the number yet
	if (code && typed.startsWith('+')) {
		digits = code.startsWith(typed.slice(1)) ? '' : typed.slice(1).startsWith(code) ? digits.slice(code.length) : digits;
	}

	// The code without its +, or a trunk prefix: told once the number runs over
	if (code && digits.length > slots && digits.startsWith(code)) {
		digits = digits.slice(code.length);
	}

	if (trunk && digits.length > slots && digits.startsWith(trunk)) {
		digits = digits.slice(trunk.length);
	}

	return digits.slice(0, slots);
};

// at[n]: where the caret goes after the n-th digit
export const fill = (digits, mask) => {
	const at = [Math.max(0, mask.indexOf('#'))];
	let out = '';
	let i = 0;

	for (const char of mask) {
		if (i >= digits.length) {
			break;
		}

		out += char === '#' ? digits[i++] : char;

		if (char === '#') {
			at.push(out.length);
		}
	}

	return { out, at };
};

// The browser's check of a complete number (pattern uses the v flag: only syntax characters are escaped)
export const maskPattern = (mask) => mask.replace(/[\^$\\.*+?()[\]{}|/]/g, '\\$&').split('#').join('[0-9]');

/**
 * A form's masks, country lists and flags; prepare( part ) sets up a part added later (a repeated row)
 *
 * @return {{ prepare: Function, flagged: Function }}
 */
export const setupTel = (form) => {
	// The mask's start ("+7 ("): shown while the empty number has the focus, so its code isn't typed again
	const lead = (el) => el.dataset.remailyMask.split('#')[0];

	// A masked number formats itself; Backspace over a sign takes the digit before it
	const masked = (el, event) => {
		const trunk = el.dataset.remailyTrunk || '';
		const caret = el.selectionEnd ?? el.value.length;
		const end = caret >= el.value.length;
		const focused = document.activeElement === el;
		let digits = national(el.value, el.dataset.remailyMask, trunk);
		let n = Math.min(national(el.value.slice(0, caret), el.dataset.remailyMask, trunk).length, digits.length);

		if (event?.inputType === 'deleteContentBackward' && digits === el.remailyDigits && n > 0) {
			digits = digits.slice(0, n - 1) + digits.slice(n);
			n--;
		}

		// The visitor typing the code again ("+7 (+7"): left as it is until the number starts
		if (!digits && focused && el.value.lastIndexOf('+') > 0) {
			el.remailyDigits = digits;

			return;
		}

		const { out, at } = fill(digits, el.dataset.remailyMask);

		el.value = out || (focused ? lead(el) : '');
		el.remailyDigits = digits;

		if (focused && (!end || !out)) {
			const to = out ? at[n] : el.value.length;

			el.setSelectionRange(to, to);
		}
	};

	// The country list in front of a number: its mask, the digits typed kept
	const country = (select) => {
		const el = select.parentElement.querySelector('[data-remaily-mask]');
		const option = select.selectedOptions[0];

		if (!el || !option) {
			return;
		}

		const digits = national(el.value, el.dataset.remailyMask, el.dataset.remailyTrunk || '');

		if (el.placeholder === el.dataset.remailyMask.split('#').join('_')) {
			el.placeholder = option.dataset.mask.split('#').join('_');
		}

		el.dataset.remailyMask = option.dataset.mask;
		el.dataset.remailyTrunk = option.dataset.trunk || '';
		el.pattern = maskPattern(option.dataset.mask);
		el.value = fill(digits, option.dataset.mask).out;
		el.remailyDigits = digits;
	};

	// Masks and country flags of the controls in a part of the form: all of it, then each new repeated row
	const prepare = (scope) => {
		scope.querySelectorAll('[data-remaily-mask]').forEach((el) => {
			el.pattern = maskPattern(el.dataset.remailyMask);
			masked(el);
		});

		scope.querySelectorAll('.remaily-country').forEach((wrap) => {
			const select = wrap.querySelector('select');

			// The flag and name go where the list's own text would, whatever the theme's padding
			if (select) {
				wrap.style.setProperty('--remaily-flag-start', getComputedStyle(select).paddingInlineStart);
			}

			wrap.classList.add('is-ready');
		});
	};

	form.addEventListener('input', (event) => event.target.dataset?.remailyMask && masked(event.target, event));
	form.addEventListener('focusin', (event) => {
		const el = event.target;

		// After the click has placed the caret: at the end of the code
		if (el.dataset?.remailyMask && !el.value && lead(el)) {
			el.value = lead(el);
			setTimeout(() => el.setSelectionRange(el.value.length, el.value.length));
		}
	});
	form.addEventListener('focusout', (event) => event.target.dataset?.remailyMask && masked(event.target));
	form.addEventListener('change', (event) => event.target.matches?.('[data-remaily-country]') && country(event.target));

	// The flag inside a country list (Countries::flagged()), and a Country field's name, follow the country picked
	const flagged = (select) => {
		const wrap = select.parentElement;
		const mark = wrap?.querySelector(':scope > .remaily-flag [data-remaily-flag]');
		const name = wrap?.querySelector(':scope > .remaily-flag [data-remaily-flag-name]');
		const code = select.value;

		if (mark) {
			mark.textContent = !/^[a-z]{2}$/i.test(code) ? '' : 'letters' in mark.dataset ? code.toUpperCase() : String.fromCodePoint(...[...code.toUpperCase()].map((char) => 127397 + char.charCodeAt(0)));
		}

		if (name) {
			name.textContent = (select.selectedOptions[0]?.textContent || '').replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').trim();
		}
	};

	form.addEventListener('change', (event) => event.target.tagName === 'SELECT' && flagged(event.target));
	prepare(form);

	return { prepare, flagged };
};
