/**
 * The rules of a group's conditions: the same as Submission\Conditions on the server
 */
export const isEmpty = (value) => (Array.isArray(value) ? !value.some((item) => String(item) !== '') : String(value).trim() === '');
const isNumber = (value) => !Array.isArray(value) && String(value).trim() !== '' && !Number.isNaN(Number(value));

export const rule = (r, value) => {
	const target = String(r.value ?? '');

	switch (r.op) {
		case 'is':
			return Array.isArray(value) ? value.map(String).includes(target) : String(value) === target;
		case 'is_not':
			return !rule({ ...r, op: 'is' }, value);
		case 'contains':
			return Array.isArray(value) ? value.map(String).includes(target) : String(value).toLowerCase().includes(target.toLowerCase());
		case 'not_contains':
			return !rule({ ...r, op: 'contains' }, value);
		case 'empty':
			return isEmpty(value);
		case 'not_empty':
			return !isEmpty(value);
		case 'gt':
			return isNumber(value) && isNumber(target) && Number(value) > Number(target);
		case 'lt':
			return isNumber(value) && isNumber(target) && Number(value) < Number(target);
	}

	return false;
};

export const matches = (group, values) => {
	const results = group.rules.map((r) => rule(r, values[r.field] ?? ''));

	return group.match === 'any' ? results.includes(true) : !results.includes(false);
};
