/**
 * A script loaded once, whoever asks for it: a captcha's, or the payment script a reply names
 */
const scripts = {};
export const load = (src) =>
	(scripts[src] ||= new Promise((resolve, reject) => {
		const script = document.createElement('script');

		script.src = src;
		script.onload = resolve;
		script.onerror = reject;
		document.head.append(script);
	}));
