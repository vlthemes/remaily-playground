/**
 * The visit's campaign tags (utm_source…, gclid…), from the page it landed on, kept for the visit; a new campaign
 * in the address replaces them. Sent with each form as _remaily_utm (Submission\Visitor::utm())
 */
export const utm = (() => {
	const keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'yclid'];
	const query = new URLSearchParams(window.location.search);
	const fresh = Object.fromEntries(keys.filter((key) => query.get(key)).map((key) => [key, query.get(key)]));
	let kept = {};

	try {
		kept = JSON.parse(sessionStorage.getItem('remaily-utm') || '{}');

		if (Object.keys(fresh).length) {
			sessionStorage.setItem('remaily-utm', JSON.stringify(fresh));
		}
	} catch {}

	return Object.keys(fresh).length ? fresh : kept;
})();
