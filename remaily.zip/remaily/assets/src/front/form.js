/**
 * One form on the page: reads its fields, shows and hides its groups, keeps its outputs and counts up to date,
 * checks it and sends it without a reload
 */
import { resetCaptchas, setupSmartCaptcha } from './captcha.js';
import { load } from './load.js';
import { setupRepeaters } from './repeater.js';
import { matches } from './rules.js';
import { national, setupTel } from './tel.js';
import { utm } from './utm.js';

const data = window.remailyData || {};
const STATUSES = ['sending', 'success', 'invalid', 'failed', 'spam', 'aborted', 'payment'];
const tokens = (el, attr) => (el.getAttribute(attr) || '').split(/\s+/).filter(Boolean);

export function init(root, { beforeSend, checks, derived }) {
	const form = root.querySelector('form[data-remaily]');

	if (!form || form.remailyReady) {
		return;
	}

	form.remailyReady = true;

	const config = JSON.parse(root.dataset.remailyConfig || '{}');
	const utmInput = form.querySelector('input[name="_remaily_utm"]');

	if (utmInput && Object.keys(utm).length) {
		utmInput.value = JSON.stringify(utm);
	}
	const messages = config.messages || {};
	const groups = config.groups || {};
	const box = form.querySelector('[data-remaily-response]');
	let tried = false;

	const wrappers = () => [...form.querySelectorAll('[data-remaily-field]')];
	const wrapper = (name) => form.querySelector(`[data-remaily-field="${CSS.escape(name)}"]`);
	// A field's own name: a repeated row's control is named rows[0][phone], its field phone
	const nameOf = (wrap) => wrap.dataset.remailyName || wrap.dataset.remailyField;
	const controls = (wrap) => [...wrap.querySelectorAll('input, select, textarea')].filter((el) => el.name && !el.name.startsWith('_remaily'));
	const groupsOf = (el) => {
		const names = [];

		for (let group = el.parentElement?.closest('[data-remaily-group]'); group; group = group.parentElement?.closest('[data-remaily-group]')) {
			names.push(group.dataset.remailyGroup);
		}

		return names;
	};

	// A field's value: a list for checkboxes and multiple selects; labels instead of values when asked
	const read = (wrap, labels = false) => {
		const els = controls(wrap);
		const picked = [];
		const multiple = wrap.dataset.remailyType === 'checkbox' || els.some((el) => el.multiple && el.tagName === 'SELECT');

		els.forEach((el) => {
			if (el.type === 'checkbox' || el.type === 'radio') {
				if (el.checked) {
					picked.push(labels ? el.closest('.remaily-choice')?.querySelector('.remaily-choice__label')?.textContent ?? el.value : el.value);
				}
			} else if (el.tagName === 'SELECT') {
				[...el.selectedOptions].filter((option) => option.value !== '').forEach((option) => picked.push(labels ? option.textContent : option.value));
			} else if (el.type === 'file') {
				picked.push([...el.files].map((file) => file.name).join(', '));
			} else {
				picked.push(el.value);
			}
		});

		return multiple ? picked : (picked[0] ?? '');
	};

	const conditions = () => {
		const values = {};
		const parents = {};

		// A repeated field's rows count as one list of values, as on the server
		wrappers().forEach((wrap) => {
			const name = nameOf(wrap);

			if (wrap.dataset.remailyName) {
				values[name] = [...(values[name] || []), ...[read(wrap)].flat()];
			} else {
				values[name] = read(wrap);
			}

			parents[name] = groupsOf(wrap);
		});

		let hidden = [];

		// A rule may read a field another group hides: settle in a few passes
		for (let pass = 0; pass < 3; pass++) {
			let visible = { ...values };

			Object.keys(visible).forEach((name) => {
				if (parents[name].some((group) => hidden.includes(group))) {
					visible[name] = Array.isArray(visible[name]) ? [] : '';
				}
			});

			// Values worked out from the others (an add-on's calculations), as remaily_values on the server
			derived.forEach((fn) => (visible = fn(visible, form, hidden) || visible));

			const next = [];

			Object.entries(groups).forEach(([name, group]) => {
				if ((group.parents || []).some((parent) => next.includes(parent))) {
					next.push(name);
				} else if (group.rules?.length && (group.action === 'show') !== matches(group, visible)) {
					next.push(name);
				}
			});

			if (next.join() === hidden.join()) {
				break;
			}

			hidden = next;
		}

		form.querySelectorAll('[data-remaily-group]').forEach((el) => {
			const hide = hidden.includes(el.dataset.remailyGroup);

			if (el.hidden !== hide) {
				el.hidden = hide;
				el.inert = hide;

				if (hide) {
					el.querySelectorAll('[data-remaily-field]').forEach((wrap) => setError(wrap, ''));
				}
			}
		});
	};

	const outputs = () => {
		form.querySelectorAll('[data-remaily-output]').forEach((out) => {
			const name = out.dataset.remailyOutput;
			// A repeated field: what each row has, joined
			const wraps = wrappers().filter((wrap) => nameOf(wrap) === name && !wrap.closest('[data-remaily-group][hidden]'));
			const text = wraps
				.map((wrap) => read(wrap, true))
				.map((value) => (Array.isArray(value) ? value.join(', ') : String(value)))
				.filter((value, i, all) => value !== '' || all.length === 1)
				.join(', ');

			out.textContent = text === '' ? out.dataset.empty || '' : (out.dataset.format || '{value}').split('{value}').join(text);
		});

		// Characters as Count::text() counts them (code points, as mb_strlen)
		form.querySelectorAll('[data-remaily-count]').forEach((out) => {
			const el = wrapper(out.dataset.remailyCount)?.querySelector('input, textarea');
			const count = el ? [...el.value].length : 0;
			const max = Number(out.dataset.max || 0);
			const min = Number(out.dataset.min || 0);
			const values = { '{count}': count, '{left}': max ? max - count : '', '{max}': max || '' };

			out.textContent = (out.dataset.format || '{count}').replace(/\{(count|left|max)\}/g, (token) => values[token]);
			out.style.setProperty('--remaily-count', count);
			out.style.setProperty('--remaily-max', max);
			out.classList.toggle('is-over', Boolean(max) && count > max);
			out.classList.toggle('is-under', Boolean(min) && count > 0 && count < min);
		});

		// [[name:count]] and [[name:left]] in the text (Text::own_info()), counted the same way
		form.querySelectorAll('[data-remaily-live]').forEach((out) => {
			const [name, key] = out.dataset.remailyLive.split(':');
			const el = wrapper(name)?.querySelector('input, textarea');
			const count = el ? [...el.value].length : 0;
			const max = Number(out.dataset.max || 0);
			const min = Number(out.dataset.min || 0);

			out.textContent = key === 'left' ? (max ? max - count : '') : count;
			out.style.setProperty('--remaily-count', count);
			out.style.setProperty('--remaily-max', max);
			out.classList.toggle('is-over', Boolean(max) && count > max);
			out.classList.toggle('is-under', Boolean(min) && count > 0 && count < min);
		});
	};

	const setError = (wrap, message) => {
		const error = wrap.querySelector('[data-remaily-error]');

		wrap.classList.toggle('is-invalid', Boolean(message));

		if (error) {
			error.textContent = message;
			error.hidden = !message;
		}

		controls(wrap).forEach((el) => {
			if (el.type === 'hidden') {
				return;
			}

			const described = tokens(el, 'aria-describedby').filter((id) => !error || id !== error.id);

			if (message) {
				el.setAttribute('aria-invalid', 'true');

				if (error) {
					described.push(error.id);
				}
			} else {
				el.removeAttribute('aria-invalid');
			}

			if (described.length) {
				el.setAttribute('aria-describedby', described.join(' '));
			} else {
				el.removeAttribute('aria-describedby');
			}
		});
	};

	// The message key of the browser's own checks, named as the server names them
	const problem = (type, el) => {
		const v = el.validity;

		if (v.valueMissing) {
			return type === 'acceptance' ? 'accept_terms' : 'required';
		}

		if (v.typeMismatch || v.patternMismatch || v.badInput || v.stepMismatch) {
			return messages[`invalid_${type}`] ? `invalid_${type}` : 'invalid';
		}

		if (v.tooLong) {
			return 'too_long';
		}

		if (v.tooShort) {
			return 'too_short';
		}

		if (v.rangeUnderflow) {
			return type === 'date' ? 'date_too_early' : 'number_too_small';
		}

		if (v.rangeOverflow) {
			return type === 'date' ? 'date_too_late' : 'number_too_large';
		}

		if (el.type === 'file') {
			const max = Number(el.dataset.remailyMaxSize || 0);
			const accept = (el.accept || '').toLowerCase().split(',').filter(Boolean);

			for (const file of el.files) {
				if (max && file.size > max) {
					return 'upload_file_too_large';
				}

				if (accept.length && !accept.some((ext) => file.name.toLowerCase().endsWith(ext))) {
					return 'upload_file_type_invalid';
				}
			}
		}

		return '';
	};

	const check = (wrap) => {
		if (wrap.closest('[data-remaily-group][hidden]')) {
			setError(wrap, '');

			return true;
		}

		const els = controls(wrap);
		let key = wrap.hasAttribute('data-remaily-required') && !els.some((el) => el.checked) ? 'required' : '';

		for (const el of els) {
			key = key || problem(wrap.dataset.remailyType, el);
		}

		// An inverted acceptance: sent only with the box clear
		if (!key && wrap.hasAttribute('data-remaily-invert') && els.some((el) => el.checked)) {
			key = 'accept_terms';
		}

		let text = key ? messages[key] || messages.invalid || '' : '';

		// An add-on's own check: a message key, or its own text
		for (const fn of key ? [] : checks) {
			key = fn(wrap) || '';
			text = key ? messages[key] || key : '';

			if (key) {
				break;
			}
		}

		setError(wrap, text);

		return !key;
	};

	const setStatus = (status) => {
		root.classList.remove(...STATUSES.map((s) => `is-${s}`));

		if (status) {
			root.classList.add(`is-${status}`);
		}

		form.toggleAttribute('aria-busy', status === 'sending');
	};

	const emit = (name, response = null, cancelable = false) =>
		form.dispatchEvent(new CustomEvent(`remaily:${name}`, { bubbles: true, cancelable, detail: { id: Number(form.dataset.remaily), form, response } }));

	const focusFirst = () => form.querySelector('[aria-invalid="true"]')?.focus();

	const alert = (status, message) => {
		const div = document.createElement('div');
		const text = document.createElement('span');

		div.className = `remaily-alert remaily-alert--${status}`;
		text.className = 'remaily-alert__text';
		text.textContent = message;
		div.append(text);
		box.replaceChildren(div);
	};

	const post = (withNonce) =>
		fetch(`${data.restUrl}forms/${form.dataset.remaily}/submit`, {
			method: 'POST',
			body: new FormData(form),
			credentials: 'same-origin',
			headers: withNonce && form.dataset.nonce ? { 'X-WP-Nonce': form.dataset.nonce } : {},
		});

	const send = async () => {
		setStatus('sending');
		box.replaceChildren();

		try {
			for (const fn of beforeSend) {
				await fn(form);
			}

			let res = await post(true);

			// A cached page's nonce has expired: send as a visitor
			if (res.status === 403 && form.dataset.nonce) {
				res = await post(false);
			}

			const json = await res.json();

			if (!res.ok || !json.status) {
				throw new Error(json.message || res.statusText);
			}

			wrappers().forEach((wrap) => setError(wrap, ''));
			(json.invalid || []).forEach(({ field, message }) => {
				const wrap = wrapper(field);

				if (wrap) {
					setError(wrap, message);
				}
			});

			setStatus(json.status);
			box.innerHTML = json.html || '';

			if (!box.innerHTML) {
				alert(json.status, json.message);
			}

			if (json.status === 'invalid') {
				focusFirst();
			}

			if (json.status === 'success') {
				tried = false;
				form.reset();
			}

			resetCaptchas(form);

			if (json.data?.script) {
				await load(json.data.script);
			}

			emit('sent', json);
			emit(json.status, json);

			if (json.redirect) {
				window.location.assign(json.redirect);
			}
		} catch (err) {
			setStatus('failed');
			alert('failed', messages.failed || err.message);
			emit('failed');
		}
	};

	form.addEventListener('submit', (event) => {
		event.preventDefault();

		if (root.classList.contains('is-sending')) {
			return;
		}

		tried = true;

		// A number with only its code (sent with Enter) is empty
		form.querySelectorAll('[data-remaily-mask]').forEach((el) => !national(el.value, el.dataset.remailyMask, el.dataset.remailyTrunk || '') && (el.value = ''));

		if (wrappers().map(check).includes(false)) {
			setStatus('invalid');
			alert('invalid', messages.invalid || '');
			focusFirst();
			emit('invalid');

			return;
		}

		// The editor's preview checks the fields but sends nothing
		if (form.dataset.remailyPreview) {
			setStatus('success');
			alert('success', form.dataset.remailyPreview);

			return;
		}

		if (emit('submit', null, true)) {
			send();
		}
	});

	const changed = (event) => {
		// Exclusive checkboxes: ticking one clears the others
		if (event.type === 'change' && event.target.checked && event.target.closest('[data-remaily-exclusive]')) {
			controls(event.target.closest('[data-remaily-field]')).forEach((el) => el !== event.target && (el.checked = false));
		}

		conditions();
		outputs();

		const wrap = event.target.closest?.('[data-remaily-field]');

		if (wrap && (tried || wrap.classList.contains('is-invalid'))) {
			check(wrap);
		}
	};

	// A link used as the submit button; a date opens its calendar wherever it's clicked, not only on the icon
	form.addEventListener('click', (event) => {
		if (event.target.closest('[data-remaily-submit]')) {
			event.preventDefault();
			form.requestSubmit();
		}

		if (event.target.matches?.('input[type="date"]:not([readonly], :disabled)')) {
			try {
				event.target.showPicker();
			} catch {}
		}
	});

	form.addEventListener('keydown', (event) => {
		if (event.key === ' ' && event.target.closest('[data-remaily-submit]')) {
			event.preventDefault();
			form.requestSubmit();
		}
	});

	const tel = setupTel(form);
	const repeaters = setupRepeaters(form, {
		prepare: tel.prepare,
		update: () => {
			conditions();
			outputs();
		},
	});

	form.addEventListener('input', changed);
	form.addEventListener('change', changed);

	form.addEventListener('reset', () => {
		// The controls are reset after this event
		setTimeout(() => {
			repeaters.reset();
		wrappers().forEach((wrap) => setError(wrap, ''));
			form.querySelectorAll('.remaily-flagged > select').forEach(tel.flagged);
			conditions();
			outputs();
			emit('reset');
		});
	});

	// window.remaily.check(): the fields inside an element of this form
	form.remailyCheck = (scope) => {
		const ok = !wrappers()
			.filter((wrap) => scope === form || scope.contains(wrap))
			.map(check)
			.includes(false);

		if (!ok) {
			focusFirst();
		}

		return ok;
	};

	setupSmartCaptcha(form);
	conditions();
	outputs();
	emit('ready');
}
