/**
 * Captchas: reCAPTCHA v3's token asked for as the form is sent, Turnstile, hCaptcha and SmartCaptcha widgets reset
 * after each reply (their answers work once)
 */
import { load } from './load.js';

// reCAPTCHA v3: a token for this send. Its script is loaded now if a cookie banner or an optimizer held it back:
// without a token the message is turned down as spam.
export const recaptcha = async (form) => {
	const input = form.querySelector('[data-remaily-captcha="recaptcha"]');

	if (!input) {
		return;
	}

	if (!window.grecaptcha?.execute && input.dataset.src) {
		await load(input.dataset.src);
	}

	await new Promise((resolve) => window.grecaptcha.ready(resolve));
	input.value = await window.grecaptcha.execute(input.dataset.sitekey, { action: 'contact_form' });
};

// A form may run several captchas: each widget is reset
export const resetCaptchas = (form) =>
	form.querySelectorAll('[data-remaily-captcha]').forEach((widget) => {
		if (widget.dataset.remailyCaptcha === 'turnstile') {
			window.turnstile?.reset(`#${widget.id}`);
		} else if (widget.dataset.remailyCaptcha === 'hcaptcha') {
			window.hcaptcha?.reset(widget.querySelector('iframe')?.dataset.hcaptchaWidgetId);
		} else if (widget.dataset.remailyCaptcha === 'smartcaptcha' && widget.dataset.widgetId) {
			// The first widget's ID is 0
			window.smartCaptcha?.reset(Number(widget.dataset.widgetId));
		}
	});

// SmartCaptcha: made here, so its ID is known for reset()
const renderSmartCaptcha = (form) => {
	form.querySelectorAll('[data-remaily-captcha="smartcaptcha"]').forEach((container) => {
		if (container.dataset.widgetId) {
			return;
		}

		container.dataset.widgetId = String(window.smartCaptcha.render(container, { sitekey: container.dataset.sitekey }));
	});
};

/**
 * A form's SmartCaptcha widgets, once Yandex's script is there (it may come a little later)
 */
export const setupSmartCaptcha = (form) => {
	if (!form.querySelector('[data-remaily-captcha="smartcaptcha"]')) {
		return;
	}

	if (window.smartCaptcha) {
		renderSmartCaptcha(form);

		return;
	}

	const poll = setInterval(() => {
		if (window.smartCaptcha) {
			clearInterval(poll);
			renderSmartCaptcha(form);
		}
	}, 200);

	setTimeout(() => clearInterval(poll), 10000);
};
