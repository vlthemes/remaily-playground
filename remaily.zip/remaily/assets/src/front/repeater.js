/**
 * Repeated groups ([data-remaily-repeater]): Add copies the row template with a new key, Remove takes its row out;
 * min and max hide the buttons. update() runs the rules and outputs again after a change
 *
 * @return {{ reset: Function }} Back to the rows the form started with
 */
export const setupRepeaters = (form, { prepare, update }) => {
	// Repeated groups: Add copies the row template with a new key, Remove takes its row out; min and max hold
	const repeaters = [...form.querySelectorAll('[data-remaily-repeater]')];
	const rowsOf = (repeater) => [...repeater.querySelector('.remaily-repeater__rows').children];
	const initial = new Map(repeaters.map((repeater) => [repeater, rowsOf(repeater).length]));

	const limits = (repeater) => {
		const count = rowsOf(repeater).length;
		const max = Number(repeater.dataset.max || 0);

		repeater.querySelector('[data-remaily-add]').hidden = Boolean(max) && count >= max;
		repeater.querySelectorAll('[data-remaily-remove]').forEach((button) => (button.hidden = count <= Number(repeater.dataset.min || 0)));
	};

	const addRow = (repeater) => {
		const template = repeater.querySelector('template[data-remaily-row-template]');
		const key = Math.max(-1, ...rowsOf(repeater).map((row) => Number(row.dataset.remailyRow) || 0)) + 1;
		const holder = document.createElement('div');

		holder.innerHTML = template.innerHTML.split('__i__').join(String(key));

		const row = holder.firstElementChild;

		repeater.querySelector('.remaily-repeater__rows').append(row);
		prepare(row);
		limits(repeater);

		return row;
	};

	repeaters.forEach(limits);

	form.addEventListener('click', (event) => {
		const add = event.target.closest('[data-remaily-add]');
		const remove = event.target.closest('[data-remaily-remove]');

		if (add) {
			addRow(add.closest('[data-remaily-repeater]'))
				.querySelector('input:not([type="hidden"]), select, textarea')
				?.focus();
		} else if (remove) {
			const repeater = remove.closest('[data-remaily-repeater]');

			remove.closest('.remaily-repeater__row').remove();
			limits(repeater);
			repeater.querySelector('[data-remaily-add]').focus();
		} else {
			return;
		}

		update();
	});

	return {
		reset: () =>
			repeaters.forEach((repeater) => {
				rowsOf(repeater)
					.slice(initial.get(repeater))
					.forEach((row) => row.remove());

				while (rowsOf(repeater).length < initial.get(repeater)) {
					addRow(repeater);
				}

				limits(repeater);
			}),
	};
};
