/**
 * Remaily forms: checks fields, shows and hides groups, mirrors output fields, counts characters and sends without a reload
 *
 * Events on the <form>, with detail { id, form, response }:
 *   remaily:submit (cancelable, before sending), remaily:sent (any reply), remaily:success, remaily:invalid,
 *   remaily:failed, remaily:spam, remaily:aborted, remaily:payment (a payment to make first: payments.js), remaily:reset,
 *   remaily:ready (the form is set up)
 * Forms added later (popups, AJAX): window.remaily.init( element ). window.remaily.beforeSend: async steps before
 * sending. window.remaily.check( element ): checks the fields inside it (a step), shows their errors, returns whether
 * all pass. window.remaily.checks: ( wrap ) => a message key or text for a field the browser can't check, '' if fine.
 * [data-remaily-live] spans ([[message:left]]…) follow what is typed, as the Count field does. Repeated groups
 * ([data-remaily-repeater]) add and remove rows from their template.
 * Captchas are handled here: reCAPTCHA v3's token asked for as the form is sent, Turnstile and hCaptcha widgets reset
 * after each reply (their answers work once). A reply's data.script (the payment script) loads before its event fires.
 * window.remaily.values: ( values, form, hidden ) => values, worked out before the rules read them.
 *
 * The parts: form.js (one form), rules.js (conditions), tel.js (numbers and countries), repeater.js, captcha.js,
 * utm.js, load.js; built into assets/build/front.js, one file for the page.
 */
import { recaptcha } from './captcha.js';
import { init } from './form.js';

// Async steps awaited before a form is sent: ( form ) => Promise
const beforeSend = [recaptcha];
// ( wrap ) => a message key or text for a field the browser can't check, '' when it's fine
const checks = [];
// ( values, form, hidden groups ) => values: what is worked out before the rules read them (remaily_values)
const derived = [];

const hooks = { beforeSend, checks, derived };

const check = (scope) => {
	const form = scope?.closest?.('form[data-remaily]') || scope?.querySelector?.('form[data-remaily]');

	return form?.remailyCheck ? form.remailyCheck(form.contains(scope) ? scope : form) : true;
};

const initAll = (scope = document) => {
	(scope.matches?.('.remaily') ? [scope] : [...scope.querySelectorAll('.remaily')]).forEach((root) => init(root, hooks));
};

window.remaily = { init: initAll, beforeSend, checks, check, values: derived };

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', () => initAll());
} else {
	initAll();
}
