/**
 * Re:Maily Contact Form block: picks a saved form. The editor shows which one, not the form itself; the site renders it
 */
import { __, sprintf } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Button, ExternalLink, PanelBody, Placeholder, SelectControl } from '@wordpress/components';

const { forms = [], editUrl, newUrl, canEdit, icon } = window.remailyBlocks || {};

const options = [{ value: 0, label: __( 'Choose a form', 'remaily' ) }, ...forms.map((form) => ({ value: form.id, label: form.title }))];

// The Re:Maily logo (assets/icons/logo.webp), the same as Elementor's and WPBakery's
const Logo = () => (
	<span className="block-editor-block-icon">
		<img src={icon} width="24" height="24" alt="" />
	</span>
);

const FormSelect = ({ value, onChange, hideLabel = false }) => (
	<SelectControl
		label={__( 'Form', 'remaily' )}
		hideLabelFromVision={hideLabel}
		value={value}
		options={options}
		onChange={(next) => onChange(Number(next))}
		__nextHasNoMarginBottom
		__next40pxDefaultSize
	/>
);

registerBlockType('remaily/form', {
	icon: <Logo />,
	edit({ attributes, setAttributes }) {
		const props = useBlockProps();
		// By hash first: after an export and import the saved post ID is another form's, or none
		const form = forms.find((f) => attributes.hash && f.hash === attributes.hash) || forms.find((f) => f.id === attributes.id);
		const id = form ? form.id : attributes.id;
		const pick = (next) => setAttributes({ id: next, hash: forms.find((f) => f.id === next)?.hash || '' });

		return (
			<div {...props}>
				<InspectorControls>
					<PanelBody title={__( 'Form', 'remaily' )}>
						<FormSelect value={id} onChange={pick} />
						{id > 0 && canEdit && <ExternalLink href={editUrl + id}>{__( 'Edit this form', 'remaily' )}</ExternalLink>}
					</PanelBody>
				</InspectorControls>

				<Placeholder
					icon={<Logo />}
					label={__( 'Re:Maily Contact Form', 'remaily' )}
					instructions={
						form
							? /* translators: %s: form title */ sprintf( __( 'Shows “%s” on the site.', 'remaily' ), form.title )
							: forms.length
								? __( 'Pick one of your forms.', 'remaily' )
								: __( 'There are no forms yet.', 'remaily' )
					}
				>
					{forms.length > 0 && <FormSelect value={form ? id : 0} onChange={pick} hideLabel />}
					{form && canEdit && (
						<Button variant="secondary" href={editUrl + id} target="_blank" __next40pxDefaultSize>
							{__( 'Edit this form', 'remaily' )}
						</Button>
					)}
					{!form && canEdit && (
						<Button variant="secondary" href={newUrl} target="_blank" __next40pxDefaultSize>
							{__( 'Make a new form', 'remaily' )}
						</Button>
					)}
				</Placeholder>
			</div>
		);
	},
	save: () => null,
});
