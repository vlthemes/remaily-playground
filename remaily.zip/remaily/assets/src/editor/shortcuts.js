/**
 * Keyboard shortcuts, as Forma's: WordPress's access modifier (Ctrl+Alt, ⌃⌥ on a Mac) and a key for the tabs, Preview
 * and Describe; ⌘S / Ctrl+S saves anywhere on the screen. ⌘G (wrap in a group) lives in the code (code-editor.js).
 */
import { useEffect } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { displayShortcut, isKeyboardEvent } from '@wordpress/keycodes';

// Action => [ modifier, key ]
const KEYS = {
	save: ['primary', 's'],
	preview: ['access', 'p'],
	describe: ['access', 'd'],
};

/**
 * Calls run( action ) on its shortcut, run( 'tab', index ) on Ctrl+Alt+1…9; Escape goes back to the field list
 *
 * @param {Function} run Handler
 */
export function useShortcuts(run) {
	useEffect(() => {
		const onKeyDown = (event) => {
			// The code editor handled it already (⌘S, ⌘G inside it)
			if (event.defaultPrevented) {
				return;
			}

			const action = Object.keys(KEYS).find((name) => isKeyboardEvent[KEYS[name][0]](event, KEYS[name][1]));
			const tab = [1, 2, 3, 4, 5, 6, 7, 8, 9].find((n) => isKeyboardEvent.access(event, String(n)));

			if (action) {
				event.preventDefault();
				run(action);
			} else if (tab) {
				event.preventDefault();
				run('tab', tab - 1);
			} else if ('Escape' === event.key && !event.target.closest?.('input, textarea, select, [contenteditable="true"], .remaily-dialog')) {
				run('back');
			}
		};

		document.addEventListener('keydown', onKeyDown);

		return () => document.removeEventListener('keydown', onKeyDown);
	}, [run]);
}

/**
 * The list under the field list
 */
export function ShortcutList() {
	const rows = [
		[__( 'Save', 'remaily' ), displayShortcut.primary('s')],
		[__( 'Preview', 'remaily' ), displayShortcut.access('p')],
		[__( 'Describe your form', 'remaily' ), displayShortcut.access('d')],
		[__( 'Select code, then: make it a group', 'remaily' ), displayShortcut.primary('g')],
		[__( 'Form, Mail, Messages, Advanced', 'remaily' ), displayShortcut.access('1') + '…4'],
		[__( 'Back to the field list', 'remaily' ), 'Esc'],
	];

	return (
		<div className="remaily-shortcuts">
			<h3>{__( 'Keyboard shortcuts', 'remaily' )}</h3>
			<dl>
				{rows.map(([label, keys]) => (
					<div key={label}>
						<dt>{label}</dt>
						<dd>
							<kbd>{keys}</kbd>
						</dd>
					</div>
				))}
			</dl>
		</div>
	);
}
