/**
 * A tab drawn from a Controls tree (Addons::form_tabs(), remaily_form_tabs): the same trees as Settings, in the
 * editor's own controls. Conditions come in their long form (paths from the top, Controls::export()); options are
 * [ { value, label } ], and source adds the form's fields of some types or the items of an add-on's REST route.
 */
import apiFetch from '@wordpress/api-fetch';
import { useEffect, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Field, NumberInput, Radios, Text, Textarea, Toggle, asRadios } from './controls.js';
import { matches, pick, put } from './conditions.js';
import Action from './parts/action.js';
import Message from './parts/message.js';

let uid = 0;

// One request per route for the whole editor
const routes = {};
const fetchRoute = (route) => (routes[route] = routes[route] || apiFetch({ path: `/${route.replace(/^\/+/, '')}` }));

/**
 * The options of a select or checkboxes: its own, then those of its source
 */
const useOptions = (node, fields, source = node.source, own = node.options) => {
	const route = source?.route;
	const [found, setFound] = useState({ items: route ? null : [], error: '' });

	useEffect(() => {
		if (route) {
			fetchRoute(route)
				.then((answer) => setFound({ items: (source.key ? answer?.[source.key] : answer) || [], error: '' }))
				.catch((err) => setFound({ items: [], error: err.message || __( 'The options couldn\'t be loaded.', 'remaily' ) }));
		}
	}, [route]);

	// '*': every field but the submit button
	const types = source?.fields || [];
	const named = Object.entries(fields || {})
		.filter(([, field]) => (types.includes('*') ? 'submit' !== field.type : types.includes(field.type)))
		.map(([name]) => ({ value: name, label: name }));
	const items = (found.items || []).map((item) => ({ value: String(item.value ?? item.id), label: String(item.label ?? item.name ?? item.value) }));

	return { options: [...(own || []), ...named, ...items], loading: null === found.items, error: found.error };
};

const Select = ({ node, value, onChange, fields }) => {
	const [id] = useState(() => `remaily-tree-${++uid}`);
	// A failed route shows its error once, under the checkboxes that use it; a select keeps its own options
	const { options } = useOptions(node, fields);
	// A saved value the list doesn't have yet (still loading, or gone) stays shown
	const list = '' !== String(value ?? '') && !options.some((o) => o.value === String(value)) ? [...options, { value: String(value), label: String(value) }] : options;

	// A few short options of its own, none from a source: radios
	if (!node.source && asRadios(list, node.as)) {
		return <Radios label={node.label} help={node.help} inline={node.inline} value={value} options={list} onChange={onChange} />;
	}

	return (
		<Field label={node.label} help={node.help} id={id}>
			<select id={id} className="remaily-input remaily-select" value={String(value ?? '')} onChange={(e) => onChange(e.target.value)}>
				{list.map((option) => (
					<option key={option.value} value={option.value}>
						{option.label}
					</option>
				))}
			</select>
		</Field>
	);
};

const Checkboxes = ({ node, value, onChange, fields }) => {
	const { options, loading, error } = useOptions(node, fields);
	const picked = (Array.isArray(value) ? value : []).map(String);

	return (
		<Field label={node.label} help={node.help}>
			{error && <p className="remaily-side__error">{error}</p>}
			{!error && loading && <p className="remaily-panel__intro">{__( 'Loading…', 'remaily' )}</p>}
			{!error && !loading && !options.length && node.empty && <p className="remaily-panel__intro">{node.empty}</p>}
			{options.map((option) => (
				<Toggle
					key={option.value}
					label={option.label}
					checked={picked.includes(option.value)}
					onChange={(on) => onChange(on ? [...picked, option.value] : picked.filter((item) => item !== option.value))}
				/>
			))}
		</Field>
	);
};

/**
 * Pairs: a name typed or picked from key_source (a datalist), and one of the options (the form's fields, say)
 */
const MapControl = ({ node, value, onChange, fields }) => {
	const [list] = useState(() => `remaily-tree-keys-${++uid}`);
	const keys = useOptions(node, fields, node.key_source, node.key_options);
	const { options } = useOptions(node, fields);
	// Lines of "name = [field]" saved before become pairs
	const rows = Array.isArray(value)
		? value
		: String(value || '')
				.split('\n')
				.filter((line) => line.includes('='))
				.map((line) => {
					const [key, ...rest] = line.split('=');
					const tag = rest.join('=').trim();

					return { key: key.trim(), value: tag.replace(/^\[([a-z][a-z0-9_-]*)\]$/, '$1') };
				});
	const change = (i, part) => onChange(rows.map((row, n) => (n === i ? { ...row, ...part } : row)));

	return (
		<Field label={node.label} help={node.help}>
			<datalist id={list}>
				{keys.options.map((option) => (
					<option key={option.value} value={option.value} />
				))}
			</datalist>
			<div className="remaily-map">
				{rows.map((row, i) => (
					<div key={i} className="remaily-map__row">
						<input className="remaily-input" list={list} placeholder={node.key_placeholder || ''} value={row.key || ''} aria-label={node.key_label || __( 'Name', 'remaily' )} onChange={(e) => change(i, { key: e.target.value })} />
						<span className="remaily-map__arrow" aria-hidden="true">←</span>
						<select className="remaily-input remaily-select" value={row.value || ''} aria-label={node.value_label || __( 'Value', 'remaily' )} onChange={(e) => change(i, { value: e.target.value })}>
							{[{ value: '', label: node.value_placeholder || __( 'Choose…', 'remaily' ) }, ...options].map((option) => (
								<option key={option.value} value={option.value}>
									{option.label}
								</option>
							))}
						</select>
						<button type="button" className="remaily-map__remove" aria-label={__( 'Remove', 'remaily' )} onClick={() => onChange(rows.filter((_, n) => n !== i))}>
							×
						</button>
					</div>
				))}
				<button type="button" className="remaily-button is-secondary remaily-map__add" onClick={() => onChange([...rows, { key: '', value: '' }])}>
					{node.add_label || __( 'Add', 'remaily' )}
				</button>
			</div>
		</Field>
	);
};

const Control = ({ node, value, onChange, fields }) => {
	switch (node.type) {
		case 'toggle':
			return <Toggle label={node.label} help={node.help} checked={value} onChange={onChange} />;

		case 'select':
			return <Select node={node} value={value} onChange={onChange} fields={fields} />;

		case 'checkboxes':
			return <Checkboxes node={node} value={value} onChange={onChange} fields={fields} />;

		case 'map':
			return <MapControl node={node} value={value} onChange={onChange} fields={fields} />;

		case 'textarea':
			// 'tags' => true: the form's fields and everyday tags to click in
			if (node.tags) {
				return <Message label={node.label} help={node.help} rows={node.rows || 5} placeholder={node.placeholder} value={value} onChange={onChange} fields={fields} />;
			}

			return <Textarea label={node.label} help={node.help} rows={node.rows || 4} mono={!node.paragraphs} placeholder={node.placeholder} value={value} onChange={onChange} />;

		case 'number':
			return <NumberInput label={node.label} help={node.help} min={node.min} step={node.step} value={value} onChange={onChange} />;

		default:
			// text, slug, unit, color, secret
			return <Text label={node.label} help={node.help} placeholder={node.placeholder} type={node.input || 'text'} value={value} onChange={onChange} />;
	}
};

const Nodes = ({ fields, level, top, onChange, form }) =>
	Object.entries(fields || {}).map(([key, node]) => {
		if (node.condition && !matches(node.condition, top)) {
			return null;
		}

		switch (node.type) {
			case 'section':
				return (
					<section key={key} className="remaily-tree__section">
						{node.title && <h3 className="remaily-tree__title">{node.title}</h3>}
						{node.description && <p className="remaily-panel__intro" dangerouslySetInnerHTML={{ __html: node.description }} />}
						<Nodes fields={node.fields} level={false !== node.nested ? [...level, key] : level} top={top} onChange={onChange} form={form} />
					</section>
				);

			case 'row':
				return (
					<div key={key} className="remaily-tree__row" style={{ '--remaily-columns': node.columns || Object.keys(node.fields || {}).length }}>
						<Nodes fields={node.fields} level={level} top={top} onChange={onChange} form={form} />
					</div>
				);

			case 'divider':
				return <hr key={key} className="remaily-tree__divider" />;

			case 'notice':
				return <p key={key} className={`remaily-tree__notice is-${node.tone || 'info'}`} dangerouslySetInnerHTML={{ __html: node.text || '' }} />;

			// A button that does something now, through the add-on's REST route (parts/action.js)
			case 'action':
				return <Action key={key} node={node} />;

			default: {
				const path = [...level, key];

				return <Control key={key} node={node} value={pick(top, path.join('.'))} onChange={(value) => onChange(put(top, path, value))} fields={form} />;
			}
		}
	});

/**
 * The tab: its title with the add-on's icon, then the tree (AddonTab gives values and setAll)
 */
const TreeTab = ({ tab, config, values, setAll }) => (
	<section className="remaily-panel remaily-tree">
		<h2 className="remaily-panel__title has-logo">
			{tab.icon && <span className="remaily-panel__logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: tab.icon }} />}
			{tab.label}
		</h2>
		<Nodes fields={tab.fields} level={[]} top={values || {}} onChange={setAll} form={config.fields} />
	</section>
);

export default TreeTab;
