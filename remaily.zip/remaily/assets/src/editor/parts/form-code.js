/**
 * Form code (Advanced → Copy to another site): the whole form as JSON, and reading it back on the other site
 */

/**
 * The form as code to copy
 *
 * @param {Object} doc { title, description, template, config }
 * @return {string} JSON
 */
export const formCode = (doc) => JSON.stringify({ remaily: 1, title: doc.title, description: doc.description, template: doc.template, config: doc.config }, null, 2);

/**
 * Pasted form code, or null when the text isn't one
 *
 * @param {string} text Pasted text
 * @return {Object|null} { title?, description?, template, config }
 */
export const readFormCode = (text) => {
	let pasted;

	try {
		pasted = JSON.parse(text);
	} catch {
		return null;
	}

	return 1 === pasted?.remaily && 'string' === typeof pasted.template && pasted.config && 'object' === typeof pasted.config ? pasted : null;
};
