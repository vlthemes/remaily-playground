/**
 * Form code (Advanced → Copy to another site): the whole form as JSON, and reading it back on the other site
 */

/**
 * The form as code to copy, with the values of the add-ons that are on only: those of add-ons off or gone stay on
 * this site, waiting for them, as in an export (Transfer::portable())
 *
 * @param {Object}   doc    { title, description, template, config }
 * @param {string[]} addons IDs of the add-on tabs this editor has
 * @return {string} JSON
 */
export const formCode = (doc, addons = []) => {
	const values = Object.fromEntries(Object.entries(doc.config.addons || {}).filter(([id]) => addons.includes(id)));

	return JSON.stringify({ remaily: 1, title: doc.title, description: doc.description, template: doc.template, config: { ...doc.config, addons: values } }, null, 2);
};

/**
 * Pasted form code, or null when the text isn't one
 *
 * @param {string} text Pasted text
 * @return {Object|null} { title?, description?, template, config }
 */
export const readFormCode = (text) => {
	let pasted;

	try {
		pasted = JSON.parse(text);
	} catch {
		return null;
	}

	return 1 === pasted?.remaily && 'string' === typeof pasted.template && pasted.config && 'object' === typeof pasted.config ? pasted : null;
};
