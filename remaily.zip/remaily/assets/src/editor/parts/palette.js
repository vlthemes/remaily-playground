/**
 * The field buttons above the code: each type and each place not placed yet, in the row or in its More menu
 * (Field::menu(), remaily_places). Drag one into the code, or click to add it at the cursor
 */
import { useEffect, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Icon } from '../icons.js';

// The More menu's width, to open it the other way when it would leave the screen
const MENU_WIDTH = 296;

/**
 * @param {Object}   props
 * @param {Array}    props.items    [ { name, label, summary, icon, menu, place } ]
 * @param {boolean}  props.disabled While the CSS or JavaScript code is open
 * @param {Function} props.onInsert Add one at the cursor: ( name )
 * @param {Function} props.onDrag   A button dragged: ( event, item )
 */
const Palette = ({ items, disabled, onInsert, onDrag }) => {
	// false, or the side it opens to: start or end
	const [more, setMore] = useState(false);
	const main = items.filter((item) => 'more' !== item.menu);
	const rest = items.filter((item) => 'more' === item.menu);

	// A click anywhere else closes it
	useEffect(() => {
		if (!more) {
			return;
		}

		const close = (e) => !e.target.closest('.remaily-more') && setMore(false);

		document.addEventListener('click', close);

		return () => document.removeEventListener('click', close);
	}, [more]);

	const toggle = (e) => {
		// Opens the other way when the menu would leave the screen at its end (the left on an RTL screen)
		const { left, right } = e.currentTarget.getBoundingClientRect();
		const overflows = 'rtl' === getComputedStyle(e.currentTarget).direction ? right - MENU_WIDTH < 0 : left + MENU_WIDTH > document.documentElement.clientWidth;

		setMore(more ? false : overflows ? 'end' : 'start');
	};

	return (
		<div className={`remaily-palette${disabled ? ' is-off' : ''}`} role="toolbar" aria-label={__( 'Fields', 'remaily' )} aria-disabled={disabled} inert={disabled ? '' : undefined}>
			<div className="remaily-palette__types">
				{main.map((item) => (
					<button
						key={item.name}
						type="button"
						className="remaily-palette__item"
						draggable
						title={item.summary || __( 'Drag into the editor, or click to add at the cursor', 'remaily' )}
						onDragStart={(e) => onDrag(e, item)}
						onClick={() => onInsert(item.name)}
					>
						<Icon name={item.icon} />
						{item.label}
					</button>
				))}
				{rest.length > 0 && (
					<span className={`remaily-more${more ? ' is-open' : ''}${more === 'end' ? ' is-end' : ''}`}>
						<button type="button" className="remaily-palette__item is-muted" aria-haspopup="menu" aria-expanded={Boolean(more)} onClick={toggle}>
							{__( 'More', 'remaily' )}
							<Icon name="chevron" />
						</button>
						{more && (
							<span className="remaily-save__menu remaily-more__menu" role="menu">
								{rest.map((item) => (
									<button
										key={item.name}
										type="button"
										role="menuitem"
										draggable
										onDragStart={(e) => onDrag(e, item)}
										onDragEnd={() => setMore(false)}
										onClick={() => {
											onInsert(item.name);
											setMore(false);
										}}
									>
										<Icon name={item.icon} />
										<span className="remaily-save__text">
											<strong>{item.label}</strong>
											{item.summary && <span>{item.summary}</span>}
										</span>
									</button>
								))}
							</span>
						)}
					</span>
				)}
			</div>
		</div>
	);
};

export default Palette;
