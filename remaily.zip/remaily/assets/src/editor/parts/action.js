/**
 * A button of an add-on's tab that does something now (send past entries to a spreadsheet, test a connection):
 * a POST to its REST route with the form's ID, then the answer's message under it. In a Controls tree:
 *
 *     'past' => [ 'type' => 'action', 'label' => 'Past entries', 'button' => 'Send them now', 'route' => 'my-addon/v1/send-past' ]
 */
import apiFetch from '@wordpress/api-fetch';
import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Field } from '../controls.js';
import data from '../state.js';

const Action = ({ node }) => {
	const [busy, setBusy] = useState(false);
	const [answer, setAnswer] = useState(null);

	const run = () => {
		setBusy(true);
		setAnswer(null);
		apiFetch({ path: `/${String(node.route).replace(/^\/+/, '')}`, method: 'POST', data: { form: data.form?.id || 0 } })
			.then((reply) => setAnswer({ ok: true, text: reply?.message || __( 'Done.', 'remaily' ) }))
			.catch((error) => setAnswer({ ok: false, text: error?.message || __( 'That didn\'t work. Try again in a moment.', 'remaily' ) }))
			.finally(() => setBusy(false));
	};

	return (
		<Field label={node.label} help={node.help}>
			<div className="remaily-action">
				<Button onClick={run} disabled={busy}>
					{busy ? node.busy || __( 'Working…', 'remaily' ) : node.button || node.label}
				</Button>
				{answer && (
					<p className={`remaily-action__answer ${answer.ok ? 'is-ok' : 'is-error'}`} role="status">
						{answer.text}
					</p>
				)}
			</div>
		</Field>
	);
};

export default Action;
