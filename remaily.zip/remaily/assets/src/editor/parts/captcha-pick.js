/**
 * Which captcha the form runs: the site's (those Settings → Spam runs on every form), none, or one of those set up
 */
import { createInterpolateElement } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Radios } from '../controls.js';
import data from '../state.js';

const CaptchaPick = ({ captchas, value, onChange }) => {
	const every = Object.entries(captchas).filter(([, c]) => c.every).map(([, c]) => c.label);
	const runs = (id) => ('' === value ? captchas[id].every : value === id);

	return (
		<>
			<div className="remaily-picks" aria-label={__( 'Captchas this form runs', 'remaily' )}>
				{Object.entries(captchas).map(([id, captcha]) => (
					// A click picks it for this form alone
					<button key={id} type="button" aria-pressed={runs(id)} className={`remaily-pick${runs(id) ? ' is-on' : ''}`} onClick={() => onChange(id)}>
						<span className="remaily-pick__logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: captcha.logo }} />
						{captcha.label}
					</button>
				))}
			</div>
			<Radios
				label={__( 'Captcha', 'remaily' )}
				help={createInterpolateElement(__( 'Set up in <a>Settings → Spam</a>. It goes before the submit button, or where you put [[captcha]] in the code.', 'remaily' ), {
					a: <a href={data.settingsUrl} />,
				})}
				value={captchas[value] || 'none' === value ? value : ''}
				options={{
					/* translators: %s: captcha names, such as Cloudflare Turnstile */
					'': every.length ? sprintf( __( 'As on every form: %s', 'remaily' ), every.join(', ') ) : __( 'As on every form: none', 'remaily' ),
					none: __( 'No captcha on this form', 'remaily' ),
					...Object.fromEntries(Object.entries(captchas).map(([id, c]) => [id, sprintf( /* translators: %s: captcha name */ __( 'Only %s', 'remaily' ), c.label )])),
				}}
				onChange={onChange}
			/>
		</>
	);
};

export default CaptchaPick;
