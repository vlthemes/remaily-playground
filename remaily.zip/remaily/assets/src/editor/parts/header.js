/**
 * The editor's header: the form's title and note (click to change them), Copy shortcode, Save, the tabs and Preview
 */
import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button } from '../controls.js';
import { Icon } from '../icons.js';
import data from '../state.js';

/**
 * @param {Object}   props
 * @param {Object}   props.doc       Title and description
 * @param {Function} props.setDoc    Change the document
 * @param {string}   props.status    publish or draft
 * @param {Array}    props.tabs      [ [ id, label ], … ]
 * @param {string}   props.tab       The open tab
 * @param {Function} props.onTab     Open a tab
 * @param {Object}   props.warn      [ tab id => true ] for tabs with something to check
 * @param {Object}   props.changed   [ tab id => true ] for tabs with unsaved changes
 * @param {Function} props.onCopy    Copy the shortcode
 * @param {Function} props.onPreview Open the Preview
 * @param {Object}   props.children  The Save button
 */
const Header = ({ doc, setDoc, status, tabs, tab, onTab, warn, changed, onCopy, onPreview, children }) => {
	// title or description while it's being typed
	const [editing, setEditing] = useState('');
	const edit = (key, label, placeholder) => (
		<input
			className={'title' === key ? 'remaily-head__title-input' : 'remaily-head__description'}
			autoFocus
			value={doc[key]}
			placeholder={placeholder}
			aria-label={label}
			onChange={(e) => setDoc((d) => ({ ...d, [key]: e.target.value }))}
			onBlur={() => setEditing('')}
			onKeyDown={(e) => e.key === 'Enter' && setEditing('')}
		/>
	);

	return (
		<header className="remaily-card remaily-head">
			<div className="remaily-head__brand">
				<span className="remaily-logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: data.logo || '' }} />
				<div className="remaily-head__titles">
					{'title' === editing ? (
						edit('title', __( 'Form title', 'remaily' ))
					) : (
						<span className="remaily-head__title-row">
							<button type="button" className="remaily-head__title" onClick={() => setEditing('title')}>
								{doc.title || __( 'Untitled form', 'remaily' )}
								<Icon name="pencil" />
							</button>
							{'draft' === status && <span className="remaily-head__status">{__( 'Draft', 'remaily' )}</span>}
						</span>
					)}
					{'description' === editing ? (
						edit('description', __( 'Description', 'remaily' ), __( 'Add a note about this form', 'remaily' ))
					) : (
						<button type="button" className="remaily-head__note" onClick={() => setEditing('description')}>
							{doc.description || __( 'Add a note about this form', 'remaily' )}
							<Icon name="pencil" />
						</button>
					)}
				</div>
			</div>
			<div className="remaily-head__actions">
				<Button icon="copy" onClick={onCopy}>
					{__( 'Copy shortcode', 'remaily' )}
				</Button>
				{children}
			</div>
			<nav className="remaily-head__tabs" role="tablist">
				{tabs.map(([id, label]) => (
					<button key={id} type="button" role="tab" aria-selected={tab === id} className={`remaily-tab${tab === id ? ' is-active' : ''}`} onClick={() => onTab(id)}>
						{warn[id] && (
							<span className="remaily-tab__problem" title={__( 'Something here needs checking', 'remaily' )}>
								<Icon name="warning" />
							</span>
						)}
						{label}
						{changed[id] && <span className="remaily-tab__dot" title={__( 'Unsaved changes', 'remaily' )} />}
					</button>
				))}
				<div className="remaily-head__ai">
					<Button variant="dark" icon="eye" onClick={onPreview}>
						{__( 'Preview', 'remaily' )}
					</Button>
				</div>
			</nav>
		</header>
	);
};

export default Header;
