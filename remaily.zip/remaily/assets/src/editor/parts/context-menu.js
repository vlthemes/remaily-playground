/**
 * The code's right-click menu: duplicate or remove the chip under the pointer, wrap the selection in a group, edit
 * the group around the pointer or ungroup it
 */
import { __, sprintf } from '@wordpress/i18n';
import { Icon } from '../icons.js';
import { isInfo, places } from '../state.js';

/**
 * @param {Object}   props
 * @param {Object}   props.menu        { x, y, chip?: { inner, pos, length }, canWrap?, group?: { name } }
 * @param {Function} props.onClose     Close it
 * @param {Function} props.onDuplicate ( chip )
 * @param {Function} props.onRemove    ( chip )
 * @param {Function} props.onWrap      Wrap the selection in a group
 * @param {Function} props.onEditGroup ( name )
 * @param {Function} props.onUngroup   ( name )
 */
const ContextMenu = ({ menu, onClose, onDuplicate, onRemove, onWrap, onEditGroup, onUngroup }) => {
	// Each item closes the menu, then does its job
	const item = (icon, label, run, key = label) => (
		<button
			key={key}
			type="button"
			role="menuitem"
			onClick={() => {
				onClose();
				run();
			}}
		>
			<Icon name={icon} />
			{label}
			{'group' === icon && <kbd>⌘G</kbd>}
		</button>
	);
	const { chip, group } = menu;

	return (
		<div className="remaily-menu" style={{ left: menu.x, top: menu.y }} role="menu" onClick={(e) => e.stopPropagation()}>
			{/* A field's chip can be copied; a place or a setting as text can't */}
			{chip && !isInfo(chip.inner) && !places[chip.inner] && item('copy', __( 'Duplicate field', 'remaily' ), () => onDuplicate(chip))}
			{chip && item('close', __( 'Remove', 'remaily' ), () => onRemove(chip))}
			{menu.canWrap && item('group', __( 'Wrap in group', 'remaily' ), onWrap)}
			{group && item('pencil', sprintf( /* translators: %s: group name */ __( 'Edit group "%s"', 'remaily' ), group.name ), () => onEditGroup(group.name))}
			{group && item('close', __( 'Ungroup', 'remaily' ), () => onUngroup(group.name), 'ungroup')}
		</div>
	);
};

export default ContextMenu;
