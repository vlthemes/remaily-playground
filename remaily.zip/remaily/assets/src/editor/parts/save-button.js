/**
 * Save, as published, with a menu beside it: Save as draft
 */
import { __ } from '@wordpress/i18n';
import { Button } from '../controls.js';
import { Icon } from '../icons.js';

const SaveButton = ({ saving, open, onToggle, onSave, up, status }) => (
	<span className={`remaily-save${open ? ' is-open' : ''}${up ? ' is-up' : ''}`}>
		<Button variant="primary" icon="save" onClick={() => onSave('publish')} disabled={saving}>
			{saving ? __( 'Saving…', 'remaily' ) : __( 'Save', 'remaily' )}
		</Button>
		<button type="button" className="remaily-save__caret" aria-haspopup="menu" aria-expanded={open} aria-label={__( 'More ways to save', 'remaily' )} onClick={onToggle} disabled={saving}>
			<Icon name="chevron" />
		</button>
		{open && (
			<span className="remaily-save__menu" role="menu">
				{[
					['publish', __( 'Save and publish', 'remaily' ), __( 'The form shows wherever it is placed.', 'remaily' )],
					['draft', __( 'Save as draft', 'remaily' ), __( 'Kept off the site until you publish it.', 'remaily' )],
				].map(([value, title, text]) => (
					<button key={value} type="button" role="menuitemradio" aria-checked={status === value} className={status === value ? 'is-current' : ''} onClick={() => onSave(value)}>
						<span className="remaily-save__text">
							<strong>{title}</strong>
							<span>{text}</span>
						</span>
						{status === value && <Icon name="check" className="remaily-save__check" />}
					</button>
				))}
			</span>
		)}
	</span>
);

export default SaveButton;
