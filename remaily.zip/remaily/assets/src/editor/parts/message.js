/**
 * A message with the form's tags (a Telegram or WhatsApp text, a confirmation email): the text, and under it the form's
 * fields and a few everyday tags to click in where the cursor is. An add-on asks for it with 'tags' => true on a
 * textarea of its Controls tree
 */
import { useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Field } from '../controls.js';
import { typeOf } from '../state.js';

let uid = 0;

// The tags most messages need, named in plain words; the Mail tab lists every one
const EVERYDAY = [
	['_all_fields', __( 'All fields', 'remaily' ), __( 'Every field that has a value, a line each: "Your name: Ann"', 'remaily' )],
	['_form_title', __( 'Form title', 'remaily' ), ''],
	['_site_title', __( 'Site name', 'remaily' ), ''],
	['_date', __( 'Date', 'remaily' ), __( 'The day it was sent', 'remaily' )],
	['_time', __( 'Time', 'remaily' ), __( 'The time it was sent', 'remaily' )],
	['_url', __( 'Page', 'remaily' ), __( 'The address of the page it was sent from', 'remaily' )],
];

const Chip = ({ label, title, onClick }) => (
	<button type="button" className="remaily-chip is-info" title={title} onMouseDown={(e) => e.preventDefault()} onClick={onClick}>
		<span className="remaily-chip__name">{label}</span>
	</button>
);

/**
 * @param {Object}   props
 * @param {string}   props.label       Label
 * @param {string}   props.help        Help
 * @param {string}   props.value       Text
 * @param {Function} props.onChange    ( text )
 * @param {Object}   props.fields      The form's fields, [ name => settings ]
 * @param {number}   props.rows        Rows
 * @param {string}   props.placeholder Placeholder
 */
const Message = ({ label, help, value, onChange, fields = {}, rows = 5, placeholder }) => {
	const input = useRef(null);
	const id = useRef(`remaily-message-${++uid}`).current;
	const text = value ?? '';
	// Fields that send something: a Submit or an Output has no value to show
	const names = Object.entries(fields)
		.filter(([, field]) => typeOf(field?.type)?.submits)
		.map(([name]) => name);

	// The tag goes where the cursor is, in place of what is selected
	const put = (tag) => {
		const el = input.current;
		const from = el?.selectionStart ?? text.length;
		const to = el?.selectionEnd ?? text.length;

		onChange(text.slice(0, from) + tag + text.slice(to));
		requestAnimationFrame(() => {
			el?.focus();
			el?.setSelectionRange(from + tag.length, from + tag.length);
		});
	};

	return (
		<Field label={label} help={help} id={id}>
			<textarea ref={input} id={id} className="remaily-input" rows={rows} value={text} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
			{names.length > 0 && (
				<div className="remaily-message__row">
					<span className="remaily-message__title">{__( 'Fields', 'remaily' )}</span>
					<div className="remaily-info-chips">
						{names.map((name) => (
							<Chip key={name} label={name} title={`[${name}]`} onClick={() => put(`[${name}]`)} />
						))}
					</div>
				</div>
			)}
			<div className="remaily-message__row">
				<span className="remaily-message__title">{__( 'Also', 'remaily' )}</span>
				<div className="remaily-info-chips">
					{EVERYDAY.map(([tag, name, title]) => (
						<Chip key={tag} label={name} title={title ? `[${tag}]: ${title}` : `[${tag}]`} onClick={() => put(`[${tag}]`)} />
					))}
				</div>
			</div>
		</Field>
	);
};

export default Message;
