/**
 * Mail tab: Mail and Mail 2, and the tags they can use
 */
import { useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { ChipsControl, Textarea, Text, Toggle } from '../controls.js';
import data, { mailProblems, placed, typeOf } from '../state.js';

const MailPanel = ({ title, intro, mail, onChange, focus, files }) => {
	const set = (key, value) => onChange({ ...mail, [key]: value });
	const bind = (key) => ({ value: mail[key], onChange: (v) => set(key, v), onFocus: (e) => (focus.current = { el: e.target, key, set }) });

	return (
		<section className="remaily-panel">
			<h2 className="remaily-panel__title">{title}</h2>
			{intro && <p className="remaily-panel__intro">{intro}</p>}
			<div className="remaily-panel__grid">
				<Text label={__( 'To', 'remaily' )} help={__( 'Who gets this mail. Several addresses: separate them with commas. Tags work, such as [your_email]. A select, radio or checkbox tag gives its options\' values here, so "sales@example.com : Sales" sends to sales@example.com.', 'remaily' )} {...bind('to')} />
				<Text label={__( 'From', 'remaily' )} help={__( 'Use an address on your own domain, or mail servers may treat the mail as spam.', 'remaily' )} {...bind('from')} />
			</div>
			<Text label={__( 'Subject', 'remaily' )} help={__( 'The subject line. Tags work here too.', 'remaily' )} {...bind('subject')} />
			<Textarea label={__( 'Additional headers', 'remaily' )} help={__( 'One per line, such as Reply-To: [your_email] or Cc: someone@example.com.', 'remaily' )} rows={2} mono {...bind('headers')} />
			<Textarea label={__( 'Message', 'remaily' )} help={__( 'The text of the mail. Tags in square brackets are replaced with what visitors sent; click one on the right to add it.', 'remaily' )} rows={10} mono {...bind('body')} />
			{/* The form's File fields as chips; text that isn't only their tags stays in a box as it was written */}
			{files.length > 0 && (!String(mail.attachments || '').trim() || String(mail.attachments).split(/[\s,;]+/).filter(Boolean).every((tag) => files.includes(tag.replace(/^\[|\]$/g, '')))) ? (
				<ChipsControl
					label={__( 'Attach the files sent with', 'remaily' )}
					help={__( 'The files visitors upload go with this mail.', 'remaily' )}
					value={mail.attachments}
					options={Object.fromEntries(files.map((name) => [`[${name}]`, name]))}
					placeholder={__( 'Pick a file field', 'remaily' )}
					onChange={(v) => set('attachments', v)}
				/>
			) : (
				String(mail.attachments || '').trim() && <Textarea label={__( 'Attachments', 'remaily' )} help={__( 'The tags of file fields whose files go with the mail, such as [your_file].', 'remaily' )} rows={2} mono {...bind('attachments')} />
			)}
			<Toggle label={__( 'Send as HTML', 'remaily' )} help={__( 'Line breaks become paragraphs and the mail gets a simple layout. Off: plain text.', 'remaily' )} checked={mail.html} onChange={(v) => set('html', v)} />
		</section>
	);
};

const MailTab = ({ config, template, update }) => {
	const focus = useRef(null);
	const fields = placed(template).fields.filter((n) => typeOf(config.fields[n]?.type)?.submits);
	const files = fields.filter((n) => config.fields[n]?.type === 'file');
	const insert = (tag) => {
		const target = focus.current;

		if (!target?.el?.isConnected) {
			navigator.clipboard?.writeText(tag);

			return;
		}

		const { el, set } = target;
		const start = el.selectionStart ?? el.value.length;
		const value = el.value.slice(0, start) + tag + el.value.slice(el.selectionEnd ?? start);

		set(target.key, value);
		requestAnimationFrame(() => {
			el.focus();
			el.setSelectionRange(start + tag.length, start + tag.length);
		});
	};

	const problems = mailProblems(config, template);

	return (
		<div className="remaily-mail">
			<div className="remaily-mail__main">
				{problems.length > 0 && (
					<section className="remaily-panel remaily-problems" role="alert">
						<h2 className="remaily-panel__title">{__( 'Check these before saving', 'remaily' )}</h2>
						<ul>
							{problems.map((problem, i) => (
								<li key={i}>
									<strong>{problem.mail}:</strong> {problem.text}
								</li>
							))}
						</ul>
					</section>
				)}
				<MailPanel title={__( 'Mail', 'remaily' )} mail={config.mail} focus={focus} files={files} onChange={(v) => update('mail', v)} />
				<section className="remaily-panel">
					<Toggle
						label={__( 'Send Mail 2', 'remaily' )}
						help={__( 'A second mail sent after the first one, often a copy for the person who filled in the form.', 'remaily' )}
						checked={config.mail_2.active}
						onChange={(v) => update('mail_2', { ...config.mail_2, active: v })}
					/>
				</section>
				{config.mail_2.active && <MailPanel title={__( 'Mail 2', 'remaily' )} mail={config.mail_2} focus={focus} files={files} onChange={(v) => update('mail_2', v)} />}
			</div>
			<aside className="remaily-mail__tags">
				<h3>{__( 'Tags', 'remaily' )}</h3>
				<p>{__( 'Click a tag to put it where your cursor is.', 'remaily' )}</p>
				<div className="remaily-tags">
					{fields.map((name) => (
						<button type="button" key={name} className="remaily-tag is-field" onMouseDown={(e) => e.preventDefault()} onClick={() => insert(`[${name}]`)}>
							[{name}]
						</button>
					))}
				</div>
				<h4>{__( 'Site and visitor', 'remaily' )}</h4>
				<div className="remaily-tags">
					{(data.specialTags || []).map((tag) => (
						<button type="button" key={tag} className="remaily-tag" onMouseDown={(e) => e.preventDefault()} onClick={() => insert(`[${tag}]`)}>
							[{tag}]
						</button>
					))}
				</div>
				<p className="remaily-mail__hint">{__( '[_raw_name] prints the values of options instead of their labels. [group:name] … [/group:name] prints its text only when the group was shown.', 'remaily' )}</p>
			</aside>
		</div>
	);
};

export default MailTab;
