/**
 * Advanced tab: the form's look, where it goes after sending, and how it behaves
 */
import { createInterpolateElement, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Select, Text, Textarea, Toggle } from '../controls.js';
import data from '../state.js';
import CaptchaPick from '../parts/captcha-pick.js';

/**
 * Copy to another site: this form's code to copy, and a box to paste another site's code into this form
 */
const FormCode = ({ code, onCopy, onPaste }) => {
	const [pasted, setPasted] = useState('');
	const [error, setError] = useState('');

	return (
		<section className="remaily-panel">
			<h2 className="remaily-panel__title">{__( 'Copy to another site', 'remaily' )}</h2>
			<Textarea
				label={__( 'This form\'s code', 'remaily' )}
				help={__( 'The whole form: its markup, fields, mails, messages and settings. Copy it here, then paste it into a form on the other site, such as a new one from Add New.', 'remaily' )}
				rows={4}
				mono
				readOnly
				value={code}
				onFocus={(e) => e.target.select()}
				onChange={() => {}}
			/>
			<Button icon="copy" onClick={onCopy}>
				{__( 'Copy form code', 'remaily' )}
			</Button>
			<Textarea
				label={__( 'Paste form code', 'remaily' )}
				help={__( 'Code copied from a form on another site. It replaces everything in this form; nothing is saved until you click Save.', 'remaily' )}
				rows={4}
				mono
				placeholder='{ "remaily": 1, … }'
				value={pasted}
				onChange={(v) => {
					setPasted(v);
					setError('');
				}}
			/>
			{error && <p className="remaily-side__error">{error}</p>}
			<Button
				disabled={!pasted.trim()}
				onClick={() => {
					// eslint-disable-next-line no-alert
					if (!window.confirm(__( 'Replace everything in this form with the pasted code?', 'remaily' ))) {
						return;
					}

					const problem = onPaste(pasted);

					setError(problem);

					if (!problem) {
						setPasted('');
					}
				}}
			>
				{__( 'Replace this form', 'remaily' )}
			</Button>
		</section>
	);
};

const AdvancedTab = ({ config, update, formCode, onCopy, onPaste }) => {
	const settings = config.settings;
	const set = (key, value) => update('settings', { ...settings, [key]: value });

	return (
		<>
			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Look and redirect', 'remaily' )}</h2>
				<Select
					label={__( 'Form style', 'remaily' )}
					help={__( 'Re:Maily style: the plugin draws the form and its fields. Inherit from theme: no Re:Maily CSS, your theme styles everything. A field can still pick a style of its own, and your theme can add styles in its remaily/ folder.', 'remaily' )}
					value={settings.style}
					options={data.formStyles || { default: __( 'Re:Maily style', 'remaily' ) }}
					onChange={(v) => set('style', v)}
				/>
				<Text
					label={__( 'Page to open after sending', 'remaily' )}
					help={__( 'A thank-you page, for example. Leave empty to stay on the page and show the message.', 'remaily' )}
					type="url"
					placeholder="https://"
					value={settings.redirect}
					onChange={(v) => set('redirect', v)}
				/>
				<Text label={__( 'CSS classes', 'remaily' )} help={__( "Added to the form's wrapper.", 'remaily' )} value={settings.class} onChange={(v) => set('class', v)} />
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Behavior', 'remaily' )}</h2>
				<Toggle
					label={__( 'Save entries', 'remaily' )}
					help={__( 'Keeps a copy of every message in Contact Form → Entries, even when the mail fails.', 'remaily' )}
					checked={settings.store_entries}
					onChange={(v) => set('store_entries', v)}
				/>
				<Toggle
					label={__( 'Hide the success message after a few seconds', 'remaily' )}
					help={__( 'The "sent" message fades out after 5 seconds. Error messages stay until the visitor fixes them.', 'remaily' )}
					checked={!!settings.hide_success}
					onChange={(v) => set('hide_success', v)}
				/>
				<Toggle
					label={__( 'Browser autofill', 'remaily' )}
					help={__( 'Lets browsers suggest saved names, emails and addresses. Some browsers still offer saved addresses when it is off.', 'remaily' )}
					checked={settings.autocomplete}
					onChange={(v) => set('autocomplete', v)}
				/>
				<Toggle
					label={__( 'Logged-in users only', 'remaily' )}
					help={__( 'Visitors who are not logged in see a message instead of the form. You can change it in the Messages tab.', 'remaily' )}
					checked={settings.subscribers_only}
					onChange={(v) => set('subscribers_only', v)}
				/>
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Spam', 'remaily' )}</h2>
				{Object.keys(data.captchas || {}).length > 0 ? (
					<CaptchaPick captchas={data.captchas} value={settings.captcha || ''} onChange={(v) => set('captcha', v)} />
				) : (
					<p className="remaily-panel__intro">
						{createInterpolateElement(__( 'Add the keys of Cloudflare Turnstile, hCaptcha, Yandex SmartCaptcha or reCAPTCHA in <a>Settings → Spam</a> to use a captcha.', 'remaily' ), {
							a: <a href={data.settingsUrl} />,
						})}
					</p>
				)}
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Webhooks', 'remaily' )}</h2>
				<Textarea
					label={__( 'Send each message to', 'remaily' )}
					help={
						data.canWebhooks
							? __( 'Web addresses, one per line. Each message that goes through is posted to them as JSON: the form, the entry, every field (labels and raw values) and the page it came from. Use it with Zapier, Make, n8n or your own code. Addresses on your own network are refused.', 'remaily' )
							: __( 'Only administrators can change these: they send visitors\' messages to other servers.', 'remaily' )
					}
					rows={3}
					mono
					readOnly={!data.canWebhooks}
					placeholder="https://"
					value={(settings.webhooks || []).join('\n')}
					onChange={(v) => set('webhooks', v.split('\n'))}
				/>
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Testing', 'remaily' )}</h2>
				<Toggle
					label={__( 'Test mode', 'remaily' )}
					help={
						data.testMode
							? __( 'On for every form: REMAILY_TEST_MODE is set in wp-config.php. Remove it there to turn it off.', 'remaily' )
							: __( 'Fields are checked as usual, then nothing is sent or saved and visitors see the "sent" message. Turn it off before the site goes live.', 'remaily' )
					}
					checked={data.testMode || settings.demo}
					disabled={data.testMode}
					onChange={(v) => set('demo', v)}
				/>
				<Toggle
					label={__( "Don't send mail", 'remaily' )}
					help={
						data.mailOff
							? __( 'On for every form: REMAILY_DISABLE_MAIL is set in wp-config.php. Entries are still saved. Remove it there to send mail again.', 'remaily' )
							: __( 'No mail goes out, but entries are still saved.', 'remaily' )
					}
					checked={data.mailOff || settings.skip_mail}
					disabled={data.mailOff}
					onChange={(v) => set('skip_mail', v)}
				/>
				<p className="remaily-panel__intro">
					{__( "To test every form at once, on a staging site for example, add define( 'REMAILY_TEST_MODE', true ); or define( 'REMAILY_DISABLE_MAIL', true ); to wp-config.php.", 'remaily' )}
				</p>
			</section>

			<FormCode code={formCode} onCopy={onCopy} onPaste={onPaste} />
		</>
	);
};

export default AdvancedTab;
