/**
 * Advanced tab: the form's look, where it goes after sending, and how it behaves
 */
import apiFetch from '@wordpress/api-fetch';
import { createInterpolateElement, useEffect, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Field, Select, Text, Textarea, Toggle } from '../controls.js';
import data from '../state.js';

/**
 * Copy to another site: this form's code to copy, and a box to paste another site's code into this form
 */
const FormCode = ({ code, onCopy, onPaste }) => {
	const [pasted, setPasted] = useState('');
	const [error, setError] = useState('');

	return (
		<section className="remaily-panel">
			<h2 className="remaily-panel__title">{__( 'Copy to another site', 'remaily' )}</h2>
			<Textarea
				label={__( 'This form\'s code', 'remaily' )}
				help={__( 'The whole form: its markup, fields, mails, messages and settings. Copy it here, then paste it into a form on the other site, such as a new one from Add New.', 'remaily' )}
				rows={4}
				mono
				readOnly
				value={code}
				onFocus={(e) => e.target.select()}
				onChange={() => {}}
			/>
			<Button icon="copy" onClick={onCopy}>
				{__( 'Copy form code', 'remaily' )}
			</Button>
			<Textarea
				label={__( 'Paste form code', 'remaily' )}
				help={__( 'Code copied from a form on another site. It replaces everything in this form; nothing is saved until you click Save.', 'remaily' )}
				rows={4}
				mono
				placeholder='{ "remaily": 1, … }'
				value={pasted}
				onChange={(v) => {
					setPasted(v);
					setError('');
				}}
			/>
			{error && <p className="remaily-side__error">{error}</p>}
			<Button
				disabled={!pasted.trim()}
				onClick={() => {
					// eslint-disable-next-line no-alert
					if (!window.confirm(__( 'Replace everything in this form with the pasted code?', 'remaily' ))) {
						return;
					}

					const problem = onPaste(pasted);

					setError(problem);

					if (!problem) {
						setPasted('');
					}
				}}
			>
				{__( 'Replace this form', 'remaily' )}
			</Button>
		</section>
	);
};

/**
 * Brevo: the lists the sender joins, which field is the email, a consent box, attributes, a welcome template and
 * double opt-in (Integrations\Brevo)
 */
const BrevoPanel = ({ settings, set, fields }) => {
	const [account, setAccount] = useState(null);
	const [error, setError] = useState('');
	const lists = account?.lists;
	const names = (types) => Object.entries(fields).filter(([, field]) => types.includes(field.type)).map(([name]) => name);
	const picked = settings.brevo_lists || [];

	useEffect(() => {
		if (data.brevo) {
			apiFetch({ path: '/remaily/v1/brevo' })
				.then(setAccount)
				.catch((err) => setError(err.message || ''));
		}
	}, []);

	return (
		<section className="remaily-panel">
			<h2 className="remaily-panel__title has-logo">
				<span className="remaily-panel__logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: data.brevoLogo }} />
				Brevo
			</h2>
			{!data.brevo ? (
				<p className="remaily-panel__intro">
					{createInterpolateElement(__( 'Add your Brevo API key in <a>Settings → Integrations</a> to put the people who write to you on your Brevo lists.', 'remaily' ), {
						a: <a href={`${data.settingsUrl}#integrations`} />,
					})}
				</p>
			) : (
				<>
					<Field label={__( 'Add the sender to', 'remaily' )} help={__( 'Brevo lists. None picked: this form sends nothing to Brevo.', 'remaily' )}>
						{error && <p className="remaily-side__error">{error}</p>}
						{!error && !lists && <p className="remaily-panel__intro">{__( 'Loading your lists…', 'remaily' )}</p>}
						{lists?.length === 0 && <p className="remaily-panel__intro">{__( 'Your Brevo account has no lists yet.', 'remaily' )}</p>}
						{lists?.map((list) => (
							<Toggle
								key={list.id}
								label={list.name}
								checked={picked.includes(list.id)}
								onChange={(on) => set('brevo_lists', on ? [...picked, list.id] : picked.filter((id) => id !== list.id))}
							/>
						))}
					</Field>
					<Select
						label={__( 'Email field', 'remaily' )}
						value={settings.brevo_email || ''}
						options={{ '': __( 'The first Email field', 'remaily' ), ...Object.fromEntries(names(['email']).map((name) => [name, name])) }}
						onChange={(v) => set('brevo_email', v)}
					/>
					<Select
						label={__( 'Only when ticked', 'remaily' )}
						help={__( 'An Acceptance or Checkbox field the visitor ticks to agree to your emails. Leave it on Always if the form itself is a sign-up.', 'remaily' )}
						value={settings.brevo_consent || ''}
						options={{ '': __( 'Always', 'remaily' ), ...Object.fromEntries(names(['acceptance', 'checkbox']).map((name) => [name, name])) }}
						onChange={(v) => set('brevo_consent', v)}
					/>
					<Textarea
						label={__( 'Contact attributes', 'remaily' )}
						help={__( 'One per line: a Brevo attribute, =, and mail tags. Left empty, Re:Maily fills FIRSTNAME and LASTNAME from a name field and SMS from a Tel field.', 'remaily' )}
						rows={3}
						mono
						placeholder={'FIRSTNAME = [your_name]'}
						value={settings.brevo_attributes || ''}
						onChange={(v) => set('brevo_attributes', v)}
					/>
					<Select
						label={__( 'Welcome email', 'remaily' )}
						help={__( 'A Brevo template sent to new contacts only, not to people already in Brevo.', 'remaily' )}
						value={String(settings.brevo_template || 0)}
						options={{ 0: __( 'None', 'remaily' ), ...Object.fromEntries((account?.templates || []).map((t) => [t.id, t.name])) }}
						onChange={(v) => set('brevo_template', Number(v))}
					/>
					<Toggle
						label={__( 'Ask new contacts to confirm their email', 'remaily' )}
						help={__( 'Double opt-in: people not in Brevo yet get an email with a link and are added once they open it. The link works for 7 days.', 'remaily' )}
						checked={settings.brevo_doi}
						onChange={(v) => set('brevo_doi', v)}
					/>
					{settings.brevo_doi && (
						<>
							<Text label={__( 'Confirmation email subject', 'remaily' )} value={settings.brevo_doi_subject} onChange={(v) => set('brevo_doi_subject', v)} />
							<Textarea
								label={__( 'Confirmation email', 'remaily' )}
								help={__( '[confirm_link] is the link to open. The form\'s mail tags work too.', 'remaily' )}
								rows={6}
								value={settings.brevo_doi_body}
								onChange={(v) => set('brevo_doi_body', v)}
							/>
							<Text
								label={__( 'Page after confirming', 'remaily' )}
								help={__( 'A thank-you page on this site. Leave empty for a short "Your email is confirmed" note.', 'remaily' )}
								type="url"
								placeholder="https://"
								value={settings.brevo_doi_redirect}
								onChange={(v) => set('brevo_doi_redirect', v)}
							/>
						</>
					)}
				</>
			)}
		</section>
	);
};

const AdvancedTab = ({ config, update, formCode, onCopy, onPaste }) => {
	const settings = config.settings;
	const set = (key, value) => update('settings', { ...settings, [key]: value });

	return (
		<>
			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Look and redirect', 'remaily' )}</h2>
				<Select
					label={__( 'Form style', 'remaily' )}
					help={__( 'Re:Maily style: the plugin draws the form and its fields. Inherit from theme: no Re:Maily CSS, your theme styles everything. A field can still pick a style of its own, and your theme can add styles in its remaily/ folder.', 'remaily' )}
					value={settings.style}
					options={data.formStyles || { default: __( 'Re:Maily style', 'remaily' ) }}
					onChange={(v) => set('style', v)}
				/>
				<Text
					label={__( 'Page to open after sending', 'remaily' )}
					help={__( 'A thank-you page, for example. Leave empty to stay on the page and show the message.', 'remaily' )}
					type="url"
					placeholder="https://"
					value={settings.redirect}
					onChange={(v) => set('redirect', v)}
				/>
				<Text label={__( 'CSS classes', 'remaily' )} help={__( "Added to the form's wrapper.", 'remaily' )} value={settings.class} onChange={(v) => set('class', v)} />
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Behavior', 'remaily' )}</h2>
				<Toggle
					label={__( 'Save entries', 'remaily' )}
					help={__( 'Keeps a copy of every message in Contact Form → Entries, even when the mail fails.', 'remaily' )}
					checked={settings.store_entries}
					onChange={(v) => set('store_entries', v)}
				/>
				<Toggle
					label={__( 'Browser autofill', 'remaily' )}
					help={__( 'Lets browsers suggest saved names, emails and addresses. Some browsers still offer saved addresses when it is off.', 'remaily' )}
					checked={settings.autocomplete}
					onChange={(v) => set('autocomplete', v)}
				/>
				<Toggle
					label={__( 'Logged-in users only', 'remaily' )}
					help={__( 'Visitors who are not logged in see a message instead of the form. You can change it in the Messages tab.', 'remaily' )}
					checked={settings.subscribers_only}
					onChange={(v) => set('subscribers_only', v)}
				/>
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Spam', 'remaily' )}</h2>
				{Object.keys(data.captchas || {}).length > 0 ? (
					<>
						<div className="remaily-picks" aria-label={__( 'Captchas on every form', 'remaily' )}>
							{Object.entries(data.captchas).map(([id, captcha]) => (
								<span key={id} className={`remaily-pick${settings.captcha_off ? '' : ' is-on'}`}>
									<span className="remaily-pick__logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: captcha.logo }} />
									{captcha.label}
								</span>
							))}
						</div>
						<Toggle
							label={__( 'Skip the captchas on this form', 'remaily' )}
							help={createInterpolateElement(__( 'The captchas above run on every form, set up in <a>Settings → Spam</a>. They go before the submit button, or where you put [[captcha]] in the code.', 'remaily' ), {
								a: <a href={data.settingsUrl} />,
							})}
							checked={settings.captcha_off}
							onChange={(v) => set('captcha_off', v)}
						/>
					</>
				) : (
					<p className="remaily-panel__intro">
						{createInterpolateElement(__( 'Add the keys of Cloudflare Turnstile, hCaptcha or reCAPTCHA in <a>Settings → Spam</a> and they run on every form.', 'remaily' ), {
							a: <a href={data.settingsUrl} />,
						})}
					</p>
				)}
			</section>

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Webhooks', 'remaily' )}</h2>
				<Textarea
					label={__( 'Send each message to', 'remaily' )}
					help={
						data.canWebhooks
							? __( 'Web addresses, one per line. Each message that goes through is posted to them as JSON: the form, the entry, every field (labels and raw values) and the page it came from. Use it with Zapier, Make, n8n or your own code. Addresses on your own network are refused.', 'remaily' )
							: __( 'Only administrators can change these: they send visitors\' messages to other servers.', 'remaily' )
					}
					rows={3}
					mono
					readOnly={!data.canWebhooks}
					placeholder="https://"
					value={(settings.webhooks || []).join('\n')}
					onChange={(v) => set('webhooks', v.split('\n'))}
				/>
			</section>

			<BrevoPanel settings={settings} set={set} fields={config.fields} />

			<section className="remaily-panel">
				<h2 className="remaily-panel__title">{__( 'Testing', 'remaily' )}</h2>
				<Toggle
					label={__( 'Test mode', 'remaily' )}
					help={
						data.testMode
							? __( 'On for every form: REMAILY_TEST_MODE is set in wp-config.php. Remove it there to turn it off.', 'remaily' )
							: __( 'Fields are checked as usual, then nothing is sent or saved and visitors see the "sent" message. Turn it off before the site goes live.', 'remaily' )
					}
					checked={data.testMode || settings.demo}
					disabled={data.testMode}
					onChange={(v) => set('demo', v)}
				/>
				<Toggle
					label={__( "Don't send mail", 'remaily' )}
					help={
						data.mailOff
							? __( 'On for every form: REMAILY_DISABLE_MAIL is set in wp-config.php. Entries are still saved. Remove it there to send mail again.', 'remaily' )
							: __( 'No mail goes out, but entries are still saved.', 'remaily' )
					}
					checked={data.mailOff || settings.skip_mail}
					disabled={data.mailOff}
					onChange={(v) => set('skip_mail', v)}
				/>
				<p className="remaily-panel__intro">
					{__( "To test every form at once, on a staging site for example, add define( 'REMAILY_TEST_MODE', true ); or define( 'REMAILY_DISABLE_MAIL', true ); to wp-config.php.", 'remaily' )}
				</p>
			</section>

			<FormCode code={formCode} onCopy={onCopy} onPaste={onPaste} />
		</>
	);
};

export default AdvancedTab;
