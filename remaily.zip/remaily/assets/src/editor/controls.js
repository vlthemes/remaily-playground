/**
 * Small controls of the sidebar and the tabs, in the editor's own look
 */
import { useLayoutEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Icon } from './icons.js';

let uid = 0;
const useId = (prefix) => useState(() => `remaily-${prefix}-${++uid}`)[0];

// The label row (label, then right after it the "i" shown on hover), the folded tip under it, then the control; a
// toggle's tip goes under the toggle
export const Field = ({ label, help, id, children, inline = false }) => {
	const [open, setOpen] = useState(false);
	const info = help && (
		<button type="button" className={`remaily-field-row__info${open ? ' is-active' : ''}`} aria-expanded={open} aria-label={__( 'Help', 'remaily' )} onClick={() => setOpen(!open)}>
			i
		</button>
	);
	const tip = help && open && <p className="remaily-field-row__help">{help}</p>;

	if (inline) {
		return (
			<div className="remaily-field-row is-inline">
				<div className="remaily-field-row__head">
					{children}
					{info}
				</div>
				{tip}
			</div>
		);
	}

	return (
		<div className="remaily-field-row">
			{(label || info) && (
				<div className="remaily-field-row__head">
					{label && (
						<label className="remaily-field-row__label" htmlFor={id}>
							{label}
						</label>
					)}
					{info}
				</div>
			)}
			{tip}
			{children}
		</div>
	);
};

export const Text = ({ label, help, value, onChange, ...rest }) => {
	const id = useId('text');

	return (
		<Field label={label} help={help} id={id}>
			<input id={id} className="remaily-input" type="text" value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

/**
 * A text with values to put in it ({count}, {value}): chips under the input add one where the cursor is.
 * tokens is { '{count}': label }; note is a line under the chips (a value that stays empty, say)
 */
export const FormatControl = ({ label, help, value, onChange, tokens, note }) => {
	const id = useId('format');
	const input = useRef(null);
	const add = (token) => {
		const el = input.current;
		const text = value ?? '';
		const from = el?.selectionStart ?? text.length;
		const to = el?.selectionEnd ?? text.length;

		onChange(text.slice(0, from) + token + text.slice(to));
		// After React has put the new value in
		requestAnimationFrame(() => {
			el?.focus();
			el?.setSelectionRange(from + token.length, from + token.length);
		});
	};

	return (
		<Field label={label} help={help} id={id}>
			<input ref={input} id={id} className="remaily-input" type="text" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
			<div className="remaily-info-chips is-under">
				{Object.entries(tokens || {}).map(([token, name]) => (
					<button type="button" key={token} className="remaily-chip is-info" onMouseDown={(e) => e.preventDefault()} onClick={() => add(token)}>
						<Icon name="plus" />
						<span className="remaily-chip__name">{name}</span>
					</button>
				))}
			</div>
			{note && <p className="remaily-side__note">{note}</p>}
		</Field>
	);
};

// How far the ruler moves for one step, px
const TURN = 2;

// A number with a ruler under it: drag the ruler sideways or step with its arrows
// (Shift: by 10). Empty stays empty
export const NumberInput = ({ label, help, value, onChange, step = 1, min = 0, max }) => {
	// Within min and max: over max as soon as it's typed, under min once the input is left (typing 1 on the way to 10)
	const limit = (number) => Math.max(min, max === undefined ? number : Math.min(max, number));
	const id = useId('number');
	const track = useRef(null);
	const drag = useRef(null);
	const spin = useRef(0);
	const [dragging, setDragging] = useState(false);
	const shown = value === 0 || value === '' || value === undefined || value === null ? '' : value;
	const current = () => parseFloat(drag.current?.value ?? shown) || 0;

	const turn = (steps) => {
		spin.current += steps * TURN;

		if (track.current) {
			track.current.style.backgroundPositionX = `${Math.round(spin.current)}px`;
		}
	};

	const set = (next) => onChange(String(limit(Math.round(next / step) * step)));

	const onPointerDown = (event) => {
		event.currentTarget.setPointerCapture(event.pointerId);
		drag.current = { x: event.clientX, value: current() };
		setDragging(true);
	};

	const onPointerMove = (event) => {
		if (!drag.current) {
			return;
		}

		// Let go where no pointerup came (out of the window): the drag is over
		if (!event.buttons) {
			onPointerUp();

			return;
		}

		const steps = (event.clientX - drag.current.x) * (event.shiftKey ? 10 : 1);

		drag.current.x = event.clientX;
		drag.current.value = limit(drag.current.value + steps * step);
		turn(steps);
		set(drag.current.value);
	};

	const onPointerUp = () => {
		drag.current = null;
		setDragging(false);
	};

	const stepBy = (event, direction) => {
		const delta = direction * step * (event.shiftKey ? 10 : 1);

		turn(delta / step);
		set(current() + delta);
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className={`remaily-number${dragging ? ' is-dragging' : ''}`}>
				<input
					id={id}
					className="remaily-input"
					type="number"
					min={min}
					max={max}
					step={step}
					value={shown}
					onChange={(e) => onChange(e.target.value !== '' && max !== undefined && Number(e.target.value) > max ? String(max) : e.target.value)}
					onBlur={(e) => e.target.value !== '' && Number(e.target.value) < min && onChange(String(min))}
				/>
				<div className="remaily-number__ruler">
					<button type="button" className="remaily-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, -1)}>
						◀
					</button>
					<span
						className="remaily-number__track"
						ref={track}
						title={__( 'Drag to change (Shift: faster)', 'remaily' )}
						onPointerDown={onPointerDown}
						onPointerMove={onPointerMove}
						onPointerUp={onPointerUp}
						onPointerCancel={onPointerUp}
						onLostPointerCapture={onPointerUp}
					/>
					<button type="button" className="remaily-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, 1)}>
						▶
					</button>
				</div>
			</div>
		</Field>
	);
};

export const Textarea = ({ label, help, value, onChange, rows = 4, mono = false, ...rest }) => {
	const id = useId('textarea');

	return (
		<Field label={label} help={help} id={id}>
			<textarea id={id} className={`remaily-input${mono ? ' is-mono' : ''}`} rows={rows} value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

// Text edited as lines, parsed on each change but kept as typed while the field is open
export const LinesControl = ({ label, help, value, toText, fromText, onChange, rows = 4, placeholder }) => {
	const [text, setText] = useState(() => toText(value));

	return (
		<Textarea
			label={label}
			help={help}
			rows={rows}
			mono
			placeholder={placeholder}
			value={text}
			onChange={(next) => {
				setText(next);
				onChange(fromText(next));
			}}
		/>
	);
};

export const Select = ({ label, help, value, onChange, options }) => {
	const id = useId('select');

	// A saved value the list doesn't have (typed in before, or by an add-on) stays shown
	const list = value && !(value in options) ? { ...options, [value]: value } : options;

	return (
		<Field label={label} help={help} id={id}>
			<select id={id} className="remaily-input remaily-select" value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
				{Object.entries(list).map(([key, text]) => (
					<option key={key} value={key}>
						{text}
					</option>
				))}
			</select>
		</Field>
	);
};

/**
 * Whether options read best as radios: two or three short ones, each in sight. A schema's as ('radio', 'select')
 * decides instead, as on the Settings page
 *
 * @param {Object|Array} options [ key => label ] or [ { value, label } ]
 * @param {string}       as      The schema's choice
 * @return {boolean} Radios
 */
export const asRadios = (options, as) => {
	if (as) {
		return 'radio' === as;
	}

	const labels = Array.isArray(options) ? options.map((o) => o.label) : Object.values(options || {});

	return labels.length >= 2 && labels.length <= 3 && labels.every((text) => String(text).length <= 28);
};

// inline: side by side while they fit, else one a line
export const Radios = ({ label, help, value, onChange, options, inline = false }) => {
	const id = useId('radios');
	const list = Array.isArray(options) ? options : Object.entries(options || {}).map(([key, text]) => ({ value: key, label: text }));

	return (
		<Field label={label} help={help} id={id}>
			<span className={`remaily-radios${inline ? ' is-inline' : ''}`} role="radiogroup" id={id}>
				{list.map((option) => (
					<label className="remaily-check" key={option.value}>
						<input type="radio" name={id} checked={String(value ?? '') === String(option.value)} onChange={() => onChange(String(option.value))} />
						<span>{option.label}</span>
					</label>
				))}
			</span>
		</Field>
	);
};

/**
 * A select, or radios for a few short options (asRadios())
 */
export const Choice = ({ as, inline, ...props }) => (asRadios(props.options, as) ? <Radios {...props} inline={inline} /> : <Select {...props} />);

// A date setting: none, today, days from today (today+7, today-1) or a fixed YYYY-MM-DD; the site turns "today"
// into a date when the form is shown
const RELATIVE = /^today([+-]\d+)?$/;
const isoDay = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

export const DateControl = ({ label, help, value, onChange, empty }) => {
	const id = useId('date');
	const current = value || '';
	const relative = current.match(RELATIVE);
	let mode = 'date';

	if (!current) {
		mode = 'none';
	} else if (current === 'today') {
		mode = 'today';
	} else if (relative) {
		mode = 'offset';
	}

	const days = relative ? Number(relative[1] || 0) : 0;
	const preview = (offset) => {
		const date = new Date();

		date.setDate(date.getDate() + offset);

		return date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
	};

	const pick = (next) => {
		if (next === 'none') {
			onChange('');
		} else if (next === 'today') {
			onChange('today');
		} else if (next === 'offset') {
			onChange('today+7');
		} else {
			onChange(isoDay(new Date()));
		}
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className="remaily-date">
				<select id={id} className="remaily-input remaily-select" value={mode} onChange={(e) => pick(e.target.value)}>
					<option value="none">{empty || __( 'None', 'remaily' )}</option>
					<option value="today">{__( 'Today', 'remaily' )}</option>
					<option value="offset">{__( 'Days from today', 'remaily' )}</option>
					<option value="date">{__( 'A set date', 'remaily' )}</option>
				</select>

				{mode === 'date' && (
					<input className="remaily-input" type="date" aria-label={label} value={current} onChange={(e) => onChange(e.target.value)} />
				)}

				{mode === 'offset' && (
					<div className="remaily-date__offset">
						<input
							className="remaily-input"
							type="number"
							step="1"
							aria-label={__( 'Days from today', 'remaily' )}
							value={days}
							onChange={(e) => {
								const n = parseInt(e.target.value, 10) || 0;

								onChange(n ? `today${n > 0 ? '+' : ''}${n}` : 'today');
							}}
						/>
						<span>{__( 'days; a minus is before today', 'remaily' )}</span>
					</div>
				)}

				{(mode === 'today' || mode === 'offset') && (
					<p className="remaily-date__preview">
						{/* translators: %s: a date */ sprintf( __( 'Today that is %s. It moves with each day.', 'remaily' ), preview(days) )}
					</p>
				)}
			</div>
		</Field>
	);
};

// A country's flag: its two regional-indicator letters (Countries::flag())
const flag = (code) => String.fromCodePoint(...[...code.toUpperCase()].map((char) => 127397 + char.charCodeAt(0)));

/**
 * Values picked from a list: a chip each (remove button), in the order picked, and a search that adds more. The value
 * stays a comma-separated list, "us, ca, gb". options is { value: label }; icon( value ) draws before a label,
 * chip( value ) is a chip's text (the label by default); split is what separates the values in the saved text.
 * free also takes values typed in (Enter, a comma or leaving the box adds one), such as IDs with no list to pick from
 */
/**
 * A text input with suggestions in the editor's own list (a datalist the browser draws can't be styled): any text
 * goes, options are [ { value, label } ]
 */
export const Suggest = ({ value, onChange, options = [], placeholder, label }) => {
	const id = useId('suggest');
	const list = useRef(null);
	const [open, setOpen] = useState(false);
	const [active, setActive] = useState(-1);
	const q = String(value || '').trim().toLowerCase();
	// The whole list while the value is one of the options, so another can be picked
	const exact = options.some((option) => String(option.value).toLowerCase() === q);
	const matches = exact || !q ? options : options.filter((option) => `${option.value} ${option.label}`.toLowerCase().includes(q));
	const shown = open && matches.length > 0;

	// Room for the list: under the input, or over it when the panel (it scrolls, the footer under it) is short below
	useLayoutEffect(() => {
		const ul = list.current;

		if (!shown || !ul) {
			return;
		}

		const field = ul.previousElementSibling.closest('.remaily-suggest').getBoundingClientRect();
		let box = { top: 0, bottom: window.innerHeight };

		for (let el = ul.parentElement; el && el !== document.body; el = el.parentElement) {
			if (/(auto|scroll|hidden)/.test(getComputedStyle(el).overflowY)) {
				box = el.getBoundingClientRect();
				break;
			}
		}

		// The editor's footer sticks to the window's bottom, over the content
		const foot = document.querySelector('.remaily-foot')?.getBoundingClientRect();
		const floor = Math.min(box.bottom, window.innerHeight, foot && foot.top > field.bottom ? foot.top : Infinity);
		const below = floor - field.bottom - 12;
		const above = field.top - Math.max(box.top, 0) - 12;
		const up = below < Math.min(260, ul.scrollHeight) && above > below;

		ul.classList.toggle('is-up', up);
		ul.style.maxHeight = `${Math.max(120, Math.min(260, up ? above : below))}px`;
	}, [shown, matches.length]);

	const pick = (option) => {
		onChange(String(option.value));
		setOpen(false);
		setActive(-1);
	};

	const move = (step) => {
		const next = matches.length ? (active + step + matches.length) % matches.length : -1;

		setOpen(true);
		setActive(next);
		list.current?.children[next]?.scrollIntoView({ block: 'nearest' });
	};

	const keys = (e) => {
		if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
			e.preventDefault();
			move(e.key === 'ArrowDown' ? 1 : -1);
		} else if (e.key === 'Enter' && shown && matches[active]) {
			e.preventDefault();
			pick(matches[active]);
		} else if (e.key === 'Escape' && shown) {
			e.preventDefault();
			setOpen(false);
		}
	};

	return (
		<div className="remaily-suggest">
			<input
				id={id}
				className="remaily-input"
				type="text"
				role="combobox"
				autoComplete="off"
				spellCheck="false"
				aria-label={label}
				aria-autocomplete="list"
				aria-expanded={shown}
				aria-controls={`${id}-list`}
				aria-activedescendant={shown && matches[active] ? `${id}-${active}` : undefined}
				placeholder={placeholder}
				value={value || ''}
				onChange={(e) => {
					onChange(e.target.value);
					setActive(-1);
					setOpen(true);
				}}
				onFocus={() => setOpen(true)}
				onClick={() => setOpen(true)}
				onBlur={() => setOpen(false)}
				onKeyDown={keys}
			/>
			{options.length > 0 && <span className="remaily-suggest__caret" aria-hidden="true"><Icon name="chevron" /></span>}
			{shown && (
				<ul id={`${id}-list`} ref={list} className="remaily-listbox" role="listbox">
					{matches.map((option, i) => (
						<li
							key={option.value}
							id={`${id}-${i}`}
							role="option"
							aria-selected={String(option.value).toLowerCase() === q}
							className={[i === active && 'is-active', String(option.value).toLowerCase() === q && 'is-current'].filter(Boolean).join(' ')}
							onMouseEnter={() => setActive(i)}
							// Before the input's blur closes the list
							onMouseDown={(e) => {
								e.preventDefault();
								pick(option);
							}}
						>
							<span className="remaily-suggest__name">{option.label}</span>
							{String(option.label) !== String(option.value) && <code>{option.value}</code>}
						</li>
					))}
				</ul>
			)}
		</div>
	);
};

export const ChipsControl = ({ label, help, value, onChange, options = {}, placeholder, icon, chip, split = /[\s,;]+/, free = false }) => {
	const id = useId('chips');
	const [query, setQuery] = useState('');
	const [open, setOpen] = useState(false);
	const [active, setActive] = useState(0);
	const picked = (value || '').split(split).filter((item) => (free ? '' !== item.trim() : options[item]));
	const name = (item) => options[item] || item;
	const q = query.trim().toLowerCase();
	const matches = Object.entries(options)
		.filter(([item, name]) => !picked.includes(item) && (!q || name.toLowerCase().includes(q) || item === q))
		.slice(0, 8);
	const set = (items) => onChange(items.join(', '));
	const add = (item) => {
		set([...picked, item]);
		setQuery('');
		setActive(0);
	};
	// What's typed, as a value of its own (free); a value already picked is only cleared
	const addTyped = () => {
		const item = query.trim().replace(/,+$/, '').trim();

		if (item && !picked.includes(item)) {
			add(item);
		} else {
			setQuery('');
		}
	};

	const keys = (e) => {
		if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
			e.preventDefault();
			setOpen(true);
			setActive((i) => (matches.length ? (i + (e.key === 'ArrowDown' ? 1 : matches.length - 1)) % matches.length : 0));
		} else if (e.key === 'Enter' && open && matches[active]) {
			e.preventDefault();
			add(matches[active][0]);
		} else if (free && (e.key === 'Enter' || e.key === ',') && query.trim()) {
			e.preventDefault();
			addTyped();
		} else if (e.key === 'Backspace' && !query && picked.length) {
			set(picked.slice(0, -1));
		} else if (e.key === 'Escape') {
			setOpen(false);
		}
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className="remaily-countries">
				{picked.length > 0 && (
					<ul className="remaily-countries__picked">
						{picked.map((item) => (
							<li key={item} className="remaily-countries__chip">
								{icon && <span aria-hidden="true">{icon(item)}</span>}
								<span className="remaily-countries__name" title={name(item)}>
									{chip ? chip(item) : name(item)}
								</span>
								<button
									type="button"
									/* translators: %s: the item's name, such as a country */
									aria-label={sprintf( __( 'Remove %s', 'remaily' ), name(item) )}
									onClick={() => set(picked.filter((other) => other !== item))}
								>
									<Icon name="close" />
								</button>
							</li>
						))}
					</ul>
				)}
				<div className="remaily-countries__search">
					<input
						id={id}
						className="remaily-input"
						type="text"
						role="combobox"
						autoComplete="off"
						aria-autocomplete="list"
						aria-expanded={open && matches.length > 0}
						aria-controls={`${id}-list`}
						aria-activedescendant={open && matches[active] ? `${id}-${matches[active][0]}` : undefined}
						placeholder={placeholder}
						value={query}
						onChange={(e) => {
							setQuery(e.target.value);
							setActive(0);
							setOpen(true);
						}}
						// Pasted "a, b, c" (free): a chip each
						onPaste={(e) => {
							const items = free ? e.clipboardData.getData('text').split(/[\s,;]+/).filter(Boolean) : [];

							if (items.length > 1) {
								e.preventDefault();
								set([...new Set([...picked, ...items])]);
							}
						}}
						onFocus={() => setOpen(true)}
						onBlur={() => {
							setOpen(false);

							if (free) {
								addTyped();
							}
						}}
						onKeyDown={keys}
					/>
					{open && matches.length > 0 && (
						<ul id={`${id}-list`} className="remaily-listbox" role="listbox">
							{matches.map(([item, name], i) => (
								<li
									key={item}
									id={`${id}-${item}`}
									role="option"
									aria-selected={i === active}
									className={i === active ? 'is-active' : ''}
									onMouseEnter={() => setActive(i)}
									// Before the input's blur closes the list
									onMouseDown={(e) => {
										e.preventDefault();
										add(item);
									}}
								>
									{icon && <span aria-hidden="true">{icon(item)}</span>}
									{name}
								</li>
							))}
						</ul>
					)}
				</div>
				{picked.length > 1 && (
					<button type="button" className="remaily-countries__clear" onClick={() => set([])}>
						{__( 'Remove all', 'remaily' )}
					</button>
				)}
			</div>
		</Field>
	);
};

/**
 * Countries picked by name, with their flags. The value stays a list of codes, "us, ca, gb"; countries is { code: name }
 */
export const CountriesControl = ({ countries, placeholder, ...rest }) => (
	<ChipsControl {...rest} options={countries} icon={flag} placeholder={placeholder || __( 'Type a country', 'remaily' )} />
);

/**
 * File types picked from the ones a File field may take; types is { ext: kind }
 */
export const ExtensionsControl = ({ types, ...rest }) => (
	<ChipsControl
		{...rest}
		options={Object.fromEntries(Object.entries(types).map(([ext, kind]) => [ext, `.${ext} – ${kind}`]))}
		chip={(ext) => `.${ext}`}
		placeholder={__( 'Type a file type, such as pdf or video', 'remaily' )}
	/>
);

export const Toggle = ({ label, help, checked, onChange, disabled = false }) => {
	const id = useId('toggle');

	return (
		<Field help={help} inline>
			<label className="remaily-check" htmlFor={id}>
				<input id={id} type="checkbox" checked={Boolean(checked)} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
				<span>{label}</span>
			</label>
		</Field>
	);
};

export const Button = ({ variant = 'secondary', icon, children, className = '', ...rest }) => (
	<button type="button" className={`remaily-button is-${variant} ${className}`} {...rest}>
		{icon && <Icon name={icon} />}
		{children}
	</button>
);
