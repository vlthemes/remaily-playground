/**
 * Small controls of the sidebar and the tabs, in the editor's own look
 */
import { useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Icon } from './icons.js';

let uid = 0;
const useId = (prefix) => useState(() => `remaily-${prefix}-${++uid}`)[0];

// The label row (label, then the "i" shown on hover), the folded tip under it, then the control; a toggle's tip
// goes under the toggle
export const Field = ({ label, help, id, children, inline = false }) => {
	const [open, setOpen] = useState(false);
	const info = help && (
		<button type="button" className={`remaily-field-row__info${open ? ' is-active' : ''}`} aria-expanded={open} aria-label={__( 'Help', 'remaily' )} onClick={() => setOpen(!open)}>
			i
		</button>
	);
	const tip = help && open && <p className="remaily-field-row__help">{help}</p>;

	if (inline) {
		return (
			<div className="remaily-field-row is-inline">
				<div className="remaily-field-row__head">
					{children}
					{info}
				</div>
				{tip}
			</div>
		);
	}

	return (
		<div className="remaily-field-row">
			{(label || info) && (
				<div className="remaily-field-row__head">
					{label && (
						<label className="remaily-field-row__label" htmlFor={id}>
							{label}
						</label>
					)}
					{info}
				</div>
			)}
			{tip}
			{children}
		</div>
	);
};

export const Text = ({ label, help, value, onChange, ...rest }) => {
	const id = useId('text');

	return (
		<Field label={label} help={help} id={id}>
			<input id={id} className="remaily-input" type="text" value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

/**
 * A text with values to put in it ({count}, {value}): chips under the input add one where the cursor is.
 * tokens is { '{count}': label }; note is a line under the chips (a value that stays empty, say)
 */
export const FormatControl = ({ label, help, value, onChange, tokens, note }) => {
	const id = useId('format');
	const input = useRef(null);
	const add = (token) => {
		const el = input.current;
		const text = value ?? '';
		const from = el?.selectionStart ?? text.length;
		const to = el?.selectionEnd ?? text.length;

		onChange(text.slice(0, from) + token + text.slice(to));
		// After React has put the new value in
		requestAnimationFrame(() => {
			el?.focus();
			el?.setSelectionRange(from + token.length, from + token.length);
		});
	};

	return (
		<Field label={label} help={help} id={id}>
			<input ref={input} id={id} className="remaily-input" type="text" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
			<div className="remaily-info-chips is-under">
				{Object.entries(tokens || {}).map(([token, name]) => (
					<button type="button" key={token} className="remaily-chip is-info" onMouseDown={(e) => e.preventDefault()} onClick={() => add(token)}>
						<Icon name="plus" />
						<span className="remaily-chip__name">{name}</span>
					</button>
				))}
			</div>
			{note && <p className="remaily-side__note">{note}</p>}
		</Field>
	);
};

// How far the ruler moves for one step, px
const TURN = 2;

// A number with a ruler under it: drag the ruler sideways or step with its arrows
// (Shift: by 10). Empty stays empty
export const NumberInput = ({ label, help, value, onChange, step = 1, min = 0 }) => {
	const id = useId('number');
	const track = useRef(null);
	const drag = useRef(null);
	const spin = useRef(0);
	const [dragging, setDragging] = useState(false);
	const shown = value === 0 || value === '' || value === undefined || value === null ? '' : value;
	const current = () => parseFloat(drag.current?.value ?? shown) || 0;

	const turn = (steps) => {
		spin.current += steps * TURN;

		if (track.current) {
			track.current.style.backgroundPositionX = `${Math.round(spin.current)}px`;
		}
	};

	const set = (next) => onChange(String(Math.max(min, Math.round(next / step) * step)));

	const onPointerDown = (event) => {
		event.currentTarget.setPointerCapture(event.pointerId);
		drag.current = { x: event.clientX, value: current() };
		setDragging(true);
	};

	const onPointerMove = (event) => {
		if (!drag.current) {
			return;
		}

		// Let go where no pointerup came (out of the window): the drag is over
		if (!event.buttons) {
			onPointerUp();

			return;
		}

		const steps = (event.clientX - drag.current.x) * (event.shiftKey ? 10 : 1);

		drag.current.x = event.clientX;
		drag.current.value = Math.max(min, drag.current.value + steps * step);
		turn(steps);
		set(drag.current.value);
	};

	const onPointerUp = () => {
		drag.current = null;
		setDragging(false);
	};

	const stepBy = (event, direction) => {
		const delta = direction * step * (event.shiftKey ? 10 : 1);

		turn(delta / step);
		set(current() + delta);
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className={`remaily-number${dragging ? ' is-dragging' : ''}`}>
				<input id={id} className="remaily-input" type="number" min={min} step={step} value={shown} onChange={(e) => onChange(e.target.value)} />
				<div className="remaily-number__ruler">
					<button type="button" className="remaily-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, -1)}>
						◀
					</button>
					<span
						className="remaily-number__track"
						ref={track}
						title={__( 'Drag to change (Shift: faster)', 'remaily' )}
						onPointerDown={onPointerDown}
						onPointerMove={onPointerMove}
						onPointerUp={onPointerUp}
						onPointerCancel={onPointerUp}
						onLostPointerCapture={onPointerUp}
					/>
					<button type="button" className="remaily-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, 1)}>
						▶
					</button>
				</div>
			</div>
		</Field>
	);
};

export const Textarea = ({ label, help, value, onChange, rows = 4, mono = false, ...rest }) => {
	const id = useId('textarea');

	return (
		<Field label={label} help={help} id={id}>
			<textarea id={id} className={`remaily-input${mono ? ' is-mono' : ''}`} rows={rows} value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

// Text edited as lines, parsed on each change but kept as typed while the field is open
export const LinesControl = ({ label, help, value, toText, fromText, onChange, rows = 4, placeholder }) => {
	const [text, setText] = useState(() => toText(value));

	return (
		<Textarea
			label={label}
			help={help}
			rows={rows}
			mono
			placeholder={placeholder}
			value={text}
			onChange={(next) => {
				setText(next);
				onChange(fromText(next));
			}}
		/>
	);
};

export const Select = ({ label, help, value, onChange, options }) => {
	const id = useId('select');

	// A saved value the list doesn't have (typed in before, or by an add-on) stays shown
	const list = value && !(value in options) ? { ...options, [value]: value } : options;

	return (
		<Field label={label} help={help} id={id}>
			<select id={id} className="remaily-input remaily-select" value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
				{Object.entries(list).map(([key, text]) => (
					<option key={key} value={key}>
						{text}
					</option>
				))}
			</select>
		</Field>
	);
};

// A date setting: none, today, days from today (today+7, today-1) or a fixed YYYY-MM-DD; the site turns "today"
// into a date when the form is shown
const RELATIVE = /^today([+-]\d+)?$/;
const isoDay = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

export const DateControl = ({ label, help, value, onChange, empty }) => {
	const id = useId('date');
	const current = value || '';
	const relative = current.match(RELATIVE);
	let mode = 'date';

	if (!current) {
		mode = 'none';
	} else if (current === 'today') {
		mode = 'today';
	} else if (relative) {
		mode = 'offset';
	}

	const days = relative ? Number(relative[1] || 0) : 0;
	const preview = (offset) => {
		const date = new Date();

		date.setDate(date.getDate() + offset);

		return date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
	};

	const pick = (next) => {
		if (next === 'none') {
			onChange('');
		} else if (next === 'today') {
			onChange('today');
		} else if (next === 'offset') {
			onChange('today+7');
		} else {
			onChange(isoDay(new Date()));
		}
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className="remaily-date">
				<select id={id} className="remaily-input remaily-select" value={mode} onChange={(e) => pick(e.target.value)}>
					<option value="none">{empty || __( 'None', 'remaily' )}</option>
					<option value="today">{__( 'Today', 'remaily' )}</option>
					<option value="offset">{__( 'Days from today', 'remaily' )}</option>
					<option value="date">{__( 'A set date', 'remaily' )}</option>
				</select>

				{mode === 'date' && (
					<input className="remaily-input" type="date" aria-label={label} value={current} onChange={(e) => onChange(e.target.value)} />
				)}

				{mode === 'offset' && (
					<div className="remaily-date__offset">
						<input
							className="remaily-input"
							type="number"
							step="1"
							aria-label={__( 'Days from today', 'remaily' )}
							value={days}
							onChange={(e) => {
								const n = parseInt(e.target.value, 10) || 0;

								onChange(n ? `today${n > 0 ? '+' : ''}${n}` : 'today');
							}}
						/>
						<span>{__( 'days; a minus is before today', 'remaily' )}</span>
					</div>
				)}

				{(mode === 'today' || mode === 'offset') && (
					<p className="remaily-date__preview">
						{/* translators: %s: a date */ sprintf( __( 'Today that is %s. It moves with each day.', 'remaily' ), preview(days) )}
					</p>
				)}
			</div>
		</Field>
	);
};

// A country's flag: its two regional-indicator letters (Countries::flag())
const flag = (code) => String.fromCodePoint(...[...code.toUpperCase()].map((char) => 127397 + char.charCodeAt(0)));

/**
 * Values picked from a list: a chip each (remove button), in the order picked, and a search that adds more. The value
 * stays a comma-separated list, "us, ca, gb". options is { value: label }; icon( value ) draws before a label,
 * chip( value ) is a chip's text (the label by default); split is what separates the values in the saved text
 */
export const ChipsControl = ({ label, help, value, onChange, options, placeholder, icon, chip, split = /[\s,;]+/ }) => {
	const id = useId('chips');
	const [query, setQuery] = useState('');
	const [open, setOpen] = useState(false);
	const [active, setActive] = useState(0);
	const picked = (value || '').split(split).filter((item) => options[item]);
	const q = query.trim().toLowerCase();
	const matches = Object.entries(options)
		.filter(([item, name]) => !picked.includes(item) && (!q || name.toLowerCase().includes(q) || item === q))
		.slice(0, 8);
	const set = (items) => onChange(items.join(', '));
	const add = (item) => {
		set([...picked, item]);
		setQuery('');
		setActive(0);
	};

	const keys = (e) => {
		if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
			e.preventDefault();
			setOpen(true);
			setActive((i) => (matches.length ? (i + (e.key === 'ArrowDown' ? 1 : matches.length - 1)) % matches.length : 0));
		} else if (e.key === 'Enter' && open && matches[active]) {
			e.preventDefault();
			add(matches[active][0]);
		} else if (e.key === 'Backspace' && !query && picked.length) {
			set(picked.slice(0, -1));
		} else if (e.key === 'Escape') {
			setOpen(false);
		}
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className="remaily-countries">
				{picked.length > 0 && (
					<ul className="remaily-countries__picked">
						{picked.map((item) => (
							<li key={item} className="remaily-countries__chip">
								{icon && <span aria-hidden="true">{icon(item)}</span>}
								{chip ? chip(item) : options[item]}
								<button
									type="button"
									/* translators: %s: the item's name, such as a country */
									aria-label={sprintf( __( 'Remove %s', 'remaily' ), options[item] )}
									onClick={() => set(picked.filter((other) => other !== item))}
								>
									<Icon name="close" />
								</button>
							</li>
						))}
					</ul>
				)}
				<div className="remaily-countries__search">
					<input
						id={id}
						className="remaily-input"
						type="text"
						role="combobox"
						autoComplete="off"
						aria-autocomplete="list"
						aria-expanded={open && matches.length > 0}
						aria-controls={`${id}-list`}
						aria-activedescendant={open && matches[active] ? `${id}-${matches[active][0]}` : undefined}
						placeholder={placeholder}
						value={query}
						onChange={(e) => {
							setQuery(e.target.value);
							setActive(0);
							setOpen(true);
						}}
						onFocus={() => setOpen(true)}
						onBlur={() => setOpen(false)}
						onKeyDown={keys}
					/>
					{open && matches.length > 0 && (
						<ul id={`${id}-list`} className="remaily-countries__list" role="listbox">
							{matches.map(([item, name], i) => (
								<li
									key={item}
									id={`${id}-${item}`}
									role="option"
									aria-selected={i === active}
									className={i === active ? 'is-active' : ''}
									onMouseEnter={() => setActive(i)}
									// Before the input's blur closes the list
									onMouseDown={(e) => {
										e.preventDefault();
										add(item);
									}}
								>
									{icon && <span aria-hidden="true">{icon(item)}</span>}
									{name}
								</li>
							))}
						</ul>
					)}
				</div>
				{picked.length > 1 && (
					<button type="button" className="remaily-countries__clear" onClick={() => set([])}>
						{__( 'Remove all', 'remaily' )}
					</button>
				)}
			</div>
		</Field>
	);
};

/**
 * Countries picked by name, with their flags. The value stays a list of codes, "us, ca, gb"; countries is { code: name }
 */
export const CountriesControl = ({ countries, placeholder, ...rest }) => (
	<ChipsControl {...rest} options={countries} icon={flag} placeholder={placeholder || __( 'Type a country', 'remaily' )} />
);

/**
 * File types picked from the ones a File field may take; types is { ext: kind }
 */
export const ExtensionsControl = ({ types, ...rest }) => (
	<ChipsControl
		{...rest}
		options={Object.fromEntries(Object.entries(types).map(([ext, kind]) => [ext, `.${ext} – ${kind}`]))}
		chip={(ext) => `.${ext}`}
		placeholder={__( 'Type a file type, such as pdf or video', 'remaily' )}
	/>
);

export const Toggle = ({ label, help, checked, onChange, disabled = false }) => {
	const id = useId('toggle');

	return (
		<Field help={help} inline>
			<label className="remaily-check" htmlFor={id}>
				<input id={id} type="checkbox" checked={Boolean(checked)} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
				<span>{label}</span>
			</label>
		</Field>
	);
};

export const Button = ({ variant = 'secondary', icon, children, className = '', ...rest }) => (
	<button type="button" className={`remaily-button is-${variant} ${className}`} {...rest}>
		{icon && <Icon name={icon} />}
		{children}
	</button>
);
