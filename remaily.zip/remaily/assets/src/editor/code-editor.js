/**
 * The Form tab's editor: CodeMirror with the template, kept in step with the app
 */
import { forwardRef, useEffect, useImperativeHandle, useRef } from '@wordpress/element';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap, drawSelection } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import { LRLanguage, LanguageSupport, indentUnit, syntaxHighlighting } from '@codemirror/language';
import { parser } from '@lezer/html';
import { MIME_MOVE, MIME_NEW, clearDrop, dragField, dropField, dropHandlers, freeSpot, showSpots, groupAt, groupEnd, highlight, infoFacet, lowerNames, spaced, tokenField } from './cm.js';
import { TOKEN, outsideTag } from './state.js';

// HTML alone: @codemirror/lang-html would add the CSS and JavaScript languages, far heavier than a form needs
const html = new LanguageSupport(LRLanguage.define({ name: 'html', parser }));

const info = new Compartment();
const indent = new Compartment();

const CodeEditor = forwardRef(({ value, onChange, fields, selected, spaces, handlers, hidden }, ref) => {
	const parent = useRef(null);
	const view = useRef(null);
	const live = useRef(handlers);

	live.current = handlers;

	const onChangeRef = useRef(onChange);

	onChangeRef.current = onChange;

	// The handlers object stays one, so the facet doesn't change on every render
	const proxy = useRef(new Proxy({}, { get: (target, key) => live.current[key] })).current;

	useEffect(() => {
		const keys = keymap.of([
			{ key: 'Mod-s', preventDefault: true, run: () => (live.current.save?.(), true) },
			{ key: 'Mod-g', preventDefault: true, run: () => (live.current.wrap?.(), true) },
			...defaultKeymap,
			...historyKeymap,
			indentWithTab,
		]);

		view.current = new EditorView({
			parent: parent.current,
			state: EditorState.create({
				doc: value,
				extensions: [
					history(),
					drawSelection(),
					keys,
					html,
					syntaxHighlighting(highlight),
					EditorView.lineWrapping,
					// HTML reads left to right on an RTL screen too
					EditorView.editorAttributes.of({ dir: 'ltr' }),
					indent.of([indentUnit.of(' '.repeat(spaces)), EditorState.tabSize.of(spaces)]),
					info.of(infoFacet.of({ fields, selected, handlers: proxy })),
					lowerNames,
					tokenField,
					dropField,
					dragField,
					dropHandlers,
					EditorView.updateListener.of((update) => update.docChanged && onChangeRef.current(update.state.doc.toString())),
				],
			}),
		});

		// A drag that ends anywhere (a field button dropped outside the editor, Escape) takes the slot away
		const end = () => view.current && clearDrop(view.current);
		// A chip picked up anywhere (a field button, a chip): the places it can go show at once
		const start = (e) => {
			const types = [...(e.dataTransfer?.types || [])];

			// A frame later: changing the editor while the drag starts would cancel the drag of a chip inside it
			if (view.current && (types.includes(MIME_NEW) || types.includes(MIME_MOVE))) {
				requestAnimationFrame(() => view.current && showSpots(view.current, true));
			}
		};

		document.addEventListener('dragstart', start);
		document.addEventListener('dragend', end);
		document.addEventListener('drop', end);

		return () => {
			document.removeEventListener('dragstart', start);
			document.removeEventListener('dragend', end);
			document.removeEventListener('drop', end);
			view.current.destroy();
		};
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => {
		view.current?.dispatch({ effects: info.reconfigure(infoFacet.of({ fields, selected, handlers: proxy })) });
	}, [fields, selected, proxy]);

	useEffect(() => {
		view.current?.dispatch({ effects: indent.reconfigure([indentUnit.of(' '.repeat(spaces)), EditorState.tabSize.of(spaces)]) });
	}, [spaces]);

	useImperativeHandle(ref, () => ({
		view: () => view.current,
		focus: () => view.current.focus(),
		// Insert a token at a position (the cursor by default)
		insert(text, pos) {
			const v = view.current;
			// Never inside a tag, where it would break it: after the tag instead
			const at = outsideTag(v.state.doc.toString(), pos ?? v.state.selection.main.head);
			const insert = spaced(v.state.doc.toString(), at, text);

			v.dispatch({ changes: { from: at, insert }, selection: { anchor: at + insert.length } });
			v.focus();
		},
		// Text such as [[name:key]]: in place of the selected text, else right at the cursor (in an attribute's value too)
		insertText(text) {
			const v = view.current;
			const sel = v.state.selection.main;
			const from = sel.empty ? freeSpot(v.state.doc.toString(), sel.head) : sel.from;
			const to = sel.empty ? from : sel.to;

			v.dispatch({ changes: { from, to, insert: text }, selection: { anchor: from + text.length } });
			v.focus();
		},
		// Replace the whole document, as one undo step
		replace(text) {
			const v = view.current;

			v.dispatch({ changes: { from: 0, to: v.state.doc.length, insert: text } });
		},
		// Remove a token at a position
		removeAt(pos, token) {
			const v = view.current;

			if (v.state.sliceDoc(pos, pos + token.length) === token) {
				v.dispatch({ changes: { from: pos, to: pos + token.length, insert: '' } });
			}
		},
		// Rename every [[from]] (or group) token
		renameTokens(from, to, kind) {
			const v = view.current;
			const changes = [];
			const text = v.state.doc.toString();

			for (const m of text.matchAll(TOKEN)) {
				if ((kind === 'field' && m[1] === from) || (kind === 'group' && m[1] === `group:${from}`)) {
					changes.push({ from: m.index, to: m.index + m[0].length, insert: kind === 'field' ? `[[${to}]]` : `[[group:${to}]]` });
				} else if (kind === 'field' && m[1].startsWith(`${from}:`)) {
					changes.push({ from: m.index, to: m.index + m[0].length, insert: `[[${to}${m[1].slice(from.length)}]]` });
				}
			}

			v.dispatch({ changes });
		},
		// Remove every [[name]] token, and its [[name:key]] ones
		removeTokens(name) {
			const v = view.current;
			const changes = [...v.state.doc.toString().matchAll(TOKEN)].filter((m) => m[1] === name || m[1].startsWith(`${name}:`)).map((m) => ({ from: m.index, to: m.index + m[0].length, insert: '' }));

			v.dispatch({ changes });
		},
		// Wrap the selected lines in a group
		wrap(name) {
			const v = view.current;
			const sel = v.state.selection.main;
			const first = v.state.doc.lineAt(sel.from);
			const last = v.state.doc.lineAt(sel.to);
			const pad = first.text.match(/^\s*/)[0];

			v.dispatch({
				changes: [
					{ from: first.from, insert: `${pad}[[group:${name}]]\n` },
					{ from: last.to, insert: `\n${pad}[[/group]]` },
				],
			});
			v.focus();
		},
		// Remove a group's tokens, keeping what is inside
		ungroup(name) {
			const v = view.current;
			const text = v.state.doc.toString();
			const open = [...text.matchAll(TOKEN)].find((m) => m[1] === `group:${name}`);

			if (!open) {
				return;
			}

			const end = groupEnd(text, open.index);
			const close = end - '[[/group]]'.length;
			const line = (pos, len) => {
				const l = v.state.doc.lineAt(pos);

				// A token alone on its line takes the line with it
				return l.text.trim().length === len && l.number < v.state.doc.lines ? { from: l.from, to: l.to + 1 } : { from: pos, to: pos + len };
			};

			v.dispatch({ changes: [{ ...line(open.index, open[0].length), insert: '' }, { ...(text.slice(close, end) === '[[/group]]' ? line(close, 10) : { from: end, to: end }), insert: '' }] });
		},
		// Change the indent unit of every line: each step of `from` spaces (or a tab) becomes `to` spaces
		reindent(from, to) {
			const v = view.current;
			const changes = [];

			for (let n = 1; n <= v.state.doc.lines; n++) {
				const line = v.state.doc.line(n);
				const lead = line.text.match(/^[ \t]*/)[0];

				if (lead) {
					const width = [...lead].reduce((sum, ch) => sum + (ch === '\t' ? from : 1), 0);
					const next = ' '.repeat(Math.floor(width / from) * to + (width % from));

					if (next !== lead) {
						changes.push({ from: line.from, to: line.from + lead.length, insert: next });
					}
				}
			}

			if (changes.length) {
				v.dispatch({ changes });
			}
		},
		groupAt: (pos) => groupAt(view.current.state.doc.toString(), pos ?? view.current.state.selection.main.head),
	}));

	return <div className="remaily-code" ref={parent} hidden={hidden} />;
});

export default CodeEditor;
