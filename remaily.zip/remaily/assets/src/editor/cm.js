/**
 * CodeMirror parts of the Form tab: tokens shown as chips, groups as dashed boxes, dragging fields in and around,
 * the context menu
 *
 * What the editor knows of the form (fields, selected, handlers) comes in through infoFacet.
 */
import { EditorState, Facet, StateEffect, StateField } from '@codemirror/state';
import { Decoration, EditorView, WidgetType } from '@codemirror/view';
import { HighlightStyle } from '@codemirror/language';
import { tags as t } from '@lezer/highlight';
import { __, sprintf } from '@wordpress/i18n';
import { svg } from './icons.js';
import { ANY_CASE, TOKEN, isInfo, outsideTag, places, tagEndAt, typeOf } from './state.js';

export const MIME_NEW = 'application/x-remaily-new';
export const MIME_MOVE = 'application/x-remaily-move';
// A [[name:key]] chip: text, so it lands where it's let go (in text or an attribute's value), not at the marked places
export const MIME_FREE = 'application/x-remaily-free';
// A token dragged in from outside the code, such as a sidebar's Use in text button: the text to insert
export const MIME_TEXT = 'application/x-remaily-text';

export const infoFacet = Facet.define({
	combine: (values) => values[values.length - 1] || { fields: {}, selected: null, handlers: {} },
});

const handlers = (view) => view.state.facet(infoFacet).handlers;

/**
 * A token with a space on each side where it touches text or a tag, so chips never stick to their neighbours
 *
 * @param {string} text  Document
 * @param {number} pos   Where it goes
 * @param {string} token Token
 * @return {string} What to insert
 */
export const spaced = (text, pos, token) => (pos > 0 && !/\s/.test(text[pos - 1]) ? ' ' : '') + token + (pos < text.length && !/\s/.test(text[pos]) ? ' ' : '');

/**
 * Where a [[name:key]] chip lands: the position itself between tags or inside an attribute's quoted value, else
 * after the tag
 *
 * @param {string} text Document
 * @param {number} pos  Position
 * @return {number} Position
 */
export const freeSpot = (text, pos) => {
	if (tagEndAt(text, pos) < 0) {
		return pos;
	}

	const inTag = text.slice(text.lastIndexOf('<', pos), pos);

	return (inTag.split('"').length - 1) % 2 || (inTag.split("'").length - 1) % 2 ? pos : outsideTag(text, pos);
};

// While dragging: an empty slot where the chip will land, opening a gap between the elements around it
const setDrop = StateEffect.define();

class DropSlot extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-drop-slot';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}
}

export const dropField = StateField.define({
	create: () => null,
	update(pos, tr) {
		for (const effect of tr.effects) {
			if (effect.is(setDrop)) {
				return effect.value;
			}
		}

		return null === pos || !tr.docChanged ? pos : tr.changes.mapPos(pos);
	},
	provide: (field) => EditorView.decorations.from(field, (pos) => (null === pos ? Decoration.none : Decoration.set([Decoration.widget({ widget: new DropSlot(), side: 1 }).range(pos)]))),
});

// While dragging: a mark at each place a chip can go (around tags and chips, never inside a tag)
const setDragging = StateEffect.define();

class DropSpot extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-drop-spot';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}
}

/**
 * The places a chip can go: before and after each tag and chip, one where only spaces lie between two, and each
 * empty line
 *
 * @param {string} text Document
 * @return {number[]} Positions, in order
 */
export const dropSpots = (text) => {
	const spots = new Set([0, text.length]);
	const blank = new Set();

	// An empty line, after its indentation; not one inside a tag that spans lines
	for (const m of text.matchAll(/^[ \t]*$/gm)) {
		const pos = m.index + m[0].length;

		if (tagEndAt(text, pos) < 0) {
			blank.add(pos);
			spots.add(pos);
		}
	}

	for (const m of text.matchAll(/<\/?[a-zA-Z][^>]*>|\[\[[^\]]+\]\]/g)) {
		if (m[0][0] === '[' && tagEndAt(text, m.index) >= 0) {
			continue;
		}

		spots.add(m.index);
		spots.add(m.index + m[0].length);
	}

	const sorted = [...spots].sort((a, b) => a - b);

	return sorted.filter((pos, i) => i === 0 || blank.has(pos) || text.slice(sorted[i - 1], pos).trim() !== '');
};

export const dragField = StateField.define({
	create: () => false,
	update(on, tr) {
		for (const effect of tr.effects) {
			if (effect.is(setDragging)) {
				return effect.value;
			}
		}

		return on;
	},
	provide: (field) =>
		EditorView.decorations.compute([field, 'doc'], (state) =>
			state.field(field) ? Decoration.set(dropSpots(state.doc.toString()).map((pos) => Decoration.widget({ widget: new DropSpot(), side: -1 }).range(pos))) : Decoration.none
		),
});

/**
 * Show or hide the places a chip can go
 *
 * @param {EditorView} view Editor
 * @param {boolean}    on   Dragging
 */
export const showSpots = (view, on) => {
	if (view.state.field(dragField) !== on) {
		view.dispatch({ effects: setDragging.of(on) });
	}
};

/**
 * Take the slot and the marks away (a drag ended anywhere: dropped outside the editor, or let go with Escape)
 *
 * @param {EditorView} view Editor
 */
export const clearDrop = (view) => {
	showDrop(view, null);
	showSpots(view, false);
};

const showDrop = (view, pos) => {
	if (view.state.field(dropField) !== pos) {
		view.dispatch({ effects: setDrop.of(pos) });
	}
};

/**
 * The marked place nearest the pointer, on screen
 *
 * @param {EditorView} view  Editor
 * @param {DragEvent}  event Drag over
 * @return {number|null} Position
 */
const nearestSpot = (view, event) => {
	const { from, to } = view.viewport;
	let best = null;
	let distance = Infinity;

	for (const pos of dropSpots(view.state.doc.toString())) {
		if (pos < from || pos > to) {
			continue;
		}

		const box = view.coordsAtPos(pos, -1);

		if (box) {
			// Lines count more than sideways, so the slot stays on the pointer's line
			const d = Math.hypot(event.clientX - box.left, (event.clientY - (box.top + box.bottom) / 2) * 3);

			if (d < distance) {
				distance = d;
				best = pos;
			}
		}
	}

	return best;
};

/**
 * Where a group token's group ends (after its closing token)
 *
 * @param {string} text Document
 * @param {number} from Position of [[group:…]]
 * @return {number} End
 */
export const groupEnd = (text, from) => {
	let depth = 0;

	for (const m of text.slice(from).matchAll(TOKEN)) {
		if (m[1].startsWith('group:')) {
			depth++;
		} else if (m[1] === '/group' && --depth === 0) {
			return from + m.index + m[0].length;
		}
	}

	return text.length;
};

/**
 * The innermost group around a position
 *
 * @param {string} text Document
 * @param {number} pos  Position
 * @return {{name: string, from: number, to: number}|null} Group
 */
export const groupAt = (text, pos) => {
	const stack = [];

	for (const m of text.matchAll(TOKEN)) {
		if (m.index >= pos) {
			break;
		}

		if (m[1].startsWith('group:')) {
			stack.push({ name: m[1].slice(6), from: m.index });
		} else if (m[1] === '/group' && m.index + m[0].length <= pos) {
			stack.pop();
		}
	}

	const open = stack.pop();

	return open ? { ...open, to: groupEnd(text, open.from) } : null;
};

/**
 * A chip's element: grip, icon, name
 *
 * @param {string} icon      Icon
 * @param {string} label     Name
 * @param {string} className Classes
 * @return {HTMLElement} Chip
 */
export const chipElement = (icon, label, className = '') => {
	const el = document.createElement('span');
	const name = document.createElement('span');

	el.className = `remaily-chip ${className}`.trim();
	el.innerHTML = `<span class="remaily-chip__grip">⠿</span>${svg(icon)}`;
	name.className = 'remaily-chip__name';
	name.textContent = label;
	el.append(name);

	return el;
};

/**
 * The same drag for a field button and a chip: a chip held by its grip in the hand, the source left as a ghost
 *
 * @param {DragEvent}   event  Drag start
 * @param {HTMLElement} source What was grabbed
 * @param {HTMLElement} chip   The chip to show in the hand
 */
export const dragChip = (event, source, chip) => {
	const image = chip.cloneNode(true);

	image.classList.remove('is-selected');
	image.classList.add('remaily-drag-image');
	(source.closest('.remaily-editor') || document.body).append(image);
	event.dataTransfer.setDragImage?.(image, 14, image.offsetHeight / 2);
	setTimeout(() => image.remove());

	// After the browser has taken its picture
	requestAnimationFrame(() => source.classList.add('is-dragging'));
	source.addEventListener('dragend', () => source.classList.remove('is-dragging'), { once: true });
};

// A chip or group head lets the editor have these, so a chip dropped onto itself or its neighbour still lands
const DROP_EVENTS = ['dragenter', 'dragover', 'dragleave', 'drop'];

const drag = (view, el, length, whole, free = false) => (event) => {
	const from = view.posAtDOM(el);
	const to = whole ? groupEnd(view.state.doc.toString(), from) : from + length;

	event.dataTransfer.setData(MIME_MOVE, JSON.stringify({ from, to }));

	if (free) {
		event.dataTransfer.setData(MIME_FREE, '1');
	}

	event.dataTransfer.setData('text/plain', view.state.sliceDoc(from, to));
	event.dataTransfer.effectAllowed = 'move';
	dragChip(event, el, el.firstElementChild || el);
	// The editor may redraw the chip while the slot opens beside it; dragend then fires on the old one, off the page
	el.addEventListener('dragend', () => clearDrop(view), { once: true });
};

// The room of a space beside a chip that has none in the code, so a chip looks the same either way; nothing in the document
class TokenGap extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-token-gap';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}

	// A click or a drop here lands in the editor
	ignoreEvent() {
		return false;
	}
}

/**
 * A widget's outer span: its padding keeps chips on neighbouring lines apart
 *
 * @param {HTMLElement} el The chip
 * @return {HTMLElement} Its wrapper
 */
const wrapToken = (el) => {
	const wrap = document.createElement('span');

	wrap.className = 'remaily-token';
	wrap.append(el);

	return wrap;
};

class Chip extends WidgetType {
	constructor(name, field, selected, misplaced) {
		super();
		this.name = name;
		this.type = field?.type || '';
		this.required = Boolean(field?.required && typeOf(this.type)?.required);
		this.selected = selected;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.type === this.type && other.required === this.required && other.selected === this.selected && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const el = chipElement(
			this.type ? typeOf(this.type)?.icon || this.type : 'info',
			this.name + (this.required ? ' *' : ''),
			`is-${this.type || 'unknown'}${this.selected ? ' is-selected' : ''}${this.type ? '' : ' is-unknown'}${this.misplaced ? ' is-misplaced' : ''}`
		);

		el.dataset.remailyName = this.name;
		el.title = this.type ? typeOf(this.type)?.label || this.type : __( 'This field has no settings yet. Click to set it up.', 'remaily' );

		if (this.misplaced) {
			el.title = __( 'Inside an HTML tag, where it breaks the tag. Drag it between tags.', 'remaily' );
		}

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => handlers(view).select?.('field', this.name));
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, this.name.length + 4, false));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}

// [[captcha]], [[response]] and the other places (remaily_places): moved and removed, nothing to set up
class Place extends WidgetType {
	constructor(name, misplaced) {
		super();
		this.name = name;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const place = places[this.name];
		const el = chipElement(place.icon, place.label, `is-place${this.misplaced ? ' is-misplaced' : ''}`);

		el.title = this.misplaced ? __( 'Inside an HTML tag, where it breaks the tag. Drag it between tags.', 'remaily' ) : place.summary;

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, this.name.length + 4, false));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}

// [[name:key]]: a field's setting as text; a light chip, "name · Max size", that selects its field
class InfoChip extends WidgetType {
	constructor(inner, field) {
		super();
		this.inner = inner;
		[this.name, this.key] = inner.split(':');
		this.label = typeOf(field?.type)?.info?.[this.key] || '';
	}

	eq(other) {
		return other.inner === this.inner && other.label === this.label;
	}

	toDOM(view) {
		const el = chipElement('info', `${this.name} · ${this.label || this.key}`, `is-info${this.label ? '' : ' is-unknown'}`);

		el.title = this.label
			? /* translators: 1: setting, such as Max size, 2: field name */ sprintf( __( '%1$s of %2$s, as visitors read it. Change it in the field\'s settings.', 'remaily' ), this.label, this.name )
			: __( 'No field, or nothing of it, has this name.', 'remaily' );

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => this.label && handlers(view).select?.('field', this.name));
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.inner));
		wrap.addEventListener('dragstart', drag(view, wrap, this.inner.length + 4, false, true));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}

class GroupHead extends WidgetType {
	constructor(name, selected, misplaced) {
		super();
		this.name = name;
		this.selected = selected;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.selected === this.selected && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const el = document.createElement('span');

		el.className = `remaily-group-head${this.selected ? ' is-selected' : ''}${this.misplaced ? ' is-misplaced' : ''}`;
		el.textContent = `⠿ ${__( 'Group:', 'remaily' )} ${this.name}`;

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => handlers(view).select?.('group', this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, 0, true));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}

class GroupEnd extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-group-end';
		el.textContent = __( 'end of group', 'remaily' );

		return el;
	}
}

function build(state) {
	const { fields, selected } = state.facet(infoFacet);
	const doc = state.doc;
	const text = doc.toString();
	const decos = [];
	const stack = [];
	const spans = [];
	const gaps = new Set();
	const touches = (char) => undefined !== char && !/\s/.test(char);

	for (const m of text.matchAll(TOKEN)) {
		const from = m.index;
		const to = from + m[0].length;
		const inner = m[1];

		if (touches(text[from - 1])) {
			gaps.add(from);
		}

		if (touches(text[to])) {
			gaps.add(to);
		}

		if (inner === '/group') {
			const open = stack.pop();

			decos.push(Decoration.replace({ widget: new GroupEnd() }).range(from, to));

			if (open) {
				spans.push({ from: open.from, to, depth: stack.length });
			}
		} else if (inner.startsWith('group:')) {
			const name = inner.slice(6);

			stack.push({ from });
			decos.push(Decoration.replace({ widget: new GroupHead(name, selected?.kind === 'group' && selected.name === name, tagEndAt(text, from) >= 0) }).range(from, to));
		} else if (isInfo(inner)) {
			decos.push(Decoration.replace({ widget: new InfoChip(inner, fields[inner.split(':')[0]]) }).range(from, to));
		} else if (places[inner]) {
			decos.push(Decoration.replace({ widget: new Place(inner, tagEndAt(text, from) >= 0) }).range(from, to));
		} else {
			decos.push(Decoration.replace({ widget: new Chip(inner, fields[inner], selected?.kind === 'field' && selected.name === inner, tagEndAt(text, from) >= 0) }).range(from, to));
		}
	}

	gaps.forEach((pos) => decos.push(Decoration.widget({ widget: new TokenGap(), side: -1 }).range(pos)));

	stack.forEach((open, i) => spans.push({ from: open.from, to: doc.length, depth: i }));

	// Group boxes: each line of a group, its depth, its first and last line
	const lines = new Map();

	spans.forEach(({ from, to, depth }) => {
		const first = doc.lineAt(from).number;
		const last = doc.lineAt(to).number;

		for (let n = first; n <= last; n++) {
			const line = lines.get(n) || { depth: 0, first: false, last: false };

			line.depth = Math.max(line.depth, depth + 1);
			line.first = line.first || (n === first && line.depth === depth + 1);
			line.last = line.last || (n === last && line.depth === depth + 1);
			lines.set(n, line);
		}
	});

	lines.forEach((line, n) => {
		decos.push(
			Decoration.line({
				attributes: { class: `remaily-gline${line.first ? ' is-first' : ''}${line.last ? ' is-last' : ''}`, style: `--remaily-depth:${line.depth}` },
			}).range(doc.line(n).from)
		);
	});

	return Decoration.set(decos, true);
}

// Names are lowercase: a token typed or pasted with capitals turns lowercase in the same step, one undo
export const lowerNames = EditorState.transactionFilter.of((tr) => {
	if (!tr.docChanged) {
		return tr;
	}

	const changes = [...tr.newDoc.toString().matchAll(ANY_CASE)].filter((m) => m[0] !== m[0].toLowerCase()).map((m) => ({ from: m.index, to: m.index + m[0].length, insert: m[0].toLowerCase() }));

	return changes.length ? [tr, { changes, sequential: true }] : tr;
});

export const tokenField = StateField.define({
	create: build,
	update(value, tr) {
		return tr.docChanged || tr.startState.facet(infoFacet) !== tr.state.facet(infoFacet) ? build(tr.state) : value;
	},
	provide: (field) => [EditorView.decorations.from(field), EditorView.atomicRanges.of((view) => view.state.field(field))],
});

export const dropHandlers = EditorView.domEventHandlers({
	dragover(event, view) {
		const types = [...event.dataTransfer.types];

		if (types.includes(MIME_NEW) || types.includes(MIME_MOVE) || types.includes(MIME_TEXT)) {
			event.preventDefault();
			event.dataTransfer.dropEffect = types.includes(MIME_MOVE) ? 'move' : 'copy';

			// Text goes where the pointer is
			if (types.includes(MIME_FREE)) {
				const pos = view.posAtCoords({ x: event.clientX, y: event.clientY });

				if (pos !== null) {
					showDrop(view, freeSpot(view.state.doc.toString(), pos));
				}

				return true;
			}

			showSpots(view, true);

			// Over the slot itself: it stays where it is; else it opens at the marked place nearest the pointer
			if (!event.target.closest?.('.remaily-drop-slot')) {
				const pos = nearestSpot(view, event) ?? view.posAtCoords({ x: event.clientX, y: event.clientY });

				if (pos !== null) {
					showDrop(view, outsideTag(view.state.doc.toString(), pos));
				}
			}

			return true;
		}

		return false;
	},
	dragleave(event, view) {
		if (!view.dom.contains(event.relatedTarget)) {
			showDrop(view, null);
		}
	},
	dragend(event, view) {
		clearDrop(view);
	},
	drop(event, view) {
		const type = event.dataTransfer.getData(MIME_NEW);
		const move = event.dataTransfer.getData(MIME_MOVE);
		const token = event.dataTransfer.getData(MIME_TEXT);
		// The slot's place, else the pointer's
		const at = view.state.field(dropField) ?? view.posAtCoords({ x: event.clientX, y: event.clientY });

		clearDrop(view);

		if ((!type && !move && !token) || at === null) {
			return false;
		}

		const free = [...event.dataTransfer.types].includes(MIME_FREE);
		const pos = free ? freeSpot(view.state.doc.toString(), at) : outsideTag(view.state.doc.toString(), at);

		event.preventDefault();

		if (token) {
			view.dispatch({ changes: { from: pos, insert: token }, selection: { anchor: pos + token.length } });
		} else if (type) {
			handlers(view).insert?.(type, pos);
		} else {
			const { from, to } = JSON.parse(move);
			const text = view.state.doc.toString();

			if (pos < from || pos > to) {
				// Leaving: a space it sat between goes too
				const end = text[from - 1] === ' ' && text[to] === ' ' ? to + 1 : to;

				view.dispatch({ changes: [{ from, to: end, insert: '' }, { from: pos, insert: free ? text.slice(from, to) : spaced(text, pos, text.slice(from, to)) }] });
			}
		}

		view.focus();

		return true;
	},
	contextmenu(event, view) {
		const sel = view.state.selection.main;
		const pos = view.posAtCoords({ x: event.clientX, y: event.clientY }) ?? sel.head;
		const group = groupAt(view.state.doc.toString(), pos);

		if (sel.empty && !group) {
			return false;
		}

		event.preventDefault();
		handlers(view).contextMenu?.({ x: event.clientX, y: event.clientY, canWrap: !sel.empty, group });

		return true;
	},
});

export const highlight = HighlightStyle.define([
	{ tag: t.tagName, color: '#b32d2e' },
	{ tag: t.attributeName, color: '#3c434a' },
	{ tag: [t.attributeValue, t.string], color: '#2271b1' },
	{ tag: t.angleBracket, color: '#8c8f94' },
	{ tag: t.comment, color: '#8c8f94', fontStyle: 'italic' },
]);
