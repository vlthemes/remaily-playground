/**
 * CodeMirror parts of the Form tab, one file each in cm/: tokens shown as chips and groups as dashed boxes
 * (chips.js), dragging fields in and around (drag.js), what typing does to names and groups (groups.js), chips pasted as copies (paste.js) and the
 * code's colours (highlight.js)
 *
 * What the editor knows of the form (fields, selected, handlers) comes in through infoFacet.
 */
export { MIME_NEW, MIME_MOVE, MIME_FREE, MIME_TEXT, spaced, freeSpot, dropField, dropSpots, dragField, showSpots, clearDrop, chipElement, dragChip, dropHandlers } from './cm/drag.js';
export { groupEnd, groupAt, lowerNames, pairedGroups } from './cm/groups.js';
export { infoFacet, tokenField } from './cm/chips.js';
export { highlight } from './cm/highlight.js';
export { pasteCopies, pastedCopies } from './cm/paste.js';
