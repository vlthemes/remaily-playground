/**
 * The Form tab's sidebar: the settings of the selected field or group
 */
import { Fragment, useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import { __, sprintf } from '@wordpress/i18n';
import { Button, ChipsControl, CountriesControl, DateControl, ExtensionsControl, Field, FormatControl, LinesControl, NumberInput, Select, Text, Textarea, Toggle } from './controls.js';
import { ShortcutList } from './shortcuts.js';
import { Icon } from './icons.js';
import { MIME_FREE, MIME_TEXT, chipElement, dragChip } from './cm.js';
import data, { optionsToText, pairsToText, placed, textToOptions, textToPairs, typeOf, types } from './state.js';

const OPERATORS = {
	is: __( 'is', 'remaily' ),
	is_not: __( 'is not', 'remaily' ),
	contains: __( 'contains', 'remaily' ),
	not_contains: __( "doesn't contain", 'remaily' ),
	empty: __( 'is empty', 'remaily' ),
	not_empty: __( "isn't empty", 'remaily' ),
	gt: __( 'is more than', 'remaily' ),
	lt: __( 'is less than', 'remaily' ),
};

/**
 * The name with its rename button
 */
const NameHead = ({ name, prefix = '', onRename, onBack }) => {
	const [editing, setEditing] = useState(false);
	const [value, setValue] = useState(name);
	const [error, setError] = useState('');

	const commit = () => {
		if (value === name) {
			setEditing(false);

			return;
		}

		const problem = onRename(value);

		setError(problem);

		if (!problem) {
			setEditing(false);
		}
	};

	if (editing) {
		return (
			<div className="remaily-side__head is-editing">
				<input
					className="remaily-input"
					value={value}
					autoFocus
					aria-label={__( 'Name', 'remaily' )}
					onChange={(e) => setValue(e.target.value.replace(/\s/g, '_').toLowerCase())}
					onKeyDown={(e) => {
						if (e.key === 'Enter') {
							commit();
						} else if (e.key === 'Escape') {
							setValue(name);
							setError('');
							setEditing(false);
						}
					}}
					onBlur={commit}
				/>
				{error && <p className="remaily-side__error">{error}</p>}
			</div>
		);
	}

	return (
		<>
			<button type="button" className="remaily-side__back" onClick={onBack}>
				← {__( 'All fields', 'remaily' )}
			</button>
			<div className="remaily-side__head">
				<h2 className="remaily-side__name">
					<button type="button" onClick={() => setEditing(true)} title={__( 'Change name', 'remaily' )}>
						{prefix}
						{name}
					</button>
				</h2>
				<button type="button" className="remaily-side__rename" onClick={() => setEditing(true)}>
					<Icon name="pencil" />
					{__( 'Change name', 'remaily' )}
				</button>
			</div>
		</>
	);
};

/**
 * One control of a field type's schema; a type of the add-on's own comes from remaily.control. def.when
 * ({ setting: [ values ] }) shows it only while those settings have one of those values.
 *
 *     wp.hooks.addFilter( 'remaily.control', 'my-addon', ( control, { def, value, onChange } ) =>
 *         def.type === 'stars' ? <MyStars value={ value } onChange={ onChange } /> : control );
 */
const Control = ({ id, def, field, set, fieldNames, fields = {} }) => {
	if (def.when && !Object.entries(def.when).every(([key, values]) => values.includes(field[key]))) {
		return null;
	}

	const value = field[id];
	const common = { label: def.label, help: def.help };
	const custom = applyFilters('remaily.control', null, { id, def, value, field, onChange: (v) => set(id, v) });

	if (custom) {
		return custom;
	}

	switch (def.type) {
		case 'toggle':
			return <Toggle {...common} checked={value} onChange={(v) => set(id, v)} />;
		case 'number':
			return <NumberInput {...common} value={value} onChange={(v) => set(id, v)} />;
		case 'textarea':
			return <Textarea {...common} value={value} onChange={(v) => set(id, v)} />;
		case 'select':
			return <Select {...common} value={value} options={def.options || {}} onChange={(v) => set(id, v)} />;
		case 'options':
			return <LinesControl {...common} value={value} toText={optionsToText} fromText={textToOptions} placeholder={'Option 1\nOption 2'} onChange={(v) => set(id, v)} />;
		case 'pairs':
			return <LinesControl {...common} value={value} toText={pairsToText} fromText={textToPairs} placeholder="1 + 1 = ? | 2" onChange={(v) => set(id, v)} />;
		case 'countries':
			return <CountriesControl {...common} value={value} countries={data.countries || {}} placeholder={def.placeholder} onChange={(v) => set(id, v)} />;
		case 'choice': {
			// One of the field's own options, or several for checkboxes and multiple selects (values separated by commas)
			const options = Object.fromEntries((field.options || []).map((o) => [String(o.value), o.label]));

			return field.type === 'checkbox' || field.multiple ? (
				<ChipsControl {...common} value={value} options={options} split={/\s*,\s*/} placeholder={__( 'Pick options', 'remaily' )} onChange={(v) => set(id, v)} />
			) : (
				<Select {...common} value={value} options={{ '': field.type === 'radio' && !field.allow_null ? __( 'The first option', 'remaily' ) : __( 'None', 'remaily' ), ...options }} onChange={(v) => set(id, v)} />
			);
		}
		case 'format': {
			// Values that stay empty until the counted field has a max length (Count's {left} and {max})
			const source = field.source ? fields[field.source] : null;
			let note = '';

			if (def.need_max && !field.source) {
				note = __( 'Pick the field to count first.', 'remaily' );
			} else if (def.need_max && source && !Number(source.maxlength)) {
				/* translators: %s: field name */
				note = sprintf( __( 'Characters left and Max length stay empty until %s has a Max length.', 'remaily' ), field.source );
			}

			return <FormatControl {...common} value={value} tokens={def.tokens} note={note} onChange={(v) => set(id, v)} />;
		}
		case 'extensions':
			return <ExtensionsControl {...common} value={value} types={def.types || {}} onChange={(v) => set(id, v)} />;
		case 'date':
			return <DateControl {...common} value={value} empty={def.empty} onChange={(v) => set(id, v)} />;
		case 'field':
			return <Select {...common} value={value} options={{ '': __( '— Pick a field —', 'remaily' ), ...Object.fromEntries(fieldNames.map((n) => [n, n])) }} onChange={(v) => set(id, v)} />;
		default:
			return <Text {...common} value={value} onChange={(v) => set(id, v)} />;
	}
};

/**
 * Custom attributes: name and value rows
 */
const Attributes = ({ value, onChange }) => {
	const rows = value || [];
	const update = (i, key, v) => onChange(rows.map((row, j) => (j === i ? { ...row, [key]: v } : row)));

	return (
		<Field label={__( 'Custom attributes', 'remaily' )} help={__( 'Extra attributes on the input, such as data-something or inputmode.', 'remaily' )}>
			{rows.map((row, i) => (
				<div className="remaily-attr" key={i}>
					<input className="remaily-input" placeholder={__( 'name', 'remaily' )} value={row.name} onChange={(e) => update(i, 'name', e.target.value)} />
					<input className="remaily-input" placeholder={__( 'value', 'remaily' )} value={row.value} onChange={(e) => update(i, 'value', e.target.value)} />
					<button type="button" className="remaily-attr__remove" aria-label={__( 'Remove attribute', 'remaily' )} onClick={() => onChange(rows.filter((r, j) => j !== i))}>
						<Icon name="close" />
					</button>
				</div>
			))}
			<Button className="is-full" onClick={() => onChange([...rows, { name: '', value: '' }])}>
				{__( 'Add attribute', 'remaily' )}
			</Button>
		</Field>
	);
};

export const FieldSidebar = ({ name, field, fields, template, onChange, onRename, onType, onDelete, onBack, onInsert }) => {
	const type = typeOf(field.type);
	const set = (key, value) => onChange({ ...field, [key]: value });
	const fieldNames = placed(template).fields.filter((n) => n !== name);
	const styles = type?.styles || {};
	// The settings every field has that this type uses (Field::shared()), some only while others have a value
	const uses = (key) => {
		const when = type?.shared?.[key];

		return when === true || (Boolean(when) && Object.entries(when).every(([other, values]) => values.includes(field[other])));
	};

	return (
		<div className="remaily-side">
			<NameHead name={name} onRename={onRename} onBack={onBack} />

			<Select
				label={__( 'Field type', 'remaily' )}
				help={__( 'Changing the type keeps the name and the settings both types share.', 'remaily' )}
				value={field.type}
				options={Object.fromEntries(types.map((t) => [t.type, t.label]))}
				onChange={onType}
			/>

			{type?.docs && (
				<p className="remaily-side__note">
					<a href={type.docs} target="_blank" rel="noopener noreferrer">
						{/* translators: %s: field type, such as Text */ sprintf( __( 'How the %s field works', 'remaily' ), type.label )}
					</a>
				</p>
			)}

			{Object.entries(type?.schema || {}).map(([id, def]) => (
				<Control key={id} id={id} def={def} field={field} set={set} fieldNames={fieldNames} fields={fields} />
			))}

			{uses('required') && (
				<Toggle
					label={__( 'Required', 'remaily' )}
					help={__( 'Visitors must fill it in before they can send the form. Add a * to its label in the code so they know.', 'remaily' )}
					checked={field.required}
					onChange={(v) => set('required', v)}
				/>
			)}

			{uses('style') && Object.keys(styles).length > 0 && (
				<Select
					label={__( 'Style', 'remaily' )}
					help={__( 'How the field looks. Your theme can add styles of its own.', 'remaily' )}
					value={field.style || ''}
					options={{ '': __( 'Same as the form', 'remaily' ), ...styles }}
					onChange={(v) => set('style', v)}
				/>
			)}

			{uses('class') && <Text label={__( 'CSS classes', 'remaily' )} help={__( 'Classes added to the input, separated by spaces.', 'remaily' )} value={field.class} onChange={(v) => set('class', v)} />}
			{uses('id') && <Text label={__( 'ID', 'remaily' )} help={__( 'Leave empty and Re:Maily makes one. Set it only if your CSS or scripts need a fixed ID.', 'remaily' )} value={field.id} onChange={(v) => set('id', v)} />}
			{uses('attrs') && <Attributes value={field.attrs} onChange={(v) => set('attrs', v)} />}

			{/* Add-ons' own controls: remaily.fieldControls returns elements for this field */}
			{(applyFilters('remaily.fieldControls', [], { name, field, type, set }) || []).map((control, i) => (
				<Fragment key={i}>{control}</Fragment>
			))}

			{onInsert && Object.keys(type?.info || {}).length > 0 && (
				<Field label={__( 'Use in text', 'remaily' )} help={__( 'Click to put the setting where the cursor is in the code, or in place of the selected text, or drag it there. It stays up to date when you change it here.', 'remaily' )}>
					<div className="remaily-info-chips">
						{Object.entries(type.info).map(([key, label]) => (
							<button
								type="button"
								key={key}
								className="remaily-chip is-info"
								draggable
								onClick={() => onInsert(`[[${name}:${key}]]`)}
								onDragStart={(e) => {
									e.dataTransfer.setData(MIME_TEXT, `[[${name}:${key}]]`);
									e.dataTransfer.setData(MIME_FREE, '1');
									e.dataTransfer.setData('text/plain', `[[${name}:${key}]]`);
									e.dataTransfer.effectAllowed = 'copy';
									dragChip(e, e.currentTarget, chipElement('info', `${name} · ${label}`, 'is-info'));
								}}
							>
								<span className="remaily-chip__grip" aria-hidden="true">⠿</span>
								<Icon name="info" />
								<span className="remaily-chip__name">{label}</span>
							</button>
						))}
					</div>
				</Field>
			)}

			{type?.submits && (
				<p className="remaily-side__note">
					{sprintf(
						/* translators: %s: mail tag such as [your_name] */
						__( 'To use what visitors type here in a mail, put %s in the mail.', 'remaily' ),
						`[${name}]`
					)}
				</p>
			)}

			<Button variant="danger" icon="trash" className="is-full" onClick={onDelete}>
				{__( 'Delete field', 'remaily' )}
			</Button>
		</div>
	);
};

export const GroupSidebar = ({ name, group, config, template, onChange, onRename, onUngroup, onBack }) => {
	const rules = group.rules || [];
	const fieldNames = placed(template).fields.filter((n) => typeOf(config.fields[n]?.type)?.submits);
	const setRule = (i, key, value) => onChange({ ...group, rules: rules.map((r, j) => (j === i ? { ...r, [key]: value } : r)) });

	return (
		<div className="remaily-side">
			<NameHead name={name} prefix={__( 'Group: ', 'remaily' )} onRename={onRename} onBack={onBack} />

			<p className="remaily-side__note">{__( 'Show or hide everything inside this group, depending on what visitors pick or type. Hidden fields are not checked or sent.', 'remaily' )}</p>

			{data.docsUrl && (
				<p className="remaily-side__note">
					<a href={`${data.docsUrl.replace(/\/?$/, '/')}groups-and-conditions/`} target="_blank" rel="noopener noreferrer">
						{__( 'How groups work', 'remaily' )}
					</a>
				</p>
			)}

			<div className="remaily-side__pair">
				<Select
					help={__( 'Show: the group appears only when the rules match. Hide: it disappears when they match.', 'remaily' )}
					value={group.action || 'show'}
					options={{ show: __( 'Show this group', 'remaily' ), hide: __( 'Hide this group', 'remaily' ) }}
					onChange={(v) => onChange({ ...group, action: v })}
				/>
				<Select
					value={group.match || 'all'}
					options={{ all: __( 'when all rules match', 'remaily' ), any: __( 'when any rule matches', 'remaily' ) }}
					onChange={(v) => onChange({ ...group, match: v })}
				/>
			</div>

			{rules.map((rule, i) => {
				const source = config.fields[rule.field];
				const options = source?.options;
				const noValue = rule.op === 'empty' || rule.op === 'not_empty';

				return (
					<div className="remaily-rule" key={i}>
						<Select value={rule.field} options={{ '': __( '— Field —', 'remaily' ), ...Object.fromEntries(fieldNames.map((n) => [n, n])) }} onChange={(v) => setRule(i, 'field', v)} />
						<Select value={rule.op} options={OPERATORS} onChange={(v) => setRule(i, 'op', v)} />
						{!noValue &&
							(options?.length ? (
								<Select value={rule.value} options={{ '': '—', ...Object.fromEntries(options.map((o) => [o.value, o.label])) }} onChange={(v) => setRule(i, 'value', v)} />
							) : (
								<input className="remaily-input" value={rule.value} placeholder={__( 'Value', 'remaily' )} onChange={(e) => setRule(i, 'value', e.target.value)} />
							))}
						<button type="button" className="remaily-attr__remove" aria-label={__( 'Remove rule', 'remaily' )} onClick={() => onChange({ ...group, rules: rules.filter((r, j) => j !== i) })}>
							<Icon name="close" />
						</button>
					</div>
				);
			})}

			{!rules.length && <p className="remaily-side__note">{__( 'No rules yet, so the group always shows.', 'remaily' )}</p>}

			<Button className="is-full" icon="plus" onClick={() => onChange({ ...group, rules: [...rules, { field: fieldNames[0] || '', op: 'is', value: '' }] })}>
				{__( 'Add rule', 'remaily' )}
			</Button>

			<Button variant="danger" className="is-full" onClick={onUngroup}>
				{__( 'Ungroup', 'remaily' )}
			</Button>
		</div>
	);
};

export const EmptySidebar = ({ template, config, onSelect, onHover }) => {
	const { fields } = placed(template);

	return (
		<div className="remaily-side is-empty">
			<h2 className="remaily-side__name">{__( 'Fields', 'remaily' )}</h2>
			<p className="remaily-side__note">{__( 'Click a blue chip in the editor, or a name below, to change its settings. To make a group, select some code and right-click.', 'remaily' )}</p>
			<p className="remaily-side__note">
				<a href={data.docsUrl} target="_blank" rel="noopener noreferrer">
					{__( 'Read the documentation', 'remaily' )}
				</a>
			</p>
			<ul className="remaily-side__list">
				{fields.map((name) => (
					<li key={name}>
						<button
							type="button"
							onClick={() => onSelect(name)}
							onMouseEnter={() => onHover(name)}
							onMouseLeave={() => onHover('')}
							onFocus={() => onHover(name)}
							onBlur={() => onHover('')}
						>
							<Icon name={typeOf(config.fields[name]?.type)?.icon || 'info'} />
							{name}
						</button>
					</li>
				))}
			</ul>
			<ShortcutList />
		</div>
	);
};
