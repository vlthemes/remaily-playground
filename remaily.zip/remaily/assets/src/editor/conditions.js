/**
 * Conditions of Controls trees: the same rules as Core\Controls::matches() and admin-settings.js
 */

/**
 * A value by its dotted path
 */
export const pick = (values, path) => String(path).split('.').reduce((value, key) => (value && 'object' === typeof value ? value[key] : undefined), values);

/**
 * The values with one changed, by its path as a list of keys
 */
export const put = (values, keys, value) => {
	const [key, ...rest] = keys;
	const level = values && 'object' === typeof values && !Array.isArray(values) ? values : {};

	return { ...level, [key]: rest.length ? put(level[key], rest, value) : value };
};

const same = (a, b) => ('boolean' === typeof b ? (true === a || ('string' === typeof a && '' !== a && '0' !== a)) === b : String(a ?? '') === String(b));

/**
 * Whether a value holds against one rule
 */
export const holds = (actual, operator, expected) => {
	const list = Array.isArray(expected) ? expected : [expected];
	const empty = null === actual || undefined === actual || '' === actual || false === actual || '0' === actual;

	switch (operator) {
		case '!=':
			return !same(actual, expected);
		case 'in':
			return list.some((one) => same(actual, one));
		case 'not in':
			return !list.some((one) => same(actual, one));
		case 'empty':
			return empty;
		case 'not empty':
			return !empty;
		case '>':
			return parseFloat(actual) > parseFloat(expected);
		case '<':
			return parseFloat(actual) < parseFloat(expected);
		case '>=':
			return parseFloat(actual) >= parseFloat(expected);
		case '<=':
			return parseFloat(actual) <= parseFloat(expected);
		default:
			return same(actual, expected);
	}
};

/**
 * Whether every rule holds; rules name their controls by paths from the top
 */
export const matches = (rules, values) => (rules || []).every((rule) => holds(pick(values, rule.control), rule.operator, rule.value));
