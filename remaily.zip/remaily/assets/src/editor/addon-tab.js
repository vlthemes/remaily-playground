/**
 * A tab of an add-on: one added through remaily.tabs, or one drawn from a Controls tree (TreeTab). With tab.addon,
 * the tab gets its values for this form (config.addons[tab id]), set( key, value ) and setAll( values ); while the
 * add-on says it's read-only, its note shows above and the tab can't be changed.
 */
import { __ } from '@wordpress/i18n';
import data from './state.js';

const AddonTab = ({ tab, config, template, update }) => {
	const slug = tab.addon;
	// A tree's values sit under its own id, a remaily.tabs tab's under its add-on's slug
	const key = tab.tree ? tab.id : slug;
	const values = key ? { ...(config.addons?.[key] || {}) } : undefined;
	const setAll = (next) => update('addons', { ...config.addons, [key]: next });
	const set = (name, value) => setAll({ ...values, [name]: value });
	const addon = slug ? data.addons?.[slug] : null;
	const body = <tab.Component tab={tab} config={config} template={template} update={update} values={values} set={set} setAll={setAll} readonly={!!addon?.readonly} />;

	if (!addon?.readonly) {
		return body;
	}

	return (
		<>
			<p className="remaily-readonly">
				{addon.readonly} <a href={`${data.addonsUrl}#${slug}`}>{__( 'Open the add-on', 'remaily' )}</a>
			</p>
			<fieldset className="remaily-readonly__body" disabled>
				{body}
			</fieldset>
		</>
	);
};

export default AddonTab;
