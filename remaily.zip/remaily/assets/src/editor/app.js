/**
 * The form editor: the document and saving, the tabs (Form, Mail, Messages, Advanced, add-ons') and what joins
 * them. Its parts are in parts/ (header, field buttons, right-click menu, Save, form code) and the files beside it
 */
import { useCallback, useEffect, useMemo, useRef, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { applyFilters } from '@wordpress/hooks';
import { __, _n, sprintf } from '@wordpress/i18n';
import CodeEditor from './code-editor.js';
import { SourceEditor, SourceHelp } from './source-editor.js';
import { MIME_NEW, chipElement, dragChip } from './cm.js';
import { Icon } from './icons.js';
import { EmptySidebar, FieldSidebar, GroupSidebar } from './sidebar.js';
import data, { changeType, freeName, mailProblems, misplaced, nameFree, placed, places, prune, rename, typeOf, types } from './state.js';
import MailTab from './tabs/mail.js';
import MessagesTab from './tabs/messages.js';
import AdvancedTab from './tabs/advanced.js';
import AddonTab from './addon-tab.js';
import TreeTab from './tree.js';
import Describe from './describe.js';
import beautify from './beautify.js';
import { Preview } from './visual.js';
import { useShortcuts } from './shortcuts.js';
import ContextMenu from './parts/context-menu.js';
import { formCode, readFormCode } from './parts/form-code.js';
import Header from './parts/header.js';
import Palette from './parts/palette.js';
import SaveButton from './parts/save-button.js';

const TABS = {
	form: __( 'Form', 'remaily' ),
	mail: __( 'Mail', 'remaily' ),
	messages: __( 'Messages', 'remaily' ),
	advanced: __( 'Advanced', 'remaily' ),
};

/**
 * Tabs add-ons add: [ { id, label, Component } ], Component gets { config, template, update } and keeps its
 * settings in config (sanitized on the server through the add-on's form sanitize, or remaily_config_sanitize)
 *
 *     wp.hooks.addFilter( 'remaily.tabs', 'my-addon', ( tabs ) => [ ...tabs, { id: 'crm', label: 'CRM', Component: MyTab, addon: 'crm' } ] );
 *
 * With addon (a registered add-on's slug) MyTab gets values and set() for config.addons.crm (AddonTab)
 */
const addonTabs = () =>
	[
		// Tabs drawn from Controls trees (remaily_form_tabs in PHP)
		...(data.formTabs || []).map((tab) => ({ ...tab, Component: TreeTab, tree: true, addon: tab.addon || undefined })),
		...(applyFilters('remaily.tabs', []) || []),
	].filter((tab) => tab?.id && tab.label && tab.Component && !TABS[tab.id]);

// What each tab changes, to mark the tabs with unsaved changes
const AREAS = {
	form: (d) => [d.template, d.config.fields, d.config.groups],
	mail: (d) => [d.config.mail, d.config.mail_2],
	messages: (d) => [d.config.messages],
	advanced: (d) => [d.title, d.description, d.config.settings],
};

const stored = (key, fallback) => {
	try {
		return JSON.parse(window.localStorage.getItem(`remaily-editor-${key}`)) ?? fallback;
	} catch {
		return fallback;
	}
};

const store = (key, value) => {
	try {
		window.localStorage.setItem(`remaily-editor-${key}`, JSON.stringify(value));
	} catch {}
};

const App = () => {
	const initial = data.form;
	const [doc, setDoc] = useState(() => ({ title: initial.title, description: initial.description, template: initial.template, config: initial.config }));
	const [saved, setSaved] = useState(doc);
	const [tab, setTab] = useState('form');
	const [selected, setSelected] = useState(null);
	// The Form tab's code: html (the template), css or js (settings.css, settings.js)
	const [source, setSource] = useState('html');
	const sourceRef = useRef(null);
	const [previewing, setPreviewing] = useState(false);
	const [spaces, setSpaces] = useState(() => stored('spaces', 2));
	const [menu, setMenu] = useState(null);
	const [notice, setNotice] = useState(null);
	const [saving, setSaving] = useState(false);
	const [status, setStatus] = useState(initial.status || 'publish');
	const [saveMenu, setSaveMenu] = useState(false);
	const [describing, setDescribing] = useState(false);
	// The form before the last Describe, for Undo
	const [beforeAi, setBeforeAi] = useState(null);
	const code = useRef(null);
	const foot = useRef(null);
	const [stuck, setStuck] = useState(false);
	const docRef = useRef(doc);

	docRef.current = doc;

	const extraTabs = useMemo(addonTabs, []);
	// An add-on's tab changes its own config.addons[slug]
	const areas = useMemo(() => ({ ...AREAS, ...Object.fromEntries(extraTabs.filter((t) => t.addon || t.tree).map((t) => [t.id, (d) => [d.config.addons?.[t.tree ? t.id : t.addon]]])) }), [extraTabs]);
	const changed = useMemo(() => Object.fromEntries(Object.entries(areas).map(([id, pick]) => [id, JSON.stringify(pick(doc)) !== JSON.stringify(pick(saved))])), [areas, doc, saved]);
	// An add-on's settings live in the config too: any change there counts
	const dirty = Object.values(changed).includes(true) || JSON.stringify(doc.config) !== JSON.stringify(saved.config);
	const problems = useMemo(() => mailProblems(doc.config, doc.template), [doc.config, doc.template]);
	const inTags = useMemo(() => misplaced(doc.template), [doc.template]);

	const say = useCallback((text, type = 'success') => {
		setNotice({ text, type, key: Date.now() });
	}, []);

	useEffect(() => {
		if (!notice) {
			return;
		}

		const timer = setTimeout(() => setNotice(null), 2600);

		return () => clearTimeout(timer);
	}, [notice]);

	// The footer is square while it sticks to the bottom of the window (it sits at bottom: -1px, so it is never
	// wholly in view then), rounded as the card's foot otherwise
	useEffect(() => {
		const observer = new window.IntersectionObserver(([entry]) => setStuck(entry.intersectionRatio < 1 && entry.boundingClientRect.top > 0), { threshold: [1] });

		observer.observe(foot.current);

		return () => observer.disconnect();
	}, []);

	useEffect(() => {
		const warn = (event) => {
			if (dirty) {
				event.preventDefault();
				event.returnValue = '';
			}
		};

		window.addEventListener('beforeunload', warn);

		return () => window.removeEventListener('beforeunload', warn);
	}, [dirty]);

	const setConfig = (fn) => setDoc((d) => ({ ...d, config: fn(d.config) }));
	const update = (key, value) => setConfig((c) => ({ ...c, [key]: value }));
	const setField = (name, field) => setConfig((c) => ({ ...c, fields: { ...c.fields, [name]: field } }));
	const setGroup = (name, group) => setConfig((c) => ({ ...c, groups: { ...c.groups, [name]: group } }));

	// A copy of a field next to it, with a name of its own: your_name → your_name_2
	const duplicate = ({ inner, pos, length }) => {
		const base = inner.replace(/_\d+$/, '');
		let n = 2;

		while (!nameFree(`${base}_${n}`, docRef.current.config, docRef.current.template)) {
			n++;
		}

		const name = `${base}_${n}`;

		setField(name, structuredClone(docRef.current.config.fields[inner] || { ...types[0].defaults, type: types[0].type }));
		code.current.insert(`[[${name}]]`, pos + length);
		setSelected({ kind: 'field', name });
	};

	// Save, as published by default; "Save as draft" keeps it off the site
	const save = async (nextStatus = 'publish') => {
		const current = docRef.current;

		setSaving(true);
		setSaveMenu(false);

		try {
			const config = prune(current.config, current.template);
			const res = await apiFetch({
				path: `/remaily/v1/forms/${initial.id}`,
				method: 'POST',
				data: { title: current.title, description: current.description, template: current.template, config, status: nextStatus },
			});
			const next = { ...current, config: res.config };

			setDoc((d) => (d === current ? next : d));
			setSaved(next);
			setStatus(res.status);
			say('draft' === res.status ? __( 'Saved as a draft. It shows on the site once you publish it.', 'remaily' ) : __( 'Saved.', 'remaily' ));
		} catch (err) {
			say(err.message || __( "Couldn't save. Please try again.", 'remaily' ), 'error');
		} finally {
			setSaving(false);
		}
	};

	// A new field of a type, its settings from the type's defaults
	const addField = (type, pos) => {
		const name = freeName(type, docRef.current.config, docRef.current.template);

		setField(name, { ...(typeOf(type)?.defaults || {}), type });
		code.current.insert(`[[${name}]]`, pos);
		setSelected({ kind: 'field', name });
		setTab('form');
	};

	const wrap = () => {
		const view = code.current.view();

		if (view.state.selection.main.empty) {
			say(__( 'Select the code to put in the group first.', 'remaily' ), 'error');

			return;
		}

		const name = freeName('group', docRef.current.config, docRef.current.template);

		setGroup(name, { action: 'show', match: 'all', rules: [] });
		code.current.wrap(name);
		setSelected({ kind: 'group', name });
	};

	const renameItem = (kind, from, to) => {
		if (!nameFree(to, docRef.current.config, docRef.current.template)) {
			return __( 'Use lowercase letters, numbers, _ or -, starting with a letter, and a name no other field or group has.', 'remaily' );
		}

		code.current.renameTokens(from, to, kind);
		setConfig((c) => rename(c, from, to, kind));
		setSelected({ kind, name: to });

		return '';
	};

	const ungroup = (name) => {
		code.current.ungroup(name);
		setConfig((c) => {
			const groups = { ...c.groups };

			delete groups[name];

			return { ...c, groups };
		});
		setSelected(null);
	};

	const handlers = {
		select: (kind, name) => {
			setSelected({ kind, name });
			setMenu(null);

			// A token placed by hand gets its settings when first clicked
			if (kind === 'field' && !docRef.current.config.fields[name]) {
				setField(name, { ...types[0].defaults, type: types[0].type });
			}

			if (kind === 'group' && !docRef.current.config.groups[name]) {
				setGroup(name, { action: 'show', match: 'all', rules: [] });
			}
		},
		removeAt: (pos, name) => {
			code.current.removeAt(pos, `[[${name}]]`);
			setSelected((s) => (s?.name === name ? null : s));
		},
		// Places ([[captcha]]…) are only placed: no settings
		insert: (type, pos) => (places[type] ? code.current.insert(`[[${type}]]`, pos) : addField(type, pos)),
		contextMenu: setMenu,
		// Pasted chips the form already had (cm/paste.js): each copy gets the settings of the one it came from
		copyNames: (names) =>
			setConfig((c) => {
				const fields = { ...c.fields };
				const groups = { ...c.groups };

				Object.entries(names).forEach(([from, to]) => {
					if (c.fields?.[from]) {
						fields[to] = structuredClone(c.fields[from]);
					}

					if (c.groups?.[from]) {
						groups[to] = structuredClone(c.groups[from]);
					}
				});

				return { ...c, fields, groups };
			}),
		wrap,
		save: () => save(status),
	};

	const selectFromFrame = useCallback((name) => handlers.select('field', name), []); // eslint-disable-line react-hooks/exhaustive-deps

	const copyShortcode = () => {
		navigator.clipboard?.writeText(`[remaily id="${initial.hash}"]`).then(() => say(__( 'Shortcode copied.', 'remaily' )));
	};

	// Copy to another site (Advanced tab), read back by pasteCode() on the other site
	const shareCode = useMemo(() => formCode(doc), [doc]);

	const copyCode = () => {
		if (!navigator.clipboard) {
			say(__( 'Your browser only copies on https or localhost. Select the code in the box and copy it.', 'remaily' ), 'error');

			return;
		}

		navigator.clipboard.writeText(shareCode).then(() => say(__( 'Form code copied. On the other site, paste it into a form\'s Advanced tab.', 'remaily' )));
	};

	// '' when it went in, else what's wrong; nothing is saved until Save
	const pasteCode = (text) => {
		const pasted = readFormCode(text);

		if (!pasted) {
			return __( "This isn't form code. Copy it again from the other site.", 'remaily' );
		}

		code.current.replace(pasted.template);
		setDoc((d) => ({
			...d,
			title: 'string' === typeof pasted.title && pasted.title ? pasted.title : d.title,
			description: 'string' === typeof pasted.description ? pasted.description : d.description,
			template: pasted.template,
			// Keys the other site doesn't have keep this site's defaults
			config: { ...d.config, ...pasted.config },
		}));
		setSelected(null);
		setTab('form');
		say(__( 'Form code pasted. Check the form, then save.', 'remaily' ));

		return '';
	};

	const tidy = () => code.current.replace(beautify(docRef.current.template, spaces));

	const applyAi = ({ template, config, summary }) => {
		const current = docRef.current;

		setBeforeAi({ template: current.template, config: current.config });
		code.current.replace(template);
		setDoc((d) => ({ ...d, template, config }));
		setSelected(null);
		setDescribing(false);
		say(summary || __( 'The form is updated.', 'remaily' ));
	};

	const undoAi = () => {
		code.current.replace(beforeAi.template);
		setDoc((d) => ({ ...d, template: beforeAi.template, config: beforeAi.config }));
		setBeforeAi(null);
	};

	const trash = async () => {
		// eslint-disable-next-line no-alert
		if (!window.confirm(__( 'Move this form to the trash? Pages that show it will show nothing.', 'remaily' ))) {
			return;
		}

		await apiFetch({ path: `/remaily/v1/forms/${initial.id}`, method: 'DELETE' });
		setSaved(docRef.current);
		window.location.assign(data.listUrl);
	};

	const fields = doc.config.fields;
	const groups = doc.config.groups;

	// A name hovered in the sidebar's list: its chips in the code get a ring
	const hoverField = (name) => {
		document.querySelectorAll('.remaily-chip.is-hovered').forEach((el) => el.classList.remove('is-hovered'));

		if (name) {
			document.querySelectorAll(`.cm-editor .remaily-chip[data-remaily-name="${CSS.escape(name)}"]`).forEach((el) => el.classList.add('is-hovered'));
		}

	};

	let side = (
		<EmptySidebar
			template={doc.template}
			config={doc.config}
			onSelect={(name) => {
				// The list goes away with the click, before its mouseleave
				hoverField('');
				handlers.select('field', name);
			}}
			onHover={hoverField}
		/>
	);

	if (selected?.kind === 'field' && fields[selected.name] && placed(doc.template).fields.includes(selected.name)) {
		const name = selected.name;

		side = (
			<FieldSidebar
				key={name}
				name={name}
				field={fields[name]}
				fields={fields}
				template={doc.template}
				onChange={(field) => setField(name, field)}
				onType={(type) => setField(name, changeType(fields[name], type))}
				onRename={(to) => renameItem('field', name, to)}
				onDelete={() => {
					code.current.removeTokens(name);
					setSelected(null);
				}}
				onBack={() => setSelected(null)}
				onInsert={(text) => code.current.insertText(text)}
			/>
		);
	} else if (selected?.kind === 'group' && groups[selected.name]) {
		const name = selected.name;

		side = (
			<GroupSidebar
				key={name}
				name={name}
				group={groups[name]}
				config={doc.config}
				template={doc.template}
				onChange={(group) => setGroup(name, group)}
				onRename={(to) => renameItem('group', name, to)}
				onUngroup={() => ungroup(name)}
				onBack={() => setSelected(null)}
			/>
		);
	}

	// Keyboard shortcuts (shortcuts.js), with the state of this render
	const shortcut = useRef(null);

	shortcut.current = (action, index) => {
		const ids = [...Object.keys(TABS), ...extraTabs.map((t) => t.id)];

		if ('save' === action && !saving) {
			save(status);
		} else if ('preview' === action) {
			setPreviewing(true);
		} else if ('describe' === action) {
			setTab('form');
			setDescribing(true);
		} else if ('tab' === action && ids[index]) {
			setTab(ids[index]);
		} else if ('back' === action && !previewing && !describing) {
			setSelected(null);
		}
	};

	useShortcuts(useCallback((...args) => shortcut.current(...args), []));

	// The field buttons: the types, then the places not placed yet; each in the row or in More (Field::menu(), remaily_places)
	const items = [
		...types.map((t) => ({ name: t.type, label: t.label, summary: t.summary, icon: t.icon, menu: t.menu })),
		...Object.entries(places)
			.filter(([name, place]) => place.offered && !doc.template.includes(`[[${name}]]`))
			.map(([name, place]) => ({ ...place, name, place: true })),
	];
	// A button dragged: a field's chip with the name it will get, a place's with its label
	const dragItem = (e, item) => {
		e.dataTransfer.setData(MIME_NEW, item.name);
		e.dataTransfer.effectAllowed = 'copy';
		dragChip(e, e.currentTarget, chipElement(item.icon, item.place ? item.label : freeName(item.name, docRef.current.config, docRef.current.template), item.place ? 'is-place' : `is-${item.name}`));
	};
	// The selected field's tip, else how the editor works
	const selectedType = selected?.kind === 'field' ? typeOf(doc.config.fields[selected.name]?.type) : null;
	const hints = {
		css: __( 'selector stands for this form: selector .remaily-field styles its fields and no other form\'s.', 'remaily' ),
		js: __( 'The code runs once the form is ready, with root (its wrapper) and form at hand.', 'remaily' ),
	};
	const hint =
		hints[source] ||
		selectedType?.tip ||
		(selected?.kind === 'group'
			? __( 'A group shows or hides what is inside it by its rules. For example, show the company fields only when "I write as" is "a company".', 'remaily' )
			: __( 'Drag fields into the editor. Drag a blue chip to move it, double-click it to remove it. Select code and right-click to make a group.', 'remaily' ));

	return (
		<div
			className="remaily-editor"
			onClick={(e) => {
				if (menu) {
					setMenu(null);
				}

				if (saveMenu && !e.target.closest('.remaily-save')) {
					setSaveMenu(false);
				}
			}}
		>
			<Header
				doc={doc}
				setDoc={setDoc}
				status={status}
				tabs={[...Object.entries(TABS), ...extraTabs.map((t) => [t.id, t.label])]}
				tab={tab}
				onTab={setTab}
				warn={{ mail: problems.length > 0, form: inTags.length > 0 }}
				changed={changed}
				onCopy={copyShortcode}
				onPreview={() => setPreviewing(true)}
			>
				<SaveButton saving={saving} open={saveMenu === 'head'} onToggle={() => setSaveMenu(saveMenu === 'head' ? false : 'head')} onSave={save} up={false} status={status} />
			</Header>

			<div className={`remaily-pane${tab === 'form' ? '' : ' is-hidden'}`}>
				<Palette items={items} disabled={'html' !== source} onInsert={(name) => handlers.insert(name)} onDrag={dragItem} />

				<div className="remaily-card remaily-workspace">
					<div className="remaily-workspace__bar">
						<span className="remaily-sources" role="tablist" aria-label={__( 'Code', 'remaily' )}>
							{[
								['html', 'HTML'],
								['css', 'CSS'],
								['js', 'JavaScript'],
							].map(([id, label]) => (
								<button key={id} type="button" role="tab" aria-selected={source === id} className={`remaily-sources__tab${source === id ? ' is-active' : ''}`} onClick={() => setSource(id)}>
									{label}
								</button>
							))}
						</span>
						<code className="remaily-workspace__code">{`[remaily id="${initial.hash}"]`}</code>
						<div className="remaily-workspace__tools">
							{[2, 4].map((n) => (
								<button
									key={n}
									type="button"
									className={spaces === n ? 'is-active' : ''}
									onClick={() => {
										('html' === source ? code.current : sourceRef.current)?.reindent(spaces, n);
										setSpaces(n);
										store('spaces', n);
									}}
								>
									/ {sprintf( /* translators: %d: number of spaces */ __( '%d Space', 'remaily' ), n )}
								</button>
							))}
							{'html' === source && (
								<button type="button" onClick={tidy}>
									{__( 'Beautify HTML', 'remaily' )}
								</button>
							)}
							{'html' === source && beforeAi && (
								<button type="button" onClick={undoAi}>
									{__( 'Undo AI changes', 'remaily' )}
								</button>
							)}
							{'html' === source && (
								<button type="button" className="remaily-workspace__ai" onClick={() => setDescribing(true)}>
									<Icon name="sparkles" />
									{__( 'Describe your form', 'remaily' )}
								</button>
							)}
						</div>
					</div>
					{inTags.length > 0 && (
						<p className="remaily-workspace__problem" role="alert">
							<Icon name="warning" />
							{sprintf(
								/* translators: %s: field names, such as date_1, email */
								_n( '%s sits inside an HTML tag and breaks it. Drag it between tags.', '%s sit inside HTML tags and break them. Drag them between tags.', inTags.length, 'remaily' ),
								inTags.join(', ')
							)}
						</p>
					)}
					<div className="remaily-workspace__body">
						<CodeEditor
							ref={code}
							value={initial.template}
							onChange={(template) => setDoc((d) => ({ ...d, template }))}
							fields={fields}
							selected={selected}
							spaces={spaces}
							handlers={handlers}
							hidden={'html' !== source}
						/>
						{'html' !== source && (
							<SourceEditor
								key={source}
								ref={sourceRef}
								lang={source}
								value={doc.config.settings?.[source] || ''}
								spaces={spaces}
								readOnly={'js' === source && !data.canJs}
								onSave={() => save()}
								onChange={(value) => setConfig((c) => ({ ...c, settings: { ...c.settings, [source]: value } }))}
							/>
						)}
						<aside className="remaily-workspace__side">{'html' === source ? side : <SourceHelp lang={source} onInsert={(text) => sourceRef.current?.insert(text)} />}</aside>
					</div>
				</div>
			</div>

			{tab !== 'form' && (
				<div className="remaily-card remaily-sheet">
					{tab === 'mail' && <MailTab config={doc.config} template={doc.template} update={update} />}
					{tab === 'messages' && <MessagesTab config={doc.config} template={doc.template} update={update} />}
					{tab === 'advanced' && <AdvancedTab config={doc.config} update={update} formCode={shareCode} onCopy={copyCode} onPaste={pasteCode} />}
					{extraTabs.map((t) => tab === t.id && <AddonTab key={t.id} tab={t} config={doc.config} template={doc.template} update={update} />)}
				</div>
			)}

			<footer ref={foot} className={`remaily-card remaily-foot${stuck ? ' is-stuck' : ''}`}>
				<p className="remaily-foot__hint">
					<Icon name="info" />
					{hint}
				</p>
				<div className="remaily-foot__actions">
					<button type="button" className="remaily-foot__trash" onClick={trash}>
						{__( 'Move to trash', 'remaily' )}
					</button>
					<SaveButton saving={saving} open={saveMenu === 'foot'} onToggle={() => setSaveMenu(saveMenu === 'foot' ? false : 'foot')} onSave={save} up={true} status={status} />
				</div>
			</footer>

			{menu && (
				<ContextMenu
					menu={menu}
					onClose={() => setMenu(null)}
					onDuplicate={duplicate}
					onRemove={(chip) => handlers.removeAt(chip.pos, chip.inner)}
					onWrap={wrap}
					onEditGroup={(name) => handlers.select('group', name)}
					onUngroup={ungroup}
				/>
			)}

			{describing && <Describe doc={doc} onApply={applyAi} onClose={() => setDescribing(false)} />}
			{previewing && (
				<Preview
					doc={doc}
					selected={selected}
					onSelect={(name) => {
						setPreviewing(false);
						setTab('form');
						selectFromFrame(name);
					}}
					onClose={() => setPreviewing(false)}
				/>
			)}

			{notice && (
				<div key={notice.key} className={`remaily-notice is-${notice.type}`} role="status">
					{notice.text}
				</div>
			)}
		</div>
	);
};

export default App;
