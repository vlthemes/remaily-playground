/**
 * The form editor: header, tabs (Form, Mail, Messages, Advanced), saving
 */
import { useCallback, useEffect, useMemo, useRef, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { applyFilters } from '@wordpress/hooks';
import { __, _n, sprintf } from '@wordpress/i18n';
import CodeEditor from './code-editor.js';
import { MIME_NEW, chipElement, dragChip } from './cm.js';
import { Button } from './controls.js';
import { Icon } from './icons.js';
import { EmptySidebar, FieldSidebar, GroupSidebar } from './sidebar.js';
import data, { changeType, freeName, mailProblems, misplaced, nameFree, placed, places, prune, rename, typeOf, types } from './state.js';
import MailTab from './tabs/mail.js';
import MessagesTab from './tabs/messages.js';
import AdvancedTab from './tabs/advanced.js';
import Describe from './describe.js';
import beautify from './beautify.js';
import { Preview } from './visual.js';
import { useShortcuts } from './shortcuts.js';

const TABS = {
	form: __( 'Form', 'remaily' ),
	mail: __( 'Mail', 'remaily' ),
	messages: __( 'Messages', 'remaily' ),
	advanced: __( 'Advanced', 'remaily' ),
};

/**
 * Tabs add-ons add: [ { id, label, Component } ], Component gets { config, template, update } and keeps its
 * settings in config (sanitized on the server through remaily_config_sanitize)
 *
 *     wp.hooks.addFilter( 'remaily.tabs', 'my-addon', ( tabs ) => [ ...tabs, { id: 'crm', label: 'CRM', Component: MyTab } ] );
 */
const addonTabs = () => (applyFilters('remaily.tabs', []) || []).filter((tab) => tab?.id && tab.label && tab.Component && !TABS[tab.id]);

// What each tab changes, to mark the tabs with unsaved changes
const AREAS = {
	form: (d) => [d.template, d.config.fields, d.config.groups],
	mail: (d) => [d.config.mail, d.config.mail_2],
	messages: (d) => [d.config.messages],
	advanced: (d) => [d.title, d.description, d.config.settings],
};

const stored = (key, fallback) => {
	try {
		return JSON.parse(window.localStorage.getItem(`remaily-editor-${key}`)) ?? fallback;
	} catch {
		return fallback;
	}
};

const store = (key, value) => {
	try {
		window.localStorage.setItem(`remaily-editor-${key}`, JSON.stringify(value));
	} catch {}
};

/**
 * Save, as published, with a menu beside it: Save as draft
 */
const SaveButton = ({ saving, open, onToggle, onSave, up, status }) => (
	<span className={`remaily-save${open ? ' is-open' : ''}${up ? ' is-up' : ''}`}>
		<Button variant="primary" icon="save" onClick={() => onSave('publish')} disabled={saving}>
			{saving ? __( 'Saving…', 'remaily' ) : __( 'Save', 'remaily' )}
		</Button>
		<button type="button" className="remaily-save__caret" aria-haspopup="menu" aria-expanded={open} aria-label={__( 'More ways to save', 'remaily' )} onClick={onToggle} disabled={saving}>
			<Icon name="chevron" />
		</button>
		{open && (
			<span className="remaily-save__menu" role="menu">
				{[
					['publish', __( 'Save and publish', 'remaily' ), __( 'The form shows wherever it is placed.', 'remaily' )],
					['draft', __( 'Save as draft', 'remaily' ), __( 'Kept off the site until you publish it.', 'remaily' )],
				].map(([value, title, text]) => (
					<button key={value} type="button" role="menuitemradio" aria-checked={status === value} className={status === value ? 'is-current' : ''} onClick={() => onSave(value)}>
						<span className="remaily-save__text">
							<strong>{title}</strong>
							<span>{text}</span>
						</span>
						{status === value && <Icon name="check" className="remaily-save__check" />}
					</button>
				))}
			</span>
		)}
	</span>
);

const App = () => {
	const initial = data.form;
	const [doc, setDoc] = useState(() => ({ title: initial.title, description: initial.description, template: initial.template, config: initial.config }));
	const [saved, setSaved] = useState(doc);
	const [tab, setTab] = useState('form');
	const [selected, setSelected] = useState(null);
	const [previewing, setPreviewing] = useState(false);
	const [spaces, setSpaces] = useState(() => stored('spaces', 2));
	const [menu, setMenu] = useState(null);
	const [notice, setNotice] = useState(null);
	const [saving, setSaving] = useState(false);
	const [status, setStatus] = useState(initial.status || 'publish');
	const [saveMenu, setSaveMenu] = useState(false);
	const [more, setMore] = useState(false);
	const [editing, setEditing] = useState('');
	const [describing, setDescribing] = useState(false);
	// The form before the last Describe, for Undo
	const [beforeAi, setBeforeAi] = useState(null);
	const code = useRef(null);
	const foot = useRef(null);
	const [stuck, setStuck] = useState(false);
	const docRef = useRef(doc);

	docRef.current = doc;

	const extraTabs = useMemo(addonTabs, []);
	const changed = useMemo(() => Object.fromEntries(Object.entries(AREAS).map(([id, pick]) => [id, JSON.stringify(pick(doc)) !== JSON.stringify(pick(saved))])), [doc, saved]);
	// An add-on's settings live in the config too: any change there counts
	const dirty = Object.values(changed).includes(true) || JSON.stringify(doc.config) !== JSON.stringify(saved.config);
	const problems = useMemo(() => mailProblems(doc.config, doc.template), [doc.config, doc.template]);
	const inTags = useMemo(() => misplaced(doc.template), [doc.template]);

	const say = useCallback((text, type = 'success') => {
		setNotice({ text, type, key: Date.now() });
	}, []);

	useEffect(() => {
		if (!notice) {
			return;
		}

		const timer = setTimeout(() => setNotice(null), 2600);

		return () => clearTimeout(timer);
	}, [notice]);

	// The footer is square while it sticks to the bottom of the window (it sits at bottom: -1px, so it is never
	// wholly in view then), rounded as the card's foot otherwise
	useEffect(() => {
		const observer = new window.IntersectionObserver(([entry]) => setStuck(entry.intersectionRatio < 1 && entry.boundingClientRect.top > 0), { threshold: [1] });

		observer.observe(foot.current);

		return () => observer.disconnect();
	}, []);

	useEffect(() => {
		const warn = (event) => {
			if (dirty) {
				event.preventDefault();
				event.returnValue = '';
			}
		};

		window.addEventListener('beforeunload', warn);

		return () => window.removeEventListener('beforeunload', warn);
	}, [dirty]);

	const setConfig = (fn) => setDoc((d) => ({ ...d, config: fn(d.config) }));
	const update = (key, value) => setConfig((c) => ({ ...c, [key]: value }));
	const setField = (name, field) => setConfig((c) => ({ ...c, fields: { ...c.fields, [name]: field } }));
	const setGroup = (name, group) => setConfig((c) => ({ ...c, groups: { ...c.groups, [name]: group } }));

	// Save, as published by default; "Save as draft" keeps it off the site
	const save = async (nextStatus = 'publish') => {
		const current = docRef.current;

		setSaving(true);
		setSaveMenu(false);

		try {
			const config = prune(current.config, current.template);
			const res = await apiFetch({
				path: `/remaily/v1/forms/${initial.id}`,
				method: 'POST',
				data: { title: current.title, description: current.description, template: current.template, config, status: nextStatus },
			});
			const next = { ...current, config: res.config };

			setDoc((d) => (d === current ? next : d));
			setSaved(next);
			setStatus(res.status);
			say('draft' === res.status ? __( 'Saved as a draft. It shows on the site once you publish it.', 'remaily' ) : __( 'Saved.', 'remaily' ));
		} catch (err) {
			say(err.message || __( "Couldn't save. Please try again.", 'remaily' ), 'error');
		} finally {
			setSaving(false);
		}
	};

	// A new field of a type, its settings from the type's defaults
	const addField = (type, pos) => {
		const name = freeName(type, docRef.current.config, docRef.current.template);

		setField(name, { ...(typeOf(type)?.defaults || {}), type });
		code.current.insert(`[[${name}]]`, pos);
		setSelected({ kind: 'field', name });
		setTab('form');
	};

	const wrap = () => {
		const view = code.current.view();

		if (view.state.selection.main.empty) {
			say(__( 'Select the code to put in the group first.', 'remaily' ), 'error');

			return;
		}

		const name = freeName('group', docRef.current.config, docRef.current.template);

		setGroup(name, { action: 'show', match: 'all', rules: [] });
		code.current.wrap(name);
		setSelected({ kind: 'group', name });
	};

	const renameItem = (kind, from, to) => {
		if (!nameFree(to, docRef.current.config, docRef.current.template)) {
			return __( 'Use lowercase letters, numbers, _ or -, starting with a letter, and a name no other field or group has.', 'remaily' );
		}

		code.current.renameTokens(from, to, kind);
		setConfig((c) => rename(c, from, to, kind));
		setSelected({ kind, name: to });

		return '';
	};

	const ungroup = (name) => {
		code.current.ungroup(name);
		setConfig((c) => {
			const groups = { ...c.groups };

			delete groups[name];

			return { ...c, groups };
		});
		setSelected(null);
	};

	const handlers = {
		select: (kind, name) => {
			setSelected({ kind, name });
			setMenu(null);

			// A token placed by hand gets its settings when first clicked
			if (kind === 'field' && !docRef.current.config.fields[name]) {
				setField(name, { ...types[0].defaults, type: types[0].type });
			}

			if (kind === 'group' && !docRef.current.config.groups[name]) {
				setGroup(name, { action: 'show', match: 'all', rules: [] });
			}
		},
		removeAt: (pos, name) => {
			code.current.removeAt(pos, `[[${name}]]`);
			setSelected((s) => (s?.name === name ? null : s));
		},
		// Places ([[captcha]]…) are only placed: no settings
		insert: (type, pos) => (places[type] ? code.current.insert(`[[${type}]]`, pos) : addField(type, pos)),
		contextMenu: setMenu,
		wrap,
		save: () => save(status),
	};

	const selectFromFrame = useCallback((name) => handlers.select('field', name), []); // eslint-disable-line react-hooks/exhaustive-deps

	const copyShortcode = () => {
		navigator.clipboard?.writeText(`[remaily id="${initial.hash}"]`).then(() => say(__( 'Shortcode copied.', 'remaily' )));
	};

	// Copy to another site (Advanced tab): the whole form as JSON, read back by pasteCode() on the other site
	const formCode = useMemo(() => JSON.stringify({ remaily: 1, title: doc.title, description: doc.description, template: doc.template, config: doc.config }, null, 2), [doc]);

	const copyCode = () => {
		if (!navigator.clipboard) {
			say(__( 'Your browser only copies on https or localhost. Select the code in the box and copy it.', 'remaily' ), 'error');

			return;
		}

		navigator.clipboard.writeText(formCode).then(() => say(__( 'Form code copied. On the other site, paste it into a form\'s Advanced tab.', 'remaily' )));
	};

	// '' when it went in, else what's wrong; nothing is saved until Save
	const pasteCode = (text) => {
		let pasted;

		try {
			pasted = JSON.parse(text);
		} catch {
			return __( "This isn't form code. Copy it again from the other site.", 'remaily' );
		}

		if (1 !== pasted?.remaily || 'string' !== typeof pasted.template || !pasted.config || 'object' !== typeof pasted.config) {
			return __( "This isn't form code. Copy it again from the other site.", 'remaily' );
		}

		code.current.replace(pasted.template);
		setDoc((d) => ({
			...d,
			title: 'string' === typeof pasted.title && pasted.title ? pasted.title : d.title,
			description: 'string' === typeof pasted.description ? pasted.description : d.description,
			template: pasted.template,
			// Keys the other site doesn't have keep this site's defaults
			config: { ...d.config, ...pasted.config },
		}));
		setSelected(null);
		setTab('form');
		say(__( 'Form code pasted. Check the form, then save.', 'remaily' ));

		return '';
	};

	const tidy = () => code.current.replace(beautify(docRef.current.template, spaces));

	const applyAi = ({ template, config, summary }) => {
		const current = docRef.current;

		setBeforeAi({ template: current.template, config: current.config });
		code.current.replace(template);
		setDoc((d) => ({ ...d, template, config }));
		setSelected(null);
		setDescribing(false);
		say(summary || __( 'The form is updated.', 'remaily' ));
	};

	const undoAi = () => {
		code.current.replace(beforeAi.template);
		setDoc((d) => ({ ...d, template: beforeAi.template, config: beforeAi.config }));
		setBeforeAi(null);
	};

	const trash = async () => {
		// eslint-disable-next-line no-alert
		if (!window.confirm(__( 'Move this form to the trash? Pages that show it will show nothing.', 'remaily' ))) {
			return;
		}

		await apiFetch({ path: `/remaily/v1/forms/${initial.id}`, method: 'DELETE' });
		setSaved(docRef.current);
		window.location.assign(data.listUrl);
	};

	const fields = doc.config.fields;
	const groups = doc.config.groups;

	// A name hovered in the sidebar's list: its chips in the code get a ring
	const hoverField = (name) => {
		document.querySelectorAll('.remaily-chip.is-hovered').forEach((el) => el.classList.remove('is-hovered'));

		if (name) {
			document.querySelectorAll(`.cm-editor .remaily-chip[data-remaily-name="${CSS.escape(name)}"]`).forEach((el) => el.classList.add('is-hovered'));
		}

	};

	let side = (
		<EmptySidebar
			template={doc.template}
			config={doc.config}
			onSelect={(name) => {
				// The list goes away with the click, before its mouseleave
				hoverField('');
				handlers.select('field', name);
			}}
			onHover={hoverField}
		/>
	);

	if (selected?.kind === 'field' && fields[selected.name] && placed(doc.template).fields.includes(selected.name)) {
		const name = selected.name;

		side = (
			<FieldSidebar
				key={name}
				name={name}
				field={fields[name]}
				fields={fields}
				template={doc.template}
				onChange={(field) => setField(name, field)}
				onType={(type) => setField(name, changeType(fields[name], type))}
				onRename={(to) => renameItem('field', name, to)}
				onDelete={() => {
					code.current.removeTokens(name);
					setSelected(null);
				}}
				onBack={() => setSelected(null)}
				onInsert={(text) => code.current.insertText(text)}
			/>
		);
	} else if (selected?.kind === 'group' && groups[selected.name]) {
		const name = selected.name;

		side = (
			<GroupSidebar
				key={name}
				name={name}
				group={groups[name]}
				config={doc.config}
				template={doc.template}
				onChange={(group) => setGroup(name, group)}
				onRename={(to) => renameItem('group', name, to)}
				onUngroup={() => ungroup(name)}
				onBack={() => setSelected(null)}
			/>
		);
	}

	// Keyboard shortcuts (shortcuts.js), with the state of this render
	const shortcut = useRef(null);

	shortcut.current = (action, index) => {
		const ids = [...Object.keys(TABS), ...extraTabs.map((t) => t.id)];

		if ('save' === action && !saving) {
			save(status);
		} else if ('preview' === action) {
			setPreviewing(true);
		} else if ('describe' === action) {
			setTab('form');
			setDescribing(true);
		} else if ('tab' === action && ids[index]) {
			setTab(ids[index]);
		} else if ('back' === action && !previewing && !describing) {
			setSelected(null);
		}
	};

	useShortcuts(useCallback((...args) => shortcut.current(...args), []));

	// The field buttons: the types, then the places not placed yet; each in the row or in More (Field::menu(), remaily_places)
	const items = [
		...types.map((t) => ({ name: t.type, label: t.label, summary: t.summary, icon: t.icon, menu: t.menu })),
		...Object.entries(places)
			.filter(([name, place]) => place.offered && !doc.template.includes(`[[${name}]]`))
			.map(([name, place]) => ({ ...place, name, place: true })),
	];
	const mainItems = items.filter((item) => 'more' !== item.menu);
	const moreItems = items.filter((item) => 'more' === item.menu);
	// A button dragged: a field's chip with the name it will get, a place's with its label
	const dragItem = (e, item) => {
		e.dataTransfer.setData(MIME_NEW, item.name);
		e.dataTransfer.effectAllowed = 'copy';
		dragChip(e, e.currentTarget, chipElement(item.icon, item.place ? item.label : freeName(item.name, docRef.current.config, docRef.current.template), item.place ? 'is-place' : `is-${item.name}`));
	};
	// The selected field's tip, else how the editor works
	const selectedType = selected?.kind === 'field' ? typeOf(doc.config.fields[selected.name]?.type) : null;
	const hint =
		selectedType?.tip ||
		(selected?.kind === 'group'
			? __( 'A group shows or hides what is inside it by its rules. For example, show the company fields only when "I write as" is "a company".', 'remaily' )
			: __( 'Drag fields into the editor. Drag a blue chip to move it, double-click it to remove it. Select code and right-click to make a group.', 'remaily' ));

	return (
		<div
			className="remaily-editor"
			onClick={(e) => {
				if (menu) {
					setMenu(null);
				}

				if (saveMenu && !e.target.closest('.remaily-save')) {
					setSaveMenu(false);
				}

				if (more && !e.target.closest('.remaily-more')) {
					setMore(false);
				}
			}}
		>
			<header className="remaily-card remaily-head">
				<div className="remaily-head__brand">
					<span className="remaily-logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: data.logo || '' }} />
					<div className="remaily-head__titles">
						{'title' === editing ? (
							<input
								className="remaily-head__title-input"
								autoFocus
								value={doc.title}
								aria-label={__( 'Form title', 'remaily' )}
								onChange={(e) => setDoc((d) => ({ ...d, title: e.target.value }))}
								onBlur={() => setEditing('')}
								onKeyDown={(e) => e.key === 'Enter' && setEditing('')}
							/>
						) : (
							<span className="remaily-head__title-row">
								<button type="button" className="remaily-head__title" onClick={() => setEditing('title')}>
									{doc.title || __( 'Untitled form', 'remaily' )}
									<Icon name="pencil" />
								</button>
								{'draft' === status && <span className="remaily-head__status">{__( 'Draft', 'remaily' )}</span>}
							</span>
						)}
						{'description' === editing ? (
							<input
								className="remaily-head__description"
								autoFocus
								value={doc.description}
								placeholder={__( 'Add a note about this form', 'remaily' )}
								aria-label={__( 'Description', 'remaily' )}
								onChange={(e) => setDoc((d) => ({ ...d, description: e.target.value }))}
								onBlur={() => setEditing('')}
								onKeyDown={(e) => e.key === 'Enter' && setEditing('')}
							/>
						) : (
							<button type="button" className="remaily-head__note" onClick={() => setEditing('description')}>
								{doc.description || __( 'Add a note about this form', 'remaily' )}
								<Icon name="pencil" />
							</button>
						)}
					</div>
				</div>
				<div className="remaily-head__actions">
					<Button icon="copy" onClick={copyShortcode}>
						{__( 'Copy shortcode', 'remaily' )}
					</Button>
					<SaveButton saving={saving} open={saveMenu === 'head'} onToggle={() => setSaveMenu(saveMenu === 'head' ? false : 'head')} onSave={save} up={false} status={status} />
				</div>
				<nav className="remaily-head__tabs" role="tablist">
					{[...Object.entries(TABS), ...extraTabs.map((t) => [t.id, t.label])].map(([id, label]) => (
						<button key={id} type="button" role="tab" aria-selected={tab === id} className={`remaily-tab${tab === id ? ' is-active' : ''}`} onClick={() => setTab(id)}>
							{(('mail' === id && problems.length > 0) || ('form' === id && inTags.length > 0)) && (
								<span className="remaily-tab__problem" title={__( 'Something here needs checking', 'remaily' )}>
									<Icon name="warning" />
								</span>
							)}
							{label}
							{changed[id] && <span className="remaily-tab__dot" title={__( 'Unsaved changes', 'remaily' )} />}
						</button>
					))}
					<div className="remaily-head__ai">
						<Button variant="dark" icon="eye" onClick={() => setPreviewing(true)}>
							{__( 'Preview', 'remaily' )}
						</Button>
					</div>
				</nav>
			</header>

			<div className={`remaily-pane${tab === 'form' ? '' : ' is-hidden'}`}>
				<div className="remaily-palette" role="toolbar" aria-label={__( 'Fields', 'remaily' )}>
					<div className="remaily-palette__types">
						{mainItems.map((item) => (
							<button
								key={item.name}
								type="button"
								className="remaily-palette__item"
								draggable
								title={item.summary || __( 'Drag into the editor, or click to add at the cursor', 'remaily' )}
								onDragStart={(e) => dragItem(e, item)}
								onClick={() => handlers.insert(item.name)}
							>
								<Icon name={item.icon} />
								{item.label}
							</button>
						))}
						{moreItems.length > 0 && (
							<span className={`remaily-more${more ? ' is-open' : ''}${more === 'end' ? ' is-end' : ''}`}>
								<button
									type="button"
									className="remaily-palette__item is-muted"
									aria-haspopup="menu"
									aria-expanded={Boolean(more)}
									onClick={(e) => {
										// Opens the other way when the menu would leave the screen at its end (the left on an RTL screen)
										const { left, right } = e.currentTarget.getBoundingClientRect();
										const overflows = 'rtl' === getComputedStyle(e.currentTarget).direction ? right - 296 < 0 : left + 296 > document.documentElement.clientWidth;

										setMore(more ? false : overflows ? 'end' : 'start');
									}}
								>
									{__( 'More', 'remaily' )}
									<Icon name="chevron" />
								</button>
								{more && (
									<span className="remaily-save__menu remaily-more__menu" role="menu">
										{moreItems.map((item) => (
											<button
												key={item.name}
												type="button"
												role="menuitem"
												draggable
												onDragStart={(e) => dragItem(e, item)}
												onDragEnd={() => setMore(false)}
												onClick={() => {
													handlers.insert(item.name);
													setMore(false);
												}}
											>
												<Icon name={item.icon} />
												<span className="remaily-save__text">
													<strong>{item.label}</strong>
													{item.summary && <span>{item.summary}</span>}
												</span>
											</button>
										))}
									</span>
								)}
							</span>
						)}
					</div>
				</div>

				<div className="remaily-card remaily-workspace">
					<div className="remaily-workspace__bar">
						<span className="remaily-dots" aria-hidden="true">
							<i />
							<i />
							<i />
						</span>
						<code className="remaily-workspace__code">{`~ [remaily id="${initial.hash}"]`}</code>
						<div className="remaily-workspace__tools">
							{[2, 4].map((n) => (
								<button
									key={n}
									type="button"
									className={spaces === n ? 'is-active' : ''}
									onClick={() => {
										code.current.reindent(spaces, n);
										setSpaces(n);
										store('spaces', n);
									}}
								>
									/ {sprintf( /* translators: %d: number of spaces */ __( '%d Space', 'remaily' ), n )}
								</button>
							))}
							<button type="button" onClick={tidy}>
								{__( 'Beautify HTML', 'remaily' )}
							</button>
							{beforeAi && (
								<button type="button" onClick={undoAi}>
									{__( 'Undo AI changes', 'remaily' )}
								</button>
							)}
							<button type="button" className="remaily-workspace__ai" onClick={() => setDescribing(true)}>
								<Icon name="sparkles" />
								{__( 'Describe your form', 'remaily' )}
							</button>
						</div>
					</div>
					{inTags.length > 0 && (
						<p className="remaily-workspace__problem" role="alert">
							<Icon name="warning" />
							{sprintf(
								/* translators: %s: field names, such as date_1, email */
								_n( '%s sits inside an HTML tag and breaks it. Drag it between tags.', '%s sit inside HTML tags and break them. Drag them between tags.', inTags.length, 'remaily' ),
								inTags.join(', ')
							)}
						</p>
					)}
					<div className="remaily-workspace__body">
						<CodeEditor
							ref={code}
							value={initial.template}
							onChange={(template) => setDoc((d) => ({ ...d, template }))}
							fields={fields}
							selected={selected}
							spaces={spaces}
							handlers={handlers}
						/>
						<aside className="remaily-workspace__side">{side}</aside>
					</div>
				</div>
			</div>

			{tab !== 'form' && (
				<div className="remaily-card remaily-sheet">
					{tab === 'mail' && <MailTab config={doc.config} template={doc.template} update={update} />}
					{tab === 'messages' && <MessagesTab config={doc.config} template={doc.template} update={update} />}
					{tab === 'advanced' && <AdvancedTab config={doc.config} update={update} formCode={formCode} onCopy={copyCode} onPaste={pasteCode} />}
					{extraTabs.map((t) => tab === t.id && <t.Component key={t.id} config={doc.config} template={doc.template} update={update} />)}
				</div>
			)}

			<footer ref={foot} className={`remaily-card remaily-foot${stuck ? ' is-stuck' : ''}`}>
				<p className="remaily-foot__hint">
					<Icon name="info" />
					{hint}
				</p>
				<div className="remaily-foot__actions">
					<button type="button" className="remaily-foot__trash" onClick={trash}>
						{__( 'Move to trash', 'remaily' )}
					</button>
					<SaveButton saving={saving} open={saveMenu === 'foot'} onToggle={() => setSaveMenu(saveMenu === 'foot' ? false : 'foot')} onSave={save} up={true} status={status} />
				</div>
			</footer>

			{menu && (
				<div className="remaily-menu" style={{ left: menu.x, top: menu.y }} role="menu" onClick={(e) => e.stopPropagation()}>
					{menu.canWrap && (
						<button
							type="button"
							role="menuitem"
							onClick={() => {
								setMenu(null);
								wrap();
							}}
						>
							<Icon name="group" />
							{__( 'Wrap in group', 'remaily' )}
							<kbd>⌘G</kbd>
						</button>
					)}
					{menu.group && (
						<>
							<button
								type="button"
								role="menuitem"
								onClick={() => {
									setMenu(null);
									handlers.select('group', menu.group.name);
								}}
							>
								<Icon name="pencil" />
								{sprintf( /* translators: %s: group name */ __( 'Edit group "%s"', 'remaily' ), menu.group.name )}
							</button>
							<button
								type="button"
								role="menuitem"
								onClick={() => {
									setMenu(null);
									ungroup(menu.group.name);
								}}
							>
								<Icon name="close" />
								{__( 'Ungroup', 'remaily' )}
							</button>
						</>
					)}
				</div>
			)}

			{describing && <Describe doc={doc} onApply={applyAi} onClose={() => setDescribing(false)} />}
			{previewing && (
				<Preview
					doc={doc}
					selected={selected}
					onSelect={(name) => {
						setPreviewing(false);
						setTab('form');
						selectFromFrame(name);
					}}
					onClose={() => setPreviewing(false)}
				/>
			)}

			{notice && (
				<div key={notice.key} className={`remaily-notice is-${notice.type}`} role="status">
					{notice.text}
				</div>
			)}
		</div>
	);
};

export default App;
