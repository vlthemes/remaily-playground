/**
 * The code's colours: HTML, and the CSS and JavaScript tabs (source-editor.js)
 */
import { HighlightStyle } from '@codemirror/language';
import { tags as t } from '@lezer/highlight';

// The code's colours: HTML, and the CSS and JavaScript tabs (source-editor.js)
export const highlight = HighlightStyle.define([
	{ tag: t.tagName, color: '#b32d2e' },
	{ tag: [t.attributeName, t.propertyName], color: '#3c434a' },
	{ tag: [t.attributeValue, t.string, t.regexp], color: '#2271b1' },
	{ tag: [t.angleBracket, t.punctuation, t.operator], color: '#8c8f94' },
	{ tag: t.comment, color: '#8c8f94', fontStyle: 'italic' },
	// .class, :hover, #id
	{ tag: [t.className, t.constant(t.className), t.labelName], color: '#008a20' },
	// Numbers, units, colours, keyword values (solid, auto), true, null
	{ tag: [t.number, t.unit, t.color, t.atom, t.bool, t.null], color: '#996800' },
	// @media, !important, const, if, return
	{ tag: [t.keyword, t.controlKeyword, t.definitionKeyword, t.moduleKeyword, t.operatorKeyword, t.modifier], color: '#7b2fbf' },
	// calc(), var(), addEventListener()
	{ tag: [t.function(t.variableName), t.function(t.propertyName), t.special(t.variableName)], color: '#0a7c75' },
]);
