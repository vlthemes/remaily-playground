/**
 * Groups and names as text: where a group ends, the group around a place, names kept lowercase and a group's
 * closing removed with its opening
 */
import { EditorState } from '@codemirror/state';
import { ANY_CASE, TOKEN } from '../state.js';

/**
 * Where a group token's group ends (after its closing token)
 *
 * @param {string} text Document
 * @param {number} from Position of [[group:…]]
 * @return {number} End
 */
export const groupEnd = (text, from) => {
	let depth = 0;

	for (const m of text.slice(from).matchAll(TOKEN)) {
		if (m[1].startsWith('group:')) {
			depth++;
		} else if (m[1] === '/group' && --depth === 0) {
			return from + m.index + m[0].length;
		}
	}

	return text.length;
};
/**
 * The innermost group around a position
 *
 * @param {string} text Document
 * @param {number} pos  Position
 * @return {{name: string, from: number, to: number}|null} Group
 */
export const groupAt = (text, pos) => {
	const stack = [];

	for (const m of text.matchAll(TOKEN)) {
		if (m.index >= pos) {
			break;
		}

		if (m[1].startsWith('group:')) {
			stack.push({ name: m[1].slice(6), from: m.index });
		} else if (m[1] === '/group' && m.index + m[0].length <= pos) {
			stack.pop();
		}
	}

	const open = stack.pop();

	return open ? { ...open, to: groupEnd(text, open.from) } : null;
};
// Names are lowercase: a token typed or pasted with capitals turns lowercase in the same step, one undo
export const lowerNames = EditorState.transactionFilter.of((tr) => {
	if (!tr.docChanged) {
		return tr;
	}

	const changes = [...tr.newDoc.toString().matchAll(ANY_CASE)].filter((m) => m[0] !== m[0].toLowerCase()).map((m) => ({ from: m.index, to: m.index + m[0].length, insert: m[0].toLowerCase() }));

	return changes.length ? [tr, { changes, sequential: true }] : tr;
});
// A group's opening removed by hand: its own closing goes too, in the same step (one undo), with its line if nothing
// else is on it. The pairs are read in the text before the change, so nested groups keep theirs
export const pairedGroups = EditorState.transactionFilter.of((tr) => {
	if (!tr.docChanged) {
		return tr;
	}

	const doc = tr.newDoc;
	const stack = [];
	const changes = [];

	for (const m of tr.startState.doc.toString().matchAll(TOKEN)) {
		if (m[1].startsWith('group:')) {
			stack.push(m);
		} else if ('/group' === m[1] && stack.length) {
			const open = stack.pop();
			// Where a token went, and whether it is still there as it was
			const kept = (token) => {
				const from = tr.changes.mapPos(token.index, 1);
				const to = tr.changes.mapPos(token.index + token[0].length, -1);

				return to - from === token[0].length && doc.sliceString(from, to) === token[0] ? { from, to } : null;
			};
			const closing = kept(m);

			// Its opening went, its closing is still there
			if (!kept(open) && closing) {
				const { from, to } = closing;
				const line = doc.lineAt(from);
				const alone = '' === (line.text.slice(0, from - line.from) + line.text.slice(to - line.from)).trim();

				changes.push(alone ? { from: line.from, to: Math.min(line.to + 1, doc.length) } : { from, to });
			}
		}
	}

	return changes.length ? [tr, { changes, sequential: true }] : tr;
});
