/**
 * Pasting code with chips: a field or group the form already has comes in as a copy, a new name with the same
 * settings (email → email_2), as Duplicate does. One cut and pasted again keeps its name: it's a move
 */
import { EditorView } from '@codemirror/view';
import { RESERVED, TOKEN } from '../state.js';
import { handlers, infoFacet } from './chips.js';

/**
 * The next free name, as Duplicate makes it: email → email_2, email_2 → email_3
 *
 * @param {string} name  Name
 * @param {Set}    taken Names in use
 * @return {string} Name
 */
const copyName = (name, taken) => {
	const base = name.replace(/_\d+$/, '');
	let n = 2;

	while (taken.has(`${base}_${n}`)) {
		n++;
	}

	return `${base}_${n}`;
};

/**
 * Pasted text with the fields and groups the form already has renamed, or null when nothing needs it
 *
 * @param {string}   text  Pasted text
 * @param {string}   doc   The form's code now
 * @param {string[]} saved Names with settings, placed or not (they stay taken)
 * @return {{ text: string, names: Object }|null} The text, and [ old name => new name ]
 */
export const pastedCopies = (text, doc, saved = []) => {
	const nameOf = (inner) => (inner.startsWith('group:') ? inner.slice(6) : inner.split(':')[0]);
	const placed = new Set([...doc.matchAll(TOKEN)].map((m) => m[1]).filter((inner) => '/group' !== inner).map(nameOf));
	const taken = new Set([...placed, ...saved]);
	const names = {};

	for (const [, inner] of text.matchAll(TOKEN)) {
		const name = nameOf(inner);

		// A setting as text ([[email:size]]) follows its field; places ([[captcha]]) are one per form anyway
		if ('/group' === inner || (inner.includes(':') && !inner.startsWith('group:')) || RESERVED.includes(name) || names[name] || !placed.has(name)) {
			continue;
		}

		names[name] = copyName(name, taken);
		taken.add(names[name]);
	}

	if (!Object.keys(names).length) {
		return null;
	}

	return {
		names,
		text: text.replace(TOKEN, (whole, inner) => {
			const name = nameOf(inner);

			if (!names[name] || '/group' === inner) {
				return whole;
			}

			return inner.startsWith('group:') ? `[[group:${names[name]}]]` : `[[${inner.replace(name, names[name])}]]`;
		}),
	};
};

export const pasteCopies = EditorView.domEventHandlers({
	paste(event, view) {
		const text = event.clipboardData?.getData('text/plain');
		const copy = text ? pastedCopies(text, view.state.doc.toString(), Object.keys(view.state.facet(infoFacet).fields || {})) : null;

		if (!copy) {
			return false;
		}

		event.preventDefault();
		// Their settings first, then the chips that show them
		handlers(view).copyNames?.(copy.names);
		view.dispatch({ ...view.state.replaceSelection(copy.text), userEvent: 'input.paste', scrollIntoView: true });

		return true;
	},
});
