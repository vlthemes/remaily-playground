/**
 * Tokens drawn as chips (fields, places, settings as text), group heads and ends, and the dashed boxes of groups
 * around their lines
 */
import { Facet, StateField } from '@codemirror/state';
import { Decoration, EditorView, WidgetType } from '@codemirror/view';
import { __, sprintf } from '@wordpress/i18n';
import { svg } from '../icons.js';
import { TOKEN, isInfo, places, tagEndAt, typeOf } from '../state.js';
import { DROP_EVENTS, chipElement, drag } from './drag.js';

export const infoFacet = Facet.define({
	combine: (values) => values[values.length - 1] || { fields: {}, selected: null, handlers: {} },
});
export const handlers = (view) => view.state.facet(infoFacet).handlers;
// The room of a space beside a chip that has none in the code, so a chip looks the same either way; nothing in the document
class TokenGap extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-token-gap';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}

	// A click or a drop here lands in the editor
	ignoreEvent() {
		return false;
	}
}
/**
 * A widget's outer span: its padding keeps chips on neighbouring lines apart
 *
 * @param {HTMLElement} el The chip
 * @return {HTMLElement} Its wrapper
 */
const wrapToken = (el) => {
	const wrap = document.createElement('span');

	wrap.className = 'remaily-token';
	wrap.append(el);

	return wrap;
};
export class Chip extends WidgetType {
	constructor(name, field, selected, misplaced) {
		super();
		this.name = name;
		this.type = field?.type || '';
		this.required = Boolean(field?.required && typeOf(this.type)?.required);
		this.selected = selected;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.type === this.type && other.required === this.required && other.selected === this.selected && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const el = chipElement(
			this.type ? typeOf(this.type)?.icon || this.type : 'info',
			this.name + (this.required ? ' *' : ''),
			`is-${this.type || 'unknown'}${this.selected ? ' is-selected' : ''}${this.type ? '' : ' is-unknown'}${this.misplaced ? ' is-misplaced' : ''}`
		);

		el.dataset.remailyName = this.name;
		el.title = this.type ? typeOf(this.type)?.label || this.type : __( 'This field has no settings yet. Click to set it up.', 'remaily' );

		if (this.misplaced) {
			el.title = __( 'Inside an HTML tag, where it breaks the tag. Drag it between tags.', 'remaily' );
		}

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => handlers(view).select?.('field', this.name));
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, this.name.length + 4, false));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}
// [[captcha]], [[response]] and the other places (remaily_places): moved and removed, nothing to set up
class Place extends WidgetType {
	constructor(name, misplaced) {
		super();
		this.name = name;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const place = places[this.name];
		const el = chipElement(place.icon, place.label, `is-place${this.misplaced ? ' is-misplaced' : ''}`);

		el.title = this.misplaced ? __( 'Inside an HTML tag, where it breaks the tag. Drag it between tags.', 'remaily' ) : place.summary;

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, this.name.length + 4, false));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}
// [[name:key]]: a field's setting as text; a light chip, "name · Max size", that selects its field
class InfoChip extends WidgetType {
	constructor(inner, field) {
		super();
		this.inner = inner;
		[this.name, this.key] = inner.split(':');
		this.label = typeOf(field?.type)?.info?.[this.key] || '';
	}

	eq(other) {
		return other.inner === this.inner && other.label === this.label;
	}

	toDOM(view) {
		const el = chipElement('info', `${this.name} · ${this.label || this.key}`, `is-info${this.label ? '' : ' is-unknown'}`);

		el.title = this.label
			? /* translators: 1: setting, such as Max size, 2: field name */ sprintf( __( '%1$s of %2$s, as visitors read it. Change it in the field\'s settings.', 'remaily' ), this.label, this.name )
			: __( 'No field, or nothing of it, has this name.', 'remaily' );

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => this.label && handlers(view).select?.('field', this.name));
		wrap.addEventListener('dblclick', () => handlers(view).removeAt?.(view.posAtDOM(wrap), this.inner));
		wrap.addEventListener('dragstart', drag(view, wrap, this.inner.length + 4, false, true));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}
class GroupHead extends WidgetType {
	constructor(name, selected, misplaced) {
		super();
		this.name = name;
		this.selected = selected;
		this.misplaced = misplaced;
	}

	eq(other) {
		return other.name === this.name && other.selected === this.selected && other.misplaced === this.misplaced;
	}

	toDOM(view) {
		const el = document.createElement('span');

		el.className = `remaily-group-head${this.selected ? ' is-selected' : ''}${this.misplaced ? ' is-misplaced' : ''}`;
		el.textContent = `⠿ ${__( 'Group:', 'remaily' )} ${this.name}`;

		const wrap = wrapToken(el);

		wrap.draggable = true;
		wrap.addEventListener('mousedown', (e) => e.stopPropagation());
		wrap.addEventListener('click', () => handlers(view).select?.('group', this.name));
		wrap.addEventListener('dragstart', drag(view, wrap, 0, true));

		return wrap;
	}

	ignoreEvent(event) {
		return !DROP_EVENTS.includes(event.type);
	}
}
class GroupEnd extends WidgetType {
	constructor(name) {
		super();
		this.name = name;
	}

	eq(other) {
		return other.name === this.name;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-group-end';
		/* translators: %s: group name */
		el.textContent = this.name ? sprintf( __( 'end of %s', 'remaily' ), this.name ) : __( 'end of group', 'remaily' );

		return el;
	}
	// Only a label: a click on it puts the caret there, as on text
	ignoreEvent() {
		return false;
	}
}
// A line draws every box it sits in, the outer ones too: a box 10px inside the one around it, 6px of air above its top and
// below its bottom, its corners rounded. A line has one border of its own, so the dashes are backgrounds; the air
// outside the outer box is padding too, as CodeMirror counts a line's height without its margins
const BOX_STEP = 10;
const BOX_AIR = 6;
const BOX_RADIUS = 4;
const dash = (side) => `repeating-linear-gradient(${side}, var(--re-border-strong) 0 4px, transparent 4px 8px)`;
// A quarter circle in the colour of --re-border-strong (a data URI can't read a CSS variable), one per corner
const corner = (d) => `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="5" height="5"><path d="${d}" fill="none" stroke="#c3c4c7"/></svg>`)}")`;
const CORNERS = {
	tl: corner('M.5 5V4.5A4 4 0 0 1 4.5.5H5'),
	tr: corner('M0 .5h.5a4 4 0 0 1 4 4V5'),
	bl: corner('M.5 0v.5a4 4 0 0 0 4 4H5'),
	br: corner('M0 4.5h.5a4 4 0 0 0 4-4V0'),
};
const boxStyle = ({ depth, opens, closes }) => {
	const top = Math.min(...opens, depth + 1);
	const bottom = Math.min(...closes, depth + 1);
	const r = BOX_RADIUS;
	const layers = [];

	for (let level = 1; level <= depth; level++) {
		const x = (level - 1) * BOX_STEP;
		const opened = opens.includes(level);
		const closed = closes.includes(level);
		const y = opened ? (level - top + 1) * BOX_AIR : 0;
		const yEnd = closed ? (level - bottom + 1) * BOX_AIR : 0;
		// The sides stop where a rounded corner takes over
		const sideTop = y + (opened ? r : 0);
		const height = `calc(100% - ${sideTop + yEnd + (closed ? r : 0)}px)`;
		const width = `calc(100% - ${2 * (x + r)}px)`;

		layers.push(`${dash('to bottom')} left ${x}px top ${sideTop}px / 1px ${height} no-repeat`, `${dash('to bottom')} right ${x}px top ${sideTop}px / 1px ${height} no-repeat`);

		if (opened) {
			layers.push(`${CORNERS.tl} left ${x}px top ${y}px / 5px 5px no-repeat`, `${CORNERS.tr} right ${x}px top ${y}px / 5px 5px no-repeat`, `${dash('to right')} left ${x + r}px top ${y}px / ${width} 1px no-repeat`);
		}

		if (closed) {
			layers.push(`${CORNERS.bl} left ${x}px bottom ${yEnd}px / 5px 5px no-repeat`, `${CORNERS.br} right ${x}px bottom ${yEnd}px / 5px 5px no-repeat`, `${dash('to right')} left ${x + r}px bottom ${yEnd}px / ${width} 1px no-repeat`);
		}
	}

	// Every line keeps CodeMirror's own padding, as its selection reads the first line's: a group's text moves in by a
	// margin, and its boxes are drawn under the line across that margin (::before, editor.scss)
	const shift = 6 + (depth - 1) * BOX_STEP;

	return [
		`--remaily-depth:${depth}`,
		`--remaily-shift:${shift}px`,
		`--remaily-box:${layers.join(',')}`,
		`margin-inline:${shift}px`,
		`padding-top:${opens.length ? (depth - top + 2) * BOX_AIR : 0}px`,
		`padding-bottom:${closes.length ? (depth - bottom + 2) * BOX_AIR : 0}px`,
	].join(';');
};
function build(state) {
	const { fields, selected } = state.facet(infoFacet);
	const doc = state.doc;
	const text = doc.toString();
	const decos = [];
	const stack = [];
	const spans = [];
	const gaps = new Set();
	const touches = (char) => undefined !== char && !/\s/.test(char);

	for (const m of text.matchAll(TOKEN)) {
		const from = m.index;
		const to = from + m[0].length;
		const inner = m[1];

		if (touches(text[from - 1])) {
			gaps.add(from);
		}

		if (touches(text[to])) {
			gaps.add(to);
		}

		if (inner === '/group') {
			const open = stack.pop();

			decos.push(Decoration.replace({ widget: new GroupEnd(open?.name) }).range(from, to));

			if (open) {
				spans.push({ from: open.from, to, depth: stack.length });
			}
		} else if (inner.startsWith('group:')) {
			const name = inner.slice(6);

			stack.push({ name, from });
			decos.push(Decoration.replace({ widget: new GroupHead(name, selected?.kind === 'group' && selected.name === name, tagEndAt(text, from) >= 0) }).range(from, to));
		} else if (isInfo(inner)) {
			decos.push(Decoration.replace({ widget: new InfoChip(inner, fields[inner.split(':')[0]]) }).range(from, to));
		} else if (places[inner]) {
			decos.push(Decoration.replace({ widget: new Place(inner, tagEndAt(text, from) >= 0) }).range(from, to));
		} else {
			decos.push(Decoration.replace({ widget: new Chip(inner, fields[inner], selected?.kind === 'field' && selected.name === inner, tagEndAt(text, from) >= 0) }).range(from, to));
		}
	}

	gaps.forEach((pos) => decos.push(Decoration.widget({ widget: new TokenGap(), side: -1 }).range(pos)));

	stack.forEach((open, i) => spans.push({ from: open.from, to: doc.length, depth: i }));

	// Group boxes: each line of a group, how deep it is and which boxes open or close on it
	const lines = new Map();

	spans.forEach(({ from, to, depth }) => {
		const first = doc.lineAt(from).number;
		const last = doc.lineAt(to).number;

		for (let n = first; n <= last; n++) {
			const line = lines.get(n) || { depth: 0, opens: [], closes: [] };

			line.depth = Math.max(line.depth, depth + 1);
			n === first && line.opens.push(depth + 1);
			n === last && line.closes.push(depth + 1);
			lines.set(n, line);
		}
	});

	lines.forEach((line, n) => {
		decos.push(
			Decoration.line({
				attributes: { class: `remaily-gline${line.opens.length ? ' is-first' : ''}${line.closes.length ? ' is-last' : ''}`, style: boxStyle(line) },
			}).range(doc.line(n).from)
		);
	});

	return Decoration.set(decos, true);
}
export const tokenField = StateField.define({
	create: build,
	update(value, tr) {
		return tr.docChanged || tr.startState.facet(infoFacet) !== tr.state.facet(infoFacet) ? build(tr.state) : value;
	},
	provide: (field) => [EditorView.decorations.from(field), EditorView.atomicRanges.of((view) => view.state.field(field))],
});
