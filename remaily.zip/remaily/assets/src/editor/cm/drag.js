/**
 * Dragging chips: into the code from the field buttons and sidebars, and around inside it, with a mark at each
 * place a chip can go and a slot where it will land
 */
import { StateEffect, StateField } from '@codemirror/state';
import { Decoration, EditorView, WidgetType } from '@codemirror/view';
import { svg } from '../icons.js';
import { outsideTag, places, tagEndAt } from '../state.js';
import { Chip, handlers } from './chips.js';
import { groupAt, groupEnd } from './groups.js';

export const MIME_NEW = 'application/x-remaily-new';
export const MIME_MOVE = 'application/x-remaily-move';
// A [[name:key]] chip: text, so it lands where it's let go (in text or an attribute's value), not at the marked places
export const MIME_FREE = 'application/x-remaily-free';
// A token dragged in from outside the code, such as a sidebar's Use in text button: the text to insert
export const MIME_TEXT = 'application/x-remaily-text';
/**
 * A token with a space on each side where it touches text or a tag, so chips never stick to their neighbours
 *
 * @param {string} text  Document
 * @param {number} pos   Where it goes
 * @param {string} token Token
 * @return {string} What to insert
 */
export const spaced = (text, pos, token) => (pos > 0 && !/\s/.test(text[pos - 1]) ? ' ' : '') + token + (pos < text.length && !/\s/.test(text[pos]) ? ' ' : '');
/**
 * Where a [[name:key]] chip lands: the position itself between tags or inside an attribute's quoted value, else
 * after the tag
 *
 * @param {string} text Document
 * @param {number} pos  Position
 * @return {number} Position
 */
export const freeSpot = (text, pos) => {
	if (tagEndAt(text, pos) < 0) {
		return pos;
	}

	const inTag = text.slice(text.lastIndexOf('<', pos), pos);

	return (inTag.split('"').length - 1) % 2 || (inTag.split("'").length - 1) % 2 ? pos : outsideTag(text, pos);
};
// While dragging: an empty slot where the chip will land, opening a gap between the elements around it
const setDrop = StateEffect.define();
class DropSlot extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-drop-slot';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}
}
export const dropField = StateField.define({
	create: () => null,
	update(pos, tr) {
		for (const effect of tr.effects) {
			if (effect.is(setDrop)) {
				return effect.value;
			}
		}

		return null === pos || !tr.docChanged ? pos : tr.changes.mapPos(pos);
	},
	provide: (field) => EditorView.decorations.from(field, (pos) => (null === pos ? Decoration.none : Decoration.set([Decoration.widget({ widget: new DropSlot(), side: 1 }).range(pos)]))),
});
// While dragging: a mark at each place a chip can go (around tags and chips, never inside a tag)
const setDragging = StateEffect.define();
class DropSpot extends WidgetType {
	eq() {
		return true;
	}

	toDOM() {
		const el = document.createElement('span');

		el.className = 'remaily-drop-spot';
		el.setAttribute('aria-hidden', 'true');

		return el;
	}
}
/**
 * The places a chip can go: before and after each tag and chip, one where only spaces lie between two, and each
 * empty line
 *
 * @param {string} text Document
 * @return {number[]} Positions, in order
 */
export const dropSpots = (text) => {
	const spots = new Set([0, text.length]);
	const blank = new Set();

	// An empty line, after its indentation; not one inside a tag that spans lines
	for (const m of text.matchAll(/^[ \t]*$/gm)) {
		const pos = m.index + m[0].length;

		if (tagEndAt(text, pos) < 0) {
			blank.add(pos);
			spots.add(pos);
		}
	}

	for (const m of text.matchAll(/<\/?[a-zA-Z][^>]*>|\[\[[^\]]+\]\]/g)) {
		if (m[0][0] === '[' && tagEndAt(text, m.index) >= 0) {
			continue;
		}

		spots.add(m.index);
		spots.add(m.index + m[0].length);
	}

	const sorted = [...spots].sort((a, b) => a - b);

	return sorted.filter((pos, i) => i === 0 || blank.has(pos) || text.slice(sorted[i - 1], pos).trim() !== '');
};
export const dragField = StateField.define({
	create: () => false,
	update(on, tr) {
		for (const effect of tr.effects) {
			if (effect.is(setDragging)) {
				return effect.value;
			}
		}

		return on;
	},
	provide: (field) =>
		EditorView.decorations.compute([field, 'doc'], (state) =>
			state.field(field) ? Decoration.set(dropSpots(state.doc.toString()).map((pos) => Decoration.widget({ widget: new DropSpot(), side: -1 }).range(pos))) : Decoration.none
		),
});
/**
 * Show or hide the places a chip can go
 *
 * @param {EditorView} view Editor
 * @param {boolean}    on   Dragging
 */
export const showSpots = (view, on) => {
	if (view.state.field(dragField) !== on) {
		view.dispatch({ effects: setDragging.of(on) });
	}
};
/**
 * Take the slot and the marks away (a drag ended anywhere: dropped outside the editor, or let go with Escape)
 *
 * @param {EditorView} view Editor
 */
export const clearDrop = (view) => {
	showDrop(view, null);
	showSpots(view, false);
};
const showDrop = (view, pos) => {
	if (view.state.field(dropField) !== pos) {
		view.dispatch({ effects: setDrop.of(pos) });
	}
};
/**
 * The marked place nearest the pointer, on screen
 *
 * @param {EditorView} view  Editor
 * @param {DragEvent}  event Drag over
 * @return {number|null} Position
 */
const nearestSpot = (view, event) => {
	const { from, to } = view.viewport;
	let best = null;
	let distance = Infinity;

	for (const pos of dropSpots(view.state.doc.toString())) {
		if (pos < from || pos > to) {
			continue;
		}

		const box = view.coordsAtPos(pos, -1);

		if (box) {
			// Lines count more than sideways, so the slot stays on the pointer's line
			const d = Math.hypot(event.clientX - box.left, (event.clientY - (box.top + box.bottom) / 2) * 3);

			if (d < distance) {
				distance = d;
				best = pos;
			}
		}
	}

	return best;
};
/**
 * A chip's element: grip, icon, name
 *
 * @param {string} icon      Icon
 * @param {string} label     Name
 * @param {string} className Classes
 * @return {HTMLElement} Chip
 */
export const chipElement = (icon, label, className = '') => {
	const el = document.createElement('span');
	const name = document.createElement('span');

	el.className = `remaily-chip ${className}`.trim();
	el.innerHTML = `<span class="remaily-chip__grip">⠿</span>${svg(icon)}`;
	name.className = 'remaily-chip__name';
	name.textContent = label;
	el.append(name);

	return el;
};
/**
 * The same drag for a field button and a chip: a chip held by its grip in the hand, the source left as a ghost
 *
 * @param {DragEvent}   event  Drag start
 * @param {HTMLElement} source What was grabbed
 * @param {HTMLElement} chip   The chip to show in the hand
 */
export const dragChip = (event, source, chip) => {
	const image = chip.cloneNode(true);

	image.classList.remove('is-selected');
	image.classList.add('remaily-drag-image');
	(source.closest('.remaily-editor') || document.body).append(image);
	event.dataTransfer.setDragImage?.(image, 14, image.offsetHeight / 2);
	setTimeout(() => image.remove());

	// After the browser has taken its picture
	requestAnimationFrame(() => source.classList.add('is-dragging'));
	source.addEventListener('dragend', () => source.classList.remove('is-dragging'), { once: true });
};
// A chip or group head lets the editor have these, so a chip dropped onto itself or its neighbour still lands, and a
// right-click on it opens the editor's menu
export const DROP_EVENTS = ['dragenter', 'dragover', 'dragleave', 'drop', 'contextmenu'];
export const drag = (view, el, length, whole, free = false) => (event) => {
	const from = view.posAtDOM(el);
	const to = whole ? groupEnd(view.state.doc.toString(), from) : from + length;

	event.dataTransfer.setData(MIME_MOVE, JSON.stringify({ from, to }));

	if (free) {
		event.dataTransfer.setData(MIME_FREE, '1');
	}

	event.dataTransfer.setData('text/plain', view.state.sliceDoc(from, to));
	event.dataTransfer.effectAllowed = 'move';
	dragChip(event, el, el.firstElementChild || el);
	// The editor may redraw the chip while the slot opens beside it; dragend then fires on the old one, off the page
	el.addEventListener('dragend', () => clearDrop(view), { once: true });
};
export const dropHandlers = EditorView.domEventHandlers({
	dragover(event, view) {
		const types = [...event.dataTransfer.types];

		if (types.includes(MIME_NEW) || types.includes(MIME_MOVE) || types.includes(MIME_TEXT)) {
			event.preventDefault();
			event.dataTransfer.dropEffect = types.includes(MIME_MOVE) ? 'move' : 'copy';

			// Text goes where the pointer is
			if (types.includes(MIME_FREE)) {
				const pos = view.posAtCoords({ x: event.clientX, y: event.clientY });

				if (pos !== null) {
					showDrop(view, freeSpot(view.state.doc.toString(), pos));
				}

				return true;
			}

			showSpots(view, true);

			// Over the slot itself: it stays where it is; else it opens at the marked place nearest the pointer
			if (!event.target.closest?.('.remaily-drop-slot')) {
				const pos = nearestSpot(view, event) ?? view.posAtCoords({ x: event.clientX, y: event.clientY });

				if (pos !== null) {
					showDrop(view, outsideTag(view.state.doc.toString(), pos));
				}
			}

			return true;
		}

		return false;
	},
	dragleave(event, view) {
		if (!view.dom.contains(event.relatedTarget)) {
			showDrop(view, null);
		}
	},
	dragend(event, view) {
		clearDrop(view);
	},
	drop(event, view) {
		const type = event.dataTransfer.getData(MIME_NEW);
		const move = event.dataTransfer.getData(MIME_MOVE);
		const token = event.dataTransfer.getData(MIME_TEXT);
		// The slot's place, else the pointer's
		const at = view.state.field(dropField) ?? view.posAtCoords({ x: event.clientX, y: event.clientY });

		clearDrop(view);

		if ((!type && !move && !token) || at === null) {
			return false;
		}

		const free = [...event.dataTransfer.types].includes(MIME_FREE);
		const pos = free ? freeSpot(view.state.doc.toString(), at) : outsideTag(view.state.doc.toString(), at);

		event.preventDefault();

		if (token) {
			view.dispatch({ changes: { from: pos, insert: token }, selection: { anchor: pos + token.length } });
		} else if (type) {
			handlers(view).insert?.(type, pos);
		} else {
			const { from, to } = JSON.parse(move);
			const text = view.state.doc.toString();

			if (pos < from || pos > to) {
				// Leaving: a space it sat between goes too
				const end = text[from - 1] === ' ' && text[to] === ' ' ? to + 1 : to;

				view.dispatch({ changes: [{ from, to: end, insert: '' }, { from: pos, insert: free ? text.slice(from, to) : spaced(text, pos, text.slice(from, to)) }] });
			}
		}

		view.focus();

		return true;
	},
	contextmenu(event, view) {
		const sel = view.state.selection.main;
		const pos = view.posAtCoords({ x: event.clientX, y: event.clientY }) ?? sel.head;
		const group = groupAt(view.state.doc.toString(), pos);
		// A chip under the pointer: to duplicate or remove
		const token = event.target.closest?.('.remaily-token');
		const at = token ? view.posAtDOM(token) : -1;
		const match = token ? /^\[\[([^\]]+)\]\]/.exec(view.state.sliceDoc(at, at + 120)) : null;
		const chip = match && '/group' !== match[1] && !match[1].startsWith('group:') ? { inner: match[1], pos: at, length: match[0].length } : null;

		if (sel.empty && !group && !chip) {
			return false;
		}

		event.preventDefault();
		handlers(view).contextMenu?.({ x: event.clientX, y: event.clientY, canWrap: !sel.empty, group, chip });

		return true;
	},
});
