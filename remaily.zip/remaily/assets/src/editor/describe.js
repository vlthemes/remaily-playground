/**
 * Describe your form: a sentence becomes the form's fields, groups, mails and messages, written by the site's AI
 * (Api\Describe). Applied unsaved, with Undo.
 */
import { createInterpolateElement, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';
import { Button, Textarea } from './controls.js';
import { Icon } from './icons.js';
import data, { prune } from './state.js';

const Describe = ({ doc, onApply, onClose }) => {
	const [text, setText] = useState('');
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState('');

	const build = () => {
		setBusy(true);
		setError('');

		apiFetch({ path: '/remaily/v1/describe', method: 'POST', data: { prompt: text, template: doc.template, config: prune(doc.config, doc.template) } })
			.then((answer) => onApply(answer))
			.catch((failure) => setError(failure.message || __( 'Something went wrong. Please try again.', 'remaily' )))
			.finally(() => setBusy(false));
	};

	return (
		<div className="remaily-dialog" role="dialog" aria-modal="true" aria-labelledby="remaily-describe-title" onKeyDown={(e) => e.key === 'Escape' && onClose()}>
			<div className="remaily-dialog__box">
				<div className="remaily-dialog__head">
					<h2 id="remaily-describe-title">{__( 'Describe your form', 'remaily' )}</h2>
					<button type="button" className="remaily-dialog__close" onClick={onClose} aria-label={__( 'Close', 'remaily' )}>
						<Icon name="close" />
					</button>
				</div>

				{data.aiAvailable ? (
					<>
						<Textarea
							label={__( 'What should this form ask?', 'remaily' )}
							help={__( 'In your own words. The AI connected to your site writes the fields, conditions, mail and messages. Nothing is saved until you save the form, and Undo puts it back.', 'remaily' )}
							placeholder={__( 'A quote request: name, email, company, budget from a list, a deadline, and a file upload that shows only when they pick "I have a brief"', 'remaily' )}
							rows={5}
							autoFocus
							value={text}
							onChange={setText}
						/>
						{error && <p className="remaily-dialog__error">{error}</p>}
						<div className="remaily-dialog__actions">
							<Button onClick={onClose}>{__( 'Cancel', 'remaily' )}</Button>
							<Button variant="primary" icon="save" onClick={build} disabled={busy || text.trim().length < 3}>
								{busy ? __( 'Building…', 'remaily' ) : __( 'Build it', 'remaily' )}
							</Button>
						</div>
					</>
				) : (
					<p className="remaily-dialog__note">
						{data.connectorsUrl
							? createInterpolateElement(__( 'Connect an AI service in <a>Settings → Connectors</a> to describe a form in your own words.', 'remaily' ), {
									a: <a href={data.connectorsUrl} />,
								})
							: __( 'Connect an AI service to WordPress (Settings → Connectors in WordPress 7.0 and later) to describe a form in your own words.', 'remaily' )}
					</p>
				)}
			</div>
		</div>
	);
};

export default Describe;
