/**
 * The Form tab's CSS and JavaScript: an editor for each (settings.css, settings.js) and what can go in it
 */
import { forwardRef, useEffect, useImperativeHandle, useRef } from '@wordpress/element';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap, drawSelection } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import { indentUnit, syntaxHighlighting } from '@codemirror/language';
import { css } from '@codemirror/lang-css';
import { javascript } from '@codemirror/lang-javascript';
import { __ } from '@wordpress/i18n';
import { highlight } from './cm.js';
import data from './state.js';

// An empty CSS tab starts with the rule for this form; the JavaScript's example is beside it, in SourceHelp
const STARTERS = {
	css: 'selector {}',
	js: '',
};

const indent = new Compartment();

// Leading spaces (a tab as one step) from one indent to another: 2 spaces a step to 4
const reindented = (doc, from, to) => {
	const changes = [];

	for (let n = 1; n <= doc.lines; n++) {
		const line = doc.line(n);
		const lead = line.text.match(/^[ \t]*/)[0];

		if (lead) {
			const width = [...lead].reduce((sum, ch) => sum + ('\t' === ch ? from : 1), 0);
			const next = ' '.repeat(Math.floor(width / from) * to + (width % from));

			next !== lead && changes.push({ from: line.from, to: line.from + lead.length, insert: next });
		}
	}

	return changes;
};

export const SourceEditor = forwardRef(({ lang, value, onChange, spaces, readOnly, onSave }, ref) => {
	const parent = useRef(null);
	const view = useRef(null);
	const live = useRef({ onChange, onSave });

	live.current = { onChange, onSave };

	useEffect(() => {
		view.current = new EditorView({
			parent: parent.current,
			state: EditorState.create({
				doc: value || STARTERS[lang],
				extensions: [
					history(),
					drawSelection(),
					keymap.of([{ key: 'Mod-s', preventDefault: true, run: () => (live.current.onSave?.(), true) }, ...defaultKeymap, ...historyKeymap, indentWithTab]),
					'css' === lang ? css() : javascript(),
					syntaxHighlighting(highlight),
					EditorView.lineWrapping,
					EditorView.editorAttributes.of({ dir: 'ltr' }),
					indent.of([indentUnit.of(' '.repeat(spaces)), EditorState.tabSize.of(spaces)]),
					EditorState.readOnly.of(Boolean(readOnly)),
					EditorView.updateListener.of((update) => update.docChanged && live.current.onChange(update.state.doc.toString())),
				],
			}),
		});

		return () => view.current.destroy();
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => {
		view.current?.dispatch({ effects: indent.reconfigure([indentUnit.of(' '.repeat(spaces)), EditorState.tabSize.of(spaces)]) });
	}, [spaces]);

	useImperativeHandle(ref, () => ({
		// The code from one indent to another, as one undo step
		reindent(from, to) {
			const changes = reindented(view.current.state.doc, from, to);

			changes.length && view.current.dispatch({ changes });
		},
		// Text at the cursor, on a line of its own when the line has something
		insert(text) {
			const v = view.current;
			const at = v.state.selection.main.head;
			const line = v.state.doc.lineAt(at);
			const insert = '' === line.text.trim() ? text : `\n${text}`;

			v.dispatch({ changes: { from: '' === line.text.trim() ? at : line.to, insert }, selection: { anchor: ('' === line.text.trim() ? at : line.to) + insert.length } });
			v.focus();
		},
	}));

	return <div className="remaily-code" ref={parent} />;
});

const CLASSES = ['selector', 'selector .remaily__form', 'selector .remaily-field', 'selector .remaily-control', 'selector .remaily-error', 'selector [type="submit"]', 'selector .remaily-alert--success'];

const EVENTS = ['submit', 'sent', 'success', 'failed', 'invalid', 'reset'];

/**
 * Beside the CSS or JavaScript: what to write, a click puts it in
 */
export const SourceHelp = ({ lang, onInsert }) =>
	'css' === lang ? (
		<div className="remaily-source-help">
			<h3>{__( 'Classes', 'remaily' )}</h3>
			<ul>
				{CLASSES.map((rule, i) => (
					<li key={rule} style={{ '--depth': i ? 1 : 0 }}>
						<button type="button" onClick={() => onInsert(`${rule} {\n\t\n}`)}>
							{rule}
						</button>
					</li>
				))}
			</ul>
			<p>{__( 'selector stands for this form, so the rules reach no other form. Every rule can start with it.', 'remaily' )}</p>
			<pre>{'selector {\n\t--remaily-accent: #0a7c55;\n}\n\nselector .remaily-field {\n\tborder-radius: 12px;\n}'}</pre>
			<a href={`${data.docsUrl}css-variables/`} target="_blank" rel="noopener noreferrer">
				{__( 'The CSS variables', 'remaily' )}
			</a>
		</div>
	) : (
		<div className="remaily-source-help">
			{!data.canJs && <p className="remaily-source-help__note">{__( 'Only administrators can change the JavaScript, as it runs for every visitor.', 'remaily' )}</p>}
			<h3>{__( 'At hand', 'remaily' )}</h3>
			<ul>
				<li>
					<code>root</code> {__( 'the form\'s wrapper', 'remaily' )}
				</li>
				<li>
					<code>form</code> {__( 'the <form> itself', 'remaily' )}
				</li>
			</ul>
			<h3>{__( 'Events', 'remaily' )}</h3>
			<ul>
				{EVENTS.map((name) => (
					<li key={name}>
						<button type="button" disabled={!data.canJs} onClick={() => onInsert(`form.addEventListener('remaily:${name}', (event) => {\n\t\n});`)}>
							remaily:{name}
						</button>
					</li>
				))}
			</ul>
			<p>{__( 'The code runs once the form is ready, on every page that shows it and in the preview.', 'remaily' )}</p>
			<pre>{"form.addEventListener('remaily:sent', () => {\n\troot.classList.add('is-sent');\n});\n\nform.addEventListener('remaily:invalid', () => {\n\troot.scrollIntoView({ behavior: 'smooth' });\n});"}</pre>
			<a href={`${data.docsUrl}javascript-events/`} target="_blank" rel="noopener noreferrer">
				{__( 'The JavaScript events', 'remaily' )}
			</a>
		</div>
	);
