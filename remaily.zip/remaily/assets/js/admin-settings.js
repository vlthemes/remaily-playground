/* ========================================
 * Admin tabs, address previews and conditional fields of the settings pages.
 * The open tab is kept in the #hash so saving returns to it.
 * ======================================== */

( function () {
	var tabs = Array.prototype.slice.call( document.querySelectorAll( '[role="tab"][data-vlt-tab]' ) );

	function groupOf( tab ) {
		var list = tab.closest( '[role="tablist"]' );

		return tabs.filter( function ( item ) {
			return item.closest( '[role="tablist"]' ) === list;
		} );
	}

	function select( tab, focus ) {
		var panel = document.getElementById( tab.getAttribute( 'aria-controls' ) );

		groupOf( tab ).forEach( function ( item ) {
			var other = document.getElementById( item.getAttribute( 'aria-controls' ) );

			item.setAttribute( 'aria-selected', item === tab ? 'true' : 'false' );
			item.tabIndex = item === tab ? 0 : -1;

			if ( other ) {
				other.hidden = item !== tab;
			}
		} );

		// Settings: the form is the card of the field tabs, hidden while a module tab (its own card) is open
		var panels = panel && panel.closest( '.vlt-settings-page__panels' );
		var form = panels && panels.querySelector( '.vlt-settings-page__form' );

		if ( form ) {
			form.hidden = !form.contains( panel );
		}

		history.replaceState( history.state, '', '#' + tab.dataset.vltTab );

		// After saving, options.php / admin-post.php redirect to the referer: keep the tab in it
		document.querySelectorAll( 'input[name="_wp_http_referer"]' ).forEach( function ( input ) {
			var referer = new URL( input.value, window.location.origin );
			input.value = referer.pathname + referer.search + '#' + tab.dataset.vltTab;
		} );

		if ( panel ) {
			panel.dispatchEvent( new CustomEvent( 'vlt-tab:shown', { bubbles: true } ) );
		}

		if ( focus ) {
			tab.focus();
		}
	}

	function fromHash() {
		var id = window.location.hash.slice( 1 );

		return tabs.filter( function ( tab ) {
			return tab.dataset.vltTab === id;
		} )[ 0 ];
	}

	tabs.forEach( function ( tab ) {
		tab.addEventListener( 'click', function ( event ) {
			// A link tab opens in a new browser tab as usual
			if ( event.metaKey || event.ctrlKey || event.shiftKey ) {
				return;
			}

			event.preventDefault();
			select( tab );
		} );

		// Left / Right along the pills (Up / Down work too), the other way round on an RTL screen
		tab.addEventListener( 'keydown', function ( event ) {
			var group = groupOf( tab );
			var index = group.indexOf( tab );
			var ahead = 'rtl' === getComputedStyle( tab ).direction ? -1 : 1;
			var next = {
				ArrowDown: index + 1,
				ArrowRight: index + ahead,
				ArrowUp: index - 1,
				ArrowLeft: index - ahead,
				Home: 0,
				End: group.length - 1,
			}[ event.key ];

			if ( undefined !== next ) {
				event.preventDefault();
				select( group[ ( next + group.length ) % group.length ], true );
			}
		} );
	} );

	window.addEventListener( 'hashchange', function () {
		var tab = fromHash();

		if ( tab ) {
			select( tab );
		}
	} );

	// The page opens on the tab of the address, else the one the server marked
	if ( fromHash() ) {
		select( fromHash() );
	}

	// Address previews follow their slug field
	document.querySelectorAll( '[data-vlt-settings-preview]' ).forEach( function ( preview ) {
		var input = document.getElementById( preview.dataset.vltSettingsPreview );
		var value = preview.querySelector( 'b' );

		if ( input && value ) {
			input.addEventListener( 'input', function () {
				value.textContent = input.value.trim().toLowerCase().replace( /[^a-z0-9_-]+/g, '-' ) || input.placeholder;
			} );
		}
	} );

	// Image fields: the Media Library picks the image (wp.media, loaded by SettingsPage::enqueue())
	document.querySelectorAll( '[data-vlt-settings-image]' ).forEach( function ( field ) {
		var input = field.querySelector( 'input' );
		var preview = field.querySelector( '.vlt-settings-page__image-preview' );
		var remove = field.querySelector( '[data-vlt-settings-image-remove]' );
		var frame;

		function set( id, url ) {
			var content = document.createElement( url ? 'img' : 'span' );

			if ( url ) {
				content.src = url;
				content.alt = '';
			} else {
				content.textContent = field.dataset.empty;
			}

			input.value = id;
			preview.classList.toggle( 'is-empty', ! url );
			preview.replaceChildren( content );
			remove.hidden = ! url;
		}

		field.querySelectorAll( '[data-vlt-settings-image-choose]' ).forEach( function ( button ) {
			button.addEventListener( 'click', function () {
				if ( ! window.wp || ! wp.media ) {
					return;
				}

				frame = frame || wp.media( {
					title: field.dataset.title,
					library: { type: 'image' },
					multiple: false,
				} );

				frame.off( 'select' ).on( 'select', function () {
					var image = frame.state().get( 'selection' ).first().toJSON();
					var sizes = image.sizes || {};

					set( image.id, ( sizes.medium || sizes.full || image ).url );
				} );

				frame.open();
			} );
		} );

		remove.addEventListener( 'click', function () {
			set( 0, '' );
		} );
	} );

	// The save bar: rounded as the card's foot, square while it sticks to the bottom of the window. It sits at
	// bottom: -1px, so while stuck it is never wholly in view
	document.querySelectorAll( '.vlt-settings-page__save' ).forEach( function ( bar ) {
		if ( ! window.IntersectionObserver ) {
			return;
		}

		new IntersectionObserver( function ( entries ) {
			bar.classList.toggle( 'is-stuck', entries[ 0 ].intersectionRatio < 1 && entries[ 0 ].boundingClientRect.top > 0 );
		}, { threshold: [ 1 ] } ).observe( bar );
	} );

	// Saving without a reload (data-vlt-rest, SettingsPage::save_request()): a note at the bottom of the window says how
	// it went, as in the form editor. Without the script the form posts to options.php
	var toast;
	var toastTimer;

	function notify( message, type ) {
		if ( ! toast ) {
			toast = document.createElement( 'div' );
			toast.setAttribute( 'role', 'status' );
			document.body.appendChild( toast );
		}

		clearTimeout( toastTimer );
		toast.textContent = message;
		toast.className = 'vlt-settings-toast is-' + type;
		toast.hidden = false;

		toastTimer = setTimeout( function () {
			toast.hidden = true;
		}, 2600 );
	}

	document.querySelectorAll( 'form[data-vlt-rest]' ).forEach( function ( form ) {
		var button = form.querySelector( '.vlt-settings-page__save [type="submit"]' );

		if ( ! window.fetch || ! window.FormData ) {
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			var data = new FormData( form );

			event.preventDefault();
			button.disabled = true;

			// options.php's nonce: REST reads a _wpnonce in the body before the header, and fails on this one
			data.delete( '_wpnonce' );

			fetch( form.dataset.vltRest, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'X-WP-Nonce': form.dataset.vltNonce },
				body: data,
			} )
				.then( function ( response ) {
					return response.json().then( function ( body ) {
						if ( ! response.ok ) {
							throw new Error( body && body.message ? body.message : form.dataset.vltError );
						}

						return body;
					} );
				} )
				.then( function ( body ) {
					notify( body.message, 'success' );

					// The sections' states as saved (Connected, Not set up…)
					Object.keys( body.statuses || {} ).forEach( function ( path ) {
						var badge = form.querySelector( '[data-vlt-status="' + path + '"]' );
						var status = body.statuses[ path ];

						if ( badge ) {
							badge.textContent = status[ 0 ];
							badge.title = status[ 0 ];
							badge.className = 'vlt-settings-page__status is-' + status[ 1 ];
							badge.hidden = ! status[ 0 ];
						}
					} );
				} )
				.catch( function ( error ) {
					notify( error.message || form.dataset.vltError, 'danger' );
				} )
				.finally( function () {
					button.disabled = false;
				} );
		} );
	} );

	// A "select all" box (Import): every box of its table follows it
	document.querySelectorAll( '[data-remaily-check-all]' ).forEach( function ( all ) {
		all.addEventListener( 'change', function () {
			all.closest( 'table' ).querySelectorAll( 'tbody input[type="checkbox"]' ).forEach( function ( box ) {
				box.checked = all.checked;
			} );
		} );
	} );

	// Conditions (Core\Controls): a node with data-vlt-condition shows while its rules hold, read from the controls'
	// data-vlt-path (within its data-vlt-scope: each add-on's window has its own paths); the same rules as
	// Controls::matches()
	var conditioned = Array.prototype.slice.call( document.querySelectorAll( '[data-vlt-condition]' ) );

	function current( path, node ) {
		var scope = node.closest( '[data-vlt-scope]' ) || document;
		var control = scope.querySelector( '[data-vlt-path="' + path + '"]:checked' ) || scope.querySelector( '[data-vlt-path="' + path + '"]' );

		if ( ! control ) {
			return null;
		}

		// A box for two options: its value, or the other one's (data-vlt-off)
		if ( 'checkbox' === control.type ) {
			return undefined !== control.dataset.vltOff ? ( control.checked ? control.value : control.dataset.vltOff ) : control.checked;
		}

		// No radio picked yet
		return 'radio' === control.type && ! control.checked ? null : control.value;
	}

	function holds( actual, operator, expected ) {
		var same = function ( a, b ) {
			return 'boolean' === typeof b ? ( true === a || ( 'string' === typeof a && '' !== a && '0' !== a ) ) === b : String( null === a || undefined === a ? '' : a ) === String( b );
		};
		var list = Array.isArray( expected ) ? expected : [ expected ];
		var empty = null === actual || '' === actual || false === actual || '0' === actual;

		switch ( operator ) {
			case '!=':
				return ! same( actual, expected );
			case 'in':
				return list.some( function ( one ) { return same( actual, one ); } );
			case 'not in':
				return ! list.some( function ( one ) { return same( actual, one ); } );
			case 'empty':
				return empty;
			case 'not empty':
				return ! empty;
			case '>':
				return parseFloat( actual ) > parseFloat( expected );
			case '<':
				return parseFloat( actual ) < parseFloat( expected );
			case '>=':
				return parseFloat( actual ) >= parseFloat( expected );
			case '<=':
				return parseFloat( actual ) <= parseFloat( expected );
			default:
				return same( actual, expected );
		}
	}

	function apply() {
		conditioned.forEach( function ( node ) {
			var rules = JSON.parse( node.dataset.vltCondition || '[]' );

			node.hidden = ! rules.every( function ( rule ) {
				return holds( current( rule.control, node ), rule.operator, rule.value );
			} );
		} );
	}

	if ( conditioned.length ) {
		document.addEventListener( 'input', apply );
		document.addEventListener( 'change', apply );
	}

	// The sticky header slides its top away: how far
	var top = document.querySelector( '.vlt-admin-header__top' );

	if ( top && window.ResizeObserver ) {
		new ResizeObserver( function () {
			top.parentNode.style.setProperty( '--vlt-header-top', top.offsetHeight + 'px' );
		} ).observe( top );
	}

	// Color controls: the browser's picker and the text (any CSS color) in step
	document.querySelectorAll( '[data-vlt-color-for]' ).forEach( function ( picker ) {
		var text = document.getElementById( picker.dataset.vltColorFor );

		picker.addEventListener( 'input', function () {
			text.value = picker.value;
			text.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		} );
		text.addEventListener( 'input', function () {
			if ( /^#[0-9a-f]{6}$/i.test( text.value ) ) {
				picker.value = text.value;
			}
		} );
	} );

	// Copy buttons of secrets: what was typed, or (the mask left as is) the saved key asked of the page's REST route
	function writeText( text ) {
		var area = document.createElement( 'textarea' );

		if ( navigator.clipboard && window.isSecureContext ) {
			return text.then( function ( value ) {
				return navigator.clipboard.writeText( value );
			} );
		}

		// Plain http: the old way, which needs the text at hand
		return text.then( function ( value ) {
			area.value = value;
			area.setAttribute( 'readonly', '' );
			area.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
			document.body.appendChild( area );
			area.select();

			var done = document.execCommand( 'copy' );

			area.remove();

			if ( ! done ) {
				throw new Error();
			}
		} );
	}

	function copy( text ) {
		// Safari loses the click while the key is fetched, unless the clipboard gets a promise of it
		if ( window.ClipboardItem && navigator.clipboard && navigator.clipboard.write && window.isSecureContext ) {
			return navigator.clipboard.write( [ new window.ClipboardItem( {
				'text/plain': text.then( function ( value ) {
					return new Blob( [ value ], { type: 'text/plain' } );
				} ),
			} ) ] ).catch( function () {
				return writeText( text );
			} );
		}

		return writeText( text );
	}

	document.querySelectorAll( '[data-vlt-copy]' ).forEach( function ( button ) {
		var input = document.getElementById( button.dataset.vltCopy );
		var form = button.closest( 'form[data-vlt-rest]' );
		var label = button.getAttribute( 'aria-label' );

		input.addEventListener( 'input', function () {
			button.hidden = '' === input.value.trim();
		} );

		button.addEventListener( 'click', function () {
			var typed = input.value.trim() !== input.dataset.vltMask;
			var body = new FormData();

			body.append( 'path', input.dataset.vltPath );

			var text = typed || ! form
				? Promise.resolve( input.value.trim() )
				: fetch( form.dataset.vltRest.replace( /\/$/, '' ) + '/secret', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'X-WP-Nonce': form.dataset.vltNonce },
					body: body,
				} ).then( function ( response ) {
					return response.json().then( function ( data ) {
						if ( ! response.ok || 'string' !== typeof data.value ) {
							throw new Error();
						}

						return data.value;
					} );
				} );

			copy( text )
				.then( function () {
					button.classList.add( 'is-copied' );
					button.setAttribute( 'aria-label', button.dataset.vltCopied );

					setTimeout( function () {
						button.classList.remove( 'is-copied' );
						button.setAttribute( 'aria-label', label );
					}, 1500 );
				} )
				.catch( function () {
					notify( button.dataset.vltCopyError, 'danger' );
				} );
		} );
	} );
} )();
