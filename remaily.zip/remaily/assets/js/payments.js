/**
 * Payments of Remaily forms (the Payment field): when the first Send asks for a payment (remaily:payment), the
 * providers to pick from show in the form and the rest of it stays as sent. A pick starts the payment there
 * (POST remaily/v1/payments/start, the form isn't sent again); with one provider it comes started. Once paid,
 * "provider:payment ID" goes in the field and the form is sent again. The front script loads this script with that
 * first reply, and a provider's script loads only once it is picked.
 *
 * The box and its parts come from the field's template (templates/fields/payment/), found by their
 * data-remaily-payment* attributes, never by class: a theme lays them out as it likes.
 *
 * A provider of an add-on adds itself here, in its own script (its Gateway's script()):
 *
 *     window.remailyPaymentProviders = window.remailyPaymentProviders || {};
 *     window.remailyPaymentProviders.square = async ( box, payment, done, fail ) => { …; return () => cleanUp(); };
 */
(() => {
	const scripts = {};

	const load = (src) =>
		(scripts[src] ||= new Promise((resolve, reject) => {
			const script = document.createElement('script');

			script.src = src;
			script.onload = resolve;
			script.onerror = reject;
			document.head.append(script);
		}));

	// Each shows the payment in box (its own part: [data-remaily-payment-element]; our Pay button, for one that has
	// none: [data-remaily-payment-pay]),
	// calls done( id ) once paid, fail( message ) on an error; returns a clean-up. payment: what its Gateway's start()
	// and client() gave, with amount, label (the Pay button's text) and failed
	const providers = (window.remailyPaymentProviders = Object.assign(window.remailyPaymentProviders || {}, {
		stripe: async (box, payment, done, fail) => {
			await load('https://js.stripe.com/v3/');

			const stripe = window.Stripe(payment.key);
			const elements = stripe.elements({ clientSecret: payment.secret });
			const element = elements.create('payment');
			const pay = box.querySelector('[data-remaily-payment-pay]');

			element.mount(box.querySelector('[data-remaily-payment-element]'));
			pay.textContent = (payment.label || '{amount}').split('{amount}').join(payment.amount);
			pay.hidden = false;
			pay.onclick = async () => {
				pay.disabled = true;
				fail('');

				// Cards and wallets only (the server asks for no redirects), so the page stays
				const { error, paymentIntent } = await stripe.confirmPayment({ elements, redirect: 'if_required', confirmParams: { return_url: window.location.href } });

				pay.disabled = false;

				if (error) {
					fail(error.message || payment.failed);
				} else if (paymentIntent?.status === 'succeeded') {
					done(paymentIntent.id);
				}
			};

			return () => element.destroy();
		},

		paypal: async (box, payment, done, fail) => {
			await load(`https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(payment.key)}&currency=${payment.currency}&intent=capture&components=buttons`);

			const buttons = window.paypal.Buttons({
				createOrder: () => payment.order,
				onApprove: () => done(payment.order),
				onError: () => fail(payment.failed),
			});

			await buttons.render(box.querySelector('[data-remaily-payment-element]'));

			return () => buttons.close();
		},
	}));

	// The provider shown: gone, with its part of the box and our Pay button
	const clear = (paying) => {
		paying.destroy?.();
		paying.destroy = null;
		paying.box.querySelector('[data-remaily-payment-element]')?.replaceChildren();

		const pay = paying.box.querySelector('[data-remaily-payment-pay]');

		if (pay) {
			pay.hidden = true;
			pay.onclick = null;
		}
	};

	// Back to the form as it was: the payment hidden, the fields open again
	const close = (form) => {
		const paying = form.remailyPaying;

		if (!paying) {
			return;
		}

		form.remailyPaying = null;
		clear(paying);
		paying.box.hidden = true;
		if (paying.methods) {
			paying.methods.replaceChildren();
			paying.methods.hidden = true;
		}
		paying.locked.forEach((el) => (el.inert = false));
		form.closest('.remaily')?.classList.remove('is-paying');
	};

	document.addEventListener('remaily:payment', (event) => {
		const { form, response } = event.detail;
		const payment = response?.data?.payment;
		const wrap = payment && form.querySelector(`[data-remaily-field="${CSS.escape(payment.field)}"]`);
		const box = wrap?.querySelector('[data-remaily-payment]');

		if (!box) {
			return;
		}

		close(form);

		const input = wrap.querySelector(`input[name="${CSS.escape(payment.field)}"]`);
		const methods = box.querySelector('[data-remaily-payment-methods]');
		const error = box.querySelector('[data-remaily-payment-error]');
		const fail = (message) => {
			if (error) {
				error.textContent = message;
				error.hidden = !message;
			}
		};
		const buttons = () => (methods ? [...methods.querySelectorAll('[data-gateway]')] : []);
		// The amount was worked out from what was sent: those fields wait
		const locked = [...form.querySelectorAll('[data-remaily-field]')].filter((el) => el !== wrap && !el.inert);
		const paying = { box, methods, locked };

		// One provider at a time; a pick made while another loads wins
		let turn = 0;

		const show = async (started) => {
			const mine = ++turn;

			clear(paying);
			fail('');
			buttons().forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.gateway === started.gateway)));

			try {
				if (started.script) {
					await load(started.script);
				}

				// An add-on's provider is there once its script ran
				const run = providers[started.gateway];

				if (!run) {
					throw new Error('No provider');
				}

				const destroy = await run(box, { ...payment, ...started }, (id) => {
					input.value = `${started.gateway}:${id}`;
					form.requestSubmit();
				}, fail);

				// Closed, or another provider picked, while its script was loading
				if (form.remailyPaying !== paying || mine !== turn) {
					destroy?.();
				} else {
					paying.destroy = destroy;
				}
			} catch {
				if (mine === turn) {
					fail(payment.failed);
				}
			}
		};

		const pick = async (gateway) => {
			fail('');
			buttons().forEach((button) => (button.disabled = true));

			try {
				const reply = await fetch(payment.start, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ token: payment.token, gateway }),
				});
				const started = await reply.json();

				if (!reply.ok || !started?.gateway) {
					throw new Error('Not started');
				}

				if (form.remailyPaying === paying) {
					await show(started);
				}
			} catch {
				fail(payment.failed);
			} finally {
				buttons().forEach((button) => (button.disabled = false));
			}
		};

		locked.forEach((el) => (el.inert = true));
		form.remailyPaying = paying;
		form.closest('.remaily')?.classList.add('is-paying');
		box.hidden = false;
		fail('');
		const cancel = box.querySelector('[data-remaily-payment-cancel]');

		if (cancel) {
			cancel.onclick = () => close(form);
		}

		// More than one provider: a button each, copied from the template's, its name in its label
		const model = box.querySelector('template[data-remaily-payment-method]')?.content.firstElementChild;

		if (methods && (payment.methods || []).length > 1) {
			methods.replaceChildren(
				...payment.methods.map((method) => {
					const button = model ? model.cloneNode(true) : document.createElement('button');
					const label = button.querySelector('[data-remaily-payment-label]') || button;

					if (!model) {
						button.type = 'button';
					}

					button.dataset.gateway = method.id;
					button.setAttribute('aria-pressed', 'false');
					label.textContent = method.label;
					button.addEventListener('click', () => pick(method.id));

					return button;
				})
			);
			methods.hidden = false;
		}

		if (payment.started) {
			show(payment.started);
		}

		box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
	});

	// Any other reply ends the payment step; the IDs sent go with it
	document.addEventListener('remaily:sent', (event) => {
		const { form, response } = event.detail;

		if (response?.status === 'payment') {
			return;
		}

		close(form);
		form.querySelectorAll('[data-remaily-payment]').forEach((box) => {
			const wrap = box.closest('[data-remaily-field]');
			const input = wrap?.querySelector(`input[name="${CSS.escape(wrap.dataset.remailyField)}"]`);

			if (input) {
				input.value = '';
			}
		});
	});
})();
