/**
 * Remaily forms: checks fields, shows and hides groups, mirrors output fields, counts characters and sends without a reload
 *
 * Events on the <form>, with detail { id, form, response }:
 *   remaily:submit (cancelable, before sending), remaily:sent (any reply), remaily:success, remaily:invalid,
 *   remaily:failed, remaily:spam, remaily:aborted, remaily:payment (a payment to make first: payments.js), remaily:reset,
 *   remaily:ready (the form is set up)
 * Forms added later (popups, AJAX): window.remaily.init( element ). window.remaily.beforeSend: async steps before
 * sending. window.remaily.check( element ): checks the fields inside it (a step), shows their errors, returns whether
 * all pass. window.remaily.checks: ( wrap ) => a message key or text for a field the browser can't check, '' if fine.
 * [data-remaily-live] spans ([[message:left]]…) follow what is typed, as the Count field does.
 * Captchas are handled here: reCAPTCHA v3's token asked for as the form is sent, Turnstile and hCaptcha widgets reset
 * after each reply (their answers work once). A reply's data.script (the payment script) loads before its event fires.
 */
(() => {
	const data = window.remailyData || {};

	// reCAPTCHA v3: a token for this send. Its script is loaded now if a cookie banner or an optimizer held it back:
	// without a token the message is turned down as spam.
	const recaptcha = async (form) => {
		const input = form.querySelector('[data-remaily-captcha="recaptcha"]');

		if (!input) {
			return;
		}

		if (!window.grecaptcha?.execute && input.dataset.src) {
			await load(input.dataset.src);
		}

		await new Promise((resolve) => window.grecaptcha.ready(resolve));
		input.value = await window.grecaptcha.execute(input.dataset.sitekey, { action: 'contact_form' });
	};

	// A form may run several captchas: each widget is reset
	const resetCaptchas = (form) =>
		form.querySelectorAll('[data-remaily-captcha]').forEach((widget) => {
			if (widget.dataset.remailyCaptcha === 'turnstile') {
				window.turnstile?.reset(`#${widget.id}`);
			} else if (widget.dataset.remailyCaptcha === 'hcaptcha') {
				window.hcaptcha?.reset(widget.querySelector('iframe')?.dataset.hcaptchaWidgetId);
			}
		});

	// A script a reply asks for, once
	const scripts = {};
	const load = (src) =>
		(scripts[src] ||= new Promise((resolve, reject) => {
			const script = document.createElement('script');

			script.src = src;
			script.onload = resolve;
			script.onerror = reject;
			document.head.append(script);
		}));

	// Async functions awaited before a form is sent: ( form ) => Promise
	const beforeSend = [recaptcha];
	const checks = [];
	const STATUSES = ['sending', 'success', 'invalid', 'failed', 'spam', 'aborted', 'payment'];

	const isEmpty = (value) => (Array.isArray(value) ? !value.some((item) => String(item) !== '') : String(value).trim() === '');
	const isNumber = (value) => !Array.isArray(value) && String(value).trim() !== '' && !Number.isNaN(Number(value));

	// The same rules as Submission\Conditions
	const rule = (r, value) => {
		const target = String(r.value ?? '');

		switch (r.op) {
			case 'is':
				return Array.isArray(value) ? value.map(String).includes(target) : String(value) === target;
			case 'is_not':
				return !rule({ ...r, op: 'is' }, value);
			case 'contains':
				return Array.isArray(value) ? value.map(String).includes(target) : String(value).toLowerCase().includes(target.toLowerCase());
			case 'not_contains':
				return !rule({ ...r, op: 'contains' }, value);
			case 'empty':
				return isEmpty(value);
			case 'not_empty':
				return !isEmpty(value);
			case 'gt':
				return isNumber(value) && isNumber(target) && Number(value) > Number(target);
			case 'lt':
				return isNumber(value) && isNumber(target) && Number(value) < Number(target);
		}

		return false;
	};

	const matches = (group, values) => {
		const results = group.rules.map((r) => rule(r, values[r.field] ?? ''));

		return group.match === 'any' ? results.includes(true) : !results.includes(false);
	};

	const tokens = (el, attr) => (el.getAttribute(attr) || '').split(/\s+/).filter(Boolean);

	// Tel masks ("+1 (###) ###-####"), as Tel::fit(): the national digits of a number (without its code or a
	// trunk prefix), then the mask filled with them, its signs only as far as the digits go
	// The code a mask starts with, as written: "+1" of "+1 (###) ###-####" (Tel::sign())
	const signOf = (mask) => {
		const lead = mask.split('#')[0];
		const code = lead.replace(/\D/g, '');

		return code ? lead.slice(0, lead.lastIndexOf(code.slice(-1)) + 1) : '';
	};

	const national = (value, mask, trunk) => {
		const sign = signOf(mask);
		const code = sign.replace(/\D/g, '');
		const slots = mask.split('#').length - 1;
		let rest = value.trimStart();

		// The code the mask writes, then the same code typed again with its + ("+7 (+7 812")
		if (sign && rest.startsWith(sign)) {
			rest = rest.slice(sign.length);
		}

		let digits = rest.replace(/\D/g, '');
		const typed = rest.replace(/[^\d+]/g, '');

		// "+", "+7": the code being typed, nothing of the number yet
		if (code && typed.startsWith('+')) {
			digits = code.startsWith(typed.slice(1)) ? '' : typed.slice(1).startsWith(code) ? digits.slice(code.length) : digits;
		}

		// The code without its +, or a trunk prefix: told once the number runs over
		if (code && digits.length > slots && digits.startsWith(code)) {
			digits = digits.slice(code.length);
		}

		if (trunk && digits.length > slots && digits.startsWith(trunk)) {
			digits = digits.slice(trunk.length);
		}

		return digits.slice(0, slots);
	};

	// at[n]: where the caret goes after the n-th digit
	const fill = (digits, mask) => {
		const at = [Math.max(0, mask.indexOf('#'))];
		let out = '';
		let i = 0;

		for (const char of mask) {
			if (i >= digits.length) {
				break;
			}

			out += char === '#' ? digits[i++] : char;

			if (char === '#') {
				at.push(out.length);
			}
		}

		return { out, at };
	};

	// The browser's check of a complete number (pattern uses the v flag: only syntax characters are escaped)
	const maskPattern = (mask) => mask.replace(/[\^$\\.*+?()[\]{}|/]/g, '\\$&').split('#').join('[0-9]');

	function init(root) {
		const form = root.querySelector('form[data-remaily]');

		if (!form || form.remailyReady) {
			return;
		}

		form.remailyReady = true;

		const configEl = root.querySelector('.remaily__config');
		const config = configEl ? JSON.parse(configEl.textContent || '{}') : {};
		const messages = config.messages || {};
		const groups = config.groups || {};
		const box = form.querySelector('[data-remaily-response]');
		let tried = false;

		const wrappers = () => [...form.querySelectorAll('[data-remaily-field]')];
		const wrapper = (name) => form.querySelector(`[data-remaily-field="${CSS.escape(name)}"]`);
		const controls = (wrap) => [...wrap.querySelectorAll('input, select, textarea')].filter((el) => el.name && !el.name.startsWith('_remaily'));
		const groupsOf = (el) => {
			const names = [];

			for (let group = el.parentElement?.closest('[data-remaily-group]'); group; group = group.parentElement?.closest('[data-remaily-group]')) {
				names.push(group.dataset.remailyGroup);
			}

			return names;
		};

		// A field's value: a list for checkboxes and multiple selects; labels instead of values when asked
		const read = (wrap, labels = false) => {
			const els = controls(wrap);
			const picked = [];
			const multiple = wrap.dataset.remailyType === 'checkbox' || els.some((el) => el.multiple && el.tagName === 'SELECT');

			els.forEach((el) => {
				if (el.type === 'checkbox' || el.type === 'radio') {
					if (el.checked) {
						picked.push(labels ? el.closest('.remaily-choice')?.querySelector('.remaily-choice__label')?.textContent ?? el.value : el.value);
					}
				} else if (el.tagName === 'SELECT') {
					[...el.selectedOptions].filter((option) => option.value !== '').forEach((option) => picked.push(labels ? option.textContent : option.value));
				} else if (el.type === 'file') {
					picked.push([...el.files].map((file) => file.name).join(', '));
				} else {
					picked.push(el.value);
				}
			});

			return multiple ? picked : (picked[0] ?? '');
		};

		const conditions = () => {
			const values = {};
			const parents = {};

			wrappers().forEach((wrap) => {
				values[wrap.dataset.remailyField] = read(wrap);
				parents[wrap.dataset.remailyField] = groupsOf(wrap);
			});

			let hidden = [];

			// A rule may read a field another group hides: settle in a few passes
			for (let pass = 0; pass < 3; pass++) {
				const visible = { ...values };

				Object.keys(visible).forEach((name) => {
					if (parents[name].some((group) => hidden.includes(group))) {
						visible[name] = Array.isArray(visible[name]) ? [] : '';
					}
				});

				const next = [];

				Object.entries(groups).forEach(([name, group]) => {
					if ((group.parents || []).some((parent) => next.includes(parent))) {
						next.push(name);
					} else if (group.rules?.length && (group.action === 'show') !== matches(group, visible)) {
						next.push(name);
					}
				});

				if (next.join() === hidden.join()) {
					break;
				}

				hidden = next;
			}

			form.querySelectorAll('[data-remaily-group]').forEach((el) => {
				const hide = hidden.includes(el.dataset.remailyGroup);

				if (el.hidden !== hide) {
					el.hidden = hide;
					el.inert = hide;

					if (hide) {
						el.querySelectorAll('[data-remaily-field]').forEach((wrap) => setError(wrap, ''));
					}
				}
			});
		};

		const outputs = () => {
			form.querySelectorAll('[data-remaily-output]').forEach((out) => {
				const wrap = wrapper(out.dataset.remailyOutput);
				const value = wrap && !wrap.closest('[data-remaily-group][hidden]') ? read(wrap, true) : '';
				const text = Array.isArray(value) ? value.join(', ') : String(value);

				out.textContent = text === '' ? out.dataset.empty || '' : (out.dataset.format || '{value}').split('{value}').join(text);
			});

			// Characters as Count::text() counts them (code points, as mb_strlen)
			form.querySelectorAll('[data-remaily-count]').forEach((out) => {
				const el = wrapper(out.dataset.remailyCount)?.querySelector('input, textarea');
				const count = el ? [...el.value].length : 0;
				const max = Number(out.dataset.max || 0);
				const min = Number(out.dataset.min || 0);
				const values = { '{count}': count, '{left}': max ? max - count : '', '{max}': max || '' };

				out.textContent = (out.dataset.format || '{count}').replace(/\{(count|left|max)\}/g, (token) => values[token]);
				out.style.setProperty('--remaily-count', count);
				out.style.setProperty('--remaily-max', max);
				out.classList.toggle('is-over', Boolean(max) && count > max);
				out.classList.toggle('is-under', Boolean(min) && count > 0 && count < min);
			});

			// [[name:count]] and [[name:left]] in the text (Text::own_info()), counted the same way
			form.querySelectorAll('[data-remaily-live]').forEach((out) => {
				const [name, key] = out.dataset.remailyLive.split(':');
				const el = wrapper(name)?.querySelector('input, textarea');
				const count = el ? [...el.value].length : 0;
				const max = Number(out.dataset.max || 0);
				const min = Number(out.dataset.min || 0);

				out.textContent = key === 'left' ? (max ? max - count : '') : count;
				out.style.setProperty('--remaily-count', count);
				out.style.setProperty('--remaily-max', max);
				out.classList.toggle('is-over', Boolean(max) && count > max);
				out.classList.toggle('is-under', Boolean(min) && count > 0 && count < min);
			});
		};

		const setError = (wrap, message) => {
			const error = wrap.querySelector('[data-remaily-error]');

			wrap.classList.toggle('is-invalid', Boolean(message));

			if (error) {
				error.textContent = message;
				error.hidden = !message;
			}

			controls(wrap).forEach((el) => {
				if (el.type === 'hidden') {
					return;
				}

				const described = tokens(el, 'aria-describedby').filter((id) => !error || id !== error.id);

				if (message) {
					el.setAttribute('aria-invalid', 'true');

					if (error) {
						described.push(error.id);
					}
				} else {
					el.removeAttribute('aria-invalid');
				}

				if (described.length) {
					el.setAttribute('aria-describedby', described.join(' '));
				} else {
					el.removeAttribute('aria-describedby');
				}
			});
		};

		// The message key of the browser's own checks, named as the server names them
		const problem = (type, el) => {
			const v = el.validity;

			if (v.valueMissing) {
				return type === 'acceptance' ? 'accept_terms' : 'required';
			}

			if (v.typeMismatch || v.patternMismatch || v.badInput || v.stepMismatch) {
				return messages[`invalid_${type}`] ? `invalid_${type}` : 'invalid';
			}

			if (v.tooLong) {
				return 'too_long';
			}

			if (v.tooShort) {
				return 'too_short';
			}

			if (v.rangeUnderflow) {
				return type === 'date' ? 'date_too_early' : 'number_too_small';
			}

			if (v.rangeOverflow) {
				return type === 'date' ? 'date_too_late' : 'number_too_large';
			}

			if (el.type === 'file') {
				const max = Number(el.dataset.remailyMaxSize || 0);
				const accept = (el.accept || '').toLowerCase().split(',').filter(Boolean);

				for (const file of el.files) {
					if (max && file.size > max) {
						return 'upload_file_too_large';
					}

					if (accept.length && !accept.some((ext) => file.name.toLowerCase().endsWith(ext))) {
						return 'upload_file_type_invalid';
					}
				}
			}

			return '';
		};

		const check = (wrap) => {
			if (wrap.closest('[data-remaily-group][hidden]')) {
				setError(wrap, '');

				return true;
			}

			const els = controls(wrap);
			let key = wrap.hasAttribute('data-remaily-required') && !els.some((el) => el.checked) ? 'required' : '';

			for (const el of els) {
				key = key || problem(wrap.dataset.remailyType, el);
			}

			// An inverted acceptance: sent only with the box clear
			if (!key && wrap.hasAttribute('data-remaily-invert') && els.some((el) => el.checked)) {
				key = 'accept_terms';
			}

			let text = key ? messages[key] || messages.invalid || '' : '';

			// An add-on's own check: a message key, or its own text
			for (const fn of key ? [] : checks) {
				key = fn(wrap) || '';
				text = key ? messages[key] || key : '';

				if (key) {
					break;
				}
			}

			setError(wrap, text);

			return !key;
		};

		const setStatus = (status) => {
			root.classList.remove(...STATUSES.map((s) => `is-${s}`));

			if (status) {
				root.classList.add(`is-${status}`);
			}

			form.toggleAttribute('aria-busy', status === 'sending');
		};

		const emit = (name, response = null, cancelable = false) =>
			form.dispatchEvent(new CustomEvent(`remaily:${name}`, { bubbles: true, cancelable, detail: { id: Number(form.dataset.remaily), form, response } }));

		const focusFirst = () => form.querySelector('[aria-invalid="true"]')?.focus();

		const alert = (status, message) => {
			const div = document.createElement('div');
			const text = document.createElement('span');

			div.className = `remaily-alert remaily-alert--${status}`;
			text.className = 'remaily-alert__text';
			text.textContent = message;
			div.append(text);
			box.replaceChildren(div);
		};

		const post = (withNonce) =>
			fetch(`${data.restUrl}forms/${form.dataset.remaily}/submit`, {
				method: 'POST',
				body: new FormData(form),
				credentials: 'same-origin',
				headers: withNonce && form.dataset.nonce ? { 'X-WP-Nonce': form.dataset.nonce } : {},
			});

		const send = async () => {
			setStatus('sending');
			box.replaceChildren();

			try {
				for (const fn of beforeSend) {
					await fn(form);
				}

				let res = await post(true);

				// A cached page's nonce has expired: send as a visitor
				if (res.status === 403 && form.dataset.nonce) {
					res = await post(false);
				}

				const json = await res.json();

				if (!res.ok || !json.status) {
					throw new Error(json.message || res.statusText);
				}

				wrappers().forEach((wrap) => setError(wrap, ''));
				(json.invalid || []).forEach(({ field, message }) => {
					const wrap = wrapper(field);

					if (wrap) {
						setError(wrap, message);
					}
				});

				setStatus(json.status);
				box.innerHTML = json.html || '';

				if (!box.innerHTML) {
					alert(json.status, json.message);
				}

				if (json.status === 'invalid') {
					focusFirst();
				}

				if (json.status === 'success') {
					tried = false;
					form.reset();
				}

				resetCaptchas(form);

				if (json.data?.script) {
					await load(json.data.script);
				}

				emit('sent', json);
				emit(json.status, json);

				if (json.redirect) {
					window.location.assign(json.redirect);
				}
			} catch (err) {
				setStatus('failed');
				alert('failed', messages.failed || err.message);
				emit('failed');
			}
		};

		form.addEventListener('submit', (event) => {
			event.preventDefault();

			if (root.classList.contains('is-sending')) {
				return;
			}

			tried = true;

			// A number with only its code (sent with Enter) is empty
			form.querySelectorAll('[data-remaily-mask]').forEach((el) => !national(el.value, el.dataset.remailyMask, el.dataset.remailyTrunk || '') && (el.value = ''));

			if (wrappers().map(check).includes(false)) {
				setStatus('invalid');
				alert('invalid', messages.invalid || '');
				focusFirst();
				emit('invalid');

				return;
			}

			// The editor's preview checks the fields but sends nothing
			if (form.dataset.remailyPreview) {
				setStatus('success');
				alert('success', form.dataset.remailyPreview);

				return;
			}

			if (emit('submit', null, true)) {
				send();
			}
		});

		const changed = (event) => {
			// Exclusive checkboxes: ticking one clears the others
			if (event.type === 'change' && event.target.checked && event.target.closest('[data-remaily-exclusive]')) {
				controls(event.target.closest('[data-remaily-field]')).forEach((el) => el !== event.target && (el.checked = false));
			}

			conditions();
			outputs();

			const wrap = event.target.closest?.('[data-remaily-field]');

			if (wrap && (tried || wrap.classList.contains('is-invalid'))) {
				check(wrap);
			}
		};

		// A link used as the submit button; a date opens its calendar wherever it's clicked, not only on the icon
		form.addEventListener('click', (event) => {
			if (event.target.closest('[data-remaily-submit]')) {
				event.preventDefault();
				form.requestSubmit();
			}

			if (event.target.matches?.('input[type="date"]:not([readonly], :disabled)')) {
				try {
					event.target.showPicker();
				} catch {}
			}
		});

		form.addEventListener('keydown', (event) => {
			if (event.key === ' ' && event.target.closest('[data-remaily-submit]')) {
				event.preventDefault();
				form.requestSubmit();
			}
		});

		// The mask's start ("+7 ("): shown while the empty number has the focus, so its code isn't typed again
		const lead = (el) => el.dataset.remailyMask.split('#')[0];

		// A masked number formats itself; Backspace over a sign takes the digit before it
		const masked = (el, event) => {
			const trunk = el.dataset.remailyTrunk || '';
			const caret = el.selectionEnd ?? el.value.length;
			const end = caret >= el.value.length;
			const focused = document.activeElement === el;
			let digits = national(el.value, el.dataset.remailyMask, trunk);
			let n = Math.min(national(el.value.slice(0, caret), el.dataset.remailyMask, trunk).length, digits.length);

			if (event?.inputType === 'deleteContentBackward' && digits === el.remailyDigits && n > 0) {
				digits = digits.slice(0, n - 1) + digits.slice(n);
				n--;
			}

			// The visitor typing the code again ("+7 (+7"): left as it is until the number starts
			if (!digits && focused && el.value.lastIndexOf('+') > 0) {
				el.remailyDigits = digits;

				return;
			}

			const { out, at } = fill(digits, el.dataset.remailyMask);

			el.value = out || (focused ? lead(el) : '');
			el.remailyDigits = digits;

			if (focused && (!end || !out)) {
				const to = out ? at[n] : el.value.length;

				el.setSelectionRange(to, to);
			}
		};

		// The country list in front of a number: its mask, the digits typed kept
		const country = (select) => {
			const el = select.parentElement.querySelector('[data-remaily-mask]');
			const option = select.selectedOptions[0];

			if (!el || !option) {
				return;
			}

			const digits = national(el.value, el.dataset.remailyMask, el.dataset.remailyTrunk || '');

			if (el.placeholder === el.dataset.remailyMask.split('#').join('_')) {
				el.placeholder = option.dataset.mask.split('#').join('_');
			}

			el.dataset.remailyMask = option.dataset.mask;
			el.dataset.remailyTrunk = option.dataset.trunk || '';
			el.pattern = maskPattern(option.dataset.mask);
			el.value = fill(digits, option.dataset.mask).out;
			el.remailyDigits = digits;
		};

		form.querySelectorAll('[data-remaily-mask]').forEach((el) => {
			el.pattern = maskPattern(el.dataset.remailyMask);
			masked(el);
		});

		form.addEventListener('input', (event) => event.target.dataset?.remailyMask && masked(event.target, event));
		form.addEventListener('focusin', (event) => {
			const el = event.target;

			// After the click has placed the caret: at the end of the code
			if (el.dataset?.remailyMask && !el.value && lead(el)) {
				el.value = lead(el);
				setTimeout(() => el.setSelectionRange(el.value.length, el.value.length));
			}
		});
		form.addEventListener('focusout', (event) => event.target.dataset?.remailyMask && masked(event.target));
		form.addEventListener('change', (event) => event.target.matches?.('[data-remaily-country]') && country(event.target));

		// The flag inside a country list (Countries::flagged()), and a Country field's name, follow the country picked
		const flagged = (select) => {
			const wrap = select.parentElement;
			const mark = wrap?.querySelector(':scope > .remaily-flag [data-remaily-flag]');
			const name = wrap?.querySelector(':scope > .remaily-flag [data-remaily-flag-name]');
			const code = select.value;

			if (mark) {
				mark.textContent = !/^[a-z]{2}$/i.test(code) ? '' : 'letters' in mark.dataset ? code.toUpperCase() : String.fromCodePoint(...[...code.toUpperCase()].map((char) => 127397 + char.charCodeAt(0)));
			}

			if (name) {
				name.textContent = (select.selectedOptions[0]?.textContent || '').replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').trim();
			}
		};

		form.querySelectorAll('.remaily-country').forEach((wrap) => {
			const select = wrap.querySelector('select');

			// The flag and name go where the list's own text would, whatever the theme's padding
			if (select) {
				wrap.style.setProperty('--remaily-flag-start', getComputedStyle(select).paddingInlineStart);
			}

			wrap.classList.add('is-ready');
		});
		form.addEventListener('change', (event) => event.target.tagName === 'SELECT' && flagged(event.target));
		form.addEventListener('input', changed);
		form.addEventListener('change', changed);

		form.addEventListener('reset', () => {
			// The controls are reset after this event
			setTimeout(() => {
				wrappers().forEach((wrap) => setError(wrap, ''));
				form.querySelectorAll('.remaily-flagged > select').forEach(flagged);
				conditions();
				outputs();
				emit('reset');
			});
		});

		// window.remaily.check(): the fields inside an element of this form
		form.remailyCheck = (scope) => {
			const ok = !wrappers()
				.filter((wrap) => scope === form || scope.contains(wrap))
				.map(check)
				.includes(false);

			if (!ok) {
				focusFirst();
			}

			return ok;
		};

		conditions();
		outputs();
		emit('ready');
	}

	const check = (scope) => {
		const form = scope?.closest?.('form[data-remaily]') || scope?.querySelector?.('form[data-remaily]');

		return form?.remailyCheck ? form.remailyCheck(form.contains(scope) ? scope : form) : true;
	};

	const initAll = (scope = document) => {

		(scope.matches?.('.remaily') ? [scope] : [...scope.querySelectorAll('.remaily')]).forEach(init);
	};

	window.remaily = { init: initAll, beforeSend, checks, check };

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => initAll());
	} else {
		initAll();
	}
})();
