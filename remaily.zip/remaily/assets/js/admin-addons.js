/* ========================================
 * Contact Form → Add-ons (Addons\Addons): the filters and search of the cards, and each add-on's window, opened
 * by its Settings button or by #slug in the address (a link from the form editor, the page after a save)
 * ======================================== */

( function () {
	var cards = Array.prototype.slice.call( document.querySelectorAll( '[data-remaily-card]' ) );
	var groups = Array.prototype.slice.call( document.querySelectorAll( '[data-remaily-group]' ) );
	var filters = Array.prototype.slice.call( document.querySelectorAll( '[data-remaily-filter]' ) );
	var search = document.querySelector( '[data-remaily-search]' );
	var empty = document.querySelector( '[data-remaily-empty]' );
	var filter = 'all';

	function apply() {
		var words = search ? search.value.trim().toLowerCase() : '';
		var shown = 0;

		groups.forEach( function ( group ) {
			var inGroup = 0;

			group.querySelectorAll( '[data-remaily-card]' ).forEach( function ( card ) {
				var show = ( 'all' === filter || group.dataset.remailyGroup === filter ) && ( ! words || -1 < card.dataset.remailyFind.indexOf( words ) );

				card.hidden = ! show;
				inGroup += show ? 1 : 0;
			} );

			group.hidden = ! inGroup;
			shown += inGroup;
		} );

		if ( empty ) {
			empty.hidden = 0 < shown;

			// A search that finds nothing, or a filter with nothing in it
			empty.querySelectorAll( '[data-for]' ).forEach( function ( part ) {
				part.hidden = part.dataset.for !== ( words ? 'search' : 'none' );
			} );

			empty.querySelectorAll( '[data-text]' ).forEach( function ( text ) {
				text.textContent = text.dataset.text.replace( '%s', search.value.trim() );
			} );
		}
	}

	filters.forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			filter = button.dataset.remailyFilter;

			filters.forEach( function ( other ) {
				other.setAttribute( 'aria-pressed', other === button ? 'true' : 'false' );
			} );

			apply();
		} );
	} );

	if ( search ) {
		search.addEventListener( 'input', apply );

		// "/" jumps to the search, as on most sites
		document.addEventListener( 'keydown', function ( e ) {
			var tag = e.target.tagName;

			if ( '/' === e.key && ! /^(INPUT|TEXTAREA|SELECT)$/.test( tag ) && ! e.target.isContentEditable && ! document.querySelector( 'dialog[open]' ) ) {
				e.preventDefault();
				search.focus();
			}
		} );
	}

	// Windows
	function open( slug ) {
		var dialog = document.getElementById( 'remaily-addon-' + slug );

		if ( dialog && ! dialog.open ) {
			dialog.showModal();
			history.replaceState( null, '', '#' + slug );
		}
	}

	document.querySelectorAll( '[data-remaily-open]' ).forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			open( button.dataset.remailyOpen );
		} );
	} );

	document.querySelectorAll( '.remaily-addon-window' ).forEach( function ( dialog ) {
		dialog.addEventListener( 'close', function () {
			history.replaceState( null, '', location.pathname + location.search );
		} );

		// A click on the backdrop closes it
		dialog.addEventListener( 'click', function ( e ) {
			if ( e.target === dialog ) {
				dialog.close();
			}
		} );
	} );

	// A window's note under its head: what the last action said
	function note( dialog, type, text ) {
		var el = dialog.querySelector( ':scope > .vlt-settings-page__note' );

		if ( ! el ) {
			el = document.createElement( 'p' );
			dialog.querySelector( '.remaily-addon-window__head' ).after( el );
		}

		el.className = 'vlt-settings-page__note is-' + type;
		el.setAttribute( 'role', 'status' );
		el.textContent = text;
	}

	// On/off saved through REST: the window stays open, its card shows the new state
	var config = window.remailyAddons || {};

	document.querySelectorAll( '[data-remaily-save]' ).forEach( function ( form ) {
		form.addEventListener( 'submit', function ( e ) {
			var slug = form.dataset.remailySave;
			var dialog = form.closest( 'dialog' );
			var button = form.querySelector( '[type="submit"]' );
			var box = form.querySelector( 'input[type="checkbox"][name="enabled"]' );

			if ( ! config.rest || ! window.fetch ) {
				return;
			}

			e.preventDefault();
			button.disabled = true;

			fetch( config.rest + slug, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce },
				body: JSON.stringify( { enabled: !! ( box && box.checked ) } ),
			} )
				.then( function ( response ) {
					return response.json().then( function ( body ) {
						if ( ! response.ok ) {
							throw new Error( body && body.message ? body.message : config.error );
						}

						return body;
					} );
				} )
				.then( function ( body ) {
					var state = document.querySelector( '[data-remaily-card="' + slug + '"] [data-remaily-state]' );

					note( dialog, 'success', body.message );

					if ( state ) {
						state.className = 'remaily-addon__state is-' + body.tone;
						state.textContent = body.state;
					}
				} )
				.catch( function ( error ) {
					note( dialog, 'danger', error.message || config.error );
				} )
				.finally( function () {
					button.disabled = false;
				} );
		} );
	} );

	if ( location.hash ) {
		open( location.hash.slice( 1 ).replace( /[^a-z0-9_-]/g, '' ) );
	}
} )();
