/**
 * The editor's Preview (Admin\Preview): the form works as on the page, without sending. The gear on the field under
 * the pointer opens its settings in the editor; the editor's selection and the field hovered in its sidebar list are outlined
 * here, and the scroll position survives each reload
 */
(() => {
	const key = 'remaily-preview-scroll';

	try {
		window.scrollTo(0, Number(sessionStorage.getItem(key)) || 0);
		window.addEventListener('scroll', () => sessionStorage.setItem(key, String(window.scrollY)), { passive: true });
	} catch {}

	// A field's own box, or the one drawn around it when the theme hides the control (a file drop zone: the input out
	// of sight in a styled <label>)
	const box = (field) => (field.offsetWidth < 24 || field.offsetHeight < 16 ? field.closest('label') || field.parentElement : field);

	// The field under the pointer: inside its box, or inside the label drawn for it
	const fieldAt = (target) => target.closest?.('[data-remaily-field]') || target.closest?.('label')?.querySelector('[data-remaily-field]');

	const mark = (kind, fields) => {
		document.querySelectorAll(`.${kind}`).forEach((el) => el.classList.remove(kind));
		fields.forEach((field) => box(field).classList.add(kind));
	};

	const gear = document.createElement('button');
	let current = null;
	let hide = 0;

	// The field's line is drawn 4px outside it (preview.css): the gear sits on that line, as a tab of it
	const place = (field) => {
		const rect = box(field).getBoundingClientRect();

		gear.style.top = `${rect.top + window.scrollY - 5 - gear.offsetHeight + 1}px`;
		gear.style.left = `${rect.right + window.scrollX + 5 - gear.offsetWidth}px`;
	};

	const show = (field) => {
		clearTimeout(hide);
		current = field;
		mark('is-remaily-hover', [field]);
		gear.hidden = false;
		place(field);
	};

	// Not at once: the pointer on its way to the gear may cross a gap
	const leave = () => {
		clearTimeout(hide);
		hide = setTimeout(() => {
			current = null;
			mark('is-remaily-hover', []);
			gear.hidden = true;
		}, 300);
	};

	gear.type = 'button';
	gear.className = 'remaily-preview-edit';
	gear.hidden = true;
	gear.title = window.remailyPreview?.edit || '';
	gear.setAttribute('aria-label', gear.title);
	gear.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>';
	document.body.append(gear);

	gear.addEventListener('click', () => current && window.parent.postMessage({ remaily: 'select', name: current.dataset.remailyField }, '*'));

	document.addEventListener('mouseover', (event) => {
		// On the gear: its field stays the current one
		if (event.target.closest?.('.remaily-preview-edit')) {
			clearTimeout(hide);

			return;
		}

		const field = fieldAt(event.target);

		field ? show(field) : leave();
	});

	document.documentElement.addEventListener('mouseleave', leave);

	// Links stay on the preview
	document.addEventListener('click', (event) => event.target.closest?.('a[href]') && event.preventDefault(), true);

	window.addEventListener('message', (event) => {
		const kind = { selected: 'is-remaily-selected', hovered: 'is-remaily-hovered' }[event.data?.remaily];

		if (event.source !== window.parent || !kind) {
			return;
		}

		mark(kind, document.querySelectorAll(`[data-remaily-field="${CSS.escape(event.data.name || '')}"]`));
	});
})();
