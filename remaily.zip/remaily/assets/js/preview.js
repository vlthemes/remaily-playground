/**
 * The editor's Preview (Admin\Preview), static: a click on a field selects it in the editor, the editor's selection
 * and the field hovered in its sidebar list are outlined here, and the scroll position survives each reload
 */
(() => {
	const key = 'remaily-preview-scroll';

	try {
		window.scrollTo(0, Number(sessionStorage.getItem(key)) || 0);
		window.addEventListener('scroll', () => sessionStorage.setItem(key, String(window.scrollY)), { passive: true });
	} catch {}

	// A field's own box, or the one drawn around it when the theme hides the control (a file drop zone: the input out
	// of sight in a styled <label>)
	const box = (field) => (field.offsetWidth < 24 || field.offsetHeight < 16 ? field.closest('label') || field.parentElement || field : field);

	// The field under the pointer: inside its box, or inside the label drawn for it
	const fieldAt = (target) => target.closest?.('[data-remaily-field]') || target.closest?.('label')?.querySelector('[data-remaily-field]') || null;

	const mark = (kind, fields) => {
		document.querySelectorAll(`.${kind}`).forEach((el) => el.classList.remove(kind));
		fields.forEach((field) => box(field).classList.add(kind));
	};

	document.addEventListener('mouseover', (event) => {
		const field = fieldAt(event.target);

		mark('is-remaily-hover', field ? [field] : []);
	});

	document.addEventListener('mouseleave', () => mark('is-remaily-hover', []));

	// Static: a click selects the field, nothing gets focus, opens, ticks or is sent
	['click', 'mousedown', 'submit'].forEach((type) =>
		document.addEventListener(
			type,
			(event) => {
				event.stopPropagation();
				event.preventDefault();

				const field = 'click' === type && fieldAt(event.target);

				if (field) {
					window.parent.postMessage({ remaily: 'select', name: field.dataset.remailyField }, '*');
				}
			},
			true
		)
	);

	window.addEventListener('message', (event) => {
		const kind = { selected: 'is-remaily-selected', hovered: 'is-remaily-hovered' }[event.data?.remaily];

		if (event.source !== window.parent || !kind) {
			return;
		}

		mark(kind, document.querySelectorAll(`[data-remaily-field="${CSS.escape(event.data.name || '')}"]`));
	});
})();
