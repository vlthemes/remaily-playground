<?php
/**
 * Deleting the plugin: forms, entries and settings go only when Settings → Entries says so, site by site on a network
 *
 * @package VLT\Remaily
 */

if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$remaily_uninstall = static function () {
	$settings = get_option( 'remaily_settings', [] );

	if ( empty( $settings['entries']['delete_data'] ) ) {
		return;
	}

	foreach ( [ 'remaily_form', 'remaily_entry' ] as $type ) {
		$ids = get_posts( [ 'post_type' => $type, 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids' ] );

		foreach ( $ids as $id ) {
			wp_delete_post( $id, true );
		}
	}

	delete_option( 'remaily_settings' );
	delete_option( 'remaily_version' );
	delete_option( 'remaily_captcha_status' );
	delete_option( 'remaily_paypal_merchant' );
	delete_option( 'remaily_review' );
	wp_clear_scheduled_hook( 'remaily_entries_cleanup' );
};

if ( is_multisite() ) {
	// Each site keeps or deletes its own data, as its own setting says
	foreach ( get_sites( [ 'fields' => 'ids', 'number' => 0 ] ) as $remaily_site ) {
		switch_to_blog( $remaily_site );
		$remaily_uninstall();
		restore_current_blog();
	}
} else {
	$remaily_uninstall();
}
