<?php
/**
 * The editor's preview: the theme's styles and scripts, no header or footer
 *
 * Variables: $html (the form), $form.
 * Hooks: remaily_preview_body_class and remaily_preview_classes ( $classes, $form ),
 * remaily_preview_before / remaily_preview_after ( $form ) around the form (a theme's icon sprite, a card around it).
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$remaily_body_class = (array) apply_filters( 'remaily_preview_body_class', [ 'remaily-preview-body' ], $form );
$remaily_classes    = implode( ' ', array_map( 'sanitize_html_class', (array) apply_filters( 'remaily_preview_classes', [ 'remaily-preview' ], $form ) ) );
?><!DOCTYPE html>
<html <?php language_attributes(); ?> style="margin-top:0 !important">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex">
	<?php wp_head(); ?>
</head>
<body <?php body_class( $remaily_body_class ); ?>>
	<main class="<?php echo esc_attr( $remaily_classes ); ?>">
		<?php do_action( 'remaily_preview_before', $form ); ?>
		<?php echo wp_kses( $html, remaily_allowed_html( $html ) ); ?>
		<?php do_action( 'remaily_preview_after', $form ); ?>
	</main>
	<?php wp_footer(); ?>
</body>
</html>
