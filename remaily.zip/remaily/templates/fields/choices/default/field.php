<?php
/**
 * Checkboxes and radio buttons
 *
 * Variables: $field (settings, with name and type), $control (the input, printed by the field), $error (its
 * message, hidden until there is one), $choices (checkbox and radio: each option's value, label, id, input and
 * control), $form.
 * Copy to your-theme/remaily/fields/choices/default/field.php (or fields/radio/default/ for one type) to change it, or to a folder of your own next to default/ for a new style.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo wp_kses( $control . $error, remaily_allowed_html( $control . $error ) );
