<?php
/**
 * A payment: hidden until the first Send asks for it
 *
 * Variables: $field (settings, with name and type), $control (the hidden input the script fills in: keep it),
 * $attributes (the box's attributes, escaped: keep them on the box), $error (the field's message), $form.
 *
 * The script finds the parts inside the box by these attributes, not by class, so lay them out and style them as you
 * like; leave out a part and it is simply not used:
 *
 * - data-remaily-payment-methods: where the provider buttons go when there are several (hidden until then)
 * - template[data-remaily-payment-method]: one provider button, copied for each; its name goes in the element with
 *   data-remaily-payment-label, else in the button itself; aria-pressed="true" marks the one picked
 * - data-remaily-payment-element: where the provider shows its card fields or buttons
 * - data-remaily-payment-error: what went wrong (hidden until then)
 * - data-remaily-payment-pay: the Pay button of a provider that has none of its own, such as Stripe (hidden until
 *   then); the script writes its text from the field's Pay button setting
 * - data-remaily-payment-cancel: back to the form ("Change my details")
 *
 * Copy to your-theme/remaily/fields/payment/default/field.php to change it, or to a folder of your own next to default/ for a new style.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo wp_kses( $control, remaily_allowed_html( $control ) );
?>
<div<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by Field::html_attributes() ?>>
	<div class="remaily-payment__methods" role="group" aria-label="<?php esc_attr_e( 'Pay with', 'remaily' ); ?>" data-remaily-payment-methods hidden></div>
	<template data-remaily-payment-method>
		<button type="button" class="remaily-payment__method" aria-pressed="false"><span data-remaily-payment-label></span></button>
	</template>
	<div class="remaily-payment__element" data-remaily-payment-element></div>
	<p class="remaily-payment__error" role="alert" data-remaily-payment-error hidden></p>
	<div class="remaily-payment__actions">
		<button type="button" class="remaily-control remaily-control--submit remaily-payment__pay" data-remaily-payment-pay hidden></button>
		<button type="button" class="remaily-payment__cancel" data-remaily-payment-cancel><?php esc_html_e( 'Change my details', 'remaily' ); ?></button>
	</div>
</div>
<?php
echo wp_kses( $error, remaily_allowed_html( $error ) );
