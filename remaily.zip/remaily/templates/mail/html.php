<?php
/**
 * An HTML mail around its body
 *
 * Variables: $body (HTML), $subject, $submission.
 * Copy to your-theme/remaily/mail/html.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( $subject ); ?></title>
</head>
<body style="margin:0;padding:24px;background:#f4f5f7;font:15px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1d2127;">
	<div style="max-width:600px;margin:0 auto;padding:28px 32px;background:#ffffff;border-radius:8px;">
		<?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the mail's body, its values escaped ?>
	</div>
</body>
</html>
