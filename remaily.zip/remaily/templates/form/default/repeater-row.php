<?php
/**
 * One row of a repeated group
 *
 * Variables: $attributes (escaped: keep them on the element), $content (the row's fields and markup), $remove (the
 * Remove button, from repeater-button.php), $key (the row's key, __i__ in the template of a new row), $group, $form.
 * Copy to your-theme/remaily/form/default/repeater-row.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by Field::html_attributes() ?>><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's own markup ?><?php echo $remove; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- from repeater-button.php ?></div>
