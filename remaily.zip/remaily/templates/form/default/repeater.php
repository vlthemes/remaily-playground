<?php
/**
 * A repeated group: its rows, the template of a new row and the Add button
 *
 * Variables: $attributes (escaped: keep them on the element), $rows (the rows, each from repeater-row.php), $template
 * (the <template> the script copies for a new row: print it inside this element), $add (the Add button, from
 * repeater-button.php), $group (name), $settings (min, max, add, remove), $form.
 * The script finds the rows as the children of .remaily-repeater__rows: keep that element around $rows.
 * Copy to your-theme/remaily/form/default/repeater.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by Field::html_attributes() ?>>
	<div class="remaily-repeater__rows"><?php echo $rows; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's own markup ?></div>
	<?php echo $template; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's own markup ?>
	<?php echo $add; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- from repeater-button.php ?>
</div>
