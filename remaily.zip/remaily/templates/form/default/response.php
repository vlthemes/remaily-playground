<?php
/**
 * What the response box shows after sending
 *
 * Variables: $status (success, invalid, failed, spam, aborted, locked: logged-in users only, or the form is closed), $message, $form.
 * Copy to your-theme/remaily/form/default/response.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="remaily-alert remaily-alert--<?php echo esc_attr( $status ); ?>">
	<?php $remaily_icon = remaily_icon( 'success' === $status ? 'check' : 'alert', 'remaily-alert__icon' ); ?>
	<?php echo wp_kses( $remaily_icon, remaily_allowed_html( $remaily_icon ) ); ?>
	<span class="remaily-alert__text"><?php echo esc_html( $message ); ?></span>
</div>
