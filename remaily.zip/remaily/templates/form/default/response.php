<?php
/**
 * What the response box shows after sending
 *
 * Variables: $status (success, invalid, failed, spam, aborted, locked: logged-in users only, or the form is closed), $message, $form.
 * Copy to your-theme/remaily/form/default/response.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="remaily-alert remaily-alert--<?php echo esc_attr( $status ); ?>">
	<?php echo remaily_icon( 'success' === $status ? 'check' : 'alert', 'remaily-alert__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?>
	<span class="remaily-alert__text"><?php echo esc_html( $message ); ?></span>
</div>
