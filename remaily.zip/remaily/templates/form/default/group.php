<?php
/**
 * A group: a wrapped part of the form, shown or hidden by its conditions
 *
 * Variables: $attributes (escaped: keep them on the element, the script shows and hides it by them), $content (what
 * the group wraps), $group (name), $inner (true inside a repeated group's row: it always shows), $form.
 * Copy to your-theme/remaily/form/default/group.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by Field::html_attributes() ?>><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's own markup, printed by the plugin ?></div>
