<?php
/**
 * A repeated group's Add or Remove button
 *
 * Variables: $action (add, remove), $label (the group's button text), $attributes (the button's attributes, escaped:
 * keep them on whatever element you print, the script finds the button by them), $group (group name), $form.
 * Copy to your-theme/remaily/form/default/repeater-button.php to change it.
 *
 * @package VLT\Remaily
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<button<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by Field::html_attributes() ?>><?php echo esc_html( $label ); ?></button>
